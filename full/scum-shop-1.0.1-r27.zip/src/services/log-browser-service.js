import fs from 'node:fs/promises';
import path from 'node:path';
import { formatRconAccessMessage } from './rcon-command-description.js';

const SOURCE_LABELS = { shop: '商城后台', scum: 'SCUM 游戏', ue4ss: 'UE4SS / RCON' };
const GAME_CATEGORIES = [
  ['admin_command', '管理命令', '⌨️', ['admin']], ['field_kill', '野外击杀', '🎯', ['kill']], ['event_kill', '活动击杀', '🏁', ['event_kill']], ['chat', '聊天', '💬', ['chat']], ['presence', '上下线', '👣', ['login']], ['teammate_claim', '队友认领', '🤝', ['chest_ownership']],
  ['purchase', '购买', '🛒', ['economy']], ['sale', '出售', '🏷️', ['economy']], ['balance', '余额', '💳', ['economy']], ['bank_transfer', '存取转账', '🔄', ['economy']], ['gold', '金条', '🟡', ['economy']], ['bank_card', '银行卡', '💳', ['economy']],
  ['vehicle', '载具', '🚗', ['vehicle_destruction']], ['chest', '箱子', '📦', ['chest_ownership']], ['lockpick', '开锁', '🔓', ['gameplay']], ['wire_cut', '剪线', '✂️', ['gameplay']], ['trap', '陷阱', '⚠️', ['gameplay']], ['fame', '声望', '⭐', ['famepoints']],
  ['gameplay', '玩法', '🎮', ['gameplay', 'armor_absorption', 'server_notifications']], ['territory_risk', '领地风险', '🧭', ['raid_protection']], ['quest', '系统任务', '📋', ['quests']], ['sentry', '岗哨', '🤖', ['sentry']],
  ['bunker_unlock', '地堡解锁', '🔐', ['gameplay']], ['bunker_status', '地堡状态', '🏠', ['gameplay']], ['base_destruction', '基地破坏', '🏗️', ['base_building_destruction']], ['rcon_stats', 'RCON统计', '🤖', ['bot_killevents']], ['kick', '踢出', '⛔', ['admin', 'violations', 'server_notifications']],
  ['distance', '超距', '📏', ['violations']], ['ammo', '弹药', '🧪', ['violations']], ['ballistics', '弹道', '🎯', ['violations']], ['other_violation', '其他违规', '🚨', ['violations']], ['loot_diagnostic', 'Loot诊断', '📦', ['loot']], ['raid_diagnostic', '突袭诊断', '⏱️', ['raid_protection']]
].map(([id, label, icon, physical]) => ({ id, label, icon, physical }));
const CATEGORY_LABELS = { all: '全部日志', application: '后台运行', warning: '后台警告', error: '后台错误', mysql: 'MySQL', ue4ss: 'RCON运行' };
const SHOP_MODULES = {
  mysql: { label: 'MySQL', description: '数据库读写日志' },
  rcon: { label: 'RCON', description: '访问游戏服务器的日志' },
  application: { label: '商城服务', description: '客户访问商城及商城服务运行日志' }
};
const SHOP_CATEGORIES = [
  { id: 'all', label: '全部日志', icon: '📚' },
  { id: 'application', label: '后台运行', icon: '▶️' },
  { id: 'warning', label: '后台警告', icon: '⚠️' },
  { id: 'error', label: '后台错误', icon: '❌' }
];
const MAX_TAIL_BYTES = 256 * 1024;

function physicalCategory(source, filename) {
  if (source === 'shop') {
    if (/mysql/i.test(filename)) return 'mysql';
    if (/error/i.test(filename)) return 'error';
    return 'application';
  }
  if (source === 'ue4ss') return 'ue4ss';
  return filename.replace(/\.log$/i, '').replace(/_\d{8,14}$/i, '').replace(/^SCUMServerBot_/i, 'bot_').toLowerCase();
}

function classifyGameLog(physical, line) {
  const value = line.replace(/^\d{4}\.\d{2}\.\d{2}-\d{2}\.\d{2}\.\d{2}:\s*/, '');
  if (/^Game version:/i.test(value) || /^-{10,}$/.test(value.trim())) return '';
  if (physical === 'admin') {
    if (/\b(kicked|kick(?:ed)? player|removed from server|disconnected by admin|auto-?kick|#kick)\b/i.test(value)) return 'kick';
    return 'admin_command';
  }
  if (physical === 'kill') return 'field_kill';
  if (physical === 'event_kill') return 'event_kill';
  if (physical === 'chat') return 'chat';
  if (physical === 'login') return 'presence';
  if (physical === 'chest_ownership') return /ownership changed/i.test(value) ? 'teammate_claim' : 'chest';
  if (physical === 'economy') {
    if (/^\[Bank\].*\b(purchased|renewed|destroyed|lost|blocked|unblocked|activated|deactivated)\b.*\bcard\b/i.test(value)) return 'bank_card';
    if (/^\[Currency Conversion\].*\b(purchased|bought|converted)\b.*\b(gold|gold bars?)\b/i.test(value)) return 'gold';
    if (/^\[Bank\].*\b(deposited|withdr(?:aw|ew|awn)|transferred|transfer(?:red)?|sent|received)\b/i.test(value)) return 'bank_transfer';
    if (/^\[Trade-Mechanic\].*\bpurchased by\b/i.test(value) || /^\[Trade\].*\b(purchased|bought)\s+by\b/i.test(value)) return 'purchase';
    if (/^\[Trade\].*\bsold by\b/i.test(value)) return 'sale';
    if (/\bBefore\s+(buying|selling)|\bAfter\s+(buying|selling)/i.test(value)) return 'balance';
    return 'balance';
  }
  if (physical === 'vehicle_destruction') return 'vehicle';
  if (physical === 'gameplay') {
    if (/^\[LogBunkerLock\].*\bBunker (?:Activated|Deactivated)\b/i.test(value)) return 'bunker_unlock';
    if (/^\[LogBunkerLock\].*(Bunker activations:|Locked bunkers:|Bunker is (Active|Locked))/i.test(value)) return 'bunker_status';
    if (/\[LogLockpick(?:ing)?\]|\[LockpickingMinigame_C\]|\blockpick(?:ing|ed)?\b|\bpicked\s+(a\s+)?lock\b/i.test(value)) return 'lockpick';
    if (/\b(cut(?:ting)?\s+(the\s+)?wire|wire\s+(cut|cutting|cutter)|barbed\s+wire.*cut)\b/i.test(value)) return 'wire_cut';
    if (/\b(trap|mine|claymore)\b.*\b(placed|armed|triggered|activated|disarmed|defused|destroyed|detonated|crafted)\b|\b(placed|armed|triggered|activated|disarmed|defused|destroyed|detonated|crafted)\b.*\b(trap|mine|claymore)\b/i.test(value)) return 'trap';
    return 'gameplay';
  }
  if (physical === 'armor_absorption' || physical === 'server_notifications') {
    if (/\b(kicked|auto-?kick|removed from server)\b/i.test(value)) return 'kick';
    return 'gameplay';
  }
  if (physical === 'famepoints') {
    return 'fame_removed';
  }
  if (physical === 'raid_protection') return /\b(flag|territory|base|squad)\b.*\b(unprotected|vulnerable|vulnerability|risk|warning|expires|ended)\b|\bRaidProtection\b.*\b(activated|deactivated|started|ended|expired)\b/i.test(value) ? 'territory_risk' : 'raid_diagnostic';
  if (physical === 'quests') return 'quest';
  if (physical === 'sentry') return 'sentry';
  if (physical === 'base_building_destruction') return 'base_destruction';
  if (physical === 'bot_killevents') return 'rcon_stats';
  if (physical === 'violations') {
    if (/\b(kicked|auto-?kick|removed from server)\b/i.test(value)) return 'kick';
    if (/^\[OutOfInteractionRange\]|InteractionRange|OutOfRange|TooFar/i.test(value)) return 'distance';
    if (/^\[(Ammo|AmmoCountMismatch|InvalidAmmo|MagazineAmmoMismatch|InfiniteAmmo)\]|\b(ammo|ammunition|magazine)\b.*\b(mismatch|invalid|illegal|infinite|violation)\b/i.test(value)) return 'ammo';
    if (/^\[(Projectile|Ballistics|InvalidProjectile|ProjectileMismatch|Trajectory|HitValidation|ImpossibleHit)\]|\b(projectile|trajectory|ballistic|hit location|shot)\b.*\b(mismatch|invalid|impossible|violation|validation failed)\b/i.test(value)) return 'ballistics';
    return 'other_violation';
  }
  if (physical === 'loot') return 'loot_diagnostic';
  return 'gameplay';
}

function adminAuditOf(line) {
  const timestamp = timestampOf(line, null);
  const message = line.replace(/^\d{4}\.\d{2}\.\d{2}-\d{2}\.\d{2}\.\d{2}:\s*/, '').trim();
  let match = message.match(/^'(\d{15,20}):(.*)\((\d+)\)' Command: '([\s\S]*)'$/);
  if (match) {
    const command = match[4];
    return { timestamp, playerName: match[2], playerNumber: match[3], steamId: match[1], type: /^\s*(kick|kickplayer)\b/i.test(command) ? 'admin_kick_command' : 'admin_command', typeLabel: /^\s*(kick|kickplayer)\b/i.test(command) ? '踢出命令' : '管理命令', content: command, raw: message };
  }
  match = message.match(/^Deleting players that haven't logged in for (\d+) day\(s\)\.\.\.$/);
  if (match) return { timestamp, playerName: '系统', playerNumber: '0', steamId: '', type: 'inactive_cleanup_start', typeLabel: '未活跃清理开始', content: `开始清理 ${match[1]} 天未登录玩家`, inactiveThresholdDays: Number(match[1]), raw: message };
  match = message.match(/^Deleted player profile '(\d+) \(([\s\S]*)\)' that last logged in (\d+) days ago$/);
  if (match) return { timestamp, playerName: match[2], playerNumber: match[1], profileId: match[1], steamId: '', type: 'inactive_profile_deleted', typeLabel: '未活跃玩家档案清理', content: `删除长期未登录玩家档案 ProfileID=${match[1]} Name=${match[2]} LastLoginDays=${match[3]}`, inactiveDays: Number(match[3]), raw: message };
  match = message.match(/^Deleted player '(\d{15,20}) \(([\s\S]*)\)' that last logged in (\d+) days ago$/);
  if (match) return { timestamp, playerName: match[2], playerNumber: '0', steamId: match[1], type: 'inactive_player_deleted', typeLabel: '未活跃玩家清理', content: `删除长期未登录玩家 SteamID=${match[1]} Name=${match[2]} LastLoginDays=${match[3]}`, inactiveDays: Number(match[3]), raw: message };
  match = message.match(/^Completed in (\d+(?:\.\d+)?)s for (\d+) player profiles? and (\d+) players?\.$/);
  if (match) return { timestamp, playerName: '系统', playerNumber: '0', steamId: '', type: 'inactive_cleanup_completed', typeLabel: '未活跃清理完成', content: `长期未登录清理完成：耗时 ${match[1]}s，档案 ${match[2]}，玩家 ${match[3]}`, durationSeconds: Number(match[1]), profileCount: Number(match[2]), playerCount: Number(match[3]), raw: message };
  match = message.match(/^Custom Zones updated by \{([\s\S]*) \((\d+), (\d{15,20})\)\}$/);
  if (match) return { timestamp, playerName: match[1], playerNumber: match[2], steamId: match[3], type: 'custom_zones_updated', typeLabel: '区域配置更新', content: '更新游戏自定义区域配置', raw: message };
  return { timestamp, playerName: '系统', playerNumber: '0', steamId: '', type: 'admin_event', typeLabel: '管理事件', content: message, raw: message };
}

function messageOf(line) {
  return line.replace(/^\d{4}\.\d{2}\.\d{2}-\d{2}\.\d{2}\.\d{2}:\s*/, '').trim();
}

function locationOf(x, y, z) {
  const values = [x, y, z].map(Number);
  return values.every(Number.isFinite) ? { x: values[0], y: values[1], z: values[2] } : null;
}

function prefixedJsonOf(line) {
  const value = messageOf(line);
  if (!value.startsWith('{')) return null;
  try { return JSON.parse(value); } catch { return null; }
}

function killAuditOf(line, parsed = prefixedJsonOf(line), allowUnknown = false) {
  const timestamp = timestampOf(line, parsed);
  const message = messageOf(line);
  if (parsed?.Killer && parsed?.Victim) {
    const killerLocation = locationOf(parsed.Killer.ServerLocation?.X, parsed.Killer.ServerLocation?.Y, parsed.Killer.ServerLocation?.Z);
    const victimLocation = locationOf(parsed.Victim.ServerLocation?.X, parsed.Victim.ServerLocation?.Y, parsed.Victim.ServerLocation?.Z);
    const distance = killerLocation && victimLocation ? Math.sqrt((killerLocation.x - victimLocation.x) ** 2 + (killerLocation.y - victimLocation.y) ** 2 + (killerLocation.z - victimLocation.z) ** 2) / 100 : null;
    return { timestamp, killerName: parsed.Killer.ProfileName || null, killerSteamId: parsed.Killer.UserId || null, victimName: parsed.Victim.ProfileName || null, victimSteamId: parsed.Victim.UserId || null, weapon: parsed.Weapon || null, distance, killerLocation, victimLocation, eventType: 'kill', raw: line };
  }
  let match = message.match(/^Died:\s*(.*?)\s*\((\d{15,20}|NPC)\),\s*Killer:\s*(.*?)\s*\((\d{15,20}|NPC)\)\s*Weapon:\s*(.*?)\s*S:\[KillerLoc\s*:\s*([^,]+),\s*([^,]+),\s*([^\s]+)\s+VictimLoc:\s*([^,]+),\s*([^,]+),\s*([^,]+),\s*Distance:\s*([\d.]+)\s*m\]$/i);
  if (match) return { timestamp, killerName: match[3], killerSteamId: match[4], victimName: match[1], victimSteamId: match[2], weapon: match[5], distance: Number(match[12]), killerLocation: locationOf(match[6], match[7], match[8]), victimLocation: locationOf(match[9], match[10], match[11]), eventType: 'kill', raw: line };
  match = message.match(/^Comm?itted suicide\.\s*User:\s*(.*?)\s*\((\d+),\s*(\d{15,20})\),\s*\[(.*?)\]\.\s*Location:\s*X=([^\s]+)\s+Y=([^\s]+)\s+Z=([^\.]+(?:\.\d+)?)\.?$/i);
  if (match) return { timestamp, killerName: match[1], killerSteamId: match[3], victimName: match[1], victimSteamId: match[3], weapon: '自杀', distance: 0, killerLocation: locationOf(match[5], match[6], match[7]), victimLocation: locationOf(match[5], match[6], match[7]), eventType: 'suicide', raw: line };
  return allowUnknown ? { timestamp, killerName: null, killerSteamId: null, victimName: null, victimSteamId: null, weapon: null, distance: null, killerLocation: null, victimLocation: null, eventType: 'unknown', raw: line } : null;
}

function chatAuditOf(line) {
  const match = messageOf(line).match(/^'(\d{15,20}):(.*)\((\d+)\)'\s+'([^:']+):\s*([\s\S]*)'$/);
  return match ? { timestamp: timestampOf(line, null), channel: match[4], playerName: match[2], steamId: match[1], playerNumber: match[3], content: match[5], raw: line } : null;
}

function presenceAuditOf(line) {
  const match = messageOf(line).match(/^'(\S+)\s+(\d{15,20}):(.*)\((\d+)\)'\s+logged\s+(in|out)\s+at:\s*(.*)$/i);
  if (!match) return null;
  const coordinates = match[6].match(/^X=([^\s]+)\s+Y=([^\s]+)\s+Z=([^\s]+)$/i);
  return { timestamp: timestampOf(line, null), eventType: match[5].toLowerCase() === 'in' ? 'login' : 'logout', playerName: match[3], steamId: match[2], ip: match[1], location: match[6].trim() === '?' ? null : coordinates ? locationOf(coordinates[1], coordinates[2], coordinates[3]) : null, playerNumber: match[4], raw: line };
}

function teammateClaimAuditOf(line) {
  const match = messageOf(line).match(/^Chest \(entity id:\s*(\d+)\) ownership changed\. Old owner:\s*(\d{15,20})\s*\((\d+),\s*(.*?)\)\s*->\s*New owner:\s*(\d{15,20})\s*\((\d+),\s*(.*?)\)\.\s*Location:\s*X=([^\s]+)\s+Y=([^\s]+)\s+Z=([^\s]+)$/i);
  return match ? { timestamp: timestampOf(line, null), recordId: match[1], eventType: 'ownership_changed', oldOwner: { steamId: match[2], playerNumber: match[3], playerName: match[4] }, newOwner: { steamId: match[5], playerNumber: match[6], playerName: match[7] }, oldOwnerSteamId: match[2], newOwnerSteamId: match[5], location: locationOf(match[8], match[9], match[10]), raw: line } : null;
}

function numeric(value) {
  if (value === undefined || value === null || value === '') return null;
  const number = Number(String(value).replace(/,/g, ''));
  return Number.isFinite(number) ? number : null;
}

function itemParts(blob) {
  const quantity = numeric(blob.match(/\(x\s*(-?[\d,.]+)\)\s*$/i)?.[1]);
  const itemName = blob.replace(/\s*\((?:x\s*-?[\d,.]+|health:[\s\S]*)\)\s*$/i, '').trim();
  return { itemName: itemName || null, quantity };
}

function purchaseAuditOf(line) {
  const message = messageOf(line);
  const match = message.match(/^\[(Trade|Trade-Mechanic)\]\s+(Tradeable|Service)\s+\(([\s\S]+)\)\s+purchased by\s+([\s\S]+?)\((\d{15,20})\)\s+for\s+(-?[\d,.]+)\s+money\s+from trader\s+([^,]+)(?:,\s*old amount in store (?:was|is)\s*(-?[\d,.]+),\s*new amount is\s*(-?[\d,.]+))?,\s*and effective users online:\s*(\d+)\.?$/i);
  if (!match) return null;
  const parts = itemParts(match[3]);
  return { timestamp: timestampOf(line, null), itemName: parts.itemName, itemBlob: match[3], quantity: parts.quantity, price: numeric(match[6]), playerName: match[4].trim(), steamId: match[5], type: match[2].toLowerCase() === 'service' ? '服务' : '商品', trader: match[7].trim(), oldStock: numeric(match[8]), newStock: numeric(match[9]), online: numeric(match[10]), raw: line };
}

function saleAuditOf(line) {
  const message = messageOf(line);
  const match = message.match(/^\[Trade\]\s+Tradeable\s+\(([\s\S]+)\)\s+sold by\s+([\s\S]+?)\((\d{15,20})\)\s+for\s+(-?[\d,.]+)\s+\((-?[\d,.]+)\s*\+\s*(-?[\d,.]+)\s+worth of contained items\)\s+to trader\s+([^,]+),\s*old amount in store (?:was|is)\s*(-?[\d,.]+),\s*new amount is\s*(-?[\d,.]+),\s*and effective users online:\s*(\d+)\.?$/i);
  if (!match) return null;
  const parts = itemParts(match[1]);
  const quantityOrDurability = parts.quantity ?? numeric(match[1].match(/\bstack count:\s*(-?[\d.]+)/i)?.[1]) ?? numeric(match[1].match(/\buses:\s*(-?[\d.]+)/i)?.[1]) ?? numeric(match[1].match(/\bhealth:\s*(-?[\d.]+)/i)?.[1]);
  return { timestamp: timestampOf(line, null), itemName: parts.itemName, itemBlob: match[1], quantityOrDurability, totalPrice: numeric(match[4]), basePrice: numeric(match[5]), containedValue: numeric(match[6]), playerName: match[2].trim(), steamId: match[3], trader: match[7].trim(), oldStock: numeric(match[8]), newStock: numeric(match[9]), online: numeric(match[10]), raw: line };
}

function balanceAuditOf(line) {
  const message = messageOf(line);
  const match = message.match(/^\[Trade(?:-Mechanic)?\]\s+(Before|After)\s+(?:purchasing tradeales|tradeable purchase|selling tradeables|tradeable sale)\s+(?:from|to) trader\s+([^,]+),\s*player\s+([\s\S]+?)\((\d{15,20})\)\s+(?:had|has)\s+(-?[\d,.]+)\s+cash,\s*(-?[\d,.]+)\s+(?:bank\s+)?account balance\s+and\s+(-?[\d,.]+)\s+gold\s+and trader\s+(?:had|has)\s+(-?[\d,.]+)\s+funds\.?$/i);
  if (!match) return null;
  return { timestamp: timestampOf(line, null), phase: match[1], action: /purchas/i.test(message) ? 'purchase' : 'sale', playerName: match[3].trim(), steamId: match[4], cash: numeric(match[5]), accountBalance: numeric(match[6]), gold: numeric(match[7]), trader: match[2].trim(), traderFunds: numeric(match[8]), raw: line };
}

function bankTransferAuditOf(line) {
  const message = messageOf(line);
  const identity = '^\\[Bank\\]\\s+([\\s\\S]+?)\\(ID:(\\d{15,20})\\)\\(Account Number:(\\d+)\\)\\s+';
  let match = message.match(new RegExp(`${identity}deposited\\s+(-?[\\d,.]+)\\((-?[\\d,.]+) was added\\)\\s+to Account Number:\\s*(\\d+)\\(([^)]*)\\)\\(([^)]*)\\)\\s+at X=([^\\s]+)\\s+Y=([^\\s]+)\\s+Z=([^\\s.]+(?:\\.\\d+)?)\\.?$`, 'i'));
  if (match) return { timestamp: timestampOf(line, null), eventType: 'deposit', actorName: match[1].trim(), actorSteamId: match[2], actorAccount: match[3], amount: numeric(match[4]), netAmount: numeric(match[5]), removedAmount: null, sourceAccount: match[3], targetName: match[7] === 'unknown' ? null : match[7], targetSteamId: match[8] === 'unknown' ? null : match[8], targetAccount: match[6], location: locationOf(match[9], match[10], match[11]), fee: numeric(match[4]) - numeric(match[5]), raw: line };
  match = message.match(new RegExp(`${identity}withdrew\\s+(-?[\\d,.]+)\\((-?[\\d,.]+) was removed\\)\\s+from Account Number:\\s*(\\d+)\\(([^)]*)\\)\\(([^)]*)\\)\\s+at X=([^\\s]+)\\s+Y=([^\\s]+)\\s+Z=([^\\s.]+(?:\\.\\d+)?)\\.?$`, 'i'));
  if (match) return { timestamp: timestampOf(line, null), eventType: 'withdraw', actorName: match[1].trim(), actorSteamId: match[2], actorAccount: match[3], amount: numeric(match[4]), netAmount: null, removedAmount: numeric(match[5]), sourceAccount: match[6], targetName: match[7] === 'unknown' ? null : match[7], targetSteamId: match[8] === 'unknown' ? null : match[8], targetAccount: null, location: locationOf(match[9], match[10], match[11]), fee: numeric(match[5]) - numeric(match[4]), raw: line };
  match = message.match(new RegExp(`${identity}transferred\\s+(-?[\\d,.]+)\\((-?[\\d,.]+) was removed\\)\\s+from Account Number:\\s*(\\d+)\\(([^)]*)\\)\\(([^)]*)\\)\\s+to Account Number:\\s*(\\d+)\\(([^)]*)\\)\\(([^)]*)\\)\\s+at X=([^\\s]+)\\s+Y=([^\\s]+)\\s+Z=([^\\s.]+(?:\\.\\d+)?)\\.?$`, 'i'));
  if (match) return { timestamp: timestampOf(line, null), eventType: 'transfer', actorName: match[1].trim(), actorSteamId: match[2], actorAccount: match[3], amount: numeric(match[4]), netAmount: null, removedAmount: numeric(match[5]), sourceAccount: match[6], targetName: match[10] === 'unknown' ? null : match[10], targetSteamId: match[11] === 'unknown' ? null : match[11], targetAccount: match[9], location: locationOf(match[12], match[13], match[14]), fee: numeric(match[5]) - numeric(match[4]), raw: line };
  return null;
}

function goldAuditOf(line) {
  const match = messageOf(line).match(/^\[Currency Conversion\]\s+([\s\S]+?)\(ID:(\d{15,20})\)\(Account Number:(\d+)\)\s+purchased\s+(-?[\d,.]+)\s+gold\s+for\s+(-?[\d,.]+)\s+credits\s+\(new account balance is\s+(-?[\d,.]+)\s+gold\/(-?[\d,.]+)\s+credits\)\s+at X=([^\s]+)\s+Y=([^\s]+)\s+Z=([^\s.]+(?:\.\d+)?)\.?$/i);
  if (!match) return null;
  const goldBought = numeric(match[4]);
  const creditsPaid = numeric(match[5]);
  return { timestamp: timestampOf(line, null), playerName: match[1].trim(), steamId: match[2], account: match[3], goldBought, creditsPaid, newGold: numeric(match[6]), newCredits: numeric(match[7]), location: locationOf(match[8], match[9], match[10]), unitPrice: goldBought ? creditsPaid / goldBought : null, raw: line };
}

function bankCardAuditOf(line) {
  const message = messageOf(line);
  let match = message.match(/^\[Bank\]\s+([\s\S]+?)\(ID:(\d{15,20})\)\(Account Number:(\d+)\)\s+purchased\s+(.+?)\s+card\s+\(free renewal:\s*([^)]+)\),\s*new account balance is\s+(-?[\d,.]+)\s+credits,\s*at X=([^\s]+)\s+Y=([^\s]+)\s+Z=([^\s.]+(?:\.\d+)?)\.?$/i);
  if (match) return { timestamp: timestampOf(line, null), eventType: 'purchase', typeLabel: '购买', playerName: match[1].trim(), steamId: match[2], actorAccount: match[3], targetAccount: match[3], cardType: match[4].trim(), freeRenewal: match[5].trim(), newBalance: numeric(match[6]), location: locationOf(match[7], match[8], match[9]), raw: line };
  match = message.match(/^\[Bank\]\s+([\s\S]+?)\(ID:(\d{15,20})\)\(Account Number:(\d+)\)\s+manually destroyed\s+(.+?)\s+card belonging to Account Number:\s*(\d+),\s*at X=([^\s]+)\s+Y=([^\s]+)\s+Z=([^\s.]+(?:\.\d+)?)\.?$/i);
  return match ? { timestamp: timestampOf(line, null), eventType: 'destroy', typeLabel: '销毁', playerName: match[1].trim(), steamId: match[2], actorAccount: match[3], targetAccount: match[5], cardType: match[4].trim(), freeRenewal: null, newBalance: null, location: locationOf(match[6], match[7], match[8]), raw: line } : null;
}

function vehicleAuditOf(line) {
  const message = messageOf(line);
  const match = message.match(/^\[([^\]]+)\]\s+(.+?)\.\s*VehicleId:\s*([^\.]+)\.\s*Owner:\s*(N\/A|0|(?:(\d{15,20})\s*\((\d+),\s*(.*?)\)))\.\s*Location:\s*X=([^\s]+)\s+Y=([^\s]+)\s+Z=([^\s]+)\.?$/i);
  if (!match) return { timestamp: timestampOf(line, null), status: 'unknown', statusLabel: '未知状态', vehicleType: null, vehicleId: null, ownerName: null, ownerSteamId: null, ownerNumber: null, location: null, raw: line };
  const normalized = match[1].toLowerCase();
  const status = ({ destroyed: 'destroyed', disappeared: 'disappeared', inactivetimerreached: 'inactive_timer_reached', vehicleinactivetimerreached: 'inactive_timer_reached', sold: 'sold' })[normalized] || 'unknown';
  const statusLabel = ({ destroyed: '已损毁', disappeared: '已消失', inactive_timer_reached: '闲置计时到期', sold: '已出售', unknown: match[1] })[status];
  return { timestamp: timestampOf(line, null), status, statusLabel, vehicleType: match[2].trim(), vehicleId: match[3].trim(), ownerName: match[7]?.trim() || null, ownerSteamId: match[5] || null, ownerNumber: match[6] || null, location: locationOf(match[8], match[9], match[10]), raw: line };
}

function chestAuditOf(line) {
  const message = messageOf(line);
  let match = message.match(/^Chest \(entity id:\s*(\d+)\) ownership claimed\. Owner:\s*(\d{15,20})\s*\((\d+),\s*(.*?)\)\.\s*Location:\s*X=([^\s]+)\s+Y=([^\s]+)\s+Z=([^\s]+)$/i);
  if (match) {
    const owner = { steamId: match[2], playerNumber: match[3], playerName: match[4] };
    return { timestamp: timestampOf(line, null), eventType: 'claimed', eventLabel: '认领', chestId: match[1], chestType: '未知箱子', oldOwner: owner, newOwner: null, currentOwner: owner, location: locationOf(match[5], match[6], match[7]), raw: line };
  }
  const changed = teammateClaimAuditOf(line);
  if (!changed) return null;
  return { timestamp: changed.timestamp, eventType: 'changed', eventLabel: '所有权变更', chestId: changed.recordId, chestType: '未知箱子', oldOwner: changed.oldOwner, newOwner: changed.newOwner, currentOwner: changed.newOwner, location: changed.location, raw: line };
}

function behaviorAuditOf(line) {
  const message = messageOf(line);
  const match = message.match(/^\[LogMinigame\]\s+\[([^\]]+)\]\s+User:\s*(.*?)\s*\((\d+),\s*(\d{15,20})\)\.\s*Success:\s*(Yes|No)\.\s*Elapsed time:\s*([\d.]+)\.\s*Failed attempts:\s*(\d+)\.\s*Target object:\s*(.*?)\.\s*(?:Lock type|Difficulty):\s*(.*?)\.\s*(?:User owner|Target owner):\s*(.*?)\.\s*Location:\s*X=([^\s]+)\s+Y=([^\s]+)\s+Z=([^\s]+)$/i);
  if (!match) return { timestamp: timestampOf(line, null), result: null, playerName: null, steamId: null, duration: null, failedCount: null, target: null, difficulty: null, targetOwner: null, location: null, raw: line };
  return { timestamp: timestampOf(line, null), result: match[5].toLowerCase() === 'yes' ? 'success' : 'failed', playerName: match[2].trim(), steamId: match[4], duration: numeric(match[6]), failedCount: numeric(match[7]), target: match[8].trim(), difficulty: match[9].trim(), targetOwner: /^N\/A$/i.test(match[10].trim()) ? null : match[10].trim(), location: locationOf(match[11], match[12], match[13]), raw: line };
}

function gameplayAuditOf(line) {
  const timestamp = timestampOf(line, null);
  const message = messageOf(line);
  let match = message.match(/^\[LogMinigame\]\s+\[(BP_QuestBookMinigame_C|BP_NoticeBoardMinigame_C|BP_MobilePhoneMinigame_C)\]\s+User:\s*(.*?)\s*\((\d+),\s*(\d{15,20})\)\.\s*Success:\s*(Yes|No)\.\s*Elapsed time:\s*([\d.]+)\.\s*Failed attempts:\s*(\d+)\.?$/i);
  if (match) {
    const typeLabels = { BP_QuestBookMinigame_C: '任务书小游戏', BP_NoticeBoardMinigame_C: '公告板小游戏', BP_MobilePhoneMinigame_C: '手机小游戏' };
    const type = Object.keys(typeLabels).find((value) => value.toLowerCase() === match[1].toLowerCase()) || match[1];
    return { timestamp, categoryKey: 'minigame', categoryLabel: '小游戏', type, typeLabel: typeLabels[type], playerName: match[2].trim(), steamId: match[4], playerNumber: match[3], objectType: type, objectId: null, resultValue: match[5].toLowerCase() === 'yes' ? '成功' : '失败', elapsedTime: numeric(match[6]), failedAttempts: numeric(match[7]), location: null, raw: line };
  }
  match = message.match(/^\[LogBaseBuilding\]\s+\[Flag\]\s+Created\.\s*FlagId:\s*([^\.]+)\.\s*Owner:\s*(\d{15,20})\s*\((\d+),\s*(.*?)\)\.\s*Location:\s*X=([^\s]+)\s+Y=([^\s]+)\s+Z=([^\s]+)\.?$/i);
  if (match) return { timestamp, categoryKey: 'territory', categoryLabel: '领地事件', type: 'flag_created', typeLabel: '旗帜创建', playerName: match[4].trim(), steamId: match[2], playerNumber: match[3], objectType: 'Flag', objectId: match[1].trim(), resultValue: '已创建', elapsedTime: null, failedAttempts: null, location: locationOf(match[5], match[6], match[7]), raw: line };
  const identity = message.match(/(?:User|Player|Owner|Actor):\s*'?([^'\r\n]*?)\s*\((\d+),\s*(\d{15,20})\)/i);
  const location = message.match(/(?:Location|Coordinates?|Position):?\s*(?:X=)?(-?\d+(?:\.\d+)?)\s*[, ]+\s*(?:Y=)?(-?\d+(?:\.\d+)?)\s*[, ]+\s*(?:Z=)?(-?\d+(?:\.\d+)?)/i);
  const bracketTypes = [...message.matchAll(/\[([^\]]+)\]/g)].map((item) => item[1]);
  const objectId = message.match(/(?:Object|Flag|Vehicle|Entity|Target)Id:\s*([^\s.]+)/i)?.[1] || null;
  const result = message.match(/(?:Result|Success|Value|Amount):\s*([^\.]+)/i)?.[1]?.trim() || null;
  return { timestamp, categoryKey: 'unknown', categoryLabel: '其他玩法', type: bracketTypes[1] || bracketTypes[0] || 'unknown', typeLabel: bracketTypes[1] || bracketTypes[0] || '未知玩法', playerName: identity?.[1]?.trim() || null, steamId: identity?.[3] || null, playerNumber: identity?.[2] || null, objectType: bracketTypes[1] || null, objectId, resultValue: result, elapsedTime: numeric(message.match(/Elapsed time:\s*([\d.]+)/i)?.[1]), failedAttempts: numeric(message.match(/Failed attempts:\s*(\d+)/i)?.[1]), location: location ? locationOf(location[1], location[2], location[3]) : null, raw: line };
}

function bunkerUnlockAuditOf(line) {
  const message = messageOf(line);
  const match = message.match(/^\[LogBunkerLock\]\s+([^\s]+)\s+Bunker\s+(Activated|Deactivated)\.?$/i);
  return match ? { timestamp: timestampOf(line, null), type: match[2].toLowerCase() === 'activated' ? 'bunker_activated' : 'bunker_deactivated', typeLabel: match[2].toLowerCase() === 'activated' ? '地堡激活' : '地堡停用', bunkerId: match[1], resultValue: match[2].toLowerCase() === 'activated' ? '已激活' : '已停用', raw: line } : { timestamp: timestampOf(line, null), type: 'bunker_event', typeLabel: '地堡事件', bunkerId: null, resultValue: null, raw: line };
}

function bunkerStatusAuditOf(line) {
  const message = messageOf(line);
  let match = message.match(/^\[LogBunkerLock\]\s+Bunker activations:\s*(\d+)/i);
  if (match) return { timestamp: timestampOf(line, null), bunkerId: null, status: 'summary', statusLabel: '激活统计', resultValue: match[1], location: null, raw: line };
  match = message.match(/^\[LogBunkerLock\]\s+Locked bunkers:\s*(\d+)/i);
  if (match) return { timestamp: timestampOf(line, null), bunkerId: null, status: 'summary', statusLabel: '锁定统计', resultValue: match[1], location: null, raw: line };
  match = message.match(/^\[LogBunkerLock\]\s+([^\s]+)\s+Bunker is\s+(Active|Locked)/i);
  if (match) return { timestamp: timestampOf(line, null), bunkerId: match[1], status: match[2].toLowerCase() === 'active' ? 'active' : 'locked', statusLabel: match[2].toLowerCase() === 'active' ? '活跃中' : '已锁定', resultValue: match[2].toLowerCase() === 'active' ? '活跃中' : '已锁定', location: null, raw: line };
  return { timestamp: timestampOf(line, null), bunkerId: null, status: 'unknown', statusLabel: '未知状态', resultValue: null, location: null, raw: line };
}

function formatTimestamp(value) {
  if (value === undefined || value === null || value === '') return '';
  const text = String(value).trim();
  let match = text.match(/^(\d{4})\.(\d{2})\.(\d{2})-(\d{2})\.(\d{2})\.(\d{2})/);
  if (match) return `${match[1]}-${match[2]}-${match[3]} ${match[4]}:${match[5]}:${match[6]}`;
  match = text.match(/^(\d{4}-\d{2}-\d{2})[T ](\d{2}):(\d{2}):(\d{2})/);
  if (match) return `${match[1]} ${match[2]}:${match[3]}:${match[4]}`;
  const numeric = Number(text);
  if (Number.isFinite(numeric) && numeric > 1e9) {
    const date = new Date(numeric * (text.length > 12 ? 1 : 1000));
    if (!Number.isNaN(date.getTime())) {
      return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}:${String(date.getSeconds()).padStart(2, '0')}`;
    }
  }
  return text;
}

function baseDestructionAuditOf(line) {
  const message = messageOf(line);
  const match = message.match(/^\[LogBaseBuildingDestruction\]\s+Building:\s*(.*?)\s*\(ID:\s*([^\)]+)\)\.\s*Player:\s*(.*?)\s*\((\d{15,20})\)\.\s*Weapon:\s*(.*?)\.\s*Damage:\s*([\d.]+)\.\s*Location:\s*X=([^\s]+)\s+Y=([^\s]+)\s+Z=([^\s]+)$/i);
  if (!match) return null;
  return {
    timestamp: timestampOf(line, null),
    type: 'building_damaged',
    typeLabel: '受击',
    buildingName: match[1].trim(),
    entityId: match[2].trim(),
    playerName: match[3].trim(),
    steamId: match[4],
    weaponSource: match[5].trim(),
    damage: numeric(match[6]),
    location: locationOf(match[7], match[8], match[9]),
    raw: line
  };
}

function rconStatsAuditOf(line) {
  const parsed = prefixedJsonOf(line);
  if (!parsed) return null;
  const timestamp = formatTimestamp(parsed.time || parsed.timestamp || '');
  const sourceLabelMap = { Projectile: '普通', Melee: '近战' };
  const source = parsed.source || parsed.Source || '';
  const sourceLabel = sourceLabelMap[source] || source || '--';
  const hit = parsed.hit || parsed.Hit || {};
  const location = hit && (hit.x !== undefined || hit.y !== undefined || hit.z !== undefined)
    ? locationOf(hit.x, hit.y, hit.z)
    : null;
  return {
    timestamp,
    eventType: parsed.eventType || parsed.EventType || parsed.type || 'npc_kill',
    source,
    sourceLabel,
    playerName: parsed.playerName || parsed.PlayerName || parsed.killerName || null,
    steamId: parsed.steamId || parsed.SteamId || parsed.killerSteamId || null,
    targetType: parsed.targetType || parsed.TargetType || null,
    targetName: parsed.targetName || parsed.TargetName || parsed.victimName || null,
    targetClass: parsed.targetClass || parsed.TargetClass || null,
    damage: numeric(parsed.damage ?? parsed.Damage),
    healthBefore: numeric(parsed.healthBefore ?? parsed.HealthBefore),
    healthAfter: numeric(parsed.healthAfter ?? parsed.HealthAfter),
    bone: parsed.bone || parsed.Bone || null,
    location,
    raw: line
  };
}

function kickAuditOf(line) {
  const timestamp = timestampOf(line, null);
  const message = messageOf(line);
  let match = message.match(/^\[IllegalDlc\]\s+Illegal DLC:\s*User:\s*(.*?)\s*\((\d+),\s*(\d{15,20})\)/);
  if (match) {
    const steamId = match[3];
    const playerName = match[1].trim();
    const dedupKey = `${steamId}||${timestamp}`;
    return { timestamp, steamId, playerName, serverId: '', reason: 'Illegal DLC', reasonLabel: '非法DLC', raw: message, _dedupKey: dedupKey };
  }
  match = message.match(/^AConZGameMode::KickPlayer:\s*User id:\s*'(\d{15,20})',\s*Reason:\s*(.*)$/);
  if (match) {
    const steamId = match[1];
    const reason = match[2].trim();
    const dedupKey = `${steamId}|${reason}|${timestamp}`;
    return { timestamp, steamId, playerName: '', serverId: '', reason, reasonLabel: reason, raw: message, _dedupKey: dedupKey };
  }
  return null;
}

function distanceAuditOf(line) {
  const timestamp = timestampOf(line, null);
  const message = messageOf(line);
  const match = message.match(/^\[OutOfInteractionRange\]\s+Request character action violation detected:\s*Action:\s*(.*?),\s*Desc:\s*(.*?),\s*ServerLocation:\s*X=([^\s]+)\s*Y=([^\s]+)\s*Z=([^\s]+),\s*ClientLocation:\s*X=([^\s]+)\s*Y=([^\s]+)\s*Z=([^\s]+),\s*Distance:\s*([\d.]+)\s*m,\s*User:\s*(.*?)\s*\((\d+),\s*(\d{15,20})\)/);
  if (!match) return null;
  return {
    timestamp,
    action: match[1].trim(),
    actionDesc: match[2].trim(),
    serverLocation: locationOf(match[3], match[4], match[5]),
    clientLocation: locationOf(match[6], match[7], match[8]),
    distance: numeric(match[9]),
    playerName: match[10].trim(),
    playerNumber: match[11],
    steamId: match[12],
    raw: message
  };
}

function ammoAuditOf(line) {
  const timestamp = timestampOf(line, null);
  const message = messageOf(line);
  const match = message.match(/^\[AmmoCountMismatch\]\s+Ammo count violation detected:\s*Weapon:\s*(.*?),\s*PrisonerLocation:\s*X=([^\s]+)\s*Y=([^\s]+)\s*Z=([^\s]+),\s*Count:\s*([\d.]+),\s*User:\s*(.*?)\s*\((\d+),\s*(\d{15,20})\)/);
  if (!match) return null;
  return {
    timestamp,
    weapon: match[1].trim(),
    count: numeric(match[5]),
    location: locationOf(match[2], match[3], match[4]),
    playerName: match[6].trim(),
    playerNumber: match[7],
    steamId: match[8],
    raw: message
  };
}

function ballisticsAuditOf(line) {
  const timestamp = timestampOf(line, null);
  const message = messageOf(line);
  const match = message.match(/^\[ProjectileDamageLocationsMismatch\]\s+Location mismatch when dealing damage:\s*ServerAttackerLocation:\s*X=([^\s]+)\s*Y=([^\s]+)\s*Z=([^\s]+),\s*ServerVictimLocation:\s*X=([^\s]+)\s*Y=([^\s]+)\s*Z=([^\s]+),\s*ClientAttackerLocation:\s*X=([^\s]+)\s*Y=([^\s]+)\s*Z=([^\s]+),\s*ClientVictimLocation:\s*X=([^\s]+)\s*Y=([^\s]+)\s*Z=([^\s]+),\s*AttackerDrift:\s*([\d.]+),\s*VictimDrift:\s*([\d.]+),\s*WeaponName:\s*(.*?),\s*User:\s*(.*?)\s*\((\d+),\s*(\d{15,20})\)/);
  if (!match) return null;
  return {
    timestamp,
    serverAttackerLocation: locationOf(match[1], match[2], match[3]),
    serverVictimLocation: locationOf(match[4], match[5], match[6]),
    clientAttackerLocation: locationOf(match[7], match[8], match[9]),
    clientVictimLocation: locationOf(match[10], match[11], match[12]),
    attackerDrift: numeric(match[13]),
    victimDrift: numeric(match[14]),
    weaponName: match[15].trim(),
    playerName: match[16].trim(),
    playerNumber: match[17],
    steamId: match[18],
    raw: message
  };
}

function otherViolationAuditOf(line) {
  return null;
}

function territoryRiskAuditOf(line) {
  const message = messageOf(line);
  const match = message.match(/^\[RaidProtection\]\s+Player\s+'([^']*)'\((\d{15,20})\).*?territory.*?of\s+'([^']*)'\((\d{15,20})\).*?Flag(?:Id)?:\s*([^\s,]+).*?Distance:\s*([\d.]+).*?HitRange:\s*([\d.]+).*?Player(?:Location|Loc):\s*X=([^\s,]+)\s*Y=([^\s,]+)\s*Z=([^\s,]+).*?Flag(?:Location|Loc):\s*X=([^\s,]+)\s*Y=([^\s,]+)\s*Z=([^\s,]+)/i);
  if (!match) return null;
  return { timestamp: timestampOf(line, null), playerName: match[1], steamId: match[2], territoryOwnerName: match[3], territoryOwnerSteamId: match[4], flagId: match[5], distance: numeric(match[6]), hitRange: numeric(match[7]), playerLocation: locationOf(match[8], match[9], match[10]), flagLocation: locationOf(match[11], match[12], match[13]), raw: line };
}

function questAuditOf(line) {
  const message = messageOf(line);
  let match = message.match(/^\[Quest(?:s)?\]\s+Type[:=]\s*([^\s,]+)\s*,?\s*Status[:=]\s*([^\s,]+)\s*,?\s*(?:User|Player):\s*'?([^'(,]+)\((\d+),\s*(\d{15,20})\)\s*,?\s*InternalId[:=]\s*([^\s,]+)\s*,?\s*WeaponSource[:=]\s*([^\s,]+)/i);
  if (!match) match = message.match(/^\[LogQuests?\]\s+Status[:=]\s*([^\s,]+)\s*,?\s*Type[:=]\s*([^\s,]+)\s*,?\s*(?:User|Player):\s*([^,]+)\((\d+),\s*(\d{15,20})\)\s*,?\s*(?:InternalId[:=]\s*)?([^\s,]+)\s*,?\s*(?:WeaponSource[:=]\s*)?([^\s,]+)/i);
  if (!match) return null;
  if (match[3]) {
    return { timestamp: timestampOf(line, null), status: match[2].toLowerCase(), typeLabel: match[1], playerName: match[3].trim(), steamId: match[5], internalId: match[6], weaponSource: match[7], raw: line };
  }
  return { timestamp: timestampOf(line, null), status: match[1].toLowerCase(), typeLabel: match[2], playerName: match[3].trim(), steamId: match[5], internalId: match[6], weaponSource: match[7], raw: line };
}

function sentryAuditOf(line) {
  const message = messageOf(line);
  const match = message.match(/^\[Sentry\]\s+Player\s+'([^']*)'\((\d{15,20})\).*?Weapon[:=]\s*([^\s,]+).*?Damage[:=]\s*([\d.]+).*?(?:Location|Loc)[:=]\s*X=([^\s,]+)\s*Y=([^\s,]+)\s*Z=([^\s,]+)/i);
  if (!match) return null;
  return { timestamp: timestampOf(line, null), playerName: match[1], steamId: match[2], weapon: match[3], damage: numeric(match[4]), coordX: numeric(match[5]), coordY: numeric(match[6]), coordZ: numeric(match[7]), raw: line };
}

function trapAuditOf(line) {
  const message = messageOf(line);
  const eventMatch = message.match(/\b(placed|armed|triggered|activated|disarmed|defused|destroyed|detonated|crafted)\b/i);
  const eventType = eventMatch?.[1].toLowerCase() || 'unknown';
  const eventLabel = ({ placed: '布设', armed: '装置', triggered: '触发', activated: '激活', disarmed: '解除', defused: '拆除', destroyed: '摧毁', detonated: '爆炸', crafted: '制作', unknown: '未知事件' })[eventType];
  const identityPatterns = [
    /(?:User|Player|Owner|Actor):\s*'?([^'\r\n]*?)\s*\((\d+),\s*(\d{15,20})\)/i,
    /'?(\d{15,20}):([^'(\r\n]+)\((\d+)\)'?/,
    /([^'(\r\n]+?)\s*\((\d{15,20})\s*,\s*(\d+)\)/
  ];
  let playerName = null; let steamId = null; let playerNumber = null;
  for (const [index, pattern] of identityPatterns.entries()) {
    const match = message.match(pattern);
    if (!match) continue;
    if (index === 0) [playerName, playerNumber, steamId] = [match[1].trim(), match[2], match[3]];
    if (index === 1) [steamId, playerName, playerNumber] = [match[1], match[2].trim(), match[3]];
    if (index === 2) [playerName, steamId, playerNumber] = [match[1].trim(), match[2], match[3]];
    break;
  }
  const locationMatch = message.match(/(?:Location|Coordinates?|Position):?\s*(?:X=)?(-?\d+(?:\.\d+)?)\s*[, ]+\s*(?:Y=)?(-?\d+(?:\.\d+)?)\s*[, ]+\s*(?:Z=)?(-?\d+(?:\.\d+)?)/i);
  const trapTypeMatch = message.match(/(?:Trap(?: type)?|Target|Object|Item):\s*([^,.]+)|\b(claymore|landmine|mine|trap)\b/i);
  const trapType = (trapTypeMatch?.[1] || trapTypeMatch?.[2] || '').trim() || null;
  return { timestamp: timestampOf(line, null), eventType, eventLabel, playerName, steamId, playerNumber, target: trapType, trapType, location: locationMatch ? locationOf(locationMatch[1], locationMatch[2], locationMatch[3]) : null, raw: line };
}

function lootDiagnosticAuditOf(line, parsed) {
  const fileInfo = parsed?._file || {};
  const fileType = fileInfo.category || '';
  const match = line.match(/^(\d{4}\.\d{2}\.\d{2}-\d{2}\.\d{2}\.\d{2}):\s*(Error|Log|Warning|Game version):\s*([\s\S]*)$/);
  if (!match) return null;
  const timestamp = match[1];
  const level = match[2];
  const content = match[3];
  const levelLabels = { Error: '错误', Log: '普通', Warning: '警告', 'Game version': '版本' };
  const levelLabel = levelLabels[level] || '普通';
  let category = '通用';
  if (/spawning parameters|spawnable item/i.test(content)) category = '物品';
  else if (/spawner|spawning/i.test(content)) category = '刷新点';
  else if (/zone/i.test(content)) category = '区域';
  else if (/parse|config|loaded|building/i.test(content)) category = '配置';
  else if (/is not a valid item|could not find/i.test(content)) category = '错误';
  let errorDetail = null;
  if (level === 'Error') {
    const nodeMatch = content.match(/Node '([^']+)' could not find item spawning parameters for item '([^']+)'/);
    if (nodeMatch) {
      errorDetail = { nodePath: nodeMatch[1], itemName: nodeMatch[2] };
    } else {
      const invalidItemMatch = content.match(/'([^']+)' is not a valid item/);
      if (invalidItemMatch) {
        errorDetail = { invalidItem: invalidItemMatch[1] };
      } else {
        const failedParseMatch = content.match(/Failed to parse '([^']+)'/);
        if (failedParseMatch) {
          errorDetail = { failedFile: failedParseMatch[1] };
        } else {
          const spawnerFailMatch = content.match(/'([^']+)': Failed to find loot tree node '([^']+)'/);
          if (spawnerFailMatch) {
            errorDetail = { spawnerRef: spawnerFailMatch[1], lootNode: spawnerFailMatch[2] };
          } else {
            errorDetail = { message: content };
          }
        }
      }
    }
  }
  return { timestamp, level, levelLabel, category, content, fileType, errorDetail, raw: line };
}

function raidDiagnosticAuditOf(line, parsed) {
  const match = line.match(/^(\d{4}\.\d{2}\.\d{2}-\d{2}\.\d{2}\.\d{2}):\s*(Game version|Log):\s*([\s\S]*)$/);
  if (!match) return null;
  const timestamp = match[1];
  const level = match[2];
  const content = match[3];
  const levelLabels = { 'Game version': '版本', Log: '普通' };
  const levelLabel = levelLabels[level] || '普通';
  const category = level === 'Game version' ? '版本' : '通用';
  return { timestamp, level, levelLabel, category, content, fileType: 'raid_protection', raw: line };
}

function auditOf(category, line, parsed) {
  if (category === 'admin_command') return adminAuditOf(line);
  if (category === 'field_kill') return killAuditOf(line, parsed, false);
  if (category === 'event_kill') return killAuditOf(line, parsed, true);
  if (category === 'chat') return chatAuditOf(line);
  if (category === 'presence') return presenceAuditOf(line);
  if (category === 'teammate_claim') return teammateClaimAuditOf(line);
  if (category === 'purchase') return purchaseAuditOf(line);
  if (category === 'sale') return saleAuditOf(line);
  if (category === 'balance') return balanceAuditOf(line);
  if (category === 'bank_transfer') return bankTransferAuditOf(line);
  if (category === 'gold') return goldAuditOf(line);
  if (category === 'bank_card') return bankCardAuditOf(line);
  if (category === 'vehicle') return vehicleAuditOf(line);
  if (category === 'chest') return chestAuditOf(line);
  if (category === 'lockpick' || category === 'wire_cut') return behaviorAuditOf(line);
  if (category === 'trap') return trapAuditOf(line);
  if (category === 'gameplay') return gameplayAuditOf(line);
  if (category === 'territory_risk') return territoryRiskAuditOf(line);
  if (category === 'quest') return questAuditOf(line);
  if (category === 'sentry') return sentryAuditOf(line);
  if (category === 'bunker_unlock') return bunkerUnlockAuditOf(line);
  if (category === 'bunker_status') return bunkerStatusAuditOf(line);
  if (category === 'base_destruction') return baseDestructionAuditOf(line);
  if (category === 'rcon_stats') return rconStatsAuditOf(line);
  if (category === 'kick') return kickAuditOf(line);
  if (category === 'distance') return distanceAuditOf(line);
  if (category === 'ammo') return ammoAuditOf(line);
  if (category === 'ballistics') return ballisticsAuditOf(line);
  if (category === 'loot_diagnostic') return lootDiagnosticAuditOf(line, parsed);
  if (category === 'raid_diagnostic') return raidDiagnosticAuditOf(line, parsed);
  if (category === 'other_violation') return otherViolationAuditOf(line);
  return null;
}

function killDuplicateKey(audit) {
  if (!audit || audit.eventType !== 'kill') return '';
  return [audit.timestamp, audit.killerSteamId, audit.victimSteamId, audit.killerName, audit.victimName].join('|').toLowerCase();
}

function levelOf(line, parsed) {
  const level = String(parsed?.level || '').toLowerCase();
  if (['error', 'warn', 'info', 'debug'].includes(level)) return level;
  if (/\b(error|fatal|failed|failure|exception|crash)\b/i.test(line)) return 'error';
  if (/\b(warn|warning)\b/i.test(line)) return 'warn';
  if (/\b(debug|trace)\b/i.test(line)) return 'debug';
  return 'info';
}

function shopCategoryOf(level) {
  if (level === 'error') return 'error';
  if (level === 'warn') return 'warning';
  return 'application';
}

function shopModuleOf({ component, message, parsed, fileCategory }) {
  const normalized = String(component || '').toLowerCase();
  const code = String(parsed?.code || parsed?.errorCode || '').toUpperCase();
  const event = String(parsed?.event || '').toLowerCase();
  const text = String(message || '');
  if (normalized === 'rcon' || event === 'rcon_access' || parsed?.command || /\bRCON\b/i.test(text)) return 'rcon';
  if (fileCategory === 'mysql' || ['mysql', 'database', 'db'].includes(normalized) || /^(?:ER_|MYSQL|DB_)/.test(code) || /(?:MySQL|数据库|SQL)/i.test(text)) return 'mysql';
  return 'application';
}

function timestampOf(line, parsed) {
  if (parsed?.timestamp || parsed?.time) return parsed.timestamp || parsed.time;
  return line.match(/^\[([^\]]+)\]/)?.[1] || line.match(/^(\d{4}-\d{2}-\d{2}T[^\s]+)/)?.[1] || line.match(/^(\d{4}\.\d{2}\.\d{2}-\d{2}\.\d{2}\.\d{2})/)?.[1] || '';
}

function browserDuplicateKey(entry) {
  const details = entry.details || {};
  const identity = ['code', 'statusCode', 'path', 'command', 'status', 'errorCode', 'errorMessage', 'rconErrorCode', 'rconErrorMessage', 'error', 'eventId', 'announcementId', 'taskId', 'orderId', 'steamId', 'file'].map((key) => [key, details[key] ?? null]);
  return JSON.stringify([entry.level, entry.component, entry.message, identity]);
}

function repeatRecord(entry) {
  const suppressedCount = Number(entry.repeatCount) || 0;
  return {
    timestamp: entry.timestamp,
    file: entry.file,
    fileType: entry.fileType,
    details: entry.details || null,
    suppressedCount,
    occurrenceCount: 1 + suppressedCount,
    repeatWindowMs: Number(entry.repeatWindowMs) || 0
  };
}

function collapseShopEntries(entries) {
  const result = [];
  const indexes = new Map();
  for (const entry of entries) {
    const key = browserDuplicateKey(entry);
    const existingIndex = indexes.get(key);
    if (existingIndex === undefined) {
      indexes.set(key, result.length);
      result.push({ ...entry, repeatCount: Number(entry.repeatCount) || 0, repeatRecords: [repeatRecord(entry)] });
      continue;
    }
    result[existingIndex].repeatCount += 1 + (Number(entry.repeatCount) || 0);
    result[existingIndex].repeatRecords.push(repeatRecord(entry));
  }
  return result.map((entry) => {
    if (entry.repeatCount > 0) return entry;
    const { repeatRecords, ...single } = entry;
    return single;
  });
}

function logTimestamp(entry) {
  const timestamp = String(entry.audit?.timestamp || entry.timestamp || '').replace(/^(\d{4})\.(\d{2})\.(\d{2})-(\d{2})\.(\d{2})\.(\d{2})(?::(\d+))?/, (match, year, month, day, hour, minute, second, fraction) => `${year}-${month}-${day}T${hour}:${minute}:${second}${fraction ? '.' + fraction : ''}`);
  return Date.parse(timestamp) || 0;
}

function decode(buffer) {
  if (!buffer.length) return '';
  const utf16 = (buffer[0] === 0xff && buffer[1] === 0xfe) || buffer.subarray(0, Math.min(buffer.length, 200)).filter((value) => value === 0).length > 20;
  if (utf16) return buffer.subarray(buffer.length % 2 ? 1 : 0).toString('utf16le').replace(/^\uFEFF/, '');
  return buffer.toString('utf8').replace(/^\uFEFF/, '');
}

async function tail(file, maxBytes = MAX_TAIL_BYTES) {
  if (!Number.isFinite(maxBytes)) return fs.readFile(file).then(decode);
  const handle = await fs.open(file, 'r');
  try {
    const stat = await handle.stat();
    const size = Math.min(stat.size, maxBytes);
    const buffer = Buffer.alloc(size);
    await handle.read(buffer, 0, size, stat.size - size);
    let text = decode(buffer);
    if (stat.size > size) text = text.slice(text.search(/\r?\n/) + 1);
    return text;
  } finally { await handle.close(); }
}

function fameAuditsOf(text) {
  const entries = []; let blockTimestamp = ''; let current = null;
  const finish = () => { if (current) entries.push(current); current = null; };
  for (const sourceLine of text.split(/\r?\n/)) {
    const raw = sourceLine.trim(); if (!raw) continue;
    const timestamped = raw.match(/^(\d{4}\.\d{2}\.\d{2}-\d{2}\.\d{2}\.\d{2}):\s*([\s\S]*)$/);
    const timestamp = timestamped?.[1] || ''; const message = (timestamped?.[2] ?? raw).trim();
    if (/^-{10,}$/.test(message)) { finish(); if (timestamp) blockTimestamp = timestamp; continue; }
    let match = message.match(/^Player ([\s\S]+)\((\d{15,20})\) was awarded (-?\d+(?:\.\d+)?) fame points in (\d+) minutes for a total of (-?\d+(?:\.\d+)?)\s*$/i);
    if (match) { finish(); current = { timestamp: timestamp || blockTimestamp, type: 'period_summary', typeLabel: '阶段统计', playerName: match[1].trim(), steamId: match[2], famePoints: numeric(match[3]), reason: '10分钟统计', periodMinutes: numeric(match[4]), totalFame: numeric(match[5]), raw, details: [] }; continue; }
    match = message.match(/^Player ([\s\S]+)\((\d{15,20})\) was awarded (-?\d+(?:\.\d+)?) fame points for ([\s\S]+?)\s*$/i);
    if (match) { finish(); const audit = { timestamp: timestamp || blockTimestamp, type: 'instant', typeLabel: '即时声望', playerName: match[1].trim(), steamId: match[2], famePoints: numeric(match[3]), reason: match[4].trim(), periodMinutes: null, totalFame: null, raw, details: [] }; audit.details.push({ timestamp: audit.timestamp, reason: audit.reason, famePoints: audit.famePoints, playerName: audit.playerName, steamId: audit.steamId, raw }); entries.push(audit); continue; }
    const detail = message.match(/^([^:]+):\s*(-?\d+(?:\.\d+)?)\s*$/);
    if (current && detail) current.details.push({ timestamp: current.timestamp, reason: detail[1].trim(), famePoints: numeric(detail[2]), playerName: current.playerName, steamId: current.steamId, raw });
  }
  finish(); return entries;
}

async function filesIn(directory, source, matcher = () => true) {
  try {
    const entries = (await fs.readdir(directory, { withFileTypes: true })).filter((entry) => entry.isFile() && matcher(entry.name));
    const files = [];
    for (let index = 0; index < entries.length; index += 16) {
      const batch = await Promise.all(entries.slice(index, index + 16).map(async (entry) => {
        const filePath = path.join(directory, entry.name);
        const stat = await fs.stat(filePath);
        return { source, sourceLabel: SOURCE_LABELS[source], category: physicalCategory(source, entry.name), name: entry.name, path: filePath, size: stat.size, modifiedAt: stat.mtime.toISOString() };
      }));
      files.push(...batch);
    }
    return files;
  } catch (error) {
    if (['ENOENT', 'ENOTDIR'].includes(error.code)) return [];
    throw error;
  }
}

function ue4ssPath(config) {
  const root = String(config.ggcon?.serverDirectory || '').trim();
  if (root) return path.join(root, 'Binaries', 'Win64', 'ue4ss', 'UE4SS.log');
  const logs = String(config.scumLogs?.directory || '').trim();
  const marker = `${path.sep}Saved${path.sep}SaveFiles${path.sep}Logs`;
  const index = logs.toLowerCase().lastIndexOf(marker.toLowerCase());
  return index >= 0 ? path.join(logs.slice(0, index), 'Binaries', 'Win64', 'ue4ss', 'UE4SS.log') : '';
}

export { GAME_CATEGORIES, physicalCategory, classifyGameLog, auditOf, fameAuditsOf, timestampOf, levelOf, prefixedJsonOf, messageOf };

export class LogBrowserService {
  constructor({ root, store }) { this.root = root; this.store = store; }

  async list({ source = '', category = '', file = '', level = '', search = '', limit = 300 } = {}) {
    const unlimited = source === 'shop' && String(limit) === '0';
    const config = await this.store.read();
    const ue4ss = ue4ssPath(config);
    const gameDefinition = source === 'scum' && category ? GAME_CATEGORIES.find((item) => item.id === category) : null;
    const matchesRequestedFile = (name) => !file || name === file;
    const [shopFiles, scumFiles, ue4ssFiles] = await Promise.all([
      !source || source === 'shop' ? filesIn(path.join(this.root, 'logs'), 'shop', (name) => /\.log$/i.test(name) && matchesRequestedFile(name) && (category === 'error' ? physicalCategory('shop', name) === 'error' : physicalCategory('shop', name) !== 'error')) : [],
      !source || source === 'scum' ? filesIn(String(config.scumLogs?.directory || ''), 'scum', (name) => /\.log$/i.test(name) && matchesRequestedFile(name) && (!category || category === 'all' || gameDefinition?.physical.includes(physicalCategory('scum', name)))) : [],
      (!source || source === 'ue4ss') && ue4ss ? filesIn(path.dirname(ue4ss), 'ue4ss', (name) => name.toLowerCase() === path.basename(ue4ss).toLowerCase() && matchesRequestedFile(name)) : []
    ]);
    const allFiles = [...shopFiles, ...scumFiles, ...ue4ssFiles].sort((a, b) => b.modifiedAt.localeCompare(a.modifiedAt));
    const selected = allFiles.filter((item) => {
      if (source && item.source !== source) return false;
      if (file && item.name !== file) return false;
      if (item.source === 'shop') {
        if (category === 'error') return item.category === 'error';
        return item.category !== 'error';
      }
      if (!category || category === 'all') return true;
      return item.source === 'scum' ? gameDefinition?.physical.includes(item.category) : item.category === category;
    });
    const normalizedSearch = String(search || '').trim().toLowerCase();
    const exhaustiveSearch = Boolean(normalizedSearch);
    const readFiles = unlimited || exhaustiveSearch ? selected : selected.slice(0, file ? 1 : category === 'event_kill' ? selected.length : source || category ? 30 : 40);
    const entries = [];
    const killKeys = new Set();
    const kickKeys = new Set();
    const readFailures = [];
    const fameMode = source === 'scum' && category === 'fame';
    for (const item of readFiles) {
      let text = '';
      try {
        text = fameMode ? decode(await fs.readFile(item.path)) : await tail(item.path, unlimited || exhaustiveSearch ? Number.POSITIVE_INFINITY : MAX_TAIL_BYTES);
      } catch (error) {
        readFailures.push({ file: item.name, code: error.code || 'READ_FAILED', message: error.message });
        continue;
      }
      if (fameMode) {
        for (const audit of fameAuditsOf(text)) {
          if (level && level !== 'info') continue;
          const haystack = item.name + ' ' + audit.raw + ' ' + JSON.stringify(audit);
          if (normalizedSearch && !haystack.toLowerCase().includes(normalizedSearch)) continue;
          entries.push({ timestamp: audit.timestamp, level: 'info', source: item.source, sourceLabel: item.sourceLabel, category: 'fame', categoryLabel: '声望', file: item.name, message: audit.raw, audit, details: null });
        }
        continue;
      }
      for (const raw of text.split(/\r?\n/).filter(Boolean)) {
        let parsed = null;
        try { parsed = JSON.parse(raw); } catch { parsed = prefixedJsonOf(raw); }
        if (!parsed) parsed = {};
        if (!parsed._file) parsed._file = { name: item.name, category: item.category, source: item.source };
        let message = parsed?.message ? String(parsed.message) : raw.replace(/^\[[^\]]+\]\s*/, '');
        if (item.source === 'shop' && parsed?.command && (parsed?.event === 'rcon_access' || parsed?.component === 'rcon')) {
          const accessStatus = parsed.status || (/成功/.test(message) ? 'success' : 'failed');
          message = formatRconAccessMessage(parsed.command, accessStatus);
        }
        const entryLevel = levelOf(raw, parsed);
        const virtualCategory = item.source === 'scum' ? classifyGameLog(item.category, raw) : (item.source === 'shop' ? shopCategoryOf(entryLevel) : item.category);
        if (!virtualCategory || (category && category !== 'all' && virtualCategory !== category)) continue;
        const definition = GAME_CATEGORIES.find((entry) => entry.id === virtualCategory);
        if (level && entryLevel !== level) continue;
        const audit = item.source === 'scum' ? auditOf(virtualCategory, raw, parsed) : null;
        if (normalizedSearch && !`${item.name} ${message} ${audit ? JSON.stringify(audit) : ''}`.toLowerCase().includes(normalizedSearch)) continue;
        const duplicateKey = ['field_kill', 'event_kill'].includes(virtualCategory) ? killDuplicateKey(audit) : '';
        if (duplicateKey && killKeys.has(duplicateKey)) {
          const existingIndex = entries.findIndex((entry) => killDuplicateKey(entry.audit) === duplicateKey);
          if (existingIndex >= 0 && parsed?.Killer && parsed?.Victim) entries.splice(existingIndex, 1);
          else continue;
        }
        if (duplicateKey) killKeys.add(duplicateKey);
        const kickKey = virtualCategory === 'kick' && audit?._dedupKey ? audit._dedupKey : '';
        if (kickKey && kickKeys.has(kickKey)) continue;
        if (kickKey) kickKeys.add(kickKey);
        const rawComponent = String(parsed?.component || (item.source === 'shop' ? 'application' : item.source));
        const component = item.source === 'shop' ? shopModuleOf({ component: rawComponent, message, parsed, fileCategory: item.category }) : rawComponent;
        const module = item.source === 'shop' ? SHOP_MODULES[component] : null;
        entries.push({ timestamp: timestampOf(raw, parsed), level: entryLevel, source: item.source, sourceLabel: item.sourceLabel, category: virtualCategory, categoryLabel: definition?.label || CATEGORY_LABELS[virtualCategory] || virtualCategory, component, componentLabel: module?.label || rawComponent, componentDescription: module?.description || '', file: item.name, fileType: item.source === 'shop' && (item.category === 'error' || entryLevel === 'error') ? '错误日志' : '运行日志', message, audit, repeatCount: Number(parsed?.repeatCount) || 0, repeatWindowMs: Number(parsed?.repeatWindowMs) || 0, details: parsed && typeof parsed === 'object' ? Object.fromEntries(Object.entries(parsed).filter(([key]) => !['timestamp', 'time', 'level', 'message', 'component', 'repeatCount', 'repeatWindowMs', '_file'].includes(key))) : null });
      }
    }
    entries.reverse();
    entries.sort((first, second) => logTimestamp(second) - logTimestamp(first));
    const visibleEntries = source === 'shop' ? collapseShopEntries(entries) : entries;
    const safeLimit = unlimited ? null : Math.min(Math.max(Number(limit) || 300, 1), 1000);
    const categories = source === 'scum'
      ? GAME_CATEGORIES.map((item) => ({ id: item.id, label: item.label, icon: item.icon, fileCount: allFiles.filter((fileItem) => fileItem.source === 'scum' && item.physical.includes(fileItem.category)).length }))
      : source === 'shop'
        ? SHOP_CATEGORIES.map((item) => ({ ...item, fileCount: item.id === 'error' ? shopFiles.filter((fileItem) => fileItem.category === 'error').length : shopFiles.filter((fileItem) => fileItem.category !== 'error').length }))
        : [...new Set(allFiles.filter((item) => !source || item.source === source).map((item) => item.category))].sort().map((id) => ({ id, label: CATEGORY_LABELS[id] || id, fileCount: allFiles.filter((item) => (!source || item.source === source) && item.category === id).length }));
    return {
      entries: safeLimit === null ? visibleEntries : visibleEntries.slice(0, safeLimit),
      sources: Object.entries(SOURCE_LABELS).map(([id, label]) => ({ id, label, fileCount: allFiles.filter((item) => item.source === id).length })),
      categories,
      files: selected.map(({ source: fileSource, sourceLabel, category: fileCategory, name, size, modifiedAt }) => ({ source: fileSource, sourceLabel, category: fileCategory, name, size, modifiedAt })),
      totalFiles: allFiles.length,
      scannedFiles: readFiles.length - readFailures.length,
      readFailures,
      truncated: !unlimited && !exhaustiveSearch && (selected.length > readFiles.length || readFiles.some((item) => item.size > MAX_TAIL_BYTES))
    };
  }
}
