import crypto from 'node:crypto';
import { lotteryRewardDisplay } from './lottery-reward-display.js';
import { buildItemCommand, isSteamId64 } from './command-policy.js';
import { parseGiftCode, renderGiftRconCommand } from './gift-code-policy.js';
import { assertScumRconSuccess, parsePlayerEconomy } from './scum-rcon-parser.js';

const SKU_PATTERN = /^[A-Za-z0-9_.-]{1,64}$/;
export const ITEM_PATTERN = /^[A-Za-z0-9_]{1,80}$/;
const CURRENCY_TYPES = new Set(['coin', '商城币', 'money', 'gold']);
const IMAGE_UPLOAD_PATTERN = /^\/uploads\/(?:images|products)(?:\/[\p{L}\p{N}_ ()&-]{1,100})*\/[A-Za-z0-9][A-Za-z0-9_.-]{0,199}$/u;
const MAX_CODES = 50;
const MAX_CODES_LENGTH = 4096;

export class ServiceError extends Error {
  constructor(message, status = 400, code = 'BAD_REQUEST') {
    super(message);
    this.status = status;
    this.code = code;
  }
}

function taskCommands(task) {
  let payload = task.payloadJson;
  if (typeof payload === 'string') { try { payload = JSON.parse(payload); } catch { payload = null; } }
  const actionType = payload?.actionType;
  if (actionType === 'warehouse') return ['无游戏命令：奖励存入云储仓库'];
  if (actionType === 'shop_coin') return ['无游戏命令：商城币直接入账'];
  if (['spawn_vehicle','spawn_animal','spawn_zombie','spawn_armed_npc'].includes(actionType)) {
    const names = { spawn_vehicle: 'SpawnVehicle', spawn_animal: 'SpawnAnimal', spawn_zombie: 'SpawnZombie', spawn_armed_npc: 'SpawnArmedNPC' };
    if (actionType === 'spawn_zombie') return [`SpawnZombieForPlayer ${task.steamId} ${payload.itemId} ${payload.quantity} CONFIRM`];
    if (actionType === 'spawn_animal') return [`SpawnAnimalForPlayer ${task.steamId} ${payload.itemId} ${payload.quantity} CONFIRM`];
    return [`#${names[actionType]} ${payload.itemId} ${payload.quantity} Location ${task.steamId}`];
  }
  const total = Number(payload?.quantity || task.amount || 0);
  return Array.from({ length: Math.ceil(total / 10) }, (_, index) => {
    const amount = Math.min(10, total - index * 10);
    if (payload) return renderGiftRconCommand({ taskType: 'spawn_item', payload: { ...payload, quantity: amount } }, task.steamId);
    return buildItemCommand({ steamId: task.steamId, itemId: task.itemId, amount }, { allowedMessageLength: 500, allowedItems: [{ id: task.itemId, name: task.itemId, maxAmount: 10 }] });
  });
}
function fulfillmentFailureText(value, status) {
  const source = String(value || '').trim();
  if (/玩家当前离线|waiting_offline/i.test(source)) return '玩家不在线，发放任务等待玩家上线';
  if (/ECONNREFUSED|connect.*refused/i.test(source)) return 'RCON连接被拒绝，请检查游戏服务和插件状态';
  if (/timeout|timed out|超时/i.test(source)) return 'RCON连接或游戏命令执行超时';
  if (/unknown command|not supported|不支持.*命令/i.test(source)) return '游戏端插件不支持该发放命令';
  if (/未返回明确成功|明确成功结果/i.test(source)) return '游戏命令已发送，但未返回明确成功结果';
  if (/参数无效|invalid/i.test(source)) return '商品发放参数无效，请检查商品命令配置';
  if (/人工核验|manual_review/i.test(source) || status === 'manual_review') return '任务已进入发货阶段，结果需要人工核验';
  return '礼包发放任务执行失败，请检查游戏连接和商品命令配置';
}

function positiveInt(value, name, max = 1000000) {
  const number = Number(value);
  if (!Number.isSafeInteger(number) || number < 1 || number > max) throw new ServiceError(`${name}必须是 1-${max} 的整数`);
  return number;
}

function nonNegativeInt(value, name) {
  const number = Number(value);
  if (!Number.isSafeInteger(number) || number < 0) throw new ServiceError(`${name}必须是非负整数`);
  return number;
}

function membershipPage(value) {
  const page = Number(value ?? 1);
  if (!Number.isInteger(page) || page < 1) throw new ServiceError('页码必须是正整数', 400, 'INVALID_PAGINATION');
  return page;
}

function membershipInput(input, cancel = false) {
  const keys = Object.keys(input || {});
  const allowed = cancel ? ['reason'] : ['level', 'expiresAt', 'reason'];
  if (keys.some((key) => !allowed.includes(key))) throw new ServiceError('会员操作包含不允许的字段', 400, 'INVALID_INPUT');
  const reason = String(input?.reason || '').trim();
  if (!reason || reason.length > 500) throw new ServiceError('操作原因须为 1-500 个字符', 400, 'INVALID_INPUT');
  if (cancel) return { level: 0, expiresAt: null, reason };
  const level = Number(input?.level);
  if (!Number.isInteger(level) || level < 1 || level > 100) throw new ServiceError('会员等级须为 1-100 的整数', 400, 'INVALID_INPUT');
  let expiresAt = null;
  if (input?.expiresAt !== null && input?.expiresAt !== undefined && input.expiresAt !== '') {
    expiresAt = new Date(input.expiresAt);
    if (Number.isNaN(expiresAt.getTime())) throw new ServiceError('会员到期时间格式无效', 400, 'INVALID_INPUT');
  }
  return { level, expiresAt, reason };
}

function percentValue(value, name) {
  const number = Number(value ?? 100);
  if (!Number.isFinite(number) || number < 0 || number > 100) throw new ServiceError(`${name}必须是 0-100 的数字`, 400, 'INVALID_INPUT');
  return Number(number.toFixed(2));
}

function membershipStrategyInput(input) {
  const level = Number(input?.level);
  if (!Number.isInteger(level) || level < 0 || level > 100) throw new ServiceError('会员等级须为 0-100 的整数', 400, 'INVALID_INPUT');
  const title = String(input?.title || '').trim();
  if (!title || title.length > 100) throw new ServiceError('会员称号长度必须为 1-100', 400, 'INVALID_INPUT');
  const extraHint = String(input?.extraHint || '').trim();
  if (extraHint.length > 500) throw new ServiceError('额外提示不能超过 500 字符', 400, 'INVALID_INPUT');
  return {
    level,
    title,
    openingAmount: nonNegativeInt(input?.openingAmount ?? 0, '开通金额'),
    periodDays: positiveInt(input?.periodDays ?? 30, '开通周期', 36500),
    giftTokens: nonNegativeInt(input?.giftTokens ?? 0, '赠送代币'),
    upgradeSpend: nonNegativeInt(input?.upgradeSpend ?? 0, '升级所需消费'),
    teleportDiscount: percentValue(input?.teleportDiscount, '传送折扣'),
    onlineBonus: percentValue(input?.onlineBonus, '在线加成', 1000),
    shoppingDiscount: percentValue(input?.shoppingDiscount, '购物折扣'),
    giftDiscount: percentValue(input?.giftDiscount, '礼包折扣'),
    rechargeBonus: percentValue(input?.rechargeBonus, '充值加成'),
    dailyTeleports: nonNegativeInt(input?.dailyTeleports ?? 0, '每日传送次数'),
    checkinBonus: nonNegativeInt(input?.checkinBonus ?? 0, '签到额外赠送商城币'),
    extraHint,
    enabled: input?.enabled === undefined ? true : Boolean(input.enabled)
  };
}

function membershipPolicyInput(input = {}) {
  const renewalPriceStrategy = String(input.renewalPriceStrategy || 'original');
  const upgradeStrategy = String(input.upgradeStrategy || 'allow');
  const upgradeExpiryStrategy = String(input.upgradeExpiryStrategy || 'extend');
  const lowerLevelPurchase = String(input.lowerLevelPurchase || 'forbid');
  if (!['original','discount','fixed'].includes(renewalPriceStrategy)) throw new ServiceError('续费价格策略无效', 400, 'INVALID_INPUT');
  if (!['allow','forbid'].includes(upgradeStrategy)) throw new ServiceError('高级会员升级策略无效', 400, 'INVALID_INPUT');
  if (!['extend','reset'].includes(upgradeExpiryStrategy)) throw new ServiceError('升级到期策略无效', 400, 'INVALID_INPUT');
  if (!['allow','forbid'].includes(lowerLevelPurchase)) throw new ServiceError('低等级购买策略无效', 400, 'INVALID_INPUT');
  const openEnabled = Boolean(input.openEnabled), consumptionUpgradeEnabled = Boolean(input.consumptionUpgradeEnabled);
  if (openEnabled === consumptionUpgradeEnabled) throw new ServiceError('开通制和消费制必须且只能启用一项', 400, 'INVALID_MEMBERSHIP_MODE');
  return {
    openEnabled, consumptionUpgradeEnabled, renewalEnabled: Boolean(input.renewalEnabled),
    renewalPriceStrategy, renewalGiftEnabled: Boolean(input.renewalGiftEnabled), renewalDiscount: percentValue(input.renewalDiscount, '续费折扣'),
    renewalFixedPrice: nonNegativeInt(input.renewalFixedPrice || 0, '续费固定价'), upgradeStrategy, upgradeExpiryStrategy,
    upgradeGiftEnabled: Boolean(input.upgradeGiftEnabled), upgradeGiftAmount: nonNegativeInt(input.upgradeGiftAmount || 0, '升级赠送代币'), lowerLevelPurchase
  };
}

function optionalText(value, name, max) {
  const text = String(value || '').trim();
  if (text.length > max) throw new ServiceError(`${name}不能超过 ${max} 字符`);
  return text;
}

function normalizeCurrencyType(value) {
  const currencyType = String(value || 'coin').trim();
  if (!CURRENCY_TYPES.has(currencyType)) throw new ServiceError('货币类型仅支持商城币、美金、金条');
  return currencyType;
}

export function normalizeImagePath(value) {
  const imagePath = String(value || '').trim();
  if (imagePath.length > 500) throw new ServiceError('图片路径不能超过 500 字符');
  if (!imagePath) return '';
  if (IMAGE_UPLOAD_PATTERN.test(imagePath)) return imagePath;
  try {
    const url = new URL(imagePath);
    if ((url.protocol === 'http:' || url.protocol === 'https:') && url.href.length <= 500) return imagePath;
  } catch {}
  throw new ServiceError('图片路径仅支持本地上传路径或 http/https URL');
}

export function normalizeFulfillmentCodes(value) {
  const raw = Array.isArray(value) ? value.map((item) => String(item)).join('\n') : String(value || '');
  if (raw.length > MAX_CODES_LENGTH) throw new ServiceError(`发货代码总长不能超过 ${MAX_CODES_LENGTH} 字符`);
  const entries = Array.isArray(value) ? value : raw.split(/[\r\n,]+/);
  const codes = [];
  for (const entry of entries) {
    const text = String(entry || '').trim();
    if (!text) continue;
    parseProductCode(text, { allowVehicle: true });
    const code = /^#(?:spawnitem|spawnvehicle|spawnanimal|spawnzombie|spawnarmednpc)\s+/i.test(text)
      ? text
      : `#spawnitem ${text}`;
    codes.push(code);
  }
  if (!codes.length) throw new ServiceError('至少需要一条发货代码');
  if (codes.length > MAX_CODES) throw new ServiceError(`发货代码最多 ${MAX_CODES} 条`);
  if (codes.join(',').length > MAX_CODES_LENGTH) throw new ServiceError(`发货代码总长不能超过 ${MAX_CODES_LENGTH} 字符`);
  return codes;
}

export function parseProductCode(value, { allowVehicle = true } = {}) {
  const text = String(value || '').trim();
  if (/^#spawnanimal\b/i.test(text)) {
    const match = text.match(/^#spawnanimal\s+([A-Za-z0-9_]{1,80})(?:\s+([1-9]\d*))?$/i);
    if (!match) throw new ServiceError('动物代码格式无效，仅支持 #spawnanimal <动物代码> [数量]');
    return { itemId: match[1], quantity: Number(match[2] || 1), arguments: [], actionType: 'spawn_animal' };
  }
  if (/^#spawnzombie\b/i.test(text)) {
    const match = text.match(/^#spawnzombie\s+([A-Za-z0-9_]{1,80})(?:\s+([1-9]\d*))?$/i);
    if (!match) throw new ServiceError('木偶代码格式无效，仅支持 #SpawnZombie <木偶代码> [数量]');
    return { itemId: match[1], quantity: Number(match[2] || 1), arguments: [], actionType: 'spawn_zombie' };
  }
  if (/^#spawnarmednpc\b/i.test(text)) {
    const match = text.match(/^#spawnarmednpc\s+([A-Za-z0-9_]{1,80})$/i);
    if (!match) throw new ServiceError('武装 NPC 代码格式无效，仅支持 #SpawnArmedNPC <NPC代码>');
    return { itemId: match[1], quantity: 1, arguments: [], actionType: 'spawn_armed_npc' };
  }
  if (/^#spawnvehicle\b/i.test(text)) {
    const match = text.match(/^#spawnvehicle\s+([A-Za-z0-9_]{1,80})$/i);
    if (!match) throw new ServiceError('车辆代码格式无效，仅支持 #SpawnVehicle 车辆代码');
    if (!allowVehicle) throw new ServiceError('当前 RCON 插件未支持车辆发货，暂不允许购买或兑换', 409, 'VEHICLE_DELIVERY_UNAVAILABLE');
    return { itemId: match[1], quantity: 1, arguments: [], actionType: 'spawn_vehicle' };
  }
  const code = String(value || '').trim().replace(/^#spawnitem\s+/i, '');
  const tokens = code.split(/\s+/);
  if (tokens.length === 1 || !/^\d+$/.test(tokens[1])) tokens.splice(1, 0, '1');
  try {
    return parseGiftCode(`#spawnitem ${tokens.join(' ')}`).payload;
  } catch (error) {
    throw new ServiceError(error.message);
  }
}

function productCodes(product) {
  return normalizeFulfillmentCodes(product.fulfillment_codes || product.item_id);
}

export function productDelivery(code, multiplier) {
  const payload = parseProductCode(code);
  const quantity = payload.quantity * multiplier;
  if (payload.actionType === 'spawn_armed_npc') {
    positiveInt(quantity, '武装 NPC 数量', 100);
    return { payload: { actionType: 'spawn_armed_npc', itemId: payload.itemId, quantity: 1 }, itemId: payload.itemId, amount: quantity };
  }
  if (payload.actionType === 'spawn_vehicle') {
    positiveInt(quantity, '车辆数量', 100);
    return { payload: { actionType: 'spawn_vehicle', itemId: payload.itemId, quantity: 1 }, itemId: payload.itemId, amount: quantity };
  }
  if (payload.actionType === 'spawn_animal') {
    positiveInt(quantity, '动物数量', 100);
    return { payload: { actionType: 'spawn_animal', itemId: payload.itemId, quantity }, itemId: payload.itemId, amount: quantity };
  }
  if (payload.actionType === 'spawn_zombie') {
    positiveInt(quantity, '木偶数量', 100);
    return { payload: { actionType: 'spawn_zombie', itemId: payload.itemId, quantity }, itemId: payload.itemId, amount: quantity };
  }
  try {
    const delivery = parseGiftCode(`#spawnitem ${payload.itemId} ${quantity} ${payload.arguments.join(' ')}`).payload;
    return { payload: delivery.arguments.length ? delivery : null, itemId: delivery.itemId, amount: delivery.quantity };
  } catch (error) {
    throw new ServiceError(error.message);
  }
}

export function splitItemDelivery(delivery) {
  if (['spawn_vehicle', 'spawn_armed_npc'].includes(delivery.payload?.actionType)) return Array.from({ length: delivery.amount }, () => ({ ...delivery, amount: 1 }));
  const chunks = [];
  for (let remaining = delivery.amount; remaining > 0; remaining -= 10) {
    const amount = Math.min(10, remaining);
    chunks.push({ ...delivery, amount, payload: delivery.payload ? { ...delivery.payload, quantity: amount } : null });
  }
  return chunks;
}

function generatedSku() {
  return `PRD${Date.now().toString(36).toUpperCase()}${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
}

export function normalizeItems(items) {
  if (!Array.isArray(items) || items.length < 1 || items.length > 50) throw new ServiceError('订单商品必须为 1-50 项');
  const merged = new Map();
  for (const item of items) {
    const sku = String(item?.sku || '').trim();
    if (!SKU_PATTERN.test(sku)) throw new ServiceError('SKU 格式无效');
    const quantity = positiveInt(item?.quantity, '商品数量', 1000);
    const total = (merged.get(sku) || 0) + quantity;
    if (total > 1000) throw new ServiceError('同一 SKU 合并后的商品数量不能超过 1000');
    merged.set(sku, total);
  }
  return [...merged].map(([sku, quantity]) => ({ sku, quantity })).sort((a, b) => a.sku.localeCompare(b.sku));
}

function giftExternalOrderId(giftId, steamId) {
  return giftId === 'default' ? String(steamId) : `${giftId}:${steamId}`;
}

function normalizeGift(gift) {
  const id = String(gift?.id || '').trim();
  if (!SKU_PATTERN.test(id)) throw new ServiceError('礼包 ID 格式无效');
  return { ...gift, id, name: String(gift?.name || '').trim(), category: String(gift?.category || '').trim() };
}

function requestHash(steamId, items) {
  return crypto.createHash('sha256').update(JSON.stringify({ steamId: String(steamId), items })).digest('hex');
}

function orderNo() {
  return `ORD${Date.now()}${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
}

function isDuplicateKey(error) {
  return error?.code === 'ER_DUP_ENTRY' || error?.errno === 1062;
}

function exchangeResult(row, idempotent = false) {
  return {
    id: Number(row.id),
    direction: row.direction,
    inputAmount: Number(row.inputAmount),
    outputAmount: Number(row.outputAmount),
    rate: Number(row.rateSnapshot ?? row.rate),
    coinDelta: Number(row.coinDelta),
    goldDelta: Number(row.goldDelta),
    status: row.status,
    balance: row.balance === undefined ? undefined : Number(row.balance),
    rconResponse: row.rconResponse || null,
    errorMessage: row.errorMessage || null,
    idempotent
  };
}

function assertSameExchange(row, steamId, value) {
  if (String(row.steamId) !== String(steamId)
    || row.direction !== value.direction
    || Number(row.inputAmount) !== value.inputAmount) {
    throw new ServiceError('重复幂等键的兑换内容不一致', 409, 'IDEMPOTENCY_CONFLICT');
  }
  return exchangeResult(row, true);
}

function exchangeText(value) {
  if (value === null || value === undefined) return null;
  const text = typeof value === 'string' ? value : JSON.stringify(value);
  return String(text).slice(0, 500);
}

function exchangeRconResponse(result) {
  const visited = new Set();
  let response = result;
  // Legacy HTTP adds its own response envelope around the gateway payload.
  // Unwrap only supported envelopes; the economy parser still validates the text.
  while (response && typeof response === 'object' && !visited.has(response)) {
    visited.add(response);
    response = response.response ?? response.data;
  }
  return response;
}

function assertExchangeRconResult(result) {
  const pending = [result], visited = new Set();
  let uncertain = false, failed = false, failureMessage;
  // HTTP adapters may wrap a structured reply in response/data. Inspect every
  // envelope before classifying failure: an inner unknown result must not refund.
  while (pending.length) {
    const value = pending.pop();
    if (typeof value === 'string') {
      uncertain ||= /result unknown|command timed out waiting for the SCUM game thread/i.test(value);
      try { assertScumRconSuccess(value); }
      catch (error) {
        failed = true;
        uncertain ||= error.uncertainDelivery === true;
        failureMessage ||= error.message;
      }
    } else if (value && typeof value === 'object' && !visited.has(value)) {
      visited.add(value);
      const status = String(value.status ?? '').toLowerCase();
      uncertain ||= value.uncertainDelivery === true || ['uncertain', 'uncertain_delivery'].includes(status);
      failed ||= value.success === false || ['failed', 'failure', 'error'].includes(status);
      pending.push(value.response, value.data);
    }
  }
  if (!uncertain && !failed) return;
  const error = new Error(failureMessage || exchangeText(result?.response ?? result) || (uncertain ? 'RCON 投递结果不确定' : 'RCON 命令执行失败'));
  error.uncertainDelivery = uncertain;
  throw error;
}

function assertSameRequest(order, hash) {
  if (!order.requestHash || order.requestHash !== hash) throw new ServiceError('重复 orderId 的订单载荷不一致', 409, 'IDEMPOTENCY_CONFLICT');
  return { id: order.id, orderNo: order.orderNo, status: order.status, idempotent: true };
}

export async function recomputeOrderStatus(tx, orderId) {
  const order = (await tx.query('SELECT id,status,source,steam_id AS steamId FROM orders WHERE id = ? FOR UPDATE', [orderId]))[0];
  const rows = await tx.query("SELECT task.status, COUNT(*) AS count FROM fulfillment_tasks task JOIN (SELECT order_item_id, code_index, MAX(generation) AS generation FROM fulfillment_tasks WHERE order_id = ? GROUP BY order_item_id, code_index) latest ON latest.order_item_id = task.order_item_id AND latest.code_index = task.code_index AND latest.generation = task.generation WHERE task.order_id = ? GROUP BY task.status", [orderId, orderId]);
  const counts = new Map(rows.map((row) => [row.status, Number(row.count)]));
  const total = [...counts.values()].reduce((sum, count) => sum + count, 0);
  let status = 'pending';
  if (total > 0 && (counts.get('completed') || 0) === total) status = 'completed';
  else if (counts.has('manual_review')) status = 'manual_review';
  else if (counts.has('failed')) status = 'failed';
  else if (counts.has('processing') || counts.has('dispatching')) status = 'processing';
  await tx.query('UPDATE orders SET status = ? WHERE id = ?', [status, orderId]);
  if (status === 'completed' && order?.status !== 'completed' && order.steamId && ['shop','gift'].includes(order.source)) {
    const policy = (await tx.query('SELECT consumption_upgrade_enabled AS enabled,upgrade_gift_enabled AS giftEnabled,upgrade_gift_amount AS giftAmount FROM membership_policy WHERE id=1'))[0];
    if (policy?.enabled) {
      const spent = Number((await tx.query("SELECT COALESCE(SUM(total_amount),0) AS total FROM orders WHERE steam_id=? AND status='completed' AND source IN ('shop','gift')", [order.steamId]))[0]?.total || 0);
      const target = (await tx.query('SELECT level FROM membership_strategies WHERE enabled=1 AND level>0 AND upgrade_spend<=? ORDER BY level DESC LIMIT 1', [spent]))[0];
      const user = (await tx.query('SELECT `商城用户编号` AS id,`会员等级` AS memberLevel,`会员到期时间` AS memberExpiresAt FROM `商城用户` WHERE `SteamID`=? FOR UPDATE', [order.steamId]))[0];
      if (target && user && Number(target.level) > Number(user.memberLevel || 0)) {
        const gift = policy.giftEnabled ? Number(policy.giftAmount || 0) : 0;
        await tx.query('UPDATE `商城用户` SET `会员等级`=?,`会员到期时间`=NULL,`商城币余额`=`商城币余额`+? WHERE `商城用户编号`=?', [target.level, gift, user.id]);
        await tx.query('INSERT INTO membership_change_logs (steam_id,old_level,new_level,old_expires_at,new_expires_at,reason,operator) VALUES (?,?,?,?,NULL,?,?)', [order.steamId, Number(user.memberLevel || 0), target.level, user.memberExpiresAt || null, '累计消费自动升级', 'system']);
        if (gift > 0) {
          const balance = Number((await tx.query('SELECT `商城币余额` AS balance FROM `商城用户` WHERE `SteamID`=?', [order.steamId]))[0].balance);
          await tx.query("INSERT INTO coin_ledger (steam_id,amount,balance_after,type,reference_type,reference_id,note) VALUES (?,?,?,'membership_upgrade_gift','order',?,'消费升级赠送')", [order.steamId, gift, balance, String(orderId)]);
        }
      }
    }
  }
  return status;
}

export function calculatePresence(events, online, now = Date.now()) {
  const nowMs = Number(now);
  let sessionStartedAt = null;
  let totalOnlineSeconds = 0;
  for (const event of events) {
    const observedMs = new Date(event.observedAt).getTime();
    if (!Number.isFinite(observedMs) || observedMs > nowMs) continue;
    if (event.eventType === 'online') {
      if (sessionStartedAt === null) sessionStartedAt = observedMs;
    } else if (event.eventType === 'offline' && sessionStartedAt !== null) {
      totalOnlineSeconds += Math.max(0, Math.floor((observedMs - sessionStartedAt) / 1000));
      sessionStartedAt = null;
    }
  }
  const currentSessionSeconds = online && sessionStartedAt !== null ? Math.max(0, Math.floor((nowMs - sessionStartedAt) / 1000)) : null;
  if (currentSessionSeconds !== null) totalOnlineSeconds += currentSessionSeconds;
  return { currentSessionStartedAt: online && sessionStartedAt !== null ? new Date(sessionStartedAt).toISOString() : null, currentSessionSeconds, totalOnlineSeconds };
}

export class CommerceService {
  constructor(db, clock = () => Date.now()) {
    this.db = db;
    this.clock = clock;
  }

  async dashboard() {
    const [accounts, products, orders, tasks] = await Promise.all([
      this.db.query("SELECT COUNT(`SteamID`) AS count,COALESCE(SUM(`商城币余额`),0) AS total_balance,COUNT(DISTINCT CASE WHEN `SteamID` IS NOT NULL AND NULLIF(TRIM(`登录账号`),'') IS NOT NULL AND `账户状态`='active' THEN `SteamID` END) AS registered_count FROM `商城用户`"),
      this.db.query('SELECT COUNT(*) AS count, SUM(enabled = 1) AS enabled_count FROM products'),
      this.db.query("SELECT COUNT(*) AS count, SUM(status = 'completed') AS completed_count FROM orders"),
      this.db.query("SELECT COUNT(*) AS count, SUM(status IN ('pending','waiting_instance','waiting_offline','retry')) AS waiting_count, SUM(status IN ('failed','manual_review')) AS failed_count, SUM(status = 'completed' AND updated_at >= CURRENT_DATE() AND updated_at < CURRENT_DATE() + INTERVAL 1 DAY) AS today_processed_count FROM fulfillment_tasks")
    ]);
    return { accounts: accounts[0], products: products[0], orders: orders[0], tasks: tasks[0] };
  }

  async listProducts({ includeDisabled = true, publicView = false } = {}) {
    const columns = publicView
      ? "p.id, p.sku, p.name, p.price, p.parent_category AS parentCategory, p.category_name AS category, COALESCE(pc.sort_order,2147483647) AS parentSortOrder, COALESCE(cc.sort_order,2147483647) AS categorySortOrder, p.currency_type AS currencyType, p.min_member_level AS minMemberLevel, p.image_path AS imagePath, p.created_at AS createdAt, p.updated_at AS updatedAt, (SELECT MAX(o.created_at) FROM order_items oi JOIN orders o ON o.id = oi.order_id WHERE oi.product_id = p.id AND o.source = 'shop' AND o.status = 'completed') AS lastPurchasedAt"
      : 'p.id, p.sku, p.name, p.price, p.item_id AS itemId, p.grant_amount AS grantAmount, p.parent_category AS parentCategory, p.category_name AS category, p.currency_type AS currencyType, p.min_member_level AS minMemberLevel, p.max_uses AS maxUses, p.image_path AS imagePath, p.fulfillment_codes AS fulfillmentCodes, p.enabled, p.created_at AS createdAt, p.updated_at AS updatedAt';
    const rows = await this.db.query(`SELECT ${columns} FROM products p LEFT JOIN product_parent_categories pc ON pc.name=p.parent_category${publicView ? ' LEFT JOIN product_categories cc ON cc.parent_name=p.parent_category AND cc.name=p.category_name' : ''}${publicView || !includeDisabled ? ' WHERE enabled = 1' : ''} ORDER BY COALESCE(pc.sort_order,2147483647),p.parent_category,${publicView ? 'COALESCE(cc.sort_order,2147483647)' : 'p.category_name'},p.category_name,p.id`);
    if (publicView) return rows;
    return rows.map((row) => {
      const codes = normalizeFulfillmentCodes(row.fulfillmentCodes || row.itemId);
      return { ...row, enabled: Boolean(Number(row.enabled)), fulfillmentCodes: codes.join(','), codes };
    });
  }

  async listProductCategories() {
    const rows = await this.db.query('SELECT id, parent_name AS parentCategory, name AS category, sort_order AS sortOrder FROM product_categories ORDER BY parent_name, sort_order, id');
    return rows.map((row) => ({ ...row, id: Number(row.id), sortOrder: Number(row.sortOrder) }));
  }

  async listProductParentCategories() {
    const rows = await this.db.query('SELECT id,name,sort_order AS sortOrder FROM product_parent_categories ORDER BY sort_order,id');
    return rows.map((row) => ({ ...row, id: Number(row.id), sortOrder: Number(row.sortOrder) }));
  }

  async saveProductParentCategory(input) {
    const name = optionalText(input.name, '主分类', 100);
    if (!name) throw new ServiceError('主分类不能为空');
    const rows = await this.db.query('SELECT COALESCE(MAX(sort_order),-1)+1 AS nextOrder FROM product_parent_categories');
    const sortOrder = Number(rows[0]?.nextOrder || 0);
    const result = await this.db.query('INSERT INTO product_parent_categories (name,sort_order) VALUES (?,?)', [name, sortOrder]);
    return { id: Number(result.insertId), name, sortOrder };
  }

  async reorderProductParentCategories(input) {
    const ids = Array.isArray(input.ids) ? input.ids.map((id) => positiveInt(id, '主分类 ID')) : [];
    if (!ids.length || new Set(ids).size !== ids.length) throw new ServiceError('主分类顺序无效');
    const rows = await this.db.query('SELECT id FROM product_parent_categories ORDER BY sort_order,id');
    const existing = rows.map((row) => Number(row.id));
    if (ids.length !== existing.length || ids.some((id) => !existing.includes(id))) throw new ServiceError('主分类顺序不完整');
    const cases = ids.map(() => 'WHEN ? THEN ?').join(' ');
    const params = ids.flatMap((id, index) => [id, index]);
    await this.db.query(`UPDATE product_parent_categories SET sort_order=CASE id ${cases} END WHERE id IN (${ids.map(() => '?').join(',')})`, [...params, ...ids]);
  }

  async deleteProductParentCategory(id) {
    const parentId = positiveInt(id, '主分类 ID');
    await this.db.transaction(async (tx) => {
      const rows = await tx.query('SELECT name FROM product_parent_categories WHERE id=? FOR UPDATE', [parentId]);
      if (!rows[0]) throw new ServiceError('主分类不存在', 404, 'NOT_FOUND');
      const used = await tx.query('SELECT COUNT(*) AS count FROM products WHERE parent_category=?', [rows[0].name]);
      if (Number(used[0]?.count || 0) > 0) throw new ServiceError('该主分类正在被商品使用，无法删除');
      await tx.query('DELETE FROM product_categories WHERE parent_name=?', [rows[0].name]);
      await tx.query('DELETE FROM product_parent_categories WHERE id=?', [parentId]);
    });
  }

  async renameProductParentCategory(id, input) {
    const parentId = positiveInt(id, '主分类 ID');
    const name = optionalText(input.name, '主分类', 100);
    if (!name) throw new ServiceError('主分类不能为空');
    await this.db.transaction(async (tx) => {
      const rows = await tx.query('SELECT name FROM product_parent_categories WHERE id=? FOR UPDATE', [parentId]);
      if (!rows[0]) throw new ServiceError('主分类不存在', 404, 'NOT_FOUND');
      const oldName = rows[0].name;
      await tx.query('UPDATE product_parent_categories SET name=? WHERE id=?', [name, parentId]);
      await tx.query('UPDATE product_categories SET parent_name=? WHERE parent_name=?', [name, oldName]);
      await tx.query('UPDATE products SET parent_category=? WHERE parent_category=?', [name, oldName]);
    });
    return { id: parentId, name };
  }

  async saveProductCategory(input) {
    const parentCategory = optionalText(input.parentCategory, '主分类', 100);
    const category = optionalText(input.category, '副分类', 100);
    if (!parentCategory || !category) throw new ServiceError('主分类和副分类不能为空');
    const parent = await this.db.query('SELECT id FROM product_parent_categories WHERE name=?', [parentCategory]);
    if (!parent[0]) throw new ServiceError('主分类不存在');
    const rows = await this.db.query('SELECT COALESCE(MAX(sort_order),-1)+1 AS nextOrder FROM product_categories WHERE parent_name=?', [parentCategory]);
    const result = await this.db.query('INSERT INTO product_categories (parent_name,name,sort_order) VALUES (?,?,?)', [parentCategory, category, Number(rows[0]?.nextOrder || 0)]);
    return { id: Number(result.insertId), parentCategory, category };
  }

  async reorderProductCategories(input) {
    const parentCategory = optionalText(input.parentCategory, '主分类', 100);
    const ids = Array.isArray(input.ids) ? input.ids.map((id) => positiveInt(id, '副分类 ID')) : [];
    if (!parentCategory || !ids.length || new Set(ids).size !== ids.length) throw new ServiceError('副分类顺序无效');
    const rows = await this.db.query('SELECT id FROM product_categories WHERE parent_name=? ORDER BY sort_order,id', [parentCategory]);
    const existing = rows.map((row) => Number(row.id));
    if (ids.length !== existing.length || ids.some((id) => !existing.includes(id))) throw new ServiceError('副分类顺序不完整');
    const cases = ids.map(() => 'WHEN ? THEN ?').join(' ');
    const params = ids.flatMap((id, index) => [id, index]);
    await this.db.query(`UPDATE product_categories SET sort_order=CASE id ${cases} END WHERE parent_name=? AND id IN (${ids.map(() => '?').join(',')})`, [...params, parentCategory, ...ids]);
  }

  async deleteProductCategory(id) {
    const categoryId = positiveInt(id, '分类 ID');
    const rows = await this.db.query('SELECT parent_name AS parentCategory, name AS category FROM product_categories WHERE id=?', [categoryId]);
    if (!rows[0]) throw new ServiceError('分类不存在', 404, 'NOT_FOUND');
    const used = await this.db.query('SELECT COUNT(*) AS count FROM products WHERE parent_category=? AND category_name=?', [rows[0].parentCategory, rows[0].category]);
    if (Number(used[0]?.count || 0) > 0) throw new ServiceError('该分类正在被商品使用，无法删除');
    await this.db.query('DELETE FROM product_categories WHERE id=?', [categoryId]);
  }

  async renameProductCategory(id, input) {
    const categoryId = positiveInt(id, '副分类 ID');
    const name = optionalText(input.name, '副分类', 100);
    if (!name) throw new ServiceError('副分类不能为空');
    await this.db.transaction(async (tx) => {
      const rows = await tx.query('SELECT parent_name AS parentCategory, name AS category FROM product_categories WHERE id=? FOR UPDATE', [categoryId]);
      if (!rows[0]) throw new ServiceError('副分类不存在', 404, 'NOT_FOUND');
      await tx.query('UPDATE product_categories SET name=? WHERE id=?', [name, categoryId]);
      await tx.query('UPDATE products SET category_name=? WHERE parent_category=? AND category_name=?', [name, rows[0].parentCategory, rows[0].category]);
    });
    return { id: categoryId, name };
  }

  async saveProduct(input, id = null) {
    const name = String(input.name || '').trim();
    if (!name || name.length > 100) throw new ServiceError('商品名称长度必须为 1-100');
    const price = nonNegativeInt(input.price, '商品价格');
    const parentCategory = optionalText(input.parentCategory, '父级分类', 100);
    const category = optionalText(input.category, '分类', 100);
    const currencyType = normalizeCurrencyType(input.currencyType);
    const minMemberLevel = nonNegativeInt(input.minMemberLevel ?? 0, '会员限制等级');
    const maxUses = input.maxUses === null || input.maxUses === undefined || input.maxUses === '' ? null : positiveInt(input.maxUses, '最大使用次数', 1000000);
    const imagePath = normalizeImagePath(input.imagePath);
    const codes = normalizeFulfillmentCodes(input.fulfillmentCodes ?? input.codes ?? input.itemId).map((code) => {
      if (parentCategory !== 'NPC' || category !== '动物') return code;
      if (/^#spawnitem\s+/i.test(code)) return code.replace(/^#spawnitem\s+/i, '#spawnanimal ');
      if (/^#spawnanimal\s+/i.test(code)) return code.replace(/^#spawnanimal\s+/i, '#spawnanimal ');
      return code;
    });
    const fulfillmentCodes = codes.join(',');
    const itemId = parseProductCode(codes[0], { allowVehicle: true }).itemId;
    const enabled = input.enabled === undefined ? true : Boolean(input.enabled);
    if (id === null) {
      let sku = String(input.sku || '').trim();
      if (sku && !SKU_PATTERN.test(sku)) throw new ServiceError('SKU 格式无效');
      for (let attempt = 0; attempt < 5; attempt += 1) {
        if (!sku) sku = generatedSku();
        try {
          const result = await this.db.query('INSERT INTO products (sku, name, price, item_id, grant_amount, parent_category, category_name, currency_type, min_member_level, max_uses, image_path, fulfillment_codes, enabled) VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?)', [sku, name, price, itemId, parentCategory || null, category || null, currencyType, minMemberLevel, maxUses, imagePath || null, fulfillmentCodes, enabled]);
          return { id: result.insertId, sku, name, price, itemId, grantAmount: 1, parentCategory, category, currencyType, minMemberLevel, maxUses, imagePath, fulfillmentCodes, codes, enabled };
        } catch (error) {
          if (input.sku || !isDuplicateKey(error) || attempt === 4) throw error;
          sku = '';
        }
      }
    }
    const productId = positiveInt(id, '商品 ID');
    const existing = await this.db.query('SELECT sku, grant_amount AS grantAmount FROM products WHERE id = ?', [productId]);
    if (!existing[0]) throw new ServiceError('商品不存在', 404, 'NOT_FOUND');
    const sku = String(input.sku ?? existing[0].sku).trim();
    if (!SKU_PATTERN.test(sku)) throw new ServiceError('SKU 格式无效');
    const grantAmount = positiveInt(existing[0].grantAmount, '发放数量', 100000);
    const result = await this.db.query('UPDATE products SET sku = ?, name = ?, price = ?, item_id = ?, parent_category = ?, category_name = ?, currency_type = ?, min_member_level = ?, max_uses = ?, image_path = ?, fulfillment_codes = ?, enabled = ? WHERE id = ?', [sku, name, price, itemId, parentCategory || null, category || null, currencyType, minMemberLevel, maxUses, imagePath || null, fulfillmentCodes, enabled, productId]);
    if (!result.affectedRows) throw new ServiceError('商品不存在', 404, 'NOT_FOUND');
    return { id: productId, sku, name, price, itemId, grantAmount, parentCategory, category, currencyType, minMemberLevel, maxUses, imagePath, fulfillmentCodes, codes, enabled };
  }

  async setProductEnabled(id, enabled) {
    const result = await this.db.query('UPDATE products SET enabled = ? WHERE id = ?', [Boolean(enabled), positiveInt(id, '商品 ID')]);
    if (!result.affectedRows) throw new ServiceError('商品不存在', 404, 'NOT_FOUND');
  }

  async setAllProductsEnabled(enabled) {
    const result = await this.db.query('UPDATE products SET enabled = ?', [Boolean(enabled)]);
    return { affectedRows: Number(result.affectedRows || 0) };
  }

  async deleteProduct(id) {
    const { deleteProduct } = await import('./deletion-service.js');
    const result = await this.db.transaction((tx) => deleteProduct(tx, id));
    return result;
  }

  async getAccount(steamId) {
    if (!isSteamId64(steamId)) throw new ServiceError('SteamID 格式无效');
    const id = String(steamId);
    const accounts = await this.db.query('SELECT u.`SteamID` AS steamId,u.`商城币余额` AS balance,u.`游戏名称` AS storedCharacterName,u.`游戏币` AS storedGameMoney,u.`游戏金条` AS storedGameGold,u.`最后游戏在线时间` AS storedGameSeenAt,u.`最后游戏在线时间` AS updatedAt,u.`登录账号` AS username,u.`用户角色` AS role,u.`账户状态` AS status,COALESCE(u.`会员等级`,0) AS rawMemberLevel,u.`会员到期时间` AS memberExpiresAt,CASE WHEN COALESCE(u.`会员等级`,0)>0 AND (u.`会员到期时间` IS NULL OR u.`会员到期时间`>CURRENT_TIMESTAMP(3)) THEN u.`会员等级` ELSE 0 END AS memberLevel,u.`最后登录时间` AS lastLogin,u.`商城账户创建时间` AS userCreatedAt,EXISTS(SELECT 1 FROM shop_sessions active_session WHERE active_session.user_id=u.`商城用户编号` AND active_session.expires_at>CURRENT_TIMESTAMP(3) AND active_session.revoked_at IS NULL) AS shopOnline FROM `商城用户` u WHERE u.`SteamID`=?', [id]);
    if (!accounts[0]) throw new ServiceError('玩家账户不存在', 404, 'NOT_FOUND');
    const [currentSnapshots, latestSnapshots, events, titles, squads, giftStats, giftClaims, orderStats, orders, ledgerStats, ledger] = await Promise.all([
      this.db.query("SELECT p.character_name AS characterName, p.steam_name AS steamName, p.is_admin AS isAdmin, p.money, p.gold, p.observed_at AS observedAt, p.sample_id AS sampleId FROM online_player_snapshots p INNER JOIN server_monitor_samples s ON s.id=p.sample_id WHERE p.steam_id = ? AND s.id=(SELECT MAX(id) FROM server_monitor_samples) AND s.status='ok' AND s.player_query_ok=1 AND s.sampled_at>=DATE_SUB(UTC_TIMESTAMP(3), INTERVAL 2 MINUTE)", [id]),
      this.db.query('SELECT character_name AS characterName, steam_name AS steamName, is_admin AS isAdmin, money, gold, observed_at AS observedAt FROM online_player_snapshots WHERE steam_id = ? ORDER BY observed_at DESC, sample_id DESC LIMIT 1', [id]),
      this.db.query('SELECT event_type AS eventType, character_name AS characterName, steam_name AS steamName, is_admin AS isAdmin, observed_at AS observedAt FROM player_presence_events WHERE steam_id = ? ORDER BY observed_at, id', [id]),
      this.db.query('SELECT title_name AS titleName, expires_at AS expiresAt, created_at AS createdAt, updated_at AS updatedAt FROM player_titles WHERE steam_id = ? ORDER BY title_name', [id]),
      this.db.query('SELECT `小队编号` AS squadId, `小队名称` AS squadName, `小队更新时间` AS updatedAt FROM `商城用户` WHERE `SteamID` = ? AND `小队编号` IS NOT NULL', [id]),
      this.db.query('SELECT COUNT(*) AS claimCount, MAX(created_at) AS lastClaimAt, COALESCE(SUM(price_paid), 0) AS totalPricePaid FROM gift_claims WHERE steam_id = ?', [id]),
      this.db.query('SELECT g.name AS giftName, c.steam_id AS steamId, o.order_no AS orderNo, o.status, c.price_paid AS pricePaid, c.created_at AS createdAt FROM gift_claims c JOIN gift_packages g ON g.id=c.gift_id LEFT JOIN orders o ON o.id=c.order_id WHERE c.steam_id=? ORDER BY c.created_at DESC LIMIT 100', [id]),
      this.db.query("SELECT COUNT(*) AS orderCount, COALESCE(SUM(total_amount), 0) AS totalAmount, SUM(status = 'completed') AS completedCount, SUM(status <> 'completed') AS abnormalCount, COALESCE(SUM(CASE WHEN status = 'completed' THEN total_amount ELSE 0 END), 0) AS completedAmount, MAX(created_at) AS lastOrderAt FROM orders WHERE steam_id = ?", [id]),
      this.db.query("SELECT o.id,o.order_no AS orderNo,o.source,o.total_amount AS totalAmount,o.status,o.created_at AS createdAt,COALESCE((SELECT GROUP_CONCAT(CONCAT(oi.name,IF(oi.quantity>1,CONCAT(' × ',oi.quantity),'')) ORDER BY oi.id SEPARATOR '、') FROM order_items oi WHERE oi.order_id=o.id),'--') AS items FROM orders o WHERE o.steam_id=? ORDER BY o.id DESC LIMIT 100", [id]),
      this.db.query('SELECT COUNT(*) AS ledgerCount, COALESCE(SUM(amount), 0) AS netAmount, COALESCE(SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END), 0) AS totalIncome, MAX(created_at) AS lastLedgerAt FROM coin_ledger WHERE steam_id = ?', [id]),
      this.db.query("SELECT l.id,l.amount,l.balance_after AS balanceAfter,l.type,l.reference_type AS referenceType,l.reference_id AS referenceId,l.note,CASE WHEN l.type='order_purchase' AND l.reference_type='order' THEN COALESCE((SELECT GROUP_CONCAT(CONCAT(oi.name,IF(oi.quantity>1,CONCAT(' × ',oi.quantity),'')) ORDER BY oi.id SEPARATOR '、') FROM order_items oi WHERE oi.order_id=CAST(l.reference_id AS UNSIGNED)),l.note) ELSE l.note END AS displayNote,l.created_at AS createdAt FROM coin_ledger l WHERE l.steam_id=? ORDER BY l.id DESC LIMIT 100", [id])
    ]);
    const current = currentSnapshots[0] || null;
    const winnings = await this.db.query('SELECT d.id,d.reward_name_snapshot AS rewardName,d.prize_snapshot_json AS snapshot,d.created_at AS createdAt,b.balance_after AS balanceAfter FROM lottery_draws d JOIN lottery_batches b ON b.id=d.batch_id WHERE b.steam_id=? ORDER BY d.id DESC LIMIT 100', [id]);
    for (const win of winnings) {
      let snapshot = win.snapshot || {}; if (typeof snapshot === 'string') { try { snapshot = JSON.parse(snapshot); } catch { snapshot = {}; } }
      const reward = lotteryRewardDisplay(snapshot);
      ledger.push({ id:'lottery-win-'+win.id, type:'lottery_win', amount:0, balanceAfter:win.balanceAfter, displayNote:(win.rewardName || snapshot.name || '中奖奖品')+' × '+reward.quantityText, createdAt:win.createdAt });
    }
    ledger.sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
    const stored = accounts[0].storedGameSeenAt ? { characterName: accounts[0].storedCharacterName, steamName: '', money: accounts[0].storedGameMoney, gold: accounts[0].storedGameGold, observedAt: accounts[0].storedGameSeenAt } : null;
    const latestIdentity = current || latestSnapshots[0] || [...events].reverse().find((event) => event.characterName || event.steamName) || stored || null;
    const assetSnapshots = [stored, current, latestSnapshots[0]].filter(Boolean).sort((left, right) => new Date(right.observedAt).getTime() - new Date(left.observedAt).getTime());
    const latestMoney = assetSnapshots.find((snapshot) => snapshot.money !== null && snapshot.money !== undefined)?.money;
    const latestGold = assetSnapshots.find((snapshot) => snapshot.gold !== null && snapshot.gold !== undefined)?.gold;
    const online = Boolean(current);
    const presence = calculatePresence(events, online, this.clock());
    const observedTimes = [...events.map((event) => event.observedAt), latestSnapshots[0]?.observedAt].filter(Boolean).map((value) => new Date(value).getTime()).filter(Number.isFinite);
    const lastOnlineAt = observedTimes.length ? new Date(Math.max(...observedTimes)).toISOString() : null;
    return {
      ...accounts[0],
      characterName: latestIdentity?.characterName || null,
      steamName: latestIdentity?.steamName || null,
      isAdmin: Boolean(latestIdentity?.isAdmin),
      gameMoney: latestMoney === undefined ? null : Number(latestMoney),
      gameGold: latestGold === undefined ? null : Number(latestGold),
      online,
      currentSnapshotAt: current?.observedAt || null,
      lastOnlineAt,
      ...presence,
      titles,
      squad: squads[0] || null,
      giftStats: { claimCount: Number(giftStats[0]?.claimCount || 0), lastClaimAt: giftStats[0]?.lastClaimAt || null, totalPricePaid: Number(giftStats[0]?.totalPricePaid || 0) },
      giftClaims,
      orderStats: { orderCount: Number(orderStats[0]?.orderCount || 0), totalAmount: Number(orderStats[0]?.totalAmount || 0), completedCount: Number(orderStats[0]?.completedCount || 0), abnormalCount: Number(orderStats[0]?.abnormalCount || 0), completedAmount: Number(orderStats[0]?.completedAmount || 0), lastOrderAt: orderStats[0]?.lastOrderAt || null },
      orders: orders.map((order) => ({ ...order, totalAmount: Number(order.totalAmount || 0) })),
      ledgerStats: { ledgerCount: Number(ledgerStats[0]?.ledgerCount || 0), netAmount: Number(ledgerStats[0]?.netAmount || 0), totalIncome: Number(ledgerStats[0]?.totalIncome || 0), lastLedgerAt: ledgerStats[0]?.lastLedgerAt || null },
      ledger
    };
  }

  async membershipPolicy() {
    const rows = await this.db.query("SELECT open_enabled AS openEnabled,consumption_upgrade_enabled AS consumptionUpgradeEnabled,renewal_enabled AS renewalEnabled,renewal_price_strategy AS renewalPriceStrategy,renewal_gift_enabled AS renewalGiftEnabled,renewal_discount AS renewalDiscount,renewal_fixed_price AS renewalFixedPrice,upgrade_strategy AS upgradeStrategy,upgrade_expiry_strategy AS upgradeExpiryStrategy,upgrade_gift_enabled AS upgradeGiftEnabled,upgrade_gift_amount AS upgradeGiftAmount,lower_level_purchase AS lowerLevelPurchase,updated_at AS updatedAt FROM membership_policy WHERE id=1");
    const row = rows[0] || {};
    return { openEnabled: Boolean(row.openEnabled), consumptionUpgradeEnabled: Boolean(row.consumptionUpgradeEnabled), renewalEnabled: Boolean(row.renewalEnabled), renewalPriceStrategy: row.renewalPriceStrategy || 'original', renewalGiftEnabled: Boolean(row.renewalGiftEnabled), renewalDiscount: Number(row.renewalDiscount ?? 100), renewalFixedPrice: Number(row.renewalFixedPrice || 0), upgradeStrategy: row.upgradeStrategy || 'allow', upgradeExpiryStrategy: row.upgradeExpiryStrategy || 'extend', upgradeGiftEnabled: Boolean(row.upgradeGiftEnabled), upgradeGiftAmount: Number(row.upgradeGiftAmount || 0), lowerLevelPurchase: row.lowerLevelPurchase || 'forbid', updatedAt: row.updatedAt || null };
  }

  async membershipEntitlements(steamId) {
    if (!isSteamId64(steamId)) throw new ServiceError('SteamID 格式无效');
    const rows = await this.db.query("SELECT CASE WHEN u.`会员等级`>0 AND (u.`会员到期时间` IS NULL OR u.`会员到期时间`>CURRENT_TIMESTAMP(3)) THEN u.`会员等级` ELSE 0 END AS memberLevel,u.`会员到期时间` AS memberExpiresAt,s.title,s.teleport_discount AS teleportDiscount,s.online_bonus AS onlineBonus,s.shopping_discount AS shoppingDiscount,s.gift_discount AS giftDiscount,s.recharge_bonus AS rechargeBonus,s.daily_teleports AS dailyTeleports,s.checkin_bonus AS checkinBonus FROM `商城用户` u LEFT JOIN membership_strategies s ON s.level=CASE WHEN u.`会员等级`>0 AND (u.`会员到期时间` IS NULL OR u.`会员到期时间`>CURRENT_TIMESTAMP(3)) THEN u.`会员等级` ELSE 0 END WHERE u.`SteamID`=?", [String(steamId)]);
    const row = rows[0];
    if (!row) throw new ServiceError('商城用户不存在', 404, 'NOT_FOUND');
    return { memberLevel: Number(row.memberLevel || 0), memberExpiresAt: row.memberExpiresAt || null, title: row.title || '默认玩家', teleportDiscount: Number(row.teleportDiscount ?? 100), onlineBonus: Number(row.onlineBonus ?? 100), shoppingDiscount: Number(row.shoppingDiscount ?? 100), giftDiscount: Number(row.giftDiscount ?? 100), rechargeBonus: Number(row.rechargeBonus ?? 100), dailyTeleports: Number(row.dailyTeleports || 0), checkinBonus: Number(row.checkinBonus || 0) };
  }

  async saveMembershipPolicy(input) {
    const value = membershipPolicyInput(input);
    await this.db.query('INSERT INTO membership_policy (id,open_enabled,consumption_upgrade_enabled,renewal_enabled,renewal_price_strategy,renewal_gift_enabled,renewal_discount,renewal_fixed_price,upgrade_strategy,upgrade_expiry_strategy,upgrade_gift_enabled,upgrade_gift_amount,lower_level_purchase) VALUES (1,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE open_enabled=VALUES(open_enabled),consumption_upgrade_enabled=VALUES(consumption_upgrade_enabled),renewal_enabled=VALUES(renewal_enabled),renewal_price_strategy=VALUES(renewal_price_strategy),renewal_gift_enabled=VALUES(renewal_gift_enabled),renewal_discount=VALUES(renewal_discount),renewal_fixed_price=VALUES(renewal_fixed_price),upgrade_strategy=VALUES(upgrade_strategy),upgrade_expiry_strategy=VALUES(upgrade_expiry_strategy),upgrade_gift_enabled=VALUES(upgrade_gift_enabled),upgrade_gift_amount=VALUES(upgrade_gift_amount),lower_level_purchase=VALUES(lower_level_purchase)', [value.openEnabled, value.consumptionUpgradeEnabled, value.renewalEnabled, value.renewalPriceStrategy, value.renewalGiftEnabled, value.renewalDiscount, value.renewalFixedPrice, value.upgradeStrategy, value.upgradeExpiryStrategy, value.upgradeGiftEnabled, value.upgradeGiftAmount, value.lowerLevelPurchase]);
    return value;
  }

  async purchaseMembership(steamId, levelValue, requestKey) {
    if (!isSteamId64(steamId)) throw new ServiceError('SteamID 格式无效');
    const targetLevel = positiveInt(levelValue, '会员等级', 100);
    const key = String(requestKey || '').trim();
    if (!key || key.length > 100) throw new ServiceError('Idempotency-Key 长度必须为 1-100');
    return this.db.transaction(async (tx) => {
      const repeated = await tx.query('SELECT id,steam_id AS steamId,new_level AS memberLevel,price,gift_tokens AS giftTokens,expires_at AS memberExpiresAt,balance_after AS balanceAfter FROM membership_purchases WHERE request_key=? FOR UPDATE', [key]);
      if (repeated[0]) {
        if (String(repeated[0].steamId) !== String(steamId) || Number(repeated[0].memberLevel) !== targetLevel) throw new ServiceError('Idempotency-Key 已被其他会员购买请求使用', 409, 'IDEMPOTENCY_CONFLICT');
        return { ...repeated[0], idempotent: true };
      }
      const policy = (await tx.query('SELECT * FROM membership_policy WHERE id=1 FOR UPDATE'))[0] || {};
      const target = (await tx.query('SELECT level,title,opening_amount AS openingAmount,period_days AS periodDays,gift_tokens AS giftTokens FROM membership_strategies WHERE enabled=1 AND level=? FOR UPDATE', [targetLevel]))[0];
      if (!target) throw new ServiceError('会员等级当前不可购买', 404, 'NOT_FOUND');
      const user = (await tx.query("SELECT `商城用户编号` AS id,`会员等级` AS memberLevel,`会员到期时间` AS memberExpiresAt,`商城币余额` AS balance FROM `商城用户` WHERE `SteamID`=? AND `账户状态`='active' FOR UPDATE", [String(steamId)]))[0];
      if (!user) throw new ServiceError('商城用户不存在或已停用', 403, 'SHOP_USER_UNAVAILABLE');
      const account = user;
      const now = this.clock(), oldLevel = Number(user.memberLevel || 0);
      const active = oldLevel > 0 && (!user.memberExpiresAt || new Date(user.memberExpiresAt).getTime() > now);
      let purchaseType = 'open', price = Number(target.openingAmount), giftTokens = Number(target.giftTokens || 0), base = new Date(now);
      if (!active) {
        if (!policy.open_enabled) throw new ServiceError('会员开通当前已关闭', 409, 'MEMBERSHIP_OPEN_DISABLED');
      } else if (oldLevel === targetLevel) {
        if (!policy.renewal_enabled) throw new ServiceError('同等级续费当前已关闭', 409, 'MEMBERSHIP_RENEW_DISABLED');
        purchaseType = 'renew';
        base = user.memberExpiresAt ? new Date(Math.max(now, new Date(user.memberExpiresAt).getTime())) : new Date(now);
        if (policy.renewal_price_strategy === 'discount') price = Math.round(price * Number(policy.renewal_discount) / 100);
        else if (policy.renewal_price_strategy === 'fixed') price = Number(policy.renewal_fixed_price || 0);
        giftTokens = policy.renewal_gift_enabled ? Number(target.giftTokens || 0) : 0;
      } else if (targetLevel > oldLevel) {
        if (policy.upgrade_strategy !== 'allow') throw new ServiceError('高级会员升级当前已关闭', 409, 'MEMBERSHIP_UPGRADE_DISABLED');
        purchaseType = 'upgrade';
        const current = (await tx.query('SELECT opening_amount AS openingAmount FROM membership_strategies WHERE level=?', [oldLevel]))[0];
        price = Math.max(0, Number(target.openingAmount) - Number(current?.openingAmount || 0));
        giftTokens = policy.upgrade_gift_enabled ? Number(policy.upgrade_gift_amount || 0) : 0;
        base = policy.upgrade_expiry_strategy === 'extend' && user.memberExpiresAt ? new Date(Math.max(now, new Date(user.memberExpiresAt).getTime())) : new Date(now);
      } else {
        if (policy.lower_level_purchase !== 'allow') throw new ServiceError('禁止购买低等级会员', 409, 'LOWER_LEVEL_FORBIDDEN');
        purchaseType = 'lower';
      }
      const expiresAt = new Date(base.getTime() + Number(target.periodDays) * 86400000);
      const balance = Number(account.balance);
      if (balance < price) throw new ServiceError('商城币余额不足', 409, 'INSUFFICIENT_BALANCE');
      const after = balance - price + giftTokens;
      await tx.query('UPDATE `商城用户` SET `会员等级`=?,`会员到期时间`=?,`商城币余额`=? WHERE `商城用户编号`=?', [targetLevel, expiresAt, after, user.id]);
      const inserted = await tx.query('INSERT INTO membership_purchases (request_key,steam_id,old_level,new_level,purchase_type,price,gift_tokens,expires_at,balance_after) VALUES (?,?,?,?,?,?,?,?,?)', [key, String(steamId), oldLevel, targetLevel, purchaseType, price, giftTokens, expiresAt, after]);
      await tx.query('INSERT INTO membership_change_logs (steam_id,old_level,new_level,old_expires_at,new_expires_at,reason,operator) VALUES (?,?,?,?,?,?,?)', [String(steamId), oldLevel, targetLevel, user.memberExpiresAt || null, expiresAt, '会员' + purchaseType, 'shop']);
      await tx.query("INSERT INTO coin_ledger (steam_id,amount,balance_after,type,reference_type,reference_id,note) VALUES (?,?,?,'membership_purchase','membership_purchase',?,?)", [String(steamId), -price + giftTokens, after, String(inserted.insertId), target.title + ' ' + purchaseType]);
      return { id: inserted.insertId, memberLevel: targetLevel, memberExpiresAt: expiresAt, price, giftTokens, balanceAfter: after, purchaseType, idempotent: false };
    });
  }

  async membershipStats() {
    const rows = await this.db.query("SELECT SUM(`会员等级`>0) AS total,SUM(`会员等级`>0 AND (`会员到期时间` IS NULL OR `会员到期时间`>CURRENT_TIMESTAMP(3))) AS active,SUM(`会员等级`>0 AND `会员到期时间`>CURRENT_TIMESTAMP(3) AND `会员到期时间`<=DATE_ADD(CURRENT_TIMESTAMP(3),INTERVAL 7 DAY)) AS expiringSoon,SUM(`会员等级`>0 AND `会员到期时间`<=CURRENT_TIMESTAMP(3)) AS expired FROM `商城用户` WHERE `SteamID` IS NOT NULL");
    const row = rows[0] || {};
    return { total: Number(row.total || 0), active: Number(row.active || 0), expiringSoon: Number(row.expiringSoon || 0), expired: Number(row.expired || 0) };
  }

  async membershipConsumption(steamId) {
    if (!isSteamId64(steamId)) throw new ServiceError('SteamID 格式无效', 400, 'INVALID_INPUT');
    const users = await this.db.query("SELECT `登录账号` AS username,CASE WHEN `会员等级`>0 AND (`会员到期时间` IS NULL OR `会员到期时间`>CURRENT_TIMESTAMP(3)) THEN `会员等级` ELSE 0 END AS memberLevel,`会员到期时间` AS memberExpiresAt FROM `商城用户` WHERE `SteamID`=? AND `账户状态`='active'", [String(steamId)]);
    if (!users[0]) throw new ServiceError('该 SteamID 尚未注册商城账户', 404, 'NOT_FOUND');
    const totalSpent = Number((await this.db.query("SELECT COALESCE(SUM(total_amount),0) AS total FROM orders WHERE steam_id=? AND status='completed' AND source IN ('shop','gift')", [String(steamId)]))[0]?.total || 0);
    const currentLevel = Number(users[0].memberLevel || 0);
    const next = (await this.db.query('SELECT level,title,upgrade_spend AS upgradeSpend FROM membership_strategies WHERE enabled=1 AND level>? ORDER BY level LIMIT 1', [currentLevel]))[0] || null;
    return { steamId: String(steamId), username: users[0].username, currentLevel, memberExpiresAt: users[0].memberExpiresAt || null, totalSpent, nextLevel: next ? Number(next.level) : null, nextTitle: next?.title || null, nextUpgradeSpend: next ? Number(next.upgradeSpend) : null, remainingSpend: next ? Math.max(0, Number(next.upgradeSpend) - totalSpent) : 0, eligible: Boolean(next) && totalSpent >= Number(next.upgradeSpend) };
  }

  async listMembershipStrategies({ publicView = false } = {}) {
    const where = publicView ? 'WHERE enabled=1 AND level>0' : '';
    return this.db.query(`SELECT level,title,opening_amount AS openingAmount,period_days AS periodDays,gift_tokens AS giftTokens,upgrade_spend AS upgradeSpend,teleport_discount AS teleportDiscount,online_bonus AS onlineBonus,shopping_discount AS shoppingDiscount,gift_discount AS giftDiscount,recharge_bonus AS rechargeBonus,daily_teleports AS dailyTeleports,checkin_bonus AS checkinBonus,extra_hint AS extraHint,enabled,created_at AS createdAt,updated_at AS updatedAt FROM membership_strategies ${where} ORDER BY level`);
  }

  async saveMembershipStrategy(input, currentLevel = null) {
    const value = membershipStrategyInput(input);
    const oldLevel = currentLevel === null || currentLevel === '' ? null : nonNegativeInt(currentLevel, '原会员等级', 100);
    if (oldLevel !== null) {
      if (oldLevel !== value.level) throw new ServiceError('修改会员策略时不能修改会员等级', 400, 'INVALID_INPUT');
      const result = await this.db.query('UPDATE membership_strategies SET title=?,opening_amount=?,period_days=?,gift_tokens=?,upgrade_spend=?,teleport_discount=?,online_bonus=?,shopping_discount=?,gift_discount=?,recharge_bonus=?,daily_teleports=?,checkin_bonus=?,extra_hint=?,enabled=? WHERE level=?', [value.title, value.openingAmount, value.periodDays, value.giftTokens, value.upgradeSpend, value.teleportDiscount, value.onlineBonus, value.shoppingDiscount, value.giftDiscount, value.rechargeBonus, value.dailyTeleports, value.checkinBonus, value.extraHint || null, value.enabled, oldLevel]);
      if (!result.affectedRows) throw new ServiceError('会员策略不存在', 404, 'NOT_FOUND');
      return value;
    }
    await this.db.query('INSERT INTO membership_strategies (level,title,opening_amount,period_days,gift_tokens,upgrade_spend,teleport_discount,online_bonus,shopping_discount,gift_discount,recharge_bonus,daily_teleports,checkin_bonus,extra_hint,enabled) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE title=VALUES(title),opening_amount=VALUES(opening_amount),period_days=VALUES(period_days),gift_tokens=VALUES(gift_tokens),upgrade_spend=VALUES(upgrade_spend),teleport_discount=VALUES(teleport_discount),online_bonus=VALUES(online_bonus),shopping_discount=VALUES(shopping_discount),gift_discount=VALUES(gift_discount),recharge_bonus=VALUES(recharge_bonus),daily_teleports=VALUES(daily_teleports),checkin_bonus=VALUES(checkin_bonus),extra_hint=VALUES(extra_hint),enabled=VALUES(enabled)', [value.level, value.title, value.openingAmount, value.periodDays, value.giftTokens, value.upgradeSpend, value.teleportDiscount, value.onlineBonus, value.shoppingDiscount, value.giftDiscount, value.rechargeBonus, value.dailyTeleports, value.checkinBonus, value.extraHint || null, value.enabled]);
    return value;
  }

  async deleteMembershipStrategy(level) {
    const strategyLevel = nonNegativeInt(level, '会员等级', 100);
    if (strategyLevel === 0) throw new ServiceError('默认 0 级策略不可删除', 400, 'INVALID_OPERATION');
    const result = await this.db.query('DELETE FROM membership_strategies WHERE level=?', [strategyLevel]);
    if (!result.affectedRows) throw new ServiceError('会员策略不存在', 404, 'NOT_FOUND');
  }

  async listMemberships({ page = 1, limit = 15, search = '', level = '', status = '' } = {}) {
    const safePage = membershipPage(page);
    const safeLimit = Number(limit);
    if (!Number.isInteger(safeLimit) || safeLimit !== 15) throw new ServiceError('会员列表每页固定为 15 条', 400, 'INVALID_PAGINATION');
    const steamId = String(search || '').trim();
    if (steamId && !/^\d{1,17}$/.test(steamId)) throw new ServiceError('SteamID 搜索格式无效', 400, 'INVALID_INPUT');
    const where = ['u.`SteamID` IS NOT NULL'];
    const params = [];
    if (steamId) { where.push('u.`SteamID` LIKE ?'); params.push(`%${steamId}%`); }
    if (level !== '' && level !== undefined) { const safeLevel = nonNegativeInt(level, '会员等级'); where.push('u.`会员等级`=?'); params.push(safeLevel); }
    const safeStatus = String(status || '');
    if (safeStatus === 'active') where.push('u.`会员等级`>0 AND (u.`会员到期时间` IS NULL OR u.`会员到期时间`>CURRENT_TIMESTAMP(3))');
    else if (safeStatus === 'permanent') where.push('u.`会员等级`>0 AND u.`会员到期时间` IS NULL');
    else if (safeStatus === 'expiring') where.push('u.`会员等级`>0 AND u.`会员到期时间`>CURRENT_TIMESTAMP(3) AND u.`会员到期时间`<=DATE_ADD(CURRENT_TIMESTAMP(3), INTERVAL 7 DAY)');
    else if (safeStatus === 'expired') where.push('u.`会员等级`>0 AND u.`会员到期时间`<=CURRENT_TIMESTAMP(3)');
    else if (safeStatus === 'none') where.push('u.`会员等级`=0');
    else if (safeStatus) throw new ServiceError('会员状态筛选无效', 400, 'INVALID_INPUT');
    const clause = `WHERE ${where.join(' AND ')}`;
    const [countRows, stats] = await Promise.all([
      this.db.query(`SELECT COUNT(*) AS count FROM \`商城用户\` u ${clause}`, params),
      this.membershipStats()
    ]);
    const items = await this.db.query(`SELECT u.\`商城用户编号\` AS userId,u.\`登录账号\` AS username,u.\`SteamID\` AS steamId,u.\`会员等级\` AS memberLevel,u.\`会员到期时间\` AS memberExpiresAt,CASE WHEN u.\`会员等级\`>0 AND (u.\`会员到期时间\` IS NULL OR u.\`会员到期时间\`>CURRENT_TIMESTAMP(3)) THEN u.\`会员等级\` ELSE 0 END AS effectiveMemberLevel,CASE WHEN u.\`会员等级\`=0 THEN 'none' WHEN u.\`会员到期时间\` IS NULL THEN 'permanent' WHEN u.\`会员到期时间\`>CURRENT_TIMESTAMP(3) THEN 'active' ELSE 'expired' END AS memberStatus,u.\`商城币余额\` AS balance,u.\`最后登录时间\` AS lastLoginAt,latest.character_name AS characterName,latest.steam_name AS steamName FROM \`商城用户\` u LEFT JOIN online_player_snapshots latest ON latest.sample_id=(SELECT p.sample_id FROM online_player_snapshots p WHERE p.steam_id=u.\`SteamID\` ORDER BY p.observed_at DESC,p.sample_id DESC LIMIT 1) AND latest.steam_id=u.\`SteamID\` ${clause} ORDER BY u.\`会员等级\`>0 DESC,u.\`会员到期时间\` IS NULL DESC,u.\`会员到期时间\` DESC,u.\`商城用户编号\` DESC LIMIT 15 OFFSET ${(safePage - 1) * 15}`, params);
    return { items, page: safePage, limit: 15, total: Number(countRows[0]?.count || 0), totalMembers: stats.total, activeMembers: stats.active, expiringSoon: stats.expiringSoon };
  }

  async membershipLogs({ page = 1, steamId = '' } = {}) {
    const safePage = membershipPage(page);
    const target = String(steamId || '').trim();
    if (target && !isSteamId64(target)) throw new ServiceError('SteamID 格式无效', 400, 'INVALID_INPUT');
    const where = target ? 'WHERE l.steam_id=?' : '';
    const params = target ? [target] : [];
    const count = await this.db.query(`SELECT COUNT(*) AS count FROM membership_change_logs l ${where}`, params);
    const items = await this.db.query(`SELECT l.id,l.steam_id AS steamId,l.old_level AS oldLevel,l.new_level AS newLevel,l.old_expires_at AS oldExpiresAt,l.new_expires_at AS newExpiresAt,l.reason,l.operator,l.created_at AS createdAt,u.\`登录账号\` AS username,latest.character_name AS characterName,latest.steam_name AS steamName FROM membership_change_logs l LEFT JOIN \`商城用户\` u ON u.\`SteamID\`=l.steam_id LEFT JOIN online_player_snapshots latest ON latest.sample_id=(SELECT p.sample_id FROM online_player_snapshots p WHERE p.steam_id=l.steam_id ORDER BY p.observed_at DESC,p.sample_id DESC LIMIT 1) AND latest.steam_id=l.steam_id ${where} ORDER BY l.id DESC LIMIT 15 OFFSET ${(safePage - 1) * 15}`, params);
    return { items, page: safePage, pageSize: 15, total: Number(count[0]?.count || 0) };
  }

  async setMembership(steamId, input, operator = 'admin', cancel = false) {
    if (!isSteamId64(steamId)) throw new ServiceError('SteamID 格式无效', 400, 'INVALID_INPUT');
    const value = membershipInput(input, cancel);
    const actor = String(operator || 'admin').trim().slice(0, 100) || 'admin';
    return this.db.transaction(async (tx) => {
      const rows = await tx.query('SELECT `商城用户编号` AS id,`登录账号` AS username,`会员等级` AS memberLevel,`会员到期时间` AS memberExpiresAt FROM `商城用户` WHERE `SteamID`=? FOR UPDATE', [String(steamId)]);
      const user = rows[0];
      if (!user) throw new ServiceError('该 SteamID 尚未注册商城账户', 404, 'NOT_FOUND');
      const oldLevel = Number(user.memberLevel || 0);
      await tx.query('UPDATE `商城用户` SET `会员等级`=?,`会员到期时间`=? WHERE `商城用户编号`=?', [value.level, value.expiresAt, user.id]);
      await tx.query('INSERT INTO membership_change_logs (steam_id,old_level,new_level,old_expires_at,new_expires_at,reason,operator) VALUES (?,?,?,?,?,?,?)', [String(steamId), oldLevel, value.level, user.memberExpiresAt || null, value.expiresAt, value.reason, actor]);
      return { steamId: String(steamId), username: user.username, memberLevel: value.level, effectiveMemberLevel: value.level > 0 && (!value.expiresAt || value.expiresAt.getTime() > Date.now()) ? value.level : 0, memberExpiresAt: value.expiresAt };
    });
  }

  async listAccountExchanges() {
    return this.db.query('SELECT e.id,e.steam_id AS steamId,a.`登录账号` AS username,a.`游戏名称` AS characterName,e.direction,e.input_amount AS inputAmount,e.output_amount AS outputAmount,e.rate_snapshot AS rateSnapshot,e.status,e.error_message AS errorMessage,e.created_at AS createdAt,e.completed_at AS completedAt FROM account_exchanges e LEFT JOIN `商城用户` a ON a.`SteamID`=e.steam_id ORDER BY e.id DESC LIMIT 100');
  }

  async listCharacterGrowthPurchases(limit = 300) {
    const safeLimit = positiveInt(limit, '条数', 500);
    return this.db.query(`SELECT id,steam_id AS steamId,purchase_type AS purchaseType,target_json AS targetJson,quantity,unit_price AS unitPrice,total_price AS totalPrice,balance_after AS balanceAfter,status,error_message AS errorMessage,completed_at AS completedAt,created_at AS createdAt FROM character_growth_purchases ORDER BY id DESC LIMIT ${safeLimit}`);
  }

  async listRedeemCodeClaims(limit = 300) {
    const safeLimit = positiveInt(limit, '条数', 500);
    return this.db.query(`SELECT c.id AS claimId,c.steam_id AS steamId,c.created_at AS createdAt,r.id AS redeemCodeId,r.name AS redeemCodeName,r.code_hint AS codeHint,o.id AS orderId,o.order_no AS orderNo,o.status FROM redeem_code_claims c JOIN redeem_codes r ON r.id=c.redeem_code_id LEFT JOIN orders o ON o.id=c.order_id ORDER BY c.id DESC LIMIT ${safeLimit}`);
  }

  async listStockPriceHistory(limit = 300) {
    const safeLimit = positiveInt(limit, '条数', 500);
    return this.db.query(`SELECT h.id,h.stock_id AS stockId,s.code,s.name,h.source,h.price_before AS priceBefore,h.price_after AS priceAfter,h.change_bps AS changeBps,h.actor_username_snapshot AS actorUsername,h.reason,h.priced_at AS pricedAt FROM stock_price_history h JOIN stocks s ON s.id=h.stock_id ORDER BY h.id DESC LIMIT ${safeLimit}`);
  }

  async listPlayerCheckins(limit = 300) {
    const safeLimit = positiveInt(limit, '条数', 500);
    return this.db.query(`SELECT c.id,c.steam_id AS steamId,a.\`登录账号\` AS username,a.\`游戏名称\` AS characterName,c.checkin_day AS checkinDay,c.streak_days AS streakDays,c.total_days AS totalDays,c.created_at AS createdAt FROM player_checkins c LEFT JOIN \`商城用户\` a ON a.\`SteamID\`=c.steam_id ORDER BY c.id DESC LIMIT ${safeLimit}`);
  }

  async listAccounts(limit = 100, search = '') {
    const safeLimit = positiveInt(limit, '条数', 500);
    const keyword = String(search || '').trim();
    if (keyword.length > 100) throw new ServiceError('搜索内容不能超过 100 个字符');
    const where = keyword ? "WHERE a.`SteamID` LIKE ? OR COALESCE(a.`登录账号`,'') LIKE ? OR COALESCE(latest.character_name,a.`游戏名称`,'') LIKE ?" : '';
    const params = keyword ? Array(3).fill(`%${keyword}%`) : [];
    return this.db.query(`SELECT a.\`SteamID\` AS steamId,a.\`商城币余额\` AS balance,a.\`商城账户创建时间\` AS createdAt,COALESCE(latest.observed_at,a.\`最后游戏在线时间\`) AS updatedAt,a.\`商城用户编号\` AS userId,a.\`登录账号\` AS username,a.\`用户角色\` AS role,a.\`账户状态\` AS status,COALESCE(a.\`会员等级\`,0) AS rawMemberLevel,a.\`会员到期时间\` AS memberExpiresAt,CASE WHEN a.\`会员等级\`>0 AND (a.\`会员到期时间\` IS NULL OR a.\`会员到期时间\`>CURRENT_TIMESTAMP(3)) THEN a.\`会员等级\` ELSE 0 END AS memberLevel,a.\`最后登录时间\` AS lastLogin,COALESCE(latest.character_name,a.\`游戏名称\`) AS characterName,NULL AS steamName,COALESCE(latest.is_admin,0) AS isAdmin,COALESCE(latest.observed_at,a.\`最后游戏在线时间\`) AS lastSeenAt,CASE WHEN current_player.steam_id IS NULL THEN 0 ELSE 1 END AS online FROM \`商城用户\` a LEFT JOIN online_player_snapshots current_player ON current_player.steam_id=a.\`SteamID\` AND current_player.sample_id=(SELECT s.id FROM server_monitor_samples s WHERE s.id=(SELECT MAX(id) FROM server_monitor_samples) AND s.status='ok' AND s.player_query_ok=1 AND s.sampled_at>=DATE_SUB(UTC_TIMESTAMP(3),INTERVAL 2 MINUTE)) LEFT JOIN online_player_snapshots latest ON latest.sample_id=(SELECT p2.sample_id FROM online_player_snapshots p2 WHERE p2.steam_id=a.\`SteamID\` ORDER BY p2.observed_at DESC,p2.sample_id DESC LIMIT 1) AND latest.steam_id=a.\`SteamID\` ${where} ORDER BY COALESCE(latest.observed_at,a.\`最后游戏在线时间\`,a.\`商城账户创建时间\`) DESC LIMIT ${safeLimit}`, params);
  }

  async adjustBalance(steamId, amount, note = '') {
    if (!isSteamId64(steamId)) throw new ServiceError('SteamID 格式无效');
    const delta = Number(amount);
    if (!Number.isSafeInteger(delta) || delta === 0) throw new ServiceError('调整金额必须是非零整数');
    const safeNote = String(note || '').trim();
    if (safeNote.length > 255) throw new ServiceError('备注不能超过 255 字符');
    return this.db.transaction(async (tx) => {
      await tx.query('INSERT INTO `商城用户` (`SteamID`,`商城币余额`) VALUES (?,0) ON DUPLICATE KEY UPDATE `SteamID`=VALUES(`SteamID`)', [String(steamId)]);
      const rows = await tx.query('SELECT `商城币余额` AS balance FROM `商城用户` WHERE `SteamID`=? FOR UPDATE', [String(steamId)]);
      const balance = Number(rows[0].balance) + delta;
      if (balance < 0) throw new ServiceError('商城币余额不足', 409, 'INSUFFICIENT_BALANCE');
      await tx.query('UPDATE `商城用户` SET `商城币余额`=? WHERE `SteamID`=?', [balance, String(steamId)]);
      await tx.query("INSERT INTO coin_ledger (steam_id, amount, balance_after, type, note) VALUES (?, ?, ?, 'admin_adjustment', ?)", [String(steamId), delta, balance, safeNote || null]);
      return { steamId: String(steamId), balance };
    });
  }

  async exchangeCurrency(steamId, input, rconClient, exchangeConfig = {}) {
    if (!isSteamId64(steamId)) throw new ServiceError('SteamID 格式无效');
    if (!exchangeConfig.enabled) throw new ServiceError('账户兑换功能当前未启用', 403, 'EXCHANGE_DISABLED');
    if (!rconClient?.command) throw new ServiceError('游戏服 RCON 当前不可用', 503, 'RCON_UNAVAILABLE');

    const id = String(steamId);
    const requestKey = String(input?.requestKey || '').trim();
    if (!requestKey || requestKey.length > 100) throw new ServiceError('Idempotency-Key 长度必须为 1-100 个字符', 400, 'INVALID_IDEMPOTENCY_KEY');
    const direction = String(input?.direction || '').trim();
    if (!['coin_to_gold', 'gold_to_coin'].includes(direction)) throw new ServiceError('兑换方向无效', 400, 'INVALID_EXCHANGE_DIRECTION');
    const maxAmount = positiveInt(exchangeConfig.maxAmount, '单次兑换上限', 1000000000);
    const inputAmount = positiveInt(input?.amount, '兑换数量', maxAmount);
    const rate = Number(direction === 'coin_to_gold' ? exchangeConfig.coinToGoldRate : exchangeConfig.goldToCoinRate);
    if (!Number.isFinite(rate) || rate <= 0 || rate > 1000000) throw new ServiceError('兑换比例配置无效', 500, 'INVALID_EXCHANGE_CONFIG');
    const outputAmount = Math.floor(inputAmount * rate);
    if (!Number.isSafeInteger(outputAmount) || outputAmount < 1) throw new ServiceError('按当前比例计算的兑换结果不足 1 或数值过大', 400, 'INVALID_EXCHANGE_AMOUNT');

    const value = {
      direction,
      inputAmount,
      outputAmount,
      rate: Number(rate.toFixed(8)),
      coinDelta: direction === 'coin_to_gold' ? -inputAmount : outputAmount,
      goldDelta: direction === 'coin_to_gold' ? outputAmount : -inputAmount
    };
    const command = `#ChangeCurrencyBalance Gold ${value.goldDelta} ${id}`;

    const existingRows = await this.db.query('SELECT id,steam_id AS steamId,direction,input_amount AS inputAmount,output_amount AS outputAmount,rate_snapshot AS rateSnapshot,coin_delta AS coinDelta,gold_delta AS goldDelta,status,rcon_response AS rconResponse,error_message AS errorMessage FROM account_exchanges WHERE request_key=?', [requestKey]);
    if (existingRows[0]) return assertSameExchange(existingRows[0], id, value);

    let prepared;
    try {
      prepared = await this.db.transaction(async (tx) => {
        await tx.query('INSERT INTO `商城用户` (`SteamID`,`商城币余额`) VALUES (?,0) ON DUPLICATE KEY UPDATE `SteamID`=VALUES(`SteamID`)', [id]);
        const accountRows = await tx.query('SELECT `商城币余额` AS balance FROM `商城用户` WHERE `SteamID`=? FOR UPDATE', [id]);
        const account = accountRows[0];
        const duplicateRows = await tx.query('SELECT id,steam_id AS steamId,direction,input_amount AS inputAmount,output_amount AS outputAmount,rate_snapshot AS rateSnapshot,coin_delta AS coinDelta,gold_delta AS goldDelta,status,rcon_response AS rconResponse,error_message AS errorMessage FROM account_exchanges WHERE request_key=? FOR UPDATE', [requestKey]);
        if (duplicateRows[0]) return { existing: assertSameExchange(duplicateRows[0], id, value) };

        // The account lock serializes preparation across service instances. Keep the
        // durable guard until settlement; monitoring timestamps cannot resolve it.
        const activeRows = await tx.query("SELECT id,status FROM account_exchanges WHERE steam_id=? AND status IN ('pending','executing','uncertain') ORDER BY id LIMIT 1 FOR UPDATE", [id]);
        if (activeRows[0]) {
          if (activeRows[0].status === 'uncertain') throw new ServiceError('上一笔兑换结果待核查，请联系工作人员，暂时不能再次兑换', 409, 'EXCHANGE_PENDING_REVIEW');
          throw new ServiceError('上一笔兑换正在处理中，请稍候再试', 409, 'EXCHANGE_IN_PROGRESS');
        }
        const onlineRows = await tx.query("SELECT p.steam_id AS steamId FROM online_player_snapshots p INNER JOIN server_monitor_samples s ON s.id=p.sample_id WHERE p.steam_id=? AND s.status='ok' AND s.player_query_ok=1 AND s.id=(SELECT MAX(id) FROM server_monitor_samples WHERE status='ok' AND player_query_ok=1) LIMIT 1", [id]);
        if (!onlineRows[0]) throw new ServiceError('游戏角色必须在线才能兑换，请先进入游戏并等待在线状态同步', 409, 'PLAYER_OFFLINE');

        const balance = Number(account.balance);
        if (!Number.isSafeInteger(balance + value.coinDelta)) throw new ServiceError('商城币余额超出安全范围', 500, 'BALANCE_OVERFLOW');
        if (direction === 'coin_to_gold' && balance < inputAmount) throw new ServiceError('商城币余额不足', 409, 'INSUFFICIENT_BALANCE');

        const result = await tx.query("INSERT INTO account_exchanges (steam_id,request_key,direction,input_amount,output_amount,rate_snapshot,coin_delta,gold_delta,status,rcon_command) VALUES (?,?,?,?,?,?,?,?, 'executing',?)", [id, requestKey, direction, inputAmount, outputAmount, value.rate, value.coinDelta, value.goldDelta, command]);
        const balanceAfterReserve = direction === 'coin_to_gold' ? balance - inputAmount : balance;
        if (direction === 'coin_to_gold') await tx.query('UPDATE `商城用户` SET `商城币余额`=? WHERE `SteamID`=?', [balanceAfterReserve, id]);
        return { exchangeId: result.insertId, balance: balanceAfterReserve };
      });
    } catch (error) {
      if (!isDuplicateKey(error)) throw error;
      const rows = await this.db.query('SELECT id,steam_id AS steamId,direction,input_amount AS inputAmount,output_amount AS outputAmount,rate_snapshot AS rateSnapshot,coin_delta AS coinDelta,gold_delta AS goldDelta,status,rcon_response AS rconResponse,error_message AS errorMessage FROM account_exchanges WHERE request_key=?', [requestKey]);
      if (!rows[0]) throw error;
      return assertSameExchange(rows[0], id, value);
    }

    if (prepared.existing) return prepared.existing;

    let response;
    let commandStarted = false;
    try {
      if (direction === 'gold_to_coin') {
        let availableGold;
        try {
          // Read directly after reserving this exchange, bypassing periodic/player caches.
          const economy = await rconClient.command(`QueryPlayerEconomy ${id}`, { retry: false });
          assertExchangeRconResult(economy);
          availableGold = parsePlayerEconomy(exchangeRconResponse(economy), id).gold;
        } catch {
          throw new ServiceError('暂时无法核实游戏金条余额，请稍后重试', 503, 'GAME_GOLD_UNAVAILABLE');
        }
        if (availableGold < inputAmount) throw new ServiceError('游戏金条余额不足', 409, 'INSUFFICIENT_GAME_GOLD');
      }
      commandStarted = true;
      const result = await rconClient.command(command, { retry: false });
      assertExchangeRconResult(result);
      response = exchangeText(result?.response ?? result);
    } catch (error) {
      // A transport error without delivery evidence may arrive after the game applied the command.
      const uncertain = commandStarted && error?.uncertainDelivery !== false;
      const message = exchangeText(error?.message || 'RCON 命令执行失败');
      const failed = await this.db.transaction(async (tx) => {
        const accountRows = await tx.query('SELECT `商城币余额` AS balance FROM `商城用户` WHERE `SteamID`=? FOR UPDATE', [id]);
        const exchangeRows = await tx.query('SELECT status FROM account_exchanges WHERE id=? FOR UPDATE', [prepared.exchangeId]);
        if (exchangeRows[0]?.status !== 'executing') return null;
        let balance = Number(accountRows[0].balance);
        if (!uncertain && direction === 'coin_to_gold') {
          balance += inputAmount;
          await tx.query('UPDATE `商城用户` SET `商城币余额`=? WHERE `SteamID`=?', [balance, id]);
        }
        const status = uncertain ? 'uncertain' : 'failed';
        await tx.query('UPDATE account_exchanges SET status=?,error_message=?,completed_at=CURRENT_TIMESTAMP(3) WHERE id=?', [status, message, prepared.exchangeId]);
        return { ...value, id: prepared.exchangeId, status, balance, errorMessage: message };
      });
      if (uncertain) return exchangeResult(failed);
      if (!commandStarted) throw error;
      throw new ServiceError(`游戏服兑换失败：${message}`, 502, 'RCON_EXCHANGE_FAILED');
    }

    return this.db.transaction(async (tx) => {
      const accountRows = await tx.query('SELECT `商城币余额` AS balance FROM `商城用户` WHERE `SteamID`=? FOR UPDATE', [id]);
      const exchangeRows = await tx.query('SELECT status FROM account_exchanges WHERE id=? FOR UPDATE', [prepared.exchangeId]);
      let balance = Number(accountRows[0].balance);
      if (exchangeRows[0]?.status !== 'executing') {
        const rows = await tx.query('SELECT id,steam_id AS steamId,direction,input_amount AS inputAmount,output_amount AS outputAmount,rate_snapshot AS rateSnapshot,coin_delta AS coinDelta,gold_delta AS goldDelta,status,rcon_response AS rconResponse,error_message AS errorMessage FROM account_exchanges WHERE id=?', [prepared.exchangeId]);
        return exchangeResult({ ...rows[0], balance }, true);
      }
      if (direction === 'gold_to_coin') {
        balance += outputAmount;
        if (!Number.isSafeInteger(balance)) throw new ServiceError('商城币余额超出安全范围', 500, 'BALANCE_OVERFLOW');
        await tx.query('UPDATE `商城用户` SET `商城币余额`=? WHERE `SteamID`=?', [balance, id]);
      }
      await tx.query("INSERT INTO coin_ledger (steam_id,amount,balance_after,type,reference_type,reference_id,note) VALUES (?,?,?,'account_exchange',?,?,?)", [id, value.coinDelta, balance, direction, String(prepared.exchangeId), direction === 'coin_to_gold' ? '商城币兑换金条' : '金条兑换商城币']);
      await tx.query("UPDATE account_exchanges SET status='succeeded',rcon_response=?,completed_at=CURRENT_TIMESTAMP(3) WHERE id=?", [response, prepared.exchangeId]);
      return exchangeResult({ ...value, id: prepared.exchangeId, status: 'succeeded', balance, rconResponse: response });
    });
  }

  async adjustGameGold(steamId, amount, rconClient) {
    const id = String(steamId || '').trim();
    if (!isSteamId64(id)) throw new ServiceError('SteamID 格式无效');
    const players = await rconClient.players();
    if (!players.some((player) => String(player.steamId) === id)) throw new ServiceError('玩家当前不在线，无法调整金条', 409, 'PLAYER_OFFLINE');
    const command = `#ChangeCurrencyBalance Gold ${amount} ${id}`;
    const result = await rconClient.command(command, { retry: false });
    return { steamId: id, amount, command, response: exchangeText(result?.response ?? result) };
  }

  async findExternalOrder(source, external) {
    const rows = await this.db.query('SELECT id, order_no AS orderNo, status, request_hash AS requestHash FROM orders WHERE source = ? AND external_order_id = ?', [source, external]);
    return rows[0];
  }

  async createManualFulfillment({ steamId, code }, userId = null) {
    if (!isSteamId64(steamId)) throw new ServiceError('SteamID 格式无效');
    const parsed = parseGiftCode(code);
    const requestKey = crypto.createHash('sha256').update(`${steamId}:${parsed.displayCode}`).digest('hex');
    return this.db.transaction(async (tx) => {
      await tx.query('INSERT INTO `商城用户` (`SteamID`,`商城币余额`) VALUES (?,0) ON DUPLICATE KEY UPDATE `SteamID`=VALUES(`SteamID`)', [String(steamId)]);
      const number = orderNo();
      const order = await tx.query("INSERT INTO orders (order_no, source, request_hash, steam_id, total_amount, status) VALUES (?, 'manual_fulfillment', ?, ?, 0, 'pending')", [number, requestKey, String(steamId)]);
      const payload = parsed.actionType === 'spawn_item' ? parsed.payload : null;
      const detail = await tx.query('INSERT INTO order_items (order_id, sku, name, unit_price, quantity, item_id, grant_amount, fulfillment_codes_snapshot) VALUES (?, ?, ?, 0, 1, ?, ?, ?)', [order.insertId, 'manual_fulfillment', '管理员手动发货', payload?.itemId || null, payload?.quantity || null, parsed.displayCode]);
      const task = await tx.query('INSERT INTO fulfillment_tasks (order_id, order_item_id, steam_id, task_type, payload_json, coin_amount, item_id, amount, created_by_user_id, request_key, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, \'pending\')', [order.insertId, detail.insertId, String(steamId), parsed.actionType, payload ? JSON.stringify(payload) : null, parsed.actionType === 'shop_coin' ? parsed.payload.amount : null, payload?.itemId || null, payload?.quantity || null, userId || null, requestKey]);
      return { id: task.insertId, orderId: order.insertId, orderNo: number, status: 'pending' };
    });
  }

  async createOrder({ steamId, items, source = 'manual', externalOrderId = null }) {
    if (!isSteamId64(steamId)) throw new ServiceError('SteamID 格式无效');
    const normalized = normalizeItems(items);
    const external = externalOrderId === null ? null : String(externalOrderId).trim();
    if (external !== null && (!external || external.length > 100)) throw new ServiceError('外部订单号格式无效');
    const hash = requestHash(steamId, normalized);
    if (external) {
      const existing = await this.findExternalOrder(source, external);
      if (existing) return assertSameRequest(existing, hash);
    }
    try {
      return await this.db.transaction(async (tx) => {
        await tx.query('INSERT INTO `商城用户` (`SteamID`,`商城币余额`) VALUES (?,0) ON DUPLICATE KEY UPDATE `SteamID`=VALUES(`SteamID`)', [String(steamId)]);
        const placeholders = normalized.map(() => '?').join(',');
        const products = await tx.query(`SELECT id, sku, name, price, item_id, grant_amount, parent_category, category_name, currency_type, min_member_level, image_path, fulfillment_codes FROM products WHERE enabled = 1 AND sku IN (${placeholders}) FOR UPDATE`, normalized.map((item) => item.sku));
        if (products.length !== normalized.length) throw new ServiceError('订单包含不存在或已下架的商品', 409, 'PRODUCT_UNAVAILABLE');
        let memberStrategy = null;
        if (source === 'shop') {
          const users = await tx.query("SELECT CASE WHEN `会员等级`>0 AND (`会员到期时间` IS NULL OR `会员到期时间`>CURRENT_TIMESTAMP(3)) THEN `会员等级` ELSE 0 END AS memberLevel FROM `商城用户` WHERE `SteamID`=? AND `用户角色` IN ('user','admin','super_admin') AND `账户状态`='active' FOR UPDATE", [String(steamId)]);
          if (!users[0]) throw new ServiceError('商城用户不存在或已停用', 403, 'SHOP_USER_UNAVAILABLE');
          const memberLevel = Number(users[0].memberLevel) || 0;
          memberStrategy = (await tx.query('SELECT shopping_discount AS shoppingDiscount FROM membership_strategies WHERE level=? AND enabled=1', [memberLevel]))[0] || { shoppingDiscount: 100 };
          const restricted = products.find((product) => memberLevel < Number(product.min_member_level || 0));
          if (restricted) throw new ServiceError(`会员等级不足，商品“${restricted.name}”要求会员等级 ${restricted.min_member_level}`, 403, 'MEMBER_LEVEL_REQUIRED');
        }
        if (products.some((product) => !['coin', '商城币'].includes(product.currency_type || 'coin'))) throw new ServiceError('美金、金条商品尚未接入游戏资产结算，不能使用商城币购买', 409, 'CURRENCY_PAYMENT_UNAVAILABLE');
        const bySku = new Map(products.map((product) => [product.sku, product]));
        const discount = Number(memberStrategy?.shoppingDiscount ?? 100);
        const unitPriceFor = (product) => source === 'shop' ? Math.round(Number(product.price) * discount / 100) : Number(product.price);
        const total = normalized.reduce((sum, item) => sum + unitPriceFor(bySku.get(item.sku)) * item.quantity, 0);
        if (!Number.isSafeInteger(total)) throw new ServiceError('订单金额超出安全范围');
        const account = await tx.query('SELECT `商城币余额` AS balance FROM `商城用户` WHERE `SteamID`=? FOR UPDATE', [String(steamId)]);
        const balance = Number(account[0].balance);
        if (balance < total) throw new ServiceError('商城币余额不足', 409, 'INSUFFICIENT_BALANCE');
        const number = orderNo();
        const order = await tx.query("INSERT INTO orders (order_no, source, external_order_id, request_hash, steam_id, total_amount, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')", [number, source, external, hash, String(steamId), total]);
        for (const item of normalized) {
          const product = bySku.get(item.sku);
          const codes = productCodes(product);
          const snapshot = codes.join(',');
          const detail = await tx.query('INSERT INTO order_items (order_id, product_id, sku, name, unit_price, quantity, item_id, grant_amount, parent_category, category_name, currency_type, min_member_level, image_path, fulfillment_codes_snapshot) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [order.insertId, product.id, product.sku, product.name, unitPriceFor(product), item.quantity, product.item_id, product.grant_amount, product.parent_category || null, product.category_name || null, product.currency_type || 'coin', product.min_member_level || 0, product.image_path || null, snapshot]);
          const deliveries = codes.flatMap((code) => {
            const delivery = productDelivery(code, product.grant_amount * item.quantity);
            return splitItemDelivery(delivery);
          });
          for (const [codeIndex, delivery] of deliveries.entries()) {
            await tx.query("INSERT INTO fulfillment_tasks (order_id, order_item_id, code_index, steam_id, item_id, amount, payload_json, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')", [order.insertId, detail.insertId, codeIndex, String(steamId), delivery.itemId, delivery.amount, delivery.payload ? JSON.stringify(delivery.payload) : null]);
          }
        }
        const after = balance - total;
        await tx.query('UPDATE `商城用户` SET `商城币余额`=? WHERE `SteamID`=?', [after, String(steamId)]);
        await tx.query("INSERT INTO coin_ledger (steam_id, amount, balance_after, type, reference_type, reference_id, note) VALUES (?, ?, ?, 'order_purchase', 'order', ?, ?)", [String(steamId), -total, after, String(order.insertId), `订单 ${number}`]);
        return { id: order.insertId, orderNo: number, status: 'pending', totalAmount: total, balanceAfter: after, idempotent: false };
      });
    } catch (error) {
      if (!external || !isDuplicateKey(error)) throw error;
      const existing = await this.findExternalOrder(source, external);
      if (!existing) throw error;
      return assertSameRequest(existing, hash);
    }
  }

  async getGift(steamId, gift) {
    if (!isSteamId64(steamId)) throw new ServiceError('SteamID 格式无效');
    const normalizedGift = normalizeGift(gift);
    const external = giftExternalOrderId(normalizedGift.id, steamId);
    const [existing, products] = await Promise.all([
      this.findExternalOrder('starter_gift', external),
      normalizedGift.items?.length
        ? this.db.query(`SELECT sku, name, image_path AS imagePath FROM products WHERE sku IN (${normalizedGift.items.map(() => '?').join(',')})`, normalizedGift.items.map((item) => item.sku))
        : []
    ]);
    const bySku = new Map(products.map((product) => [product.sku, product]));
    const items = (normalizedGift.items || []).map((item) => ({ ...item, name: bySku.get(item.sku)?.name || item.sku, imagePath: bySku.get(item.sku)?.imagePath || '' }));
    return { id: normalizedGift.id, name: normalizedGift.name, category: normalizedGift.category, enabled: Boolean(normalizedGift.enabled), items, claimed: Boolean(existing), order: existing ? { id: existing.id, orderNo: existing.orderNo, status: existing.status } : null };
  }

  async listGifts(steamId, gifts) {
    const enabled = (Array.isArray(gifts) ? gifts : []).filter((gift) => gift.enabled);
    return Promise.all(enabled.map((gift) => this.getGift(steamId, gift)));
  }

  async getStarterGift(steamId, config) {
    return this.getGift(steamId, { id: 'default', name: '新手礼包', category: '基础礼包', enabled: false, items: [], ...config });
  }

  async claimGift(steamId, gift) {
    if (!isSteamId64(steamId)) throw new ServiceError('SteamID 格式无效');
    const normalizedGift = normalizeGift(gift);
    if (!normalizedGift.enabled) throw new ServiceError('礼包当前未开放', 409, 'GIFT_DISABLED');
    const normalized = normalizeItems(normalizedGift.items);
    const external = giftExternalOrderId(normalizedGift.id, steamId);
    const existing = await this.findExternalOrder('starter_gift', external);
    if (existing) return { id: existing.id, orderNo: existing.orderNo, status: existing.status, idempotent: true };
    try {
      return await this.db.transaction(async (tx) => {
        await tx.query('INSERT INTO `商城用户` (`SteamID`,`商城币余额`) VALUES (?,0) ON DUPLICATE KEY UPDATE `SteamID`=VALUES(`SteamID`)', [String(steamId)]);
        const placeholders = normalized.map(() => '?').join(',');
        const products = await tx.query(`SELECT id, sku, name, item_id, grant_amount, parent_category, category_name, currency_type, min_member_level, image_path, fulfillment_codes FROM products WHERE enabled = 1 AND sku IN (${placeholders}) FOR UPDATE`, normalized.map((item) => item.sku));
        if (products.length !== normalized.length) throw new ServiceError('礼包包含不存在或已下架的商品', 409, 'PRODUCT_UNAVAILABLE');
        const bySku = new Map(products.map((product) => [product.sku, product]));
        const number = orderNo();
        const hash = requestHash(steamId, normalized);
        const order = await tx.query("INSERT INTO orders (order_no, source, external_order_id, request_hash, steam_id, total_amount, status) VALUES (?, 'starter_gift', ?, ?, ?, 0, 'pending')", [number, external, hash, String(steamId)]);
        for (const item of normalized) {
          const product = bySku.get(item.sku);
          const codes = productCodes(product);
          const snapshot = codes.join(',');
          const detail = await tx.query('INSERT INTO order_items (order_id, product_id, sku, name, unit_price, quantity, item_id, grant_amount, parent_category, category_name, currency_type, min_member_level, image_path, fulfillment_codes_snapshot) VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [order.insertId, product.id, product.sku, product.name, item.quantity, product.item_id, product.grant_amount, product.parent_category || null, product.category_name || null, product.currency_type || 'coin', product.min_member_level || 0, product.image_path || null, snapshot]);
          const deliveries = codes.flatMap((code) => {
            const delivery = productDelivery(code, product.grant_amount * item.quantity);
            return splitItemDelivery(delivery);
          });
          for (const [codeIndex, delivery] of deliveries.entries()) {
            await tx.query("INSERT INTO fulfillment_tasks (order_id, order_item_id, code_index, steam_id, item_id, amount, payload_json, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')", [order.insertId, detail.insertId, codeIndex, String(steamId), delivery.itemId, delivery.amount, delivery.payload ? JSON.stringify(delivery.payload) : null]);
          }
        }
        return { id: order.insertId, orderNo: number, status: 'pending', totalAmount: 0, idempotent: false };
      });
    } catch (error) {
      if (!isDuplicateKey(error)) throw error;
      const claimed = await this.findExternalOrder('starter_gift', external);
      if (!claimed) throw error;
      return { id: claimed.id, orderNo: claimed.orderNo, status: claimed.status, idempotent: true };
    }
  }

  async claimStarterGift(steamId, config) {
    return this.claimGift(steamId, { id: 'default', name: '新手礼包', category: '基础礼包', enabled: false, items: [], ...config });
  }

  async listOrders(limit = 100, steamId = null) {
    const safeLimit = positiveInt(limit, '条数', 500);
    if (steamId !== null) {
      if (!isSteamId64(steamId)) throw new ServiceError('SteamID 格式无效');
      return this.db.query(`SELECT id, order_no AS orderNo, source, external_order_id AS externalOrderId, steam_id AS steamId, total_amount AS totalAmount, status, created_at AS createdAt, updated_at AS updatedAt FROM orders WHERE steam_id = ? ORDER BY id DESC LIMIT ${safeLimit}`, [String(steamId)]);
    }
    return this.db.query(`SELECT id, order_no AS orderNo, source, external_order_id AS externalOrderId, steam_id AS steamId, total_amount AS totalAmount, status, created_at AS createdAt, updated_at AS updatedAt FROM orders ORDER BY id DESC LIMIT ${safeLimit}`);
  }

  async listShopOrderLogs(limit = 300) {
    const safeLimit = positiveInt(limit, '条数', 500);
    const orders = await this.db.query(`SELECT oi.id AS orderItemId,o.id AS orderId,o.order_no AS orderNo,o.created_at AS createdAt,oi.name AS itemName,COALESCE(NULLIF(u.\`游戏名称\`,''),NULLIF(u.\`登录账号\`,''),o.steam_id) AS playerName,o.steam_id AS steamId,(oi.unit_price*oi.quantity) AS amount,o.status FROM orders o JOIN order_items oi ON oi.order_id=o.id LEFT JOIN \`商城用户\` u ON u.\`SteamID\`=o.steam_id WHERE o.source='shop' ORDER BY o.id DESC,oi.id LIMIT ${safeLimit}`);
    if (!orders.length) return [];
    const ids = orders.map((order) => Number(order.orderItemId));
    const placeholders = ids.map(() => '?').join(',');
    const tasks = await this.db.query(`SELECT task.order_item_id AS orderItemId,task.code_index AS codeIndex,task.steam_id AS steamId,task.task_type AS taskType,task.payload_json AS payloadJson,task.item_id AS itemId,task.amount FROM fulfillment_tasks task JOIN (SELECT order_item_id,code_index,MAX(generation) AS generation FROM fulfillment_tasks WHERE order_item_id IN (${placeholders}) GROUP BY order_item_id,code_index) latest ON latest.order_item_id=task.order_item_id AND latest.code_index=task.code_index AND latest.generation=task.generation ORDER BY task.order_item_id,task.code_index`, ids);
    const commands = new Map();
    for (const task of tasks) {
      const key = Number(task.orderItemId);
      const list = commands.get(key) || [];
      list.push(...taskCommands(task));
      commands.set(key, list);
    }
    return orders.map((order) => ({ ...order, commandRaw: (commands.get(Number(order.orderItemId)) || ['暂无游戏执行命令']).join('\n') }));
  }

  async listGiftClaims(limit = 300) {
    const safeLimit = positiveInt(limit, '条数', 500);
    return this.db.query(`SELECT c.id AS claimId,c.steam_id AS steamId,c.price_paid AS pricePaid,c.created_at AS createdAt,g.id AS giftId,g.name AS giftName,o.id AS orderId,o.order_no AS orderNo,o.status FROM gift_claims c JOIN gift_packages g ON g.id=c.gift_id LEFT JOIN orders o ON o.id=c.order_id ORDER BY c.id DESC LIMIT ${safeLimit}`);
  }

  async listGiftClaimLogs(limit = 300) {
    const safeLimit = positiveInt(limit, '条数', 500);
    const claims = await this.db.query(`SELECT c.id AS claimId,c.steam_id AS steamId,c.price_paid AS pricePaid,c.created_at AS claimedAt,g.id AS giftId,g.name AS giftName,g.gift_type AS giftType,o.id AS orderId,o.created_at AS orderCreatedAt,o.status,u.\`游戏名称\` AS characterName,u.\`登录账号\` AS shopUsername FROM gift_claims c JOIN gift_packages g ON g.id=c.gift_id LEFT JOIN orders o ON o.id=c.order_id LEFT JOIN \`商城用户\` u ON u.\`SteamID\`=c.steam_id ORDER BY c.id DESC LIMIT ${safeLimit}`);
    const orderIds = [...new Set(claims.map((claim) => Number(claim.orderId)).filter(Boolean))];
    if (!orderIds.length) return claims.map((claim) => ({ ...claim, commandRaw: '暂无游戏执行命令' }));
    const placeholders = orderIds.map(() => '?').join(',');
    const tasks = await this.db.query(`SELECT task.order_id AS orderId,task.order_item_id AS orderItemId,task.code_index AS codeIndex,task.steam_id AS steamId,task.task_type AS taskType,task.payload_json AS payloadJson,task.item_id AS itemId,task.amount,task.status,task.last_error AS lastError FROM fulfillment_tasks task JOIN (SELECT order_item_id,code_index,MAX(generation) AS generation FROM fulfillment_tasks WHERE order_id IN (${placeholders}) GROUP BY order_item_id,code_index) latest ON latest.order_item_id=task.order_item_id AND latest.code_index=task.code_index AND latest.generation=task.generation ORDER BY task.order_id,task.order_item_id,task.code_index`, orderIds);
    const commands = new Map();
    const failures = new Map();
    for (const task of tasks) {
      const key = Number(task.orderId);
      const list = commands.get(key) || [];
      list.push(...taskCommands(task));
      commands.set(key, list);
      if (['failed','manual_review'].includes(task.status)) { const notes = failures.get(key) || []; notes.push({ text: fulfillmentFailureText(task.lastError, task.status), source: task.lastError || (task.status === 'manual_review' ? 'manual_review' : 'failed') }); failures.set(key, notes); }
    }
    return claims.map((claim) => { const details = failures.get(Number(claim.orderId)) || (claim.status === 'failed' ? [{ text: '礼包发放任务执行失败，请检查游戏连接和商品命令配置', source: '订单状态为 failed，任务未记录具体错误' }] : []); return { ...claim, commandRaw: (commands.get(Number(claim.orderId)) || ['暂无游戏执行命令']).join('\n'), failureNote: [...new Set(details.map((item) => item.text))].join('；') || null, failureSource: [...new Set(details.map((item) => item.source))].join('；') || null }; });
  }

  async getOrder(id, steamId = null) {
    const orderId = positiveInt(id, '订单 ID');
    const params = [orderId];
    let where = 'id = ?';
    if (steamId !== null) {
      if (!isSteamId64(steamId)) throw new ServiceError('SteamID 格式无效');
      where += ' AND steam_id = ?';
      params.push(String(steamId));
    }
    const orders = await this.db.query(`SELECT id, order_no AS orderNo, source, external_order_id AS externalOrderId, steam_id AS steamId, total_amount AS totalAmount, status, created_at AS createdAt, updated_at AS updatedAt FROM orders WHERE ${where}`, params);
    if (!orders[0]) throw new ServiceError('订单不存在', 404, 'NOT_FOUND');
    const publicView = steamId !== null;
    const items = await this.db.query(`SELECT id, sku, name, unit_price AS unitPrice, quantity, parent_category AS parentCategory, category_name AS category, currency_type AS currencyType, min_member_level AS minMemberLevel, image_path AS imagePath${publicView ? '' : ', item_id AS itemId, grant_amount AS grantAmount, fulfillment_codes_snapshot AS fulfillmentCodesSnapshot'} FROM order_items WHERE order_id = ? ORDER BY id`, [orderId]);
    if (publicView) return { ...orders[0], items };
    const tasks = await this.db.query('SELECT id, order_item_id AS orderItemId, code_index AS codeIndex, generation, replacement_of_task_id AS replacementOfTaskId, created_by_user_id AS createdByUserId, replacement_reason AS replacementReason, request_key AS requestKey, steam_id AS steamId, item_id AS itemId, amount, status, attempts, next_attempt_at AS nextAttemptAt, last_error AS lastError, delivery_token AS deliveryToken, created_at AS createdAt, updated_at AS updatedAt FROM fulfillment_tasks WHERE order_id = ? ORDER BY order_item_id, code_index, generation', [orderId]);
    return { ...orders[0], items, tasks };
  }

  async listTasks(limit = 100) {
    const safeLimit = positiveInt(limit, '条数', 500);
    return this.db.query(`SELECT id, order_id AS orderId, order_item_id AS orderItemId, code_index AS codeIndex, generation, replacement_of_task_id AS replacementOfTaskId, created_by_user_id AS createdByUserId, replacement_reason AS replacementReason, request_key AS requestKey, steam_id AS steamId, item_id AS itemId, amount, status, attempts, next_attempt_at AS nextAttemptAt, last_error AS lastError, delivery_token AS deliveryToken, created_at AS createdAt, updated_at AS updatedAt FROM fulfillment_tasks ORDER BY id DESC LIMIT ${safeLimit}`);
  }

  async createReplacementTask(id, { requestKey, userId, reason, confirmUnknownDeliveryRisk = false }) {
    const taskId = positiveInt(id, '任务 ID');
    const adminId = positiveInt(userId, '管理员用户 ID');
    const key = String(requestKey || '').trim();
    const safeReason = String(reason || '').trim();
    if (!key || key.length > 100) throw new ServiceError('Idempotency-Key 长度必须为 1-100');
    if (safeReason.length > 500) throw new ServiceError('补单原因不能超过 500 字符');
    try {
      return await this.db.transaction(async (tx) => {
      const existing = await tx.query('SELECT id, order_id AS orderId, order_item_id AS orderItemId, code_index AS codeIndex, generation, replacement_of_task_id AS replacementOfTaskId, created_by_user_id AS createdByUserId, replacement_reason AS replacementReason, request_key AS requestKey, steam_id AS steamId, task_type AS taskType, payload_json AS payloadJson, coin_amount AS coinAmount, item_id AS itemId, amount, status, attempts, created_at AS createdAt, updated_at AS updatedAt FROM fulfillment_tasks WHERE request_key = ? FOR UPDATE', [key]);
      if (existing[0]) return { ...existing[0], idempotent: true };
      const rows = await tx.query('SELECT id, order_id AS orderId, order_item_id AS orderItemId, code_index AS codeIndex, generation, steam_id AS steamId, task_type AS taskType, payload_json AS payloadJson, coin_amount AS coinAmount, item_id AS itemId, amount, status FROM fulfillment_tasks WHERE id = ? FOR UPDATE', [taskId]);
      const task = rows[0];
      if (!task) throw new ServiceError('任务不存在', 404, 'NOT_FOUND');
      const latest = await tx.query('SELECT id, generation FROM fulfillment_tasks WHERE order_item_id = ? AND code_index = ? ORDER BY generation DESC LIMIT 1 FOR UPDATE', [task.orderItemId, task.codeIndex]);
      if (Number(latest[0].id) !== taskId) throw new ServiceError('只允许基于最新一代任务创建补单', 409, 'NOT_LATEST_GENERATION');
      if (['pending', 'processing', 'dispatching', 'waiting_instance', 'waiting_offline', 'retry'].includes(task.status)) throw new ServiceError('任务仍在队列或处理中，不能创建补单', 409, 'TASK_ACTIVE');
      if (task.status === 'failed') throw new ServiceError('失败任务请使用原任务重试功能', 409, 'USE_RETRY');
      if (task.status === 'manual_review' && confirmUnknownDeliveryRisk !== true) throw new ServiceError('发货结果未知，必须显式确认重复发货风险', 409, 'CONFIRM_UNKNOWN_DELIVERY_RISK');
      if (task.status === 'completed' && !safeReason) throw new ServiceError('已完成任务补偿发货必须填写原因');
      if (!['manual_review', 'completed'].includes(task.status)) throw new ServiceError('当前任务状态不可创建补单', 409, 'NOT_REPLACEABLE');
      const generation = Number(task.generation) + 1;
      const inserted = await tx.query("INSERT INTO fulfillment_tasks (order_id, order_item_id, code_index, generation, replacement_of_task_id, created_by_user_id, replacement_reason, request_key, steam_id, task_type, payload_json, coin_amount, item_id, amount, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')", [task.orderId, task.orderItemId, task.codeIndex, generation, task.id, adminId, safeReason || null, key, task.steamId, task.taskType, task.payloadJson, task.coinAmount, task.itemId, task.amount]);
      await recomputeOrderStatus(tx, task.orderId);
      return { id: inserted.insertId, orderId: task.orderId, orderItemId: task.orderItemId, codeIndex: task.codeIndex, generation, replacementOfTaskId: task.id, createdByUserId: adminId, replacementReason: safeReason || null, requestKey: key, steamId: task.steamId, itemId: task.itemId, amount: task.amount, status: 'pending', attempts: 0, idempotent: false };
      });
    } catch (error) {
      if (!isDuplicateKey(error)) throw error;
      const existing = await this.db.query('SELECT id, order_id AS orderId, order_item_id AS orderItemId, code_index AS codeIndex, generation, replacement_of_task_id AS replacementOfTaskId, created_by_user_id AS createdByUserId, replacement_reason AS replacementReason, request_key AS requestKey, steam_id AS steamId, item_id AS itemId, amount, status, attempts, created_at AS createdAt, updated_at AS updatedAt FROM fulfillment_tasks WHERE request_key = ?', [key]);
      if (!existing[0]) throw error;
      return { ...existing[0], idempotent: true };
    }
  }

  async retryTask(id) {
    const taskId = positiveInt(id, '任务 ID');
    return this.db.transaction(async (tx) => {
      const rows = await tx.query('SELECT order_id AS orderId, status FROM fulfillment_tasks WHERE id = ? FOR UPDATE', [taskId]);
      if (!rows[0] || rows[0].status === 'manual_review' || !['failed', 'retry', 'waiting_instance', 'waiting_offline'].includes(rows[0].status)) throw new ServiceError('任务不存在或当前状态不可重试', 409, 'NOT_RETRYABLE');
      await tx.query("UPDATE fulfillment_tasks SET status = 'retry', next_attempt_at = CURRENT_TIMESTAMP(3), last_error = NULL, locked_at = NULL WHERE id = ?", [taskId]);
      await tx.query("UPDATE lottery_fulfillment_logs SET status='retry', error_summary=NULL WHERE fulfillment_task_id=?", [taskId]);
      await recomputeOrderStatus(tx, rows[0].orderId);
    });
  }

  async listAttempts(limit = 100) {
    const safeLimit = positiveInt(limit, '条数', 500);
    return this.db.query(`SELECT id, task_id AS taskId, attempt_no AS attemptNo, status, message, created_at AS createdAt FROM fulfillment_attempts ORDER BY id DESC LIMIT ${safeLimit}`);
  }

  async listLotteryFulfillmentLogs({ page = 1, limit = 50 } = {}) {
    const safePage = positiveInt(page, '页码');
    const safeLimit = Math.min(positiveInt(limit, '条数', 1000000), 100);
    const offset = (safePage - 1) * safeLimit;
    if (!Number.isSafeInteger(offset)) throw new ServiceError('页码过大');
    const totals = await this.db.query('SELECT COUNT(*) AS total FROM lottery_fulfillment_logs');
    const items = await this.db.query(`SELECT l.id, l.lottery_batch_id AS lotteryBatchId, l.lottery_draw_id AS lotteryDrawId, l.order_id AS orderId, o.order_no AS orderNo, l.fulfillment_task_id AS fulfillmentTaskId, l.steam_id AS steamId, l.pool_id AS poolId, l.pool_name_snapshot AS poolName, l.reward_type AS rewardType, l.reward_name_snapshot AS rewardName, l.task_type AS taskType, l.status, l.error_summary AS errorSummary, l.created_at AS createdAt, l.updated_at AS updatedAt FROM lottery_fulfillment_logs l JOIN orders o ON o.id=l.order_id ORDER BY l.id DESC LIMIT ${safeLimit} OFFSET ${offset}`);
    return { page: safePage, limit: safeLimit, total: Number(totals[0]?.total || 0), items };
  }
}

export function verifyCallback({ rawBody, timestamp, signature, sharedSecret, now = Date.now(), toleranceMs = 300000 }) {
  if (!sharedSecret) throw new ServiceError('回调密钥未配置', 503, 'NOT_CONFIGURED');
  const timestampText = String(timestamp || '');
  if (!/^\d{10,13}$/.test(timestampText)) throw new ServiceError('timestamp 无效', 401, 'INVALID_SIGNATURE');
  const milliseconds = timestampText.length === 10 ? Number(timestampText) * 1000 : Number(timestampText);
  if (Math.abs(now - milliseconds) > toleranceMs) throw new ServiceError('回调已过期', 401, 'EXPIRED_CALLBACK');
  const supplied = String(signature || '').replace(/^sha256=/i, '').toLowerCase();
  if (!/^[a-f0-9]{64}$/.test(supplied)) throw new ServiceError('signature 无效', 401, 'INVALID_SIGNATURE');
  const body = Buffer.isBuffer(rawBody) ? rawBody : Buffer.from(rawBody || '');
  const expected = crypto.createHmac('sha256', sharedSecret).update(timestampText).update('.').update(body).digest('hex');
  if (!crypto.timingSafeEqual(Buffer.from(supplied, 'hex'), Buffer.from(expected, 'hex'))) throw new ServiceError('签名校验失败', 401, 'INVALID_SIGNATURE');
  return true;
}












