const storefrontPageFragments = [
  '/shop/pages/store/index.html',
  '/shop/pages/activity/index.html',
  '/shop/pages/account/index.html',
  '/shop/pages/membership/index.html'
];
const storefrontNestedPageFragments = [
  { url: '/shop/pages/activity/insurance/index.html', target: 'activityInsuranceMount' },
  { url: '/shop/pages/activity/teleport/index.html', target: 'activityPanelMount' }
];
const storefrontModalFragments = [
  '/shop/pages/store/modals.html',
  '/shop/pages/activity/modals.html',
  '/shop/pages/activity/insurance/modals.html',
  '/shop/pages/activity/teleport/modals.html',
  '/shop/pages/account/modals.html',
  '/shop/pages/shared/auth-modal.html'
];
const storefrontScripts = [
  '/shop/js/core.js',
  '/shop/js/store.js',
  '/shop/js/activity.js',
  '/shop/js/teleport.js',
  '/shop/js/insurance.js',
  '/shop/js/account.js',
  '/shop/js/membership.js',
  '/shop/js/core-events.js'
];
const storefrontAssetVersion = '202611281043';
const storefrontCacheUrl = (url) => url + (url.includes('?') ? '&' : '?') + 'v=' + storefrontAssetVersion;
async function loadStorefrontScriptsInOrder() {
  const sources = storefrontScripts.map((url) => storefrontCacheUrl(url));
  const preloads = sources.map((source) => {
    const link = document.createElement('link');
    link.rel = 'preload';
    link.as = 'script';
    link.href = source;
    document.head.append(link);
    return link;
  });
  try {
    for (const [index, source] of sources.entries()) {
      await new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.async = false;
        script.src = source;
        script.onload = resolve;
        script.onerror = () => reject(new Error(`脚本加载失败：${storefrontScripts[index]}`));
        document.body.append(script);
      });
    }
  } finally {
    preloads.forEach((link) => link.remove());
  }
}
let storefrontRecoveryTimer = null;
let storefrontRecoveryPending = false;

function storefrontServiceErrorMarkup() {
  return '<button class="error-overlay-close" type="button" data-service-error-close aria-label="关闭提示">×</button>' +
    '<main class="error-layout"><section class="error-copy" aria-labelledby="serviceErrorTitle">' +
    '<p class="error-kicker">商城连接已中断</p><div class="error-code" aria-hidden="true">服务暂停</div>' +
    '<h1 id="serviceErrorTitle">商城服务暂时中断</h1>' +
    '<p class="error-description">商城业务正在重连或维护中。当前操作没有完成，请勿重复提交；连接恢复后页面会自动刷新。</p>' +
    '<div class="error-actions"><button class="error-button primary" type="button" data-service-error-retry>立即重试</button>' +
    '<button class="error-button secondary" type="button" data-service-error-close>继续浏览当前页面</button></div>' +
    '<p class="error-probe-message" data-service-probe-message aria-live="polite">系统将自动检测恢复状态</p></section>' +
    '<aside class="error-status" aria-label="连接状态"><div class="error-status-head"><span>连接状态</span><b data-service-error-badge>正在重新连接</b></div>' +
    '<dl><div><dt>已加载页面</dt><dd class="state-online">已保留</dd></div><div><dt>商城业务</dt><dd class="state-warning" data-service-business-state>等待恢复</dd></div><div><dt>恢复方式</dt><dd>自动检测</dd></div></dl>' +
    '<p>服务恢复后，本页面会自动更新</p></aside></main>';
}

function closeStorefrontServiceError() {
  document.querySelector('[data-service-error-overlay]')?.remove();
  if (storefrontRecoveryTimer) window.clearInterval(storefrontRecoveryTimer);
  storefrontRecoveryTimer = null;
}

async function probeStorefrontRecovery(manual = false) {
  const overlay = document.querySelector('[data-service-error-overlay]');
  if (!overlay || storefrontRecoveryPending) return;
  storefrontRecoveryPending = true;
  const retry = overlay.querySelector('[data-service-error-retry]');
  const message = overlay.querySelector('[data-service-probe-message]');
  if (retry) retry.disabled = true;
  if (message) message.textContent = manual ? '正在重新连接，请稍候' : '系统正在自动检测恢复状态';
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), 4500);
  try {
    const response = await fetch(`/api/health?error-probe=${Date.now()}`, { cache: 'no-store', credentials: 'same-origin', signal: controller.signal });
    const body = await response.json().catch(() => null);
    if (!response.ok || body?.success !== true || body?.data?.business === 'unavailable') throw new Error('unavailable');
    const business = overlay.querySelector('[data-service-business-state]');
    if (business) { business.textContent = '已经恢复'; business.classList.remove('state-warning'); business.classList.add('state-online'); }
    overlay.querySelector('[data-service-error-badge]').textContent = '连接已恢复';
    if (message) message.textContent = '商城连接已恢复，正在刷新页面';
    if (storefrontRecoveryTimer) window.clearInterval(storefrontRecoveryTimer);
    storefrontRecoveryTimer = null;
    window.setTimeout(() => location.reload(), 900);
  } catch {
    if (message) message.textContent = '尚未恢复，系统会继续自动检测';
  } finally {
    window.clearTimeout(timeout);
    storefrontRecoveryPending = false;
    if (retry && document.body.contains(retry)) retry.disabled = false;
  }
}

function showStorefrontServiceError() {
  if (document.querySelector('[data-service-error-overlay]')) return;
  const overlay = document.createElement('section');
  overlay.className = 'storefront-error-page error-service-overlay';
  overlay.dataset.serviceErrorOverlay = '';
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.setAttribute('aria-labelledby', 'serviceErrorTitle');
  overlay.innerHTML = storefrontServiceErrorMarkup();
  overlay.addEventListener('click', (event) => {
    if (event.target.closest('[data-service-error-retry]')) probeStorefrontRecovery(true);
    else if (event.target.closest('[data-service-error-close]')) closeStorefrontServiceError();
  });
  document.body.append(overlay);
  storefrontRecoveryTimer = window.setInterval(() => probeStorefrontRecovery(), 5000);
  probeStorefrontRecovery();
}

window.addEventListener('storefront:service-unavailable', showStorefrontServiceError);
window.addEventListener('online', () => probeStorefrontRecovery(true));

async function loadStorefront() {
  const pageMount = document.getElementById('shopPageMount');
  const modalMount = document.getElementById('shopModalMount');
  pageMount.hidden = true;
  try {
    const [pageResponses, nestedPageResponses, modalResponses] = await Promise.all([
      Promise.all(storefrontPageFragments.map((url) => fetch(storefrontCacheUrl(url)))),
      Promise.all(storefrontNestedPageFragments.map(({ url }) => fetch(storefrontCacheUrl(url)))),
      Promise.all(storefrontModalFragments.map((url) => fetch(storefrontCacheUrl(url))))
    ]);
    const failed = [...pageResponses, ...nestedPageResponses, ...modalResponses].find((response) => !response.ok);
    if (failed) { const error = new Error('商城资源加载失败，请刷新页面重试'); error.status = failed.status; throw error; }
    pageMount.innerHTML = (await Promise.all(pageResponses.map((response) => response.text()))).join('');
    const nestedPageHtml = await Promise.all(nestedPageResponses.map((response) => response.text()));
    storefrontNestedPageFragments.forEach(({ target }, index) => {
      const mount = document.getElementById(target);
      if (!mount) throw new Error(`页面挂载点不存在：${target}`);
      mount.innerHTML = nestedPageHtml[index];
    });
    modalMount.innerHTML = (await Promise.all(modalResponses.map((response) => response.text()))).join('');
    await loadStorefrontScriptsInOrder();
  } catch (error) {
    pageMount.hidden = false;
    const serviceFailure = !navigator.onLine || [502, 503, 504].includes(error?.status) || error instanceof TypeError;
    if (serviceFailure) showStorefrontServiceError();
    else pageMount.innerHTML = '<section class="page active"><div class="state-panel"><strong>商城资源加载失败</strong><small>页面资源不完整，请刷新后重试</small></div></section>';
    console.error(error);
  }
}

loadStorefront();
