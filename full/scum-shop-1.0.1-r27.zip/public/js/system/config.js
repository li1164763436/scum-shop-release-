let rconPluginState = null;
let rconPluginBusy = false;

function setupRconPluginPanel() {
  $('#panelApiConfigForm')?.remove();
  const rconForm = $('#scumRconConfigForm');
  const policyForm = $('#rconPolicyConfigForm');
  if (!rconForm || !policyForm || $('#rconPluginPanel')) return;
  const capabilityPanel = $('#bridgeCapabilities');
  capabilityPanel?.remove();
  const discoveryMode = rconForm.elements.discoveryMode;
  const discoveryField = discoveryMode.closest('label');
  const fixedDiscoveryMode = document.createElement('input');
  fixedDiscoveryMode.type = 'hidden';
  fixedDiscoveryMode.name = 'discoveryMode';
  fixedDiscoveryMode.value = 'manual';
  discoveryField.replaceWith(fixedDiscoveryMode);
  const directoryField = rconForm.elements.scumGameDirectory.closest('label');
  const passwordField = rconForm.elements.rconPassword.closest('label');
  const hostField = rconForm.elements.rconHost.closest('label');
  const portField = rconForm.elements.rconPort.closest('label');
  if (hostField) hostField.firstChild.textContent = 'RCON 连接地址';
  if (portField) portField.firstChild.textContent = 'RCON 连接端口';
  if (passwordField && directoryField) directoryField.before(passwordField);
  directoryField.classList.remove('span-3');
  $('.field-hint', directoryField)?.remove();
  $('h3', rconForm).textContent = 'SCUM 配置连接';
  $('#bridgeConfigDescription').textContent = '填写连接地址、连接端口、密码和游戏目录，保存后测试连接。';
  $('.config-card-index', rconForm).textContent = '01';
  $('.config-card-index', policyForm).textContent = '03';
  $('h3', policyForm).textContent = '连接策略';
  $('.card-head p', policyForm).textContent = '控制连接超时和断线重连。';
  policyForm.elements.maxPacketSize.closest('label').hidden = true;
  const connectionStatus = document.createElement('p');
  connectionStatus.className = 'rcon-connection-status';
  connectionStatus.dataset.bridgeReason = '';
  connectionStatus.textContent = '正在读取连接状态';
  $('.form-actions', rconForm).after(connectionStatus);
  const panel = document.createElement('section');
  panel.id = 'rconPluginPanel';
  panel.className = 'card form-card rcon-config-card';
  panel.innerHTML = `<div class='card-head'><div><span class='config-card-index'>02</span><h3>RCON 插件文件</h3><p>检查签名云端文件，并在游戏服务器安全停机窗口自动备份和替换。</p></div><button class='btn secondary' type='button' id='checkRconPlugins'>重新检查</button></div>`;
  panel.innerHTML += `<div class='plugin-toolbar'><span id='rconPluginDirectory'>未读取游戏目录</span><b id='rconPluginSummary'>正在自动检查</b></div>`;
  panel.innerHTML += `<div id='rconPluginFiles' class='plugin-files'><div class='empty'>正在检查云端插件文件</div></div>`;
  panel.innerHTML += `<p class='rcon-plugin-backup-note'>每个插件固定保留最近 3 份备份；替换并校验成功后自动清理多余旧备份。</p>`;
  panel.innerHTML += `<div class='form-actions'><span class='save-note'>下载后可创建待处理任务，游戏服务器停机时自动备份并替换</span><span class='inline-fields'><button class='btn secondary' type='button' id='downloadRconPlugins'>下载云端文件</button><button class='btn primary' type='button' id='replaceRconPlugins'>下次重启自动替换</button></span></div>`;
  const rconLayout = document.createElement('div');
  rconLayout.className = 'rcon-main-grid';
  rconForm.before(rconLayout);
  rconLayout.append(rconForm, panel);
  updateRconPluginButtons();
  $('#checkRconPlugins').addEventListener('click', () => withRconPluginBusy(() => inspectRconPlugins()));
  $('#downloadRconPlugins').addEventListener('click', () => withRconPluginBusy(() => updateRconPlugins('download')));
  $('#replaceRconPlugins').addEventListener('click', () => {
    if (rconPluginBusy) return;
    if (window.confirm('确认创建插件自动替换任务？游戏服务器运行时会等待下次停机窗口，停机后自动备份、替换并校验。')) withRconPluginBusy(() => updateRconPlugins('replace'));
  });
}
function rconPluginDirectory() {
  return $('#scumRconConfigForm').elements.scumGameDirectory.value.trim();
}
function updateRconPluginButtons() {
  const data = rconPluginState;
  const files = data?.files || [];
  const syncPending = ['pending', 'applying'].includes(data?.sync?.status);
  const outdated = files.some((file) => !file.matches);
  const downloaded = files.length > 0 && files.every((file) => file.downloaded);
  $('#checkRconPlugins').disabled = rconPluginBusy;
  $('#downloadRconPlugins').disabled = rconPluginBusy || !data || syncPending || !outdated || downloaded;
  $('#replaceRconPlugins').disabled = rconPluginBusy || !data || syncPending || !outdated || !downloaded;
}
async function withRconPluginBusy(task) {
  if (rconPluginBusy) return null;
  rconPluginBusy = true;
  updateRconPluginButtons();
  try { return await task(); }
  catch (error) { toast(error.message, true); return null; }
  finally {
    rconPluginBusy = false;
    updateRconPluginButtons();
  }
}
function renderRconPlugins(data) {
  rconPluginState = data;
  const outdated = data.files.filter((file) => !file.matches).length;
  const syncPending = ['pending', 'applying'].includes(data.sync?.status);
  const syncFailed = data.sync?.status === 'failed';
  const cleanupIncomplete = data.sync?.status === 'completed' && data.sync.backupCleanup?.failed > 0;
  $('#rconPluginDirectory').textContent = data.directory;
  const summary = $('#rconPluginSummary');
  summary.dataset.status = syncPending ? 'pending' : syncFailed ? 'failed' : cleanupIncomplete ? 'warning' : outdated ? 'outdated' : 'current';
  summary.textContent = syncPending
    ? `自动替换已安排 · ${data.sync.message}`
    : syncFailed
      ? `插件同步失败 · ${data.sync.message || '请重新检查后重试'}`
      : cleanupIncomplete
        ? '插件已完成替换，旧备份清理未完成'
        : outdated
          ? `云端有新文件 · ${outdated} 个待更新 · 版本 ${data.version}`
          : `插件文件已是云端最新 · 版本 ${data.version}`;
  updateRconPluginButtons();
  $('#rconPluginFiles').innerHTML = data.files.map((file) => {
    const state = !file.installed ? '云端有新文件（本地缺失）' : file.matches ? '当前一致' : '云端有新文件';
    const cache = file.downloaded ? '已下载并校验' : '云端文件未下载';
    return `<article class='plugin-file ${file.matches ? 'ok' : 'bad'}'><strong>${esc(file.name)}</strong><span>${state}</span><small>${cache} · 本地 ${formatBytes(file.size)} / 云端 ${formatBytes(file.expectedSize)}</small><details class='rcon-plugin-checksums'><summary>查看 SHA256 校验值</summary><small>本地 SHA256：${esc(file.sha256 || '无')}</small><small>云端 SHA256：${esc(file.expectedSha256)}</small></details></article>`;
  }).join('');
}
function renderRconPluginError(error) {
  rconPluginState = null;
  $('#rconPluginSummary').dataset.status = 'failed';
  $('#rconPluginSummary').textContent = '插件检查失败';
  $('#rconPluginFiles').innerHTML = `<div class='empty'>${esc(error?.message || '插件文件检查失败')}</div>`;
  updateRconPluginButtons();
}
async function inspectRconPlugins({ automatic = false } = {}) {
  rconPluginState = null;
  updateRconPluginButtons();
  $('#rconPluginSummary').dataset.status = 'checking';
  $('#rconPluginSummary').textContent = automatic ? '正在自动检查' : '正在检查';
  const query = new URLSearchParams({ directory: rconPluginDirectory() });
  try {
    const data = await api(`/api/rcon/plugins?${query}`);
    renderRconPlugins(data);
    return data;
  } catch (error) {
    renderRconPluginError(error);
    if (!automatic) throw error;
    return null;
  }
}
async function updateRconPlugins(action) {
  const data = await api(`/api/rcon/plugins/${action}`, { method: 'POST', body: JSON.stringify({ directory: rconPluginDirectory() }) });
  renderRconPlugins(data);
  if (action === 'download') toast('插件文件已下载并校验');
  else toast(data.sync?.message || '插件同步任务保持待处理状态', data.sync?.status === 'failed' || data.sync?.backupCleanup?.failed > 0);
}
setupRconPluginPanel();

async function loadVersionUpdate() {
  const data = await api('/api/admin/version-update/status');
  const card = $('#versionUpdateStatusCard');
  card.dataset.status = data.status || 'idle';
  state.versionUpdateStatus = data.status || 'idle';
  const progress = Math.max(0, Math.min(100, Number(data.progress || 0)));
  const downloading = data.status === 'downloading';
  const statusMessage = String(data.message || '');
  let message = data.message || '检查完成';
  let badge = '已检查';
  let mode = 'checked';
  let bar = 100;
  if (downloading) { const reusing = statusMessage.startsWith('已复用'); message = reusing ? '正在复用已存在的更新文件' : '正在下载更新文件'; badge = reusing ? '复用中' : '下载中'; mode = 'downloading'; bar = progress; }
  else if (data.status === 'preparing') { message = '正在准备下载文件'; badge = '准备中'; mode = 'downloading'; bar = progress; }
  else if (!data.status || data.status === 'idle') { const changed = Number(state.versionUpdateManifest?.changedFileCount || 0); message = changed > 0 ? `检查完成，有 ${changed} 个文件更新` : '检查完成，当前已是最新版本'; }
  else if (data.status === 'ready') { message = '下载完成，等待安装替换'; badge = '可安装'; mode = 'ready'; bar = 100; }
  else if (['applying', 'staging', 'stopping', 'backing_up', 'installing', 'starting', 'rollback'].includes(data.status)) { message = data.message || '正在安装更新'; badge = '安装中'; mode = 'installing'; bar = progress; }
  else if (data.status === 'completed') { message = '更新完成'; badge = '已完成'; mode = 'checked'; bar = 100; }
  else if (data.status === 'failed') { message = data.message || '更新失败'; badge = '失败'; mode = 'failed'; bar = 100; }
  card.className = `version-update-current-status ${mode}`;
  card.dataset.status = data.status || 'idle';
  $('#versionUpdateStatus').textContent = badge;
  $('#versionUpdateMessage').textContent = message;
  $('#versionUpdateStatusBar').style.width = `${bar}%`;
  $('#versionUpdateCurrentFile').textContent = `下载进度：${progress}%`;
  $('#versionUpdateStatusDetail').hidden = !downloading;
  $('#versionUpdateTime').textContent = date(data.updatedAt);
  $('#installVersionUpdate').disabled = data.status !== 'ready';
  $('#downloadVersionUpdate').disabled = !state.versionUpdateManifest?.updateAvailable || ['preparing', 'downloading', 'ready', 'applying', 'staging', 'stopping', 'backing_up', 'installing', 'starting', 'rollback'].includes(data.status);
  renderVersionUpdateFiles();
  return data;
}
function renderVersionUpdateFiles() {
  const files = [...(state.versionUpdateManifest?.files || [])].sort((left, right) => Number(left.matches) - Number(right.matches) || String(left.path).localeCompare(String(right.path), 'zh-CN'));
  const pageSize = 5;
  const pageCount = Math.max(1, Math.ceil(files.length / pageSize));
  state.versionUpdateFilePage = Math.max(1, Math.min(pageCount, Number(state.versionUpdateFilePage || 1)));
  const start = (state.versionUpdateFilePage - 1) * pageSize;
  const page = files.slice(start, start + pageSize);
  $('#versionUpdateFileList').innerHTML = page.length ? page.map(file => {
    const name = file.path.split('/').pop();
    const currentSize = formatBytes(file.localSize);
    const targetSize = formatBytes(file.size);
    const downloaded = !file.matches && ['ready', 'applying', 'staging', 'stopping', 'backing_up', 'installing', 'starting'].includes(state.versionUpdateStatus);
    const installState = file.matches ? { className: 'installed', label: '已安装' } : downloaded ? { className: 'downloaded', label: '已下载' } : { className: 'pending', label: '需更新' };
    return `<article class="version-update-file"><span class="version-update-install-state ${installState.className}">${installState.label}</span><div class="version-update-file-name"><strong title="${esc(file.path)}">${esc(name)}</strong></div><span class="version-update-file-size" title="${esc(currentSize)}">${currentSize}</span><span class="version-update-file-size version-update-file-target-size" title="${esc(targetSize)}">${targetSize}</span><code title="${esc(file.sha256)}">${esc(file.sha256)}</code></article>`;
  }).join('') : '<div class="empty">没有更新文件</div>';
  $('#versionUpdatePageInfo').textContent = `第 ${state.versionUpdateFilePage} / ${pageCount} 页 · 共 ${files.length} 个文件`;
  $('#versionUpdatePrevPage').disabled = state.versionUpdateFilePage <= 1;
  $('#versionUpdateNextPage').disabled = state.versionUpdateFilePage >= pageCount;
}
async function loadVersionUpdateManifest() {
  const data = await api('/api/admin/version-update/manifest');
  state.versionUpdateManifest = data;
  state.versionUpdateFilePage = 1;
  const releaseLabel = (version, revision) => `${version || '--'}${Number(revision) > 0 ? ` (r${revision})` : ''}`;
  $('#versionUpdateCurrentVersion').textContent = releaseLabel(data.currentVersion, data.currentReleaseRevision);
  $('#versionUpdateRemoteVersion').textContent = releaseLabel(data.latestVersion, data.latestReleaseRevision);
  $('#versionUpdateFileCount').textContent = `${data.changedFileCount || 0} / ${data.fileCount || 0}`;
  $('#versionUpdateCurrentChecksum').textContent = data.currentChecksum || '--';
  $('#versionUpdateRemoteChecksum').textContent = data.remoteChecksum || '--';
  $('#versionUpdateChangedCount').textContent = `${data.changedFileCount || 0} 个文件需要更新`;
  renderVersionUpdateFiles();
  if (['idle', 'completed', 'failed', undefined].includes($('#versionUpdateStatusCard')?.dataset.status)) {
    const changed = Number(data.changedFileCount || 0);
    $('#versionUpdateStatusCard').className = 'version-update-current-status checked';
    $('#versionUpdateStatus').textContent = '已检查';
    $('#versionUpdateMessage').textContent = changed > 0 ? `检查完成，有 ${changed} 个文件更新` : '检查完成，当前已是最新版本';
    $('#versionUpdateStatusBar').style.width = '100%';
    $('#versionUpdateStatusDetail').hidden = true;
  }
  $('#downloadVersionUpdate').disabled = !data.updateAvailable || ['preparing', 'downloading', 'ready', 'applying', 'staging', 'stopping', 'backing_up', 'installing', 'starting', 'rollback'].includes($('#versionUpdateStatusCard')?.dataset.status);
  return data;
}
async function openVersionUpdateConfig() {
  const modal = $('#versionUpdateConfigModal');
  modal.classList.add('open');
  modal.setAttribute('aria-hidden', 'false');
  await withBusy($('#reloadVersionUpdate'), () => Promise.all([loadVersionUpdateManifest(), loadVersionUpdate()]));
}
function closeVersionUpdateConfig() {
  $('#versionUpdateConfigModal').classList.remove('open');
  $('#versionUpdateConfigModal').setAttribute('aria-hidden', 'true');
}
async function pollVersionUpdateCard() {
  try {
    const data = await loadVersionUpdate();
    if (data.status === 'completed') { await loadVersionUpdateManifest().catch(() => {}); return; }
    if (['ready', 'failed'].includes(data.status)) return;
  } catch {
    const installing = ['applying', 'staging', 'stopping', 'backing_up', 'installing', 'starting', 'rollback'].includes($('#versionUpdateStatusCard')?.dataset.status);
    $('#versionUpdateMessage').textContent = installing ? '商城服务正在重启，等待恢复连接' : '下载状态读取失败，正在重试';
  }
  state.versionUpdateTimer = setTimeout(pollVersionUpdateCard, 1000);
}
async function downloadVersionUpdate(button) {
  await withBusy(button, async () => {
    const manifest = state.versionUpdateManifest || await loadVersionUpdateManifest();
    if (!manifest.updateAvailable) {
      window.alert(`当前版本 ${manifest.currentVersion} 已是最新版本。`);
      return;
    }
    try {
      await api('/api/admin/version-update/download', { method: 'POST' });
      clearTimeout(state.versionUpdateTimer);
      await loadVersionUpdate();
      state.versionUpdateTimer = setTimeout(pollVersionUpdateCard, 300);
    } catch (error) {
      $('#versionUpdateMessage').textContent = error.message;
      throw error;
    }
  });
}
async function installVersionUpdate(button) {
  if (!window.confirm('安装更新将关闭启动器和商城服务，安装完成后自动重新打开启动器并启动商城。是否继续？')) return;
  await withBusy(button, async () => {
    try {
      await api('/api/admin/version-update/install', { method: 'POST' });
      clearTimeout(state.versionUpdateTimer);
      await loadVersionUpdate();
      state.versionUpdateTimer = setTimeout(pollVersionUpdateCard, 300);
    } catch (error) {
      $('#versionUpdateMessage').textContent = error.message;
      $('#versionUpdateStatusCard').className = 'version-update-current-status failed';
      $('#versionUpdateStatus').textContent = '失败';
      $('#versionUpdateStatusBar').style.width = '100%';
      throw error;
    }
  });
}

async function loadLicenseAccount() {
  let data;
  try { data = await api('/api/license/status'); }
  catch (error) {
    if (error.status !== 404) throw error;
    const dashboard = await api('/api/dashboard');
    data = dashboard?.license ? { activated: true, ...dashboard.license } : { activated: false };
  }
  const activated = data.activated === true;
  const expiresAt = activated && data.expiresAt ? new Date(data.expiresAt) : null;
  const expired = Boolean(expiresAt && expiresAt.getTime() <= Date.now());
  const statePanel = $('#licenseAccountState');
  statePanel.className = `license-account-state ${!activated ? 'inactive' : expired ? 'expired' : 'active'}`;
  $('.license-account-badge', statePanel).className = `license-account-badge ${!activated ? 'inactive' : expired ? 'expired' : 'active'}`;
  $('.license-account-badge', statePanel).textContent = !activated ? '未授权' : expired ? '已过期' : '授权有效';
  $('strong', statePanel).textContent = !activated ? '商城程序尚未激活授权' : data.username || '--';
  $('small', statePanel).textContent = !activated ? '请通过启动授权页面完成账号连接' : expired ? '授权已超过有效期' : '授权验证正常';
  $('#licenseAccountUsername').textContent = activated ? data.username || '--' : '--';
  $('#licenseAccountStatus').textContent = !activated ? '未授权' : expired ? '已过期' : '有效';
  $('#licenseAccountExpiresAt').textContent = activated ? date(data.expiresAt) : '--';
  $('#licenseAccountVerifiedAt').textContent = activated ? date(data.lastVerifiedAt) : '--';
  $('#licenseAccountCenter').textContent = activated ? data.baseUrl || '--' : 'https://sq.scum0.cn';
  return data;
}

const pendingRconPasswords = new WeakMap();
function maskRconPassword(value) {
  const secret = String(value || '');
  if (!secret) return '';
  if (secret.length <= 4) return '•'.repeat(secret.length);
  const edge = secret.length <= 8 ? 2 : 4;
  return `${secret.slice(0, edge)}${'•'.repeat(Math.max(6, secret.length - edge * 2))}${secret.slice(-edge)}`;
}

async function loadConfig() {
  try {
    state.config = await api('/api/config') || {};
    if (!state.products.length) {
      try { state.products = list(await api('/api/products'), ['products', 'items']); } catch { /* SKU 仍可手工安全输入。 */ }
    }
    fillConfigForms();
    await Promise.all([loadBridgeStatus(), loadLicenseAccount(), withRconPluginBusy(() => inspectRconPlugins({ automatic: true }))]);
    await loadHealth();
  } catch (error) { toast(error.message, true); }
}
function fillConfigForms() {
  const config = state.config;
  const basic = $('#basicConfigForm').elements;
  const mysql = config.mysql || {};
  basic.mysqlHost.value = mysql.host || '';
  basic.mysqlPort.value = mysql.port || 3306;
  basic.mysqlUser.value = mysql.user || '';
  basic.mysqlDatabase.value = mysql.database || '';
  $('#mysqlPasswordState').textContent = mysql.hasPassword ? '密码已配置' : '密码未配置';

  const ggcon = config.ggcon || {};
  const rcon = $('#scumRconConfigForm').elements;
  rcon.discoveryMode.value = 'manual';
  rcon.rconHost.value = !ggcon.host || ggcon.host === '0.0.0.0' || ggcon.host === '::' ? '127.0.0.1' : ggcon.host;
  rcon.rconPort.value = ggcon.port || 0;
  rcon.scumGameDirectory.value = ggcon.gameDirectory || '';
  const pendingPassword = pendingRconPasswords.get(rcon.rconPassword) || '';
  rcon.rconPassword.value = maskRconPassword(pendingPassword);
  rcon.rconPassword.placeholder = ggcon.hasPassword ? '密钥已配置（完整内容已隐藏）' : '请先点击自动生成密钥';
  const policy = $('#rconPolicyConfigForm').elements;
  policy.connectTimeoutMs.value = ggcon.connectTimeoutMs || 5000;
  policy.authTimeoutMs.value = ggcon.authTimeoutMs || 5000;
  policy.commandTimeoutMs.value = ggcon.commandTimeoutMs || 5000;
  policy.maxPacketSize.value = ggcon.maxPacketSize || 1048576;
  policy.reconnectEnabled.checked = config.reconnect?.enabled !== false;
  policy.maxAttempts.value = config.reconnect?.maxAttempts || 4;
  policy.baseDelayMs.value = config.reconnect?.baseDelayMs ?? 500;
  policy.maxDelayMs.value = config.reconnect?.maxDelayMs ?? 5000;
  $('#rconPasswordState').textContent = pendingPassword ? '（待保存，中间已隐藏）' : ggcon.hasPassword ? '（已自动读取）' : '（未配置）';
  $('#scumGameDirectoryState').textContent = ggcon.hasServerDirectory ? '（已配置）' : '（未配置）';
  const pipeMode = ggcon.mode === 'scum-shop-pipe';
  $$('#tcpRconFields input:not([name="scumGameDirectory"]), #tcpRconFields select, #rconPolicyConfigForm input[name="connectTimeoutMs"], #rconPolicyConfigForm input[name="authTimeoutMs"], #rconPolicyConfigForm input[name="commandTimeoutMs"], #rconPolicyConfigForm input[name="maxPacketSize"]').forEach((node) => { node.disabled = pipeMode; });
  $('#bridgeConfigDescription').textContent = pipeMode ? `当前为 SCUM 商城管道模式（端点 ${ggcon.endpointFile || 'runtime/bridge/endpoint.json'}），此页不会切换或覆盖模式。` : '当前为 Source TCP 模式，可配置本机 RCON 连接。';

}
async function saveConfig(partial) {
  const current = await api('/api/config');
  const payload = { ...current, ...state.config, ...partial };
  for (const key of Object.keys(partial)) {
    if (partial[key] && typeof partial[key] === 'object' && !Array.isArray(partial[key])) {
      payload[key] = { ...(current[key] || {}), ...(state.config[key] || {}), ...partial[key] };
    }
  }
  const saved = await api('/api/config', { method: 'PUT', body: JSON.stringify(payload) });
  state.config = saved || state.config;
  return Boolean(saved?.restartRequired);
}

async function testConnection(target, button) {
  await withBusy(button, async () => {
    const data = await api('/api/connections/test', { method: 'POST', body: JSON.stringify({ target }) });
    const result = data?.[target] || data;
    toast(result?.message || `${target === 'gsm3' ? 'GSM3' : 'SCUM 商城桥接'} 连接正常`, result?.ok === false && !result?.degraded);
    await Promise.all([loadBridgeStatus(), loadHealth()]);
  });
}

$('#basicConfigForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  await withBusy(event.submitter, async () => {
    const f = event.currentTarget.elements;
    const restartRequired = await saveConfig({
      mysql: { host: f.mysqlHost.value.trim(), port: Number(f.mysqlPort.value), user: f.mysqlUser.value.trim(), database: f.mysqlDatabase.value.trim(), password: f.mysqlPassword.value }
    });
    f.mysqlPassword.value = '';
    toast(restartRequired ? '数据库配置已保存，重启服务后生效' : '数据库配置已保存');
    await loadConfig();
  });
});

$('#generateRconPassword').addEventListener('click', () => {
  const f = $('#scumRconConfigForm').elements;
  const password = generateRconPassword();
  pendingRconPasswords.set(f.rconPassword, password);
  f.rconPassword.value = maskRconPassword(password);
  $('#rconPasswordState').textContent = '（待保存，中间已隐藏）';
});

$('#scumRconConfigForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  await withBusy(event.submitter, async () => {
    const f = event.currentTarget.elements;
    const rconPassword = pendingRconPasswords.get(f.rconPassword) || '';
    await saveConfig({ ggcon: { mode: 'source-tcp', discoveryMode: 'manual', serverDirectory: f.scumGameDirectory.value.trim(), host: f.rconHost.value.trim(), port: 28015, ...(rconPassword ? { password: rconPassword, syncPassword: true } : {}) } });
    pendingRconPasswords.delete(f.rconPassword);
    f.rconPassword.value = '';
    toast(rconPassword ? 'RCON 密钥已同步，请重启 SCUM 游戏服务端后再测试连接' : '配置连接已保存');
    await loadConfig();
  });
});

$('#rconPolicyConfigForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  await withBusy(event.submitter, async () => {
    const f = event.currentTarget.elements;
    await saveConfig({
      ggcon: { connectTimeoutMs: Number(f.connectTimeoutMs.value), authTimeoutMs: Number(f.authTimeoutMs.value), commandTimeoutMs: Number(f.commandTimeoutMs.value), maxPacketSize: Number(f.maxPacketSize.value) },
      reconnect: { enabled: f.reconnectEnabled.checked, maxAttempts: Number(f.maxAttempts.value), baseDelayMs: Number(f.baseDelayMs.value), maxDelayMs: Number(f.maxDelayMs.value) }
    });
    toast('连接与超时配置已保存');
    await loadConfig();
  });
});




$('#downloadVersionUpdate')?.addEventListener('click', (event) => downloadVersionUpdate(event.currentTarget));
$('#installVersionUpdate')?.addEventListener('click', (event) => installVersionUpdate(event.currentTarget));
$('#versionUpdatePrevPage')?.addEventListener('click', () => { state.versionUpdateFilePage -= 1; renderVersionUpdateFiles(); });
$('#versionUpdateNextPage')?.addEventListener('click', () => { state.versionUpdateFilePage += 1; renderVersionUpdateFiles(); });
$('#closeVersionUpdateConfig')?.addEventListener('click', closeVersionUpdateConfig);


$('#reloadLicenseAccount')?.addEventListener('click', (event) => withBusy(event.currentTarget, loadLicenseAccount));

document.addEventListener('click', (event) => {
  const button = event.target.closest('[data-config-tab]');
  if (!button) return;
  const page = button.closest('#page-config');
  if (!page) return;
  $$('.tab', page).forEach((item) => item.classList.toggle('active', item === button));
  $$('.tab-panel', page).forEach((panel) => panel.classList.toggle('active', panel.id === `config-${button.dataset.configTab}`));
});
$$('[data-test]').forEach((button) => button.addEventListener('click', () => testConnection(button.dataset.test, button)));

$('#reloadVersionUpdate')?.addEventListener('click', (event) => withBusy(event.currentTarget, () => Promise.all([loadVersionUpdateManifest(), loadVersionUpdate()])));



