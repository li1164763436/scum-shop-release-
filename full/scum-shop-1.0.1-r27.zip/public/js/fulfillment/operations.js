let adminLoginPromise = null;
let commerceLogView = 'orders';
let redeemLogView = 'cdk';
let logLoadVersion = 0;
const orderLogNav = $('.rcon-order-nav');
const orderLogTitle = $('#logPanelTitle')?.closest('.card')?.querySelector('.card-head');
if (orderLogNav && orderLogTitle) {
  orderLogNav.innerHTML = '<button class="active" type="button" data-commerce-log="orders">订单日志</button><button type="button" data-commerce-log="gifts">礼包日志</button><button type="button" data-commerce-log="redeem">兑换日志</button><button type="button" data-commerce-log="rewards">签到日志</button><button type="button" data-commerce-log="lottery">抽奖日志</button><button type="button" data-commerce-log="stocks">股市日志</button><button type="button" data-commerce-log="warehouse">仓库日志</button><button type="button" data-commerce-log="backend">后台日志</button>';
  orderLogTitle.after(orderLogNav);
}
function selectLogSource(source) {
  logLoadVersion += 1;
  const previousSource = $('#logSourceFilter').value;
  $('#logSourceFilter').value = source;
  if (previousSource !== source) $('#logSearch').value = '';
  $$('.log-source-tabs [data-log-source]').forEach((node) => node.classList.toggle('active', node.dataset.logSource === source));
  const showCategories = source === 'scum' || source === 'shop';
  $('#logCategoryTabs').hidden = !showCategories;
  $('#logCategoryTabs').style.display = showCategories ? '' : 'none';
  const meta = logSourceMeta[source] || logSourceMeta.shop;
  $('#logPanelTitle').textContent = meta[0];
  $('#logPanelDescription').textContent = meta[1];
  orderLogNav?.classList.toggle('visible', source === 'ue4ss');
  if (source === 'ue4ss') return loadCommerceLogView(commerceLogView);
  $('#logLimit').value = '300';
  $('#logCategoryFilter').value = ({ scum: 'admin_command', shop: 'all', ue4ss: 'ue4ss' })[source] || '';
  return loadLogs();
}
function loadLogOverview() {
  commerceLogView = 'backend';
  redeemLogView = 'cdk';
  return selectLogSource('ue4ss');
}
async function loadCommerceLogView(view) {
  const requestVersion = ++logLoadVersion;
  commerceLogView = view;
  $('#logCategoryTabs').hidden = true;
  $('#logCategoryTabs').style.display = 'none';
  $$('[data-commerce-log]', orderLogNav).forEach((button) => button.classList.toggle('active', button.dataset.commerceLog === view));
  if (view === 'backend') {
    $('#logPanelDescription').textContent = '商城后台运行、警告与错误日志，重复事件已合并显示';
    $('#logSourceFilter').value = 'shop';
    $('#logCategoryFilter').value = 'all';
    $('#logLimit').value = '300';
    $('#logCategoryTabs').hidden = false;
    $('#logCategoryTabs').style.display = '';
    await loadLogs();
    return;
  }
  $('#logSourceFilter').value = 'ue4ss';
  if (view === 'orders') {
    $('#logPanelDescription').textContent = '商城购买商品产生的订单记录';
    const orders = list(await api('/api/order-logs?limit=300'), ['orders', 'items']);
    if (requestVersion !== logLoadVersion) return;
    state.orderLogEntries = orders;
    $('#logCount').textContent = `${orders.length} 条订单记录`;
    renderOrderLogs();
    return;
  }
  if (view === 'gifts') {
    $('#logPanelDescription').textContent = '玩家领取商城礼包产生的记录';
    const claims = list(await api('/api/gift-claim-logs?limit=300'), ['items', 'claims']);
    if (requestVersion !== logLoadVersion) return;
    state.giftLogEntries = claims;
    $('#logCount').textContent = `${claims.length} 条礼包记录`;
    renderGiftLogs();
    return;
  }
  if (view === 'redeem') {
    return loadRedeemLogView(redeemLogView);
  }
  if (view === 'rewards') {
    $('#logPanelDescription').textContent = '签到和在线奖励领取记录';
    const claims = list(await api('/api/reward-claims?limit=300'), ['items', 'claims']);
    if (requestVersion !== logLoadVersion) return;
    $('#logCount').textContent = `${claims.length} 条签到记录`;
    const rows = claims.map((item) => `<tr><td>${esc(date(item.createdAt))}</td><td><code>${esc(item.steamId || '--')}</code></td><td>${esc(item.ruleType || '--')}</td><td>${esc(item.productName || item.giftName || (item.coinAmount != null ? `${number(item.coinAmount)} 商城币` : '--'))}</td><td><code>${esc(item.orderNo || item.orderId || '--')}</code></td><td>${item.status ? status(item.status) : '--'}</td></tr>`).join('');
    $('#logOutput').innerHTML = `<section class="structured-audit"><header class="structured-audit-head"><h3>签到日志<b>共 ${claims.length} 条</b></h3></header>${auditTable(['时间','SteamID','规则类型','奖励','订单号','状态'], rows, '暂无签到日志')}</section>`;
    return;
  }
  if (view === 'lottery') {
    $('#logPanelDescription').textContent = '玩家参与商城抽奖产生的记录';
    const records = list(await api('/api/lottery/records?limit=300'), ['items', 'records']);
    if (requestVersion !== logLoadVersion) return;
    state.lotteryLogEntries = records;
    $('#logCount').textContent = `${records.length} 条抽奖记录`;
    const rows = records.map((item) => { const draws = Number(item.drawCount || 0), drawLabel = draws === 10 ? '十连抽' : draws === 1 ? '单抽' : `${draws} 次`; return `<tr><td><span class="lottery-log-time">${esc(date(item.createdAt))}</span></td><td><span class="lottery-log-player"><strong>${esc(item.playerName || '未记录玩家昵称')}</strong><br><code>${esc(item.steamId || '未记录 SteamID')}</code></span></td><td><strong class="lottery-log-pool">${esc(item.poolName || '--')}</strong></td><td><span class="lottery-log-draw ${draws === 10 ? 'ten' : 'single'}"><strong>${number(draws)} 次</strong><small>${esc(drawLabel)}</small></span></td><td><strong class="lottery-log-paid">${number(item.pricePaid)}</strong></td><td><strong class="lottery-log-winning">${number(item.winningAmount)}</strong></td><td><span class="lottery-log-luck"><b>${number(item.pityBefore)}</b><i>→</i><b>${number(item.pityAfter)}</b></span></td><td><button class="btn tiny" type="button" data-lottery-log-detail="${item.id}">查看详情</button></td></tr>`; }).join('');
    $('#logOutput').innerHTML = `<section class="structured-audit lottery-log-audit"><header class="structured-audit-head"><h3>抽奖日志<b>共 ${records.length} 条</b></h3></header>${auditTable(['时间','玩家（玩家昵称/SteamID）','奖池','抽奖次数（单抽还是十连抽）','支付金额','中奖金额','幸运值','操作'], rows, '暂无抽奖日志')}</section>`;
    return;
  }
  if (view === 'stocks') {
    $('#logPanelDescription').textContent = '玩家买入和卖出股票产生的交易记录';
    const trades = list(await api('/api/stock-trades?limit=300'), ['items', 'trades']);
    if (requestVersion !== logLoadVersion) return;
    $('#logCount').textContent = `${trades.length} 条股市记录`;
    const rows = trades.map((item) => `<tr><td>${esc(date(item.createdAt))}</td><td><code>${esc(item.steamId || '--')}</code></td><td>${esc(item.code || '--')}</td><td>${item.direction === 'buy' ? '买入' : '卖出'}</td><td>${number(item.quantity)}</td><td>${number(item.price)}</td><td>${number(item.fee)}</td><td>${number(item.netAmount)}</td></tr>`).join('');
    $('#logOutput').innerHTML = `<section class="structured-audit"><header class="structured-audit-head"><h3>股市日志<b>共 ${trades.length} 条</b></h3></header>${auditTable(['时间','SteamID','股票','方向','数量','价格','手续费','结算金额'], rows, '暂无股市日志')}</section>`;
    return;
  }
  $('#logPanelDescription').textContent = '云储仓库入库、出库、上架和玩家交易记录';
  const warehouse = await api('/api/cloud-warehouse');
  if (requestVersion !== logLoadVersion) return;
  const inventory = list(warehouse, ['inventory']);
  state.warehouseLogEntries = [
    ...inventory.map((item) => ({ createdAt: item.createdAt, type: '入库', sellerName: item.playerName, sellerSteamId: item.steamId, buyerName: '', buyerSteamId: '', itemName: item.itemName || item.itemCode, quantity: item.quantity, amount: null })),
    ...inventory.filter((item) => item.status === 'empty').map((item) => ({ createdAt: item.updatedAt || item.createdAt, type: '出库', sellerName: '', sellerSteamId: '', buyerName: item.playerName, buyerSteamId: item.steamId, itemName: item.itemName || item.itemCode, quantity: item.quantity, amount: null })),
    ...list(warehouse, ['listingLogs', 'listings']).map((item) => ({ createdAt: item.createdAt, type: '上架', sellerName: item.sellerName, sellerSteamId: item.sellerSteamId, buyerName: '', buyerSteamId: '', itemName: item.itemName || item.itemCode, quantity: item.quantity, amount: Number(item.unitPrice || 0) * Number(item.quantity || 0) })),
    ...list(warehouse, ['trades']).map((item) => ({ createdAt: item.createdAt, type: '交易', sellerName: item.sellerName, sellerSteamId: item.sellerSteamId, buyerName: item.buyerName, buyerSteamId: item.buyerSteamId, itemName: item.itemName || item.itemCode, quantity: item.quantity, amount: item.grossAmount }))
  ].sort((left, right) => new Date(right.createdAt) - new Date(left.createdAt));
  $('#logCount').textContent = `${state.warehouseLogEntries.length} 条仓库记录`;
  renderWarehouseLogs();
}

function warehousePlayer(name, steamId) {
  if (!name && !steamId) return '<span class="muted">--</span>';
  return `<span class="warehouse-log-player"><strong>${esc(name || '未记录游戏名')}</strong><br><code>${esc(steamId || '未记录 SteamID')}</code></span>`;
}

function renderWarehouseLogs(keyword = '') {
  const normalized = String(keyword || '').trim().toLowerCase();
  const keywords = normalized.split(/\s+/).filter(Boolean);
  const entries = (state.warehouseLogEntries || []).filter((item) => {
    const searchable = [item.type, item.sellerName, item.sellerSteamId, item.buyerName, item.buyerSteamId, item.itemName, item.quantity, item.amount].map((value) => String(value ?? '').toLowerCase()).join(' ');
    return keywords.every((word) => searchable.includes(word));
  });
  const typeClasses = { '入库': 'inbound', '出库': 'outbound', '上架': 'listing', '交易': 'trade' };
  const rows = entries.map((item) => `<tr><td><span class="warehouse-log-time">${esc(date(item.createdAt))}</span></td><td><span class="warehouse-log-type ${typeClasses[item.type] || ''}">${esc(item.type)}</span></td><td>${warehousePlayer(item.sellerName, item.sellerSteamId)}</td><td>${warehousePlayer(item.buyerName, item.buyerSteamId)}</td><td><strong class="warehouse-log-item">${esc(item.itemName || '--')}</strong></td><td><span class="warehouse-log-quantity">${number(item.quantity)}</span></td><td>${item.amount === null || item.amount === undefined ? '<span class="muted">--</span>' : `<strong class="warehouse-log-amount">${number(item.amount)}</strong>`}</td></tr>`).join('');
  $('#logCount').textContent = `${entries.length} 条仓库记录`;
  $('#logOutput').innerHTML = `<section class="structured-audit warehouse-log-audit"><header class="structured-audit-head order-log-head"><h3>仓库日志<b>共 ${entries.length} 条</b></h3><div class="order-log-tools warehouse-log-tools"><input id="warehouseLogSearch" value="${esc(keyword)}" placeholder="类型 / 游戏名 / SteamID / 物品名称"><button class="btn secondary" type="button" id="warehouseLogSearchButton">搜索</button></div></header>${auditTable(['时间','类型','卖方玩家（游戏名/SteamID）','买方玩家（游戏名/SteamID）','物品名称','数量','金额'], rows, '暂无符合条件的仓库日志')}</section>`;
}
function renderGiftLogs(keyword = '', typeFilter = 'all') {
  const typeLabels = { starter: '新手礼包', normal: '普通礼包', private: '指定礼包', title: '称号礼包', squad: '战队礼包', daily: '每日礼包', weekly: '每周礼包', monthly: '每月礼包', quarterly: '季度礼包' };
  const normalized = String(keyword || '').trim().toLowerCase();
  const keywords = normalized.split(/\s+/).filter(Boolean);
  const all = state.giftLogEntries || [];
  const filtered = all.map((item, index) => ({ item, index })).filter(({ item }) => { const searchable = [item.giftName, item.characterName, item.shopUsername, item.steamId, typeLabels[item.giftType] || item.giftType].map((value) => String(value || '').toLowerCase()).join(' '); return keywords.every((word) => searchable.includes(word)) && (typeFilter === 'all' || String(item.giftType || 'normal') === typeFilter); });
  const types = [...new Set(all.map((item) => String(item.giftType || 'normal')))];
  const options = types.map((type) => `<option value="${esc(type)}"${typeFilter === type ? ' selected' : ''}>${esc(typeLabels[type] || type)}</option>`).join('');
  const rows = filtered.map(({ item, index }) => { const player = [item.characterName, item.shopUsername].filter(Boolean).join(' / ') || item.steamId || '--'; return `<tr><td>${number(item.claimId)}</td><td>${esc(item.giftName || '--')}</td><td>${esc(player)}</td><td>${number(item.pricePaid || 0)}</td><td>${esc(date(item.claimedAt))}</td><td>${esc(typeLabels[item.giftType] || item.giftType || '普通礼包')}</td><td>${item.status ? status(item.status) : '--'}</td><td><button class="btn tiny" type="button" data-gift-log-detail="${index}">详情</button></td></tr>`; }).join('');
  $('#logOutput').innerHTML = `<section class="structured-audit"><header class="structured-audit-head order-log-head"><h3>礼包日志<b>共 ${filtered.length} 条</b></h3><div class="order-log-tools"><select id="giftLogTypeFilter" class="order-log-status-filter all"><option value="all">全部类型</option>${options}</select><input id="giftLogSearch" value="${esc(keyword)}" placeholder="礼包名称 / 领取人 / SteamID"><button class="btn secondary" type="button" id="giftLogSearchButton">搜索</button></div></header>${auditTable(['ID','礼包名称','领取人','支付金额','领取时间','领取类型','状态','操作'], rows, '暂无礼包日志')}</section>`;
}
function redeemLogNavigation() {
  return `<nav class="redeem-log-nav"><button type="button" data-redeem-log="cdk" class="${redeemLogView === 'cdk' ? 'active' : ''}">CDK日志</button><button type="button" data-redeem-log="growth" class="${redeemLogView === 'growth' ? 'active' : ''}">属性购买</button><button type="button" data-redeem-log="exchange" class="${redeemLogView === 'exchange' ? 'active' : ''}">账号资产兑换</button></nav>`;
}
async function loadRedeemLogView(view) {
  const requestVersion = ++logLoadVersion;
  redeemLogView = view;
  $('#logPanelDescription').textContent = view === 'cdk' ? '玩家兑换卡密产生的领取记录' : view === 'growth' ? '玩家购买角色属性产生的记录' : '商城币与游戏金条兑换记录';
  if (view === 'cdk') {
    const claims = list(await api('/api/redeem-code-claims?limit=300'), ['items', 'claims']);
    if (requestVersion !== logLoadVersion) return;
    $('#logCount').textContent = `${claims.length} 条CDK记录`;
    const rows = claims.map((item) => `<tr><td>${esc(date(item.createdAt))}</td><td>${esc(item.redeemCodeName || '--')}</td><td>${esc(item.codeHint || '--')}</td><td><code>${esc(item.steamId || '--')}</code></td><td><code>${esc(item.orderNo || item.orderId || '--')}</code></td><td>${item.status ? status(item.status) : '--'}</td></tr>`).join('');
    $('#logOutput').innerHTML = `<section class="structured-audit">${redeemLogNavigation()}<header class="structured-audit-head"><h3>CDK日志<b>共 ${claims.length} 条</b></h3></header>${auditTable(['时间','兑换名称','卡密提示','SteamID','订单号','状态'], rows, '暂无CDK日志')}</section>`;
    return;
  }
  if (view === 'growth') {
    const purchases = list(await api('/api/character-growth-purchases?limit=300'), ['items', 'purchases']);
    if (requestVersion !== logLoadVersion) return;
    $('#logCount').textContent = `${purchases.length} 条属性购买记录`;
    const rows = purchases.map((item) => { let target={}; try { target=typeof item.targetJson==='string'?JSON.parse(item.targetJson):item.targetJson||{}; } catch {} const name=target.attribute||target.skill||item.purchaseType||'属性购买'; return `<tr><td>${esc(date(item.createdAt))}</td><td><code>${esc(item.steamId || '--')}</code></td><td>${esc(name)}</td><td>${number(item.quantity)}</td><td>${number(item.totalPrice)}</td><td>${number(item.balanceAfter)}</td><td>${item.status ? status(item.status) : '--'}</td></tr>`; }).join('');
    $('#logOutput').innerHTML = `<section class="structured-audit">${redeemLogNavigation()}<header class="structured-audit-head"><h3>属性购买<b>共 ${purchases.length} 条</b></h3></header>${auditTable(['时间','SteamID','购买属性','数量','支付商城币','购买后余额','状态'], rows, '暂无属性购买记录')}</section>`;
    return;
  }
  const exchanges = list(await api('/api/account-exchanges'), ['items', 'exchanges']);
  if (requestVersion !== logLoadVersion) return;
  $('#logCount').textContent = `${exchanges.length} 条资产兑换记录`;
  const rows = exchanges.map((item) => { const player=[item.characterName,item.username].filter(Boolean).join(' / ')||item.steamId||'--'; return `<tr><td>${esc(date(item.createdAt))}</td><td>${esc(player)}</td><td><code>${esc(item.steamId || '--')}</code></td><td>${item.direction === 'coin_to_gold' ? '商城币兑换金条' : '金条兑换商城币'}</td><td>${number(item.inputAmount)} → ${number(item.outputAmount)}</td><td>${item.status ? status(item.status) : '--'}</td><td>${esc(item.errorMessage || '无')}</td></tr>`; }).join('');
  $('#logOutput').innerHTML = `<section class="structured-audit">${redeemLogNavigation()}<header class="structured-audit-head"><h3>账号资产兑换<b>共 ${exchanges.length} 条</b></h3></header>${auditTable(['时间','玩家','SteamID','兑换方向','兑换数量','状态','说明'], rows, '暂无账号资产兑换记录')}</section>`;
}
function renderOrderLogs(keyword = '', statusFilter = 'all') {
  const normalized = String(keyword || '').trim().toLowerCase();
  const all = state.orderLogEntries || [];
  const filtered = all.map((item, index) => ({ item, index })).filter(({ item }) => {
    const matchesSearch = !normalized || [item.itemName, item.playerName, item.steamId].some((value) => String(value || '').toLowerCase().includes(normalized));
    const normal = item.status === 'completed';
    return matchesSearch && (statusFilter === 'all' || statusFilter === 'normal' && normal || statusFilter === 'abnormal' && !normal);
  });
  const abnormalCount = filtered.filter(({ item }) => item.status !== 'completed').length;
  const labels = { completed: '已完成', pending: '待处理', processing: '处理中', dispatching: '发送中', retry: '重试中', failed: '失败', manual_review: '人工处理', waiting_offline: '等待上线', waiting_instance: '等待实例' };
  const rows = filtered.map(({ item, index }) => `<tr><td>${esc(date(item.createdAt))}</td><td>${esc(item.itemName || '--')}</td><td>${esc(item.playerName || '--')}</td><td><code>${esc(item.steamId || '--')}</code></td><td>${number(item.amount)}</td><td><span class="order-log-status ${item.status === 'completed' ? 'normal' : 'abnormal'}">${esc(labels[item.status] || item.status || '未知')}</span></td><td><button class="btn tiny" type="button" data-order-log-detail="${index}">详情</button></td></tr>`).join('');
  $('#logOutput').innerHTML = `<section class="structured-audit"><header class="structured-audit-head order-log-head"><h3>订单日志<b>共 ${filtered.length} 条</b></h3><div class="order-log-tools"><select id="orderLogStatusFilter" class="order-log-status-filter ${statusFilter}"><option value="all"${statusFilter === 'all' ? ' selected' : ''}>全部状态</option><option value="normal"${statusFilter === 'normal' ? ' selected' : ''}>正常</option><option value="abnormal"${statusFilter === 'abnormal' ? ' selected' : ''}>异常</option></select><input id="orderLogSearch" value="${esc(keyword)}" placeholder="物品名称 / 玩家昵称 / SteamID"><button class="btn secondary" type="button" id="orderLogSearchButton">搜索</button><span class="order-log-abnormal">异常 ${abnormalCount} 条</span></div></header>${auditTable(['时间','物品名称','玩家昵称','SteamID','金额','状态','操作'], rows, '暂无商城商品订单')}</section>`;
}
async function loadLogs(preserveContent = false) {
  const requestVersion = ++logLoadVersion;
  if (!preserveContent) $('#logOutput').innerHTML = '<div class="empty">正在加载日志...</div>';
  try {
    const query = new URLSearchParams({ source: $('#logSourceFilter').value, category: $('#logCategoryFilter').value, file: $('#logFileFilter').value, level: $('#logLevelFilter').value, search: $('#logSearch').value.trim(), limit: $('#logLimit').value });
    const response = await api(`/api/logs?${query}`);
    if (requestVersion !== logLoadVersion) return;
    state.logBrowser = response || {};
    if (renderLogBrowserFilters()) return;
    renderLogs();
  } catch (error) {
    if (requestVersion !== logLoadVersion) return;
    $('#logOutput').innerHTML = `<div class="empty">${esc(error.message)}</div>`;
  }
}
function renderLogBrowserFilters() {
  const data = state.logBrowser || {};
  const category = $('#logCategoryFilter'); const selectedCategory = category.value;
  const categories = data.categories || [];
  const categoryIds = categories.map((item) => item.id || item).filter(Boolean);
  if ((!selectedCategory || !categoryIds.includes(selectedCategory)) && categoryIds.length) {
    category.value = categoryIds[0];
    loadLogs();
    return true;
  }
  const tabs = $('#logCategoryTabs');
  if (tabs) tabs.innerHTML = categories.filter((item) => item.id || item).map((item) => `<button type="button" class="log-category-tab ${selectedCategory === (item.id || item) ? 'active' : ''}" data-log-category="${esc(item.id || item)}"><span>${esc(item.icon || '📄')}</span>${esc(item.label || item)}</button>`).join('');
  return false;
}
function auditLocation(value) {
  if (!value) return '<span class="muted">未记录</span>';
  return `<span class="coordinate-pill">${esc([value.x, value.y, value.z].map((item) => Number(item).toFixed(1)).join(', '))}</span>`;
}
function auditId(value) { return value !== null && value !== undefined && value !== '' ? `<span class="id-pill">${esc(String(value))}</span>` : '<span class="muted">未记录</span>'; }
function auditNumber(value) { if (value === null || value === undefined || value === '') return '未记录'; const n = Number(value); return Number.isFinite(n) ? n.toLocaleString('en-US', { maximumFractionDigits: 6 }) : '未记录'; }
function formatShanghaiInstant(instant) {
  if (!(instant instanceof Date) || Number.isNaN(instant.getTime())) return '';
  const parts = Object.fromEntries(new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).formatToParts(instant).map((part) => [part.type, part.value]));
  return `${parts.year}-${parts.month}-${parts.day} ${parts.hour}:${parts.minute}:${parts.second}`;
}
function formatGameLogTimestamp(value) {
  if (value === null || value === undefined || value === '') return '--';
  const text = String(value).trim();
  let match = text.match(/^(\d{4})\.(\d{2})\.(\d{2})-(\d{2})\.(\d{2})\.(\d{2})/);
  if (match) return formatShanghaiInstant(new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]), Number(match[4]), Number(match[5]), Number(match[6]))));
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})$/i.test(text)) {
    const formatted = formatShanghaiInstant(new Date(text));
    if (formatted) return formatted;
  }
  match = text.match(/^(\d{4}-\d{2}-\d{2})[T ](\d{2}):(\d{2}):(\d{2})/);
  return match ? `${match[1]} ${match[2]}:${match[3]}:${match[4]}` : text;
}
function auditStats(items) { return `<div class="audit-stat-grid">${items.map(([label, value, note]) => `<article><span>${esc(label)}</span><strong>${esc(value)}</strong><small>${esc(note || '当前筛选结果')}</small></article>`).join('')}</div>`; }
function auditTable(headers, rows, emptyText) {
  return `<div class="table-wrap structured-audit-table-wrap"><table class="structured-audit-table"><thead><tr>${headers.map((item) => `<th>${esc(item)}</th>`).join('')}</tr></thead><tbody>${rows || `<tr><td class="empty" colspan="${headers.length}">${esc(emptyText)}</td></tr>`}</tbody></table></div>`;
}
function gameLogSearchTools() {
  return `<div class="game-log-search-tools"><input id="gameLogSearchInput" type="search" autocomplete="off" value="${esc($('#logSearch').value || '')}" placeholder="搜索当前分类全部明细"><button class="btn secondary" type="button" id="gameLogSearchButton">搜索</button></div>`;
}
function renderLogs() {
  const rows = state.logBrowser?.entries || [];
  const failureCount = state.logBrowser?.readFailures?.length || 0;
  $('#logCount').textContent = `${rows.length} 条记录 · 成功读取 ${state.logBrowser?.scannedFiles || 0} 个文件${failureCount ? ` · ${failureCount} 个文件读取失败` : ''}${state.logBrowser?.truncated ? ' · 快速范围' : ''}`;
  const category = $('#logCategoryFilter').value;
  if ($('#logSourceFilter').value !== 'scum') {
    const listTitle = $('#logPanelTitle').textContent;
    const levels = { info: '信息', log: '信息', error: '错误', warn: '警告', warning: '警告', debug: '调试', verbose: '详细', trace: '追踪', fatal: '严重错误' };
    state.structuredAuditEntries = rows.map((item) => ({ timestamp: item.timestamp, sourceLabel: item.sourceLabel, categoryLabel: item.categoryLabel || item.category, componentLabel: item.componentLabel || item.component || '商城服务', componentDescription: item.componentDescription || '', file: item.file, fileType: item.fileType || (String(item.file || '').toLowerCase().includes('error') ? '错误日志' : '运行日志'), levelKey: String(item.level || 'info').toLowerCase(), level: levels[String(item.level || 'info').toLowerCase()] || item.level, content: item.message || '', repeatCount: Number(item.repeatCount) || 0, repeatRecords: Array.isArray(item.repeatRecords) ? item.repeatRecords : [], details: item.details || null }));
    const table = auditTable(['时间', '级别', '模块', '内容', '文件类型', '操作'], state.structuredAuditEntries.map((item, index) => `<tr><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td><span class="log-status-level ${esc(item.levelKey)}">${esc(item.level)}</span></td><td><strong class="log-module-name">${esc(item.componentLabel)}</strong><small class="log-module-description">${esc(item.componentDescription)}</small></td><td class="audit-content">${esc(item.content)}${item.repeatCount ? ` <span class="log-repeat-count">合并 ${number(item.repeatCount)} 条重复记录</span>` : ''}</td><td><span class="log-file-type ${item.fileType === '错误日志' ? 'error' : 'runtime'}">${esc(item.fileType)}</span></td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`).join(''), '暂无符合条件的日志');
    const historyMode = $('#logLimit').value === '0';
    const historyTools = $('#logSourceFilter').value === 'shop' ? `<div class="backend-log-history-tools"><span>${historyMode ? '已加载全部历史' : '快速模式：最近记录'}</span><button class="btn secondary" type="button" id="toggleBackendLogHistory">${historyMode ? '返回快速模式' : '加载全部历史'}</button></div>` : '';
    $('#logOutput').innerHTML = `<section class="structured-audit"><header class="structured-audit-head"><h3>${esc(listTitle)}<b>共 ${rows.length} 条</b></h3>${historyTools}</header>${table}</section>`;
    return;
  }
  if (renderStructuredAudit(category, rows)) return;
  if (category === 'admin_command') {
    state.adminAuditEntries = rows.map((item) => item.audit || { timestamp: item.timestamp, playerName: '系统', playerNumber: '0', steamId: '', typeLabel: item.categoryLabel, content: item.message });
    const adminRows = state.adminAuditEntries.map((item, index) => `<tr><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td>${esc(item.playerName || '系统')}</td><td><code>${esc(item.playerNumber || '0')}</code></td><td>${item.steamId ? `<span class="id-pill">${esc(item.steamId)}</span>` : '<span class="muted">未记录</span>'}</td><td><span class="audit-type">● ${esc(item.typeLabel || '管理事件')}</span></td><td class="audit-content">${esc(item.content || '')} <span class="content-more">... 查看</span></td><td><button class="btn tiny" type="button" data-admin-detail="${index}">详情</button></td></tr>`).join('');
    $('#logOutput').innerHTML = `<div class="admin-audit-intro"><div class="admin-audit-title-row"><div><h3>游戏内管理命令审计 <span>安全审计</span> <b>共 ${rows.length} 条</b></h3><p>追踪管理员身份、命令类型和命令内容，便于追踪游戏内管理操作。</p></div>${gameLogSearchTools()}</div><div class="admin-audit-tags"><span>重点关注命令类型和命令内容，便于追踪管理员操作。</span></div></div><div class="table-wrap admin-audit-table-wrap"><table class="admin-audit-table"><thead><tr><th>时间</th><th>玩家昵称</th><th>玩家编号</th><th>SteamID</th><th>类型</th><th>内容</th><th>操作</th></tr></thead><tbody>${adminRows || '<tr><td class="empty" colspan="7">暂无符合条件的管理日志</td></tr>'}</tbody></table></div>`;
    return;
  }
  const categoryLabel = state.logBrowser?.categories?.find((item) => (item.id || item) === category)?.label || rows[0]?.categoryLabel || '游戏日志明细';
  const rawRows = rows.map((item) => {
    const extra = item.details && Object.keys(item.details).length ? ` ${JSON.stringify(item.details)}` : '';
    const itemLevel = String(item.level || 'info').toLowerCase();
    return `<div class="log-line"><span class="log-time">${esc(formatGameLogTimestamp(item.timestamp))}</span><span class="log-level ${esc(itemLevel)}">${esc(itemLevel.toUpperCase())}</span><span class="log-source-label">[${esc(item.categoryLabel || item.category)} / ${esc(item.file)}]</span><span>${esc(item.message || '')}${esc(extra)}</span></div>`;
  }).join('');
  $('#logOutput').innerHTML = `<section class="structured-audit"><header class="structured-audit-head"><div><h3>${esc(categoryLabel)}<b>共 ${rows.length} 条</b></h3></div>${gameLogSearchTools()}</header><div class="raw-game-log-list">${rawRows || '<div class="empty">暂无符合条件的日志</div>'}</div></section>`;
}

function searchCurrentGameLogDetail() {
  $('#logSearch').value = $('#gameLogSearchInput')?.value.trim() || '';
  loadLogs();
}
$('#reloadLogs').addEventListener('click', () => $('#logSourceFilter').value === 'ue4ss' ? loadCommerceLogView(commerceLogView) : loadLogs());
orderLogNav?.addEventListener('click', (event) => {
  const button = event.target.closest('[data-commerce-log]');
  if (button) { button.blur(); loadCommerceLogView(button.dataset.commerceLog).catch((error) => { $('#logOutput').innerHTML = `<div class="empty">${esc(error.message)}</div>`; }); }
});
$('#logOutput').addEventListener('click', (event) => { if (event.target.closest('#toggleBackendLogHistory')) { $('#logLimit').value = $('#logLimit').value === '0' ? '300' : '0'; loadLogs(); return; } if (event.target.closest('#gameLogSearchButton')) { searchCurrentGameLogDetail(); return; } const button = event.target.closest('[data-redeem-log]'); if (button) { button.blur(); loadRedeemLogView(button.dataset.redeemLog).catch((error) => { $('#logOutput').innerHTML = `<div class="empty">${esc(error.message)}</div>`; }); } });

$('#logCategoryTabs').addEventListener('click', (event) => {
  const button = event.target.closest('[data-log-category]');
  if (!button) return;
  button.blur();
  $('#logCategoryFilter').value = button.dataset.logCategory;
  $('#logFileFilter').value = '';
  $('#logSearch').value = '';
  if ($('#logSourceFilter').value === 'shop') $('#logLimit').value = '300';
  loadLogs();
});

$('#logOutput').addEventListener('click', (event) => {
  const lotteryLogButton = event.target.closest('[data-lottery-log-detail]');
  if (lotteryLogButton) {
    const item = state.lotteryLogEntries?.find((entry) => String(entry.id) === lotteryLogButton.dataset.lotteryLogDetail);
    if (!item) return;
    const typeLabels = { gift: '礼包', product: '商城物品', shop_coin: '商城币', custom: '游戏物品' };
    const prizes = (item.prizes || []).map((prize) => `<tr><td><span class="lottery-prize-type ${esc(prize.rewardType || '')}">${esc(typeLabels[prize.rewardType] || prize.rewardType || '其他')}</span></td><td><strong>${esc(prize.rewardName || '未记录奖品名称')}</strong></td><td>${number(prize.count || 0)} 次</td><td>${number(prize.quantity || prize.count || 0)} ${esc(prize.quantityUnit || '份')}</td></tr>`).join('');
    const drawLabel = Number(item.drawCount) === 10 ? '十连抽' : Number(item.drawCount) === 1 ? '单抽' : `${number(item.drawCount)} 次抽奖`;
    openModal({ title: '中奖物品详情', description: `${item.playerName || item.steamId || '--'} · ${item.poolName || '--'}`, submitText: '关闭', body: `<section class="fame-modal-summary lottery-prize-summary"><strong>${esc(drawLabel)}</strong><span>支付 ${number(item.pricePaid)} 商城币</span><span>中奖 ${number(item.winningAmount)} 商城币</span><span>幸运值 ${number(item.pityBefore)} → ${number(item.pityAfter)}</span></section><div class="table-wrap lottery-prize-detail-wrap"><table class="structured-audit-table lottery-prize-detail-table"><thead><tr><th>奖励类型</th><th>中奖物品</th><th>抽中次数</th><th>获得数量</th></tr></thead><tbody>${prizes || '<tr><td class="empty" colspan="4">暂无中奖物品明细</td></tr>'}</tbody></table></div>`, onSubmit: async () => closeModal() });
    $('#modalBackdrop').classList.add('centered-modal');
    return;
  }
  if (event.target.closest('#warehouseLogSearchButton')) { renderWarehouseLogs($('#warehouseLogSearch')?.value); return; }
  if (event.target.closest('#giftLogSearchButton')) { renderGiftLogs($('#giftLogSearch')?.value, $('#giftLogTypeFilter')?.value); return; }
  const giftLogButton = event.target.closest('[data-gift-log-detail]');
  if (giftLogButton) {
    const item = state.giftLogEntries?.[Number(giftLogButton.dataset.giftLogDetail)];
    if (!item) return;
    const failure = item.failureNote ? `<div class="structured-audit-notice gift-failure-note"><strong>发放失败说明</strong><span>${esc(item.failureNote)}${item.failureSource ? `<small>原始错误：${esc(item.failureSource)}</small>` : ''}</span></div>` : '';
    openModal({ title: '礼包发放命令原文', description: `${item.giftName || '--'} · ${item.steamId || '--'}`, submitText: '关闭', body: `${failure}<section class="fame-modal-raw"><pre>${esc(item.commandRaw || '暂无游戏执行命令')}</pre></section>`, onSubmit: async () => closeModal() });
    $('#modalBackdrop').classList.add('centered-modal');
    return;
  }
  if (event.target.closest('#orderLogSearchButton')) { renderOrderLogs($('#orderLogSearch')?.value, $('#orderLogStatusFilter')?.value); return; }
  const orderLogButton = event.target.closest('[data-order-log-detail]');
  if (orderLogButton) {
    const item = state.orderLogEntries?.[Number(orderLogButton.dataset.orderLogDetail)];
    if (!item) return;
    const raw = typeof item.commandRaw === 'string' ? item.commandRaw : JSON.stringify(item.commandRaw || [], null, 2);
    openModal({ title: '订单命令原文', description: `${item.itemName || '--'} · ${item.steamId || '--'}`, submitText: '关闭', body: `<section class="fame-modal-raw"><pre>${esc(raw || '无命令原文')}</pre></section>`, onSubmit: async () => closeModal() });
    $('#modalBackdrop').classList.add('centered-modal');
    return;
  }
  const fameButton = event.target.closest('[data-fame-detail]');
  if (fameButton) {
    const item = state.structuredAuditEntries?.[Number(fameButton.dataset.fameDetail)];
    if (!item) return;
    const detailRows = (item.details || []).map((detail) => `<tr><td><code>${esc(formatGameLogTimestamp(detail.timestamp || item.timestamp))}</code></td><td><span class="fame-reason">${esc(detail.reason || '--')}</span></td><td>${esc(auditNumber(detail.famePoints))}</td><td>${esc(detail.playerName || item.playerName || '--')}</td><td>${auditId(detail.steamId || item.steamId)}</td></tr>`).join('');
    openModal({ title: '声望点变动详情', description: formatGameLogTimestamp(item.timestamp), submitText: '关闭', body: `<section class="fame-modal-summary"><strong>${esc(item.typeLabel || '声望点')}</strong><span>${esc(item.playerName || '--')}</span><span>${esc(auditNumber(item.famePoints))} 点</span><span>${esc(item.reason || '--')}</span></section><div class="table-wrap fame-detail-table-wrap"><table class="structured-audit-table fame-detail-table"><thead><tr><th>时间</th><th>原因</th><th>声望点</th><th>玩家昵称</th><th>SteamID</th></tr></thead><tbody>${detailRows || '<tr><td class="empty" colspan="5">暂无明细</td></tr>'}</tbody></table></div><section class="fame-modal-raw"><h3>原始日志</h3><pre>${esc(item.raw || '')}</pre></section>`, onSubmit: async () => closeModal() });
    return;
  }
  const auditButton = event.target.closest('[data-audit-detail]');
  if (auditButton) {
    const item = state.structuredAuditEntries?.[Number(auditButton.dataset.auditDetail)];
    if (!item) return;
    const labels = { level: '级别', componentLabel: '模块', componentDescription: '模块说明', fileType: '文件类型', repeatCount: '已合并重复次数', file: '文件', sourceLabel: '来源', details: '附加明细', timestamp: '时间', categoryKey: '分类键', categoryLabel: '分类', typeLabel: '类型说明', objectType: '对象类型', objectId: '对象ID', resultValue: '结果/数值', elapsedTime: '耗时', failedAttempts: '失败次数', eventType: '事件类型', killerName: '击杀者', killerSteamId: '击杀者 SteamID', victimName: '死亡者', victimSteamId: '死亡者 SteamID', weapon: '武器', distance: '距离（米）', killerLocation: '击杀者坐标', victimLocation: '死亡者坐标', channel: '频道', playerName: '玩家昵称', steamId: 'SteamID', playerNumber: '玩家编号', content: '聊天内容', ip: 'IP 地址', location: '坐标', recordId: '记录 ID', oldOwnerSteamId: '旧所有者 SteamID（表头：认领人）', newOwnerSteamId: '新所有者 SteamID（表头：被认领人）', oldOwner: '旧所有者', newOwner: '新所有者', itemName: '物品名称', itemBlob: '物品原始描述', quantity: '数量', price: '购买价格', type: '类型', trader: '商人', oldStock: '商店原库存', newStock: '商店现库存', online: '在线人数', quantityOrDurability: '数量/耐久度', totalPrice: '出售总价', basePrice: '基础价值', containedValue: '附加价值', phase: '阶段', action: '交易动作', cash: '现金', accountBalance: '银行余额', gold: '金条', traderFunds: '商人资金', actorName: '操作人', actorSteamId: '操作人 SteamID', actorAccount: '操作账户', amount: '金额', netAmount: '实际到账', removedAmount: '实际扣除', sourceAccount: '来源账户', targetName: '目标玩家', targetSteamId: '目标 SteamID', targetAccount: '目标账户', fee: '手续费', account: '银行卡号', goldBought: '购买金条', creditsPaid: '花费 credits', newGold: '账户金条余额', newCredits: 'credits 余额', unitPrice: '金条单价', raw: '原始日志', eventLabel: '事件说明', chestId: '箱子ID', chestType: '箱子类型', currentOwner: '当前主人', cardType: '卡类型', freeRenewal: '免费续卡', newBalance: '账户余额', status: '生命周期状态', statusLabel: '状态说明', vehicleType: '载具类型', vehicleId: '载具ID', ownerName: '车主昵称', ownerSteamId: '车主SteamID', ownerNumber: '车主编号', result: '结果', duration: '耗时', failedCount: '失败次数', target: '目标对象', difficulty: '难度', targetOwner: '目标所有者', trapType: '陷阱类型' };
    const fields = Object.entries(item).filter(([key]) => !['_entry', 'levelKey', 'repeatRecords'].includes(key)).map(([key, value]) => `<div class="${['raw', 'content', 'oldOwner', 'newOwner', 'details'].includes(key) ? 'span-2' : ''}"><dt>${esc(labels[key] || key)}</dt><dd>${esc(key === 'timestamp' ? formatGameLogTimestamp(value) : value && typeof value === 'object' ? JSON.stringify(value) : value ?? '未记录')}</dd></div>`).join('');
    const repeatRecords = Array.isArray(item.repeatRecords) ? item.repeatRecords : [];
    const repeatRows = repeatRecords.map((record, index) => {
      const suppressed = Number(record.suppressedCount) || 0;
      const windowSeconds = Number(record.repeatWindowMs) > 0 ? `${Math.ceil(Number(record.repeatWindowMs) / 1000)} 秒内` : '';
      const recordType = suppressed ? `磁盘记录（携带${windowSeconds}抑制汇总 ${suppressed} 次）` : '磁盘记录';
      const detailText = record.details && typeof record.details === 'object' && Object.keys(record.details).length ? JSON.stringify(record.details) : '无附加明细';
      return `<tr><td>${index + 1}</td><td><code>${esc(formatGameLogTimestamp(record.timestamp))}</code></td><td>${esc(recordType)}</td><td>${esc(record.fileType || '--')}<small>${esc(record.file || '--')}</small></td><td class="backend-repeat-detail">${esc(detailText)}</td></tr>`;
    }).join('');
    const repeatSection = item.repeatCount ? `<section class="backend-repeat-section"><header><div><h3>合并记录明细</h3><p>共 ${number(item.repeatCount + 1)} 次事件，磁盘中保留 ${number(repeatRecords.length)} 条记录。日志器主动抑制的事件仅能显示汇总次数。</p></div><span>${number(item.repeatCount)} 条重复</span></header><div class="table-wrap backend-repeat-table-wrap"><table class="backend-repeat-table"><thead><tr><th>序号</th><th>时间</th><th>记录类型</th><th>日志文件</th><th>附加明细</th></tr></thead><tbody>${repeatRows || '<tr><td class="empty" colspan="5">暂无可展示的重复记录</td></tr>'}</tbody></table></div></section>` : '';
    openModal({ title: item.repeatCount ? '后台日志合并详情' : '结构化日志详情', description: `${formatGameLogTimestamp(item.timestamp)} · ${item.componentLabel}`, submitText: '关闭', body: `<div class="backend-log-detail-body"><dl class="monitor-details admin-detail-list structured-detail-list">${fields}</dl>${repeatSection}</div>`, onSubmit: async () => closeModal() });
    $('#modalBackdrop').classList.add('centered-modal');
    return;
  }
  const button = event.target.closest('[data-admin-detail]');
  if (!button) return;
  const item = state.adminAuditEntries?.[Number(button.dataset.adminDetail)];
  if (!item) return;
  openModal({ title: item.typeLabel || '管理日志详情', description: formatGameLogTimestamp(item.timestamp), submitText: '关闭', body: `<dl class="monitor-details admin-detail-list"><div><dt>玩家昵称</dt><dd>${esc(item.playerName || '系统')}</dd></div><div><dt>玩家编号</dt><dd>${esc(item.playerNumber || '0')}</dd></div><div><dt>SteamID</dt><dd>${esc(item.steamId || '未记录')}</dd></div><div><dt>事件类型</dt><dd>${esc(item.typeLabel || '管理事件')}</dd></div><div class="span-2"><dt>结构化内容</dt><dd>${esc(item.content || '')}</dd></div><div class="span-2"><dt>原始日志</dt><dd>${esc(item.raw || item.content || '')}</dd></div></dl>`, onSubmit: async () => closeModal() });
});
$('#logOutput').addEventListener('keydown', (event) => { if (event.key !== 'Enter') return; if (event.target.id === 'gameLogSearchInput') { event.preventDefault(); searchCurrentGameLogDetail(); } if (event.target.id === 'warehouseLogSearch') { event.preventDefault(); renderWarehouseLogs(event.target.value); } if (event.target.id === 'orderLogSearch') { event.preventDefault(); renderOrderLogs(event.target.value, $('#orderLogStatusFilter')?.value); } if (event.target.id === 'giftLogSearch') { event.preventDefault(); renderGiftLogs(event.target.value, $('#giftLogTypeFilter')?.value); } });
$('#logOutput').addEventListener('change', (event) => { if (event.target.id === 'orderLogStatusFilter') renderOrderLogs($('#orderLogSearch')?.value, event.target.value); if (event.target.id === 'giftLogTypeFilter') renderGiftLogs($('#giftLogSearch')?.value, event.target.value); });



$$('.log-source-tabs [data-log-source]').forEach((node) => node.addEventListener('click', () => { node.blur(); selectLogSource(node.dataset.logSource); }));

async function handleTaskClick(event) {
  const taskId = event.target.closest('[data-retry-task]')?.dataset.retryTask;
  if (taskId) await withBusy(event.target, async () => {
    await api(`/api/fulfillment/tasks/${encodeURIComponent(taskId)}/retry`, { method: 'POST', body: '{}' });
    toast('发货任务已重新进入队列'); await loadTasks();
  });
  const replacementId = event.target.closest('[data-replace-task]')?.dataset.replaceTask;
  if (replacementId) replacementModal(state.tasks.find((task) => String(task.id) === replacementId) || { id: replacementId });
}

async function handleManualActionClick(event) {
  const action = event.target.closest('[data-action]')?.dataset.action;
  if (action === 'manual-fulfillment') {
    const steamIdInput = $('#manualFulfillmentSteamId');
    const codeInput = $('#manualFulfillmentCode');
    const steamId = steamIdInput?.value.trim() || '';
    const code = codeInput?.value.trim() || '';
    if (!/^\d{17}$/.test(steamId)) { toast('SteamID 必须是 17 位数字', true); steamIdInput?.focus(); return true; }
    if (!code) { toast('请输入发货代码', true); codeInput?.focus(); return true; }
    await api('/api/fulfillment/manual', { method: 'POST', body: JSON.stringify({ steamId, code }) });
    codeInput.value = '';
    toast('发货代码已写入队列');
  }
}

const logSourceMeta = {
  shop: ['后台日志', '商城后台、发货服务及 MySQL 运行记录'],
  ue4ss: ['商城日志', '商城订单、发货与 RCON 插件运行记录'],
  scum: ['游戏日志', 'SCUM 游戏服务器产生的全部分类日志']
};
function renderStructuredAudit(category, rows) {
  const meta = {
    field_kill: ['野外击杀审计', '击杀记录', '展示野外死亡、自杀与服务端结构化击杀数据。', 'JSON 与 Died 同次记录已去重；距离按服务端三维坐标计算。'],
    event_kill: ['活动击杀审计', '活动记录', '展示活动场景下的击杀数据，并兼容未来同格式日志。', '未知日志只标记为 unknown，不补造击杀者、武器或坐标。'],
    chat: ['聊天内容审计', '聊天记录', '按频道、玩家身份和聊天内容追踪游戏内交流。', '风险内容仅按 Admin 频道及简单违禁词命中计数。'],
    presence: ['玩家上下线审计', '在线轨迹', '展示玩家登录、离线、IP 与服务器坐标。', '日志位置为 ? 时按未记录展示，不推测玩家位置。'],
    teammate_claim: ['队友认领审计', '所有权变更', '本页来自箱子所有权变更日志，字段映射为旧所有者 → 新所有者。', '“认领人 SteamID”显示旧所有者，“被认领人 SteamID”显示新所有者；不代表实际动作发起者。'],
    purchase: ['购买审计', '经济', '展示玩家从普通商人与机械师购买商品或服务的结构化记录。', '每条原始交易独立展示；日志未提供的商店库存保持“未记录”。'],
    sale: ['出售审计', '经济', '展示玩家向商人出售物品的价格、价值与库存信息。', '数量/耐久度优先使用日志可确认值，不推测未记录字段。'],
    balance: ['余额快照审计', '经济', '展示购买或出售前后的玩家资产与商人资金快照。', '玩家昵称与 SteamID 分列映射；兼容 account、bank account 与 tradeales 拼写。'],
    bank_transfer: ['存取转账审计', '货币', '展示银行存款、取款与账户间转账记录。', '手续费按日志金额差计算；unknown 目标保持未记录。'],
    gold: ['金条购买审计', '货币', '仅展示 Currency Conversion 产生的金条购买记录。', '普通余额中的 gold 字段及银行卡购买不会进入此分类。'],
    bank_card: ['银行卡审计', '银行卡', '展示银行卡购买与手动销毁记录。', '销毁记录分别展示执行账户与银行卡所属账户；金条 Currency Conversion 不进入本页。'],
    vehicle: ['载具生命周期审计', '载具', '展示载具损毁、消失、闲置到期、出售及其他生命周期状态。', '无主人或 0 值按未记录展示；其他状态保留为未知状态，不丢弃原始日志。'],
    chest: ['箱子归属 / 埋藏日志', '箱子', '展示箱子首次 claimed 归属记录。', '所有权 changed 继续仅在队友认领分类展示，避免同一变更重复出现。'],
    lockpick: ['开锁行为审计', '开锁', '展示开锁结果、玩家、耗时、失败次数、目标与锁难度。', '只呈现真实匹配日志；无法确认的字段保持未记录。'],
    wire_cut: ['剪线行为审计', '剪线', '展示剪线结果、玩家、耗时、目标与难度。', '当前无匹配日志时保留完整空表，不虚构测试数据。'],
    trap: ['陷阱事件日志', '世界事件', '展示陷阱布设、制作、触发和拆除事件，便于定位高风险爆炸物与坐标。', '触发、爆炸物和高风险事件会高亮。'],
    gameplay: ['玩法事件日志', '世界事件', '展示任务书小游戏、拨盘、爆炸物、领地旗帜和地堡快照等玩法事件。', '触发、爆炸物和高风险事件会高亮。'],
    fame: ['声望点变动日志', '声望点', '展示玩家声望获得和阶段统计，方便排查声望异常增长来源。', '大额声望变动和异常原因会高亮。'],
    territory_risk: ['领地风险记录', '安全审计', '记录玩家进入其他玩家领地附近的风险命中。', '删除、权限、价格、封禁和管理命令会醒目。'],
    quest: ['系统任务完成日志', '系统任务', '展示系统任务、玩家、内部ID和任务状态。', '任务完成、失败、取消会优先展示。'],
    sentry: ['岗哨摧毁日志', '岗哨', '展示岗哨摧毁记录、玩家身份、武器和坐标。', '岗哨摧毁、高伤害和爆炸物来源会高亮。'],
    bunker_unlock: ['废弃地堡拨盘解锁日志', '小游戏/安全', '展示地堡激活/解锁结果、耗时和失败次数。', '成功解锁、高耗时、高失败次数会突出显示。'],
    bunker_status: ['废弃地堡激活状态日志', '地堡状态', '展示地堡状态变动，用于判断开启、锁定和关闭周期。', '活跃、已激活、锁定状态会用标签区分。'],
    base_destruction: ['基地破坏/建筑受击日志', '基地建筑破坏', '展示基地建筑受击和破坏记录。', '同一建筑ID连续出现多条记录时，代表该建筑对象被多次造成伤害。'],
    rcon_stats: ['RCON/日志事件统计', '世界事件', '记录SCUMServerBot_KillEvents日志中的丧尸/NPC击杀事件。', '触发、爆炸物和高风险事件会高亮。'],
    kick: ['反作弊违规踢出日志', '聊天/安全', '展示反作弊或规则检测触发的踢出事件和原因。', '反作弊踢出属于安全事件，需关注踢出原因。'],
    distance: ['违规交互距离异常日志', '聊天/安全', '展示客户端与服务端交互距离异常、动作代码和双方坐标。', '重点关注距离差、动作描述和客户端/服务端坐标。'],
    ammo: ['违规弹药异常日志', '聊天/安全', '展示武器弹药异常、可疑数量、累计封禁次数和玩家坐标。', '可疑数量和累计封禁次数越高，越应优先核实该玩家与武器记录。'],
    ballistics: ['弹道位置异常日志', '聊天/安全', '展示攻击/受害者客户端与服务端坐标漂移，用于排查弹道与近战异常。', '聊天频道、违规原因和踢出结果会用标签显示，便于快速查阅。'],
    other_violation: ['其他违规与服务器封禁日志', '聊天/安全', '展示网络看门狗、服务器封禁、弹药同步和基地弹道位置等新增违规类型。', '先按违规类型筛选，再结合玩家身份和原始内容复核。'],
    loot_diagnostic: ['物资刷新（Loot）配置诊断', '服务器诊断', '展示 Loot 配置解析、刷新点、区域、重复配置、无效物品等诊断日志。', 'Error 级别优先检查路径和物品代码。'],
    raid_diagnostic: ['突袭保护（RaidTimes）配置诊断', '服务器诊断', '展示 RaidTimes 解析、服务器通知版本信息和突袭保护相关诊断。', 'Error/Warning 优先检查 RaidTimes、服务器通知版本和突袭保护配置。']
  }[category];
  if (!meta) return false;
  state.structuredAuditEntries = rows.map((row) => ({ ...row.audit, _entry: row })).filter((item) => item.raw);
  const audits = state.structuredAuditEntries;
  let stats = ''; let table = '';
  if (category === 'gameplay') {
    const riskWords = /(trigger|detonat|explosi|爆炸|触发|claymore|mine|炸药)/i;
    const focusCounts = audits.reduce((result, item) => { const label = item.objectId ? `对象ID:${item.objectId}` : `类型:${item.typeLabel || item.type || '未知玩法'}`; result[label] = (result[label] || 0) + 1; return result; }, {});
    const chips = Object.entries(focusCounts).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([label, count]) => `<span>${esc(label)} <b>${count}</b></span>`).join('');
    stats = chips ? `<div class="gameplay-summary-chips">${chips}</div>` : '';
    table = auditTable(['时间','分类','类型','玩家昵称','SteamID','对象类型','对象ID','结果/数值','坐标','原始内容','操作'], audits.map((item, index) => {
      const highRisk = riskWords.test(`${item.categoryLabel || ''} ${item.typeLabel || ''} ${item.objectType || ''} ${item.resultValue || ''} ${item.raw || ''}`);
      return `<tr class="${highRisk ? 'gameplay-risk-row' : ''}"><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td><span class="audit-type gameplay-blue-pill">${esc(item.categoryLabel || '--')}</span></td><td><span class="audit-type gameplay-blue-pill ${highRisk ? 'gameplay-risk-pill' : ''}">${esc(item.typeLabel || item.type || '--')}</span></td><td>${esc(item.playerName || '--')}</td><td>${auditId(item.steamId)}</td><td>${esc(item.objectType || '--')}</td><td>${auditId(item.objectId)}</td><td>${esc(item.resultValue ?? '--')}</td><td>${auditLocation(item.location)}</td><td><button class="btn tiny" type="button" data-audit-detail="${index}">查看原文</button></td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`;
    }).join(''), '暂无玩法事件记录');
  } else if (category === 'fame') {
    const total = audits.reduce((sum, item) => sum + Number(item.famePoints || 0), 0);
    const mainType = Object.entries(audits.reduce((result, item) => { const key = item.typeLabel || '未记录'; result[key] = (result[key] || 0) + 1; return result; }, {})).sort((a, b) => b[1] - a[1])[0]?.[0] || '未记录';
    stats = auditStats([['涉及玩家', new Set(audits.map((item) => item.steamId).filter(Boolean)).size, '唯一 SteamID'], ['声望合计', auditNumber(total)], ['主要类型', mainType]]);
    const fameRows = audits.map((item, index) => `<tr><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td><span class="audit-type fame-type">${esc(item.typeLabel || '--')}</span></td><td>${esc(item.playerName || '--')}</td><td>${auditId(item.steamId)}</td><td>${esc(auditNumber(item.famePoints))}</td><td><span class="fame-reason">${esc(item.reason || '--')}</span></td><td>${esc(item.periodMinutes ?? '--')}</td><td>${esc(auditNumber(item.totalFame))}</td><td><button class="btn tiny" type="button" data-fame-detail="${index}">查看原文</button></td><td><button class="btn tiny" type="button" data-fame-detail="${index}">详情</button></td></tr>`).join('');
    table = auditTable(['时间','类型','玩家昵称','SteamID','本次声望点','原因','统计周期(分钟)','累计声望','原始内容','操作'], fameRows, '暂无声望记录');
  } else if (category === 'field_kill' || category === 'event_kill') {
    const distances = audits.map((item) => Number(item.distance)).filter(Number.isFinite);
    const weapons = audits.map((item) => item.weapon).filter(Boolean);
    const weaponCounts = weapons.reduce((result, item) => ({ ...result, [item]: (result[item] || 0) + 1 }), {});
    const mainWeapon = Object.entries(weaponCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || '--';
    stats = auditStats([['当前页击杀', audits.length, '含自杀与 unknown'], ['平均距离', distances.length ? `${(distances.reduce((a, b) => a + b, 0) / distances.length).toFixed(1)} m` : '0 m', '仅统计有距离记录'], ['主要武器', mainWeapon, '当前页出现最多']]);
    table = auditTable(['时间', '击杀者', '击杀者 SteamID', '死亡者', '死亡者 SteamID', '武器', '距离', '击杀者坐标', '死亡者坐标', '操作'], audits.map((item, index) => `<tr><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td>${esc(item.killerName || '--')}</td><td>${auditId(item.killerSteamId)}</td><td>${esc(item.victimName || '--')}</td><td>${auditId(item.victimSteamId)}</td><td>${esc(item.weapon || '--')}</td><td>${Number.isFinite(Number(item.distance)) ? `${Number(item.distance).toFixed(1)} m` : '--'}</td><td>${auditLocation(item.killerLocation)}</td><td>${auditLocation(item.victimLocation)}</td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`).join(''), category === 'event_kill' ? '暂无活动击杀记录' : '暂无野外击杀记录');
  } else if (category === 'chat') {
    const channels = audits.map((item) => item.channel).filter(Boolean);
    const counts = channels.reduce((result, item) => ({ ...result, [item]: (result[item] || 0) + 1 }), {});
    const mainChannel = Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] || '--';
    const riskWords = /(admin|外挂|作弊|买号|卖号|代充)/i;
    const risks = audits.filter((item) => /^admin$/i.test(item.channel || '') || riskWords.test(item.content || '')).length;
    stats = auditStats([['当前页消息', audits.length], ['主要频道', mainChannel], ['风险内容', risks, 'Admin 频道或简单违禁词']]);
    table = auditTable(['时间', '频道', '玩家昵称', 'SteamID', '玩家编号', '聊天内容', '操作'], audits.map((item, index) => `<tr><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td><span class="audit-type channel-${esc(String(item.channel || '').toLowerCase())}">${esc(item.channel || '--')}</span></td><td>${esc(item.playerName || '--')}</td><td>${auditId(item.steamId)}</td><td><code>${esc(item.playerNumber || '--')}</code></td><td class="audit-message">${esc(item.content || '')}</td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`).join(''), '暂无聊天记录');
  } else if (category === 'presence') {
    const logins = audits.filter((item) => item.eventType === 'login').length;
    const logouts = audits.filter((item) => item.eventType === 'logout').length;
    stats = auditStats([['上线数量', logins], ['离线数量', logouts], ['涉及 IP', new Set(audits.map((item) => item.ip).filter(Boolean)).size, '唯一 IP 数量']]);
    table = auditTable(['时间', '上下线类型', '玩家昵称', 'SteamID', 'IP地址', '坐标', '玩家编号', '操作'], audits.map((item, index) => `<tr><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td><span class="audit-type ${item.eventType === 'logout' ? 'type-logout' : 'type-login'}">${item.eventType === 'logout' ? '离线' : '上线'}</span></td><td>${esc(item.playerName || '--')}</td><td>${auditId(item.steamId)}</td><td><code>${esc(item.ip || '--')}</code></td><td>${auditLocation(item.location)}</td><td><code>${esc(item.playerNumber || '--')}</code></td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`).join(''), '暂无上下线记录');
  } else if (category === 'trap') {
    const eventLabels = { placed: '布设', armed: '装置', triggered: '触发', activated: '激活', disarmed: '解除', defused: '拆除', destroyed: '摧毁', detonated: '爆炸', crafted: '制作', unknown: '未知事件' };
    const highlightedEvents = new Set(['triggered', 'activated', 'detonated']);
    table = auditTable(['时间', '玩家昵称', 'SteamID', '玩家编号', '陷阱事件/类型', '坐标', '操作'], audits.map((item, index) => `<tr class="${highlightedEvents.has(item.eventType) ? 'trap-risk-row' : ''}"><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td>${esc(item.playerName || '--')}</td><td>${auditId(item.steamId)}</td><td><code>${esc(item.playerNumber || '--')}</code></td><td><span class="audit-type trap-${esc(item.eventType || 'unknown')}">${esc(item.eventLabel || eventLabels[item.eventType] || '未知事件')}${item.trapType ? ` / ${esc(item.trapType)}` : ''}</span></td><td>${auditLocation(item.location)}</td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`).join(''), '暂无陷阱事件记录');
  } else if (['purchase', 'sale', 'balance', 'bank_transfer', 'gold', 'bank_card', 'vehicle', 'chest', 'lockpick', 'wire_cut'].includes(category)) {
    const players = new Set(audits.map((item) => item.playerName || item.actorName).filter(Boolean)).size;
    const amount = audits.reduce((sum, item) => sum + Number(item.price ?? item.totalPrice ?? item.amount ?? item.creditsPaid ?? 0), 0);
    const types = audits.map((item) => item.type || item.eventType || item.phase || '未记录').filter(Boolean);
    const counts = types.reduce((result, item) => ({ ...result, [item]: (result[item] || 0) + 1 }), {});
    const mainType = Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] || '未记录';
    const balanceTotal = audits.reduce((sum, item) => sum + Number(item.cash || 0) + Number(item.accountBalance || 0), 0);
    stats = auditStats([['涉及玩家', players], [category === 'gold' ? '金条合计' : category === 'balance' ? '现金+银行余额合计' : '金额合计', auditNumber(category === 'gold' ? audits.reduce((sum, item) => sum + Number(item.goldBought || 0), 0) : category === 'balance' ? balanceTotal : amount), '当前筛选结果'], ['主要类型', mainType]]);
    const cell = (value) => value === null || value === undefined || value === '' ? '<span class="muted">未记录</span>' : esc(value);
    const rowsOf = (columns) => audits.map((item, index) => `<tr>${columns.map((column) => `<td>${typeof column === 'function' ? column(item) : cell(column === 'timestamp' ? formatGameLogTimestamp(item[column]) : item[column])}</td>`).join('')}<td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`).join('');
    if (category === 'purchase') table = auditTable(['时间','物品名称','数量','购买价格','玩家昵称','SteamID','类型','商人','商店原库存','商店现库存','操作'], rowsOf(['timestamp','itemName', item => cell(auditNumber(item.quantity)), item => cell(auditNumber(item.price)),'playerName', item => auditId(item.steamId),'type','trader', item => cell(auditNumber(item.oldStock)), item => cell(auditNumber(item.newStock))]), '暂无购买记录');
    if (category === 'sale') table = auditTable(['时间','物品名称','数量/耐久度','出售总价','基础价值','附加价值','玩家昵称','SteamID','商人','商店原库存','操作'], rowsOf(['timestamp','itemName', item => cell(auditNumber(item.quantityOrDurability)), item => cell(auditNumber(item.totalPrice)), item => cell(auditNumber(item.basePrice)), item => cell(auditNumber(item.containedValue)),'playerName', item => auditId(item.steamId),'trader', item => cell(auditNumber(item.oldStock))]), '暂无出售记录');
    if (category === 'balance') table = auditTable(['时间','类型','玩家昵称','SteamID','现金','银行余额','金条','商人ID','商人资金','操作'], rowsOf(['timestamp', item => `<span class="audit-type">${cell(item.phase)} / ${cell(item.action)}</span>`, 'playerName', item => auditId(item.steamId), item => cell(auditNumber(item.cash)), item => cell(auditNumber(item.accountBalance)), item => cell(auditNumber(item.gold)), 'trader', item => cell(auditNumber(item.traderFunds))]), '暂无余额快照');
    if (category === 'bank_transfer') table = auditTable(['时间','类型','操作人','操作人SteamID','操作账户','目标','目标SteamID','目标账户','金额','手续费','坐标','操作'], rowsOf(['timestamp', item => `<span class="audit-type bank-${esc(item.eventType)}">${cell({ deposit:'存款', withdraw:'取款', transfer:'转账' }[item.eventType] || item.eventType)}</span>`, 'actorName', item => auditId(item.actorSteamId), 'actorAccount','targetName', item => auditId(item.targetSteamId), 'targetAccount', item => cell(auditNumber(item.amount)), item => cell(auditNumber(item.fee)), item => auditLocation(item.location)]), '暂无存取转账记录');
    if (category === 'gold') table = auditTable(['时间','玩家昵称','SteamID','银行卡号','购买数量','花费 credits','账户金条余额','credits余额','坐标','操作'], rowsOf(['timestamp','playerName', item => auditId(item.steamId),'account', item => cell(auditNumber(item.goldBought)), item => cell(auditNumber(item.creditsPaid)), item => cell(auditNumber(item.newGold)), item => cell(auditNumber(item.newCredits)), item => auditLocation(item.location)]), '暂无金条购买记录');
    if (category === 'bank_card') {
      const players = new Set(audits.map((item) => item.playerName).filter(Boolean)).size;
      const balances = audits.reduce((sum, item) => sum + Number(item.newBalance || 0), 0);
      const types = audits.reduce((result, item) => ({ ...result, [item.cardType || '未记录']: (result[item.cardType || '未记录'] || 0) + 1 }), {});
      stats = auditStats([['涉及玩家', players], ['余额快照合计', auditNumber(balances), '仅购买记录的余额快照'], ['主要类型', Object.entries(types).sort((a, b) => b[1] - a[1])[0]?.[0] || '未记录']]);
      table = auditTable(['时间','类型','玩家昵称','SteamID','银行卡号','卡类型','免费续卡','账户余额','目标账户','坐标','操作'], rowsOf(['timestamp', item => `<span class="audit-type type-${esc(item.eventType)}">${cell(item.typeLabel)}</span>`, 'playerName', item => auditId(item.steamId), 'actorAccount','cardType','freeRenewal', item => cell(auditNumber(item.newBalance)), 'targetAccount', item => auditLocation(item.location)]), '暂无银行卡记录');
    }
    if (category === 'vehicle') {
      const statuses = audits.reduce((result, item) => ({ ...result, [item.statusLabel || '未知状态']: (result[item.statusLabel || '未知状态'] || 0) + 1 }), {});
      stats = auditStats([['当前页事件', audits.length], ['移除 / 损毁', audits.filter((item) => ['destroyed','disappeared','inactive_timer_reached','sold'].includes(item.status)).length], ['主要载具', Object.entries(audits.reduce((result, item) => ({ ...result, [item.vehicleType || '未记录']: (result[item.vehicleType || '未记录'] || 0) + 1 }), {})).sort((a, b) => b[1] - a[1])[0]?.[0] || '未记录'], ['涉及车主', new Set(audits.map((item) => item.ownerSteamId).filter(Boolean)).size]]);
      table = auditTable(['时间','生命周期状态','载具类型','载具ID','车主昵称','车主SteamID','车主编号','坐标','操作'], rowsOf(['timestamp', item => `<span class="audit-type vehicle-${esc(item.status)}">${cell(item.statusLabel)}</span>`, 'vehicleType','vehicleId','ownerName', item => auditId(item.ownerSteamId), 'ownerNumber', item => auditLocation(item.location)]), '暂无载具生命周期记录');
    }
    if (category === 'chest') {
      stats = auditStats([['事件数', audits.length], ['主要事件', Object.entries(audits.reduce((result, item) => ({ ...result, [item.eventLabel || '未记录']: (result[item.eventLabel || '未记录'] || 0) + 1 }), {})).sort((a, b) => b[1] - a[1])[0]?.[0] || '未记录'], ['涉及主人', new Set(audits.flatMap((item) => [item.oldOwner?.steamId, item.currentOwner?.steamId]).filter(Boolean)).size]]);
      const owner = (item) => item.oldOwner || item.currentOwner || {};
      table = auditTable(['时间','事件类型','箱子ID','箱子类型','原/当前主人昵称','原/当前主人SteamID','原/当前主人编号','新主人/操作人昵称','新主人/操作人SteamID','新主人/操作人编号','坐标','操作'], audits.map((item, index) => { const current = owner(item); const next = item.newOwner || {}; return `<tr><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td><span class="audit-type">${esc(item.eventLabel || '--')}</span></td><td>${auditId(item.chestId)}</td><td>${esc(item.chestType || '未知箱子')}</td><td>${esc(current.playerName || '--')}</td><td>${auditId(current.steamId)}</td><td><code>${esc(current.playerNumber || '0')}</code></td><td>${esc(next.playerName || '未记录')}</td><td>${auditId(next.steamId)}</td><td><code>${esc(next.playerNumber || '0')}</code></td><td>${auditLocation(item.location)}</td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`; }).join(''), '暂无箱子认领记录');
    }
    if (category === 'lockpick' || category === 'wire_cut') {
      const success = audits.filter((item) => item.result === 'success').length;
      const failures = audits.filter((item) => item.result === 'failed').length;
      stats = auditStats([['成功', success], ['失败', failures], ['总 / 平均失败次数', `${auditNumber(audits.reduce((sum, item) => sum + Number(item.failedCount || 0), 0))} / ${audits.length ? (audits.reduce((sum, item) => sum + Number(item.failedCount || 0), 0) / audits.length).toFixed(1) : '0'}`], ['主要目标', Object.entries(audits.reduce((result, item) => ({ ...result, [item.target || '未记录']: (result[item.target || '未记录'] || 0) + 1 }), {})).sort((a, b) => b[1] - a[1])[0]?.[0] || '未记录']]);
      const headers = category === 'lockpick' ? ['时间','结果','玩家昵称','SteamID','耗时','失败次数','目标对象','锁难度','目标所有者','坐标','操作'] : ['时间','结果','玩家昵称','SteamID','耗时(秒)','目标对象','难度','坐标','操作'];
      const columns = category === 'lockpick' ? ['timestamp', item => cell(item.result === 'success' ? '成功' : item.result === 'failed' ? '失败' : '未记录'), 'playerName', item => auditId(item.steamId), item => cell(item.duration), item => cell(item.failedCount), 'target','difficulty','targetOwner', item => auditLocation(item.location)] : ['timestamp', item => cell(item.result === 'success' ? '成功' : item.result === 'failed' ? '失败' : '未记录'), 'playerName', item => auditId(item.steamId), item => cell(item.duration), 'target','difficulty', item => auditLocation(item.location)];
      table = auditTable(headers, rowsOf(columns), category === 'lockpick' ? '暂无开锁记录' : '暂无剪线记录');
    }
  } else if (category === 'territory_risk') {
    const uniquePlayers = new Set(audits.map((item) => item.steamId).filter(Boolean)).size;
    const uniqueOwners = new Set(audits.map((item) => item.territoryOwnerSteamId).filter(Boolean)).size;
    const highRisk = audits.filter((item) => Number(item.distance) > Number(item.hitRange)).length;
    stats = auditStats([['领地风险命中', audits.length], ['涉及玩家', uniquePlayers], ['涉及领地', uniqueOwners], ['超出命中范围', highRisk, '距离 > 命中范围']]);
    const territoryRows = audits.map((item, index) => {
      const riskClass = Number(item.distance) > Number(item.hitRange) ? 'territory-risk-row' : '';
      return `<tr class="${riskClass}"><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td>${esc(item.playerName || '--')}</td><td>${auditId(item.steamId)}</td><td>${esc(item.territoryOwnerName || '--')}</td><td>${auditId(item.territoryOwnerSteamId)}</td><td>${auditId(item.flagId)}</td><td>${esc(item.distance ?? '--')}</td><td>${esc(item.hitRange ?? '--')}</td>${auditLocation(item.playerLocation)}${auditLocation(item.flagLocation)}<td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`;
    }).join('');
    table = auditTable(['时间','玩家昵称','SteamID','领地归属','归属SteamID','旗帜ID','距离','命中范围','玩家坐标','旗帜坐标','操作'], territoryRows, '暂无领地风险记录');
  } else if (category === 'quest') {
    const completed = audits.filter((item) => /completed|success/i.test(item.status || '')).length;
    const failed = audits.filter((item) => /failed|fail|cancelled|cancel/i.test(item.status || '')).length;
    const topType = Object.entries(audits.reduce((result, item) => ({ ...result, [item.typeLabel || '未记录']: (result[item.typeLabel || '未记录'] || 0) + 1 }), {})).sort((a, b) => b[1] - a[1])[0]?.[0] || '未记录';
    stats = auditStats([['任务总数', audits.length], ['完成', completed], ['失败/取消', failed], ['主要类型', topType]]);
    const questRows = audits.map((item, index) => {
      const statusClass = /completed|success/i.test(item.status || '') ? 'quest-success-row' : /failed|fail|cancelled|cancel/i.test(item.status || '') ? 'quest-failed-row' : '';
      const statusLabel = /completed|success/i.test(item.status || '') ? '已完成' : /failed|fail/i.test(item.status || '') ? '失败' : /cancel/i.test(item.status || '') ? '已取消' : esc(item.status || '--');
      return `<tr class="${statusClass}"><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td><span class="audit-type quest-${esc(item.status || 'unknown')}">${esc(statusLabel)}</span></td><td>${esc(item.playerName || '--')}</td><td>${auditId(item.steamId)}</td><td>${esc(item.typeLabel || '--')}</td><td>${auditId(item.internalId)}</td><td>${esc(item.weaponSource || '--')}</td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`;
    }).join('');
    table = auditTable(['时间','状态','玩家昵称','SteamID','任务类型','内部ID','武器/来源','操作'], questRows, '暂无系统任务记录');
  } else if (category === 'sentry') {
    const uniquePlayers = new Set(audits.map((item) => item.steamId).filter(Boolean)).size;
    const damageValues = audits.map((item) => Number(item.damage)).filter(Number.isFinite);
    const avgDamage = damageValues.length ? (damageValues.reduce((a, b) => a + b, 0) / damageValues.length).toFixed(1) : '--';
    const maxDamage = damageValues.length ? Math.max(...damageValues).toFixed(1) : '--';
    stats = auditStats([['岗哨摧毁', audits.length], ['涉及玩家', uniquePlayers], ['平均伤害', avgDamage], ['最高伤害', maxDamage]]);
    const sentryRows = audits.map((item, index) => {
      const highDamage = Number(item.damage) >= 100;
      return `<tr class="${highDamage ? 'sentry-high-damage-row' : ''}"><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td>${esc(item.playerName || '--')}</td><td>${auditId(item.steamId)}</td><td>${esc(item.weapon || '--')}</td><td>${esc(item.damage ?? '--')}</td><td>${esc(item.coordX ?? '--')}</td><td>${esc(item.coordY ?? '--')}</td><td>${esc(item.coordZ ?? '--')}</td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`;
    }).join('');
    table = auditTable(['时间','玩家昵称','SteamID','武器/来源','最后一击伤害','坐标X','坐标Y','坐标Z','操作'], sentryRows, '暂无岗哨摧毁记录');
  } else if (category === 'bunker_unlock') {
    const activated = audits.filter((item) => /activated/i.test(item.type || '')).length;
    const deactivated = audits.filter((item) => /deactivated/i.test(item.type || '')).length;
    stats = auditStats([['地堡解锁事件', audits.length], ['已激活', activated], ['已停用', deactivated]]);
    const bunkerRows = audits.map((item, index) => {
      const isActivated = /activated/i.test(item.type || '');
      return `<tr><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td>${auditId(item.bunkerId)}</td><td><span class="audit-type ${isActivated ? 'bunker-activated' : 'bunker-deactivated'}">${esc(item.typeLabel || '--')}</span></td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`;
    }).join('');
    table = auditTable(['时间','地堡编号','状态','操作'], bunkerRows, '暂无地堡解锁记录');
  } else if (category === 'bunker_status') {
    const active = audits.filter((item) => item.status === 'active').length;
    const locked = audits.filter((item) => item.status === 'locked').length;
    const summary = audits.filter((item) => item.status === 'summary').length;
    stats = auditStats([['状态变动', audits.length], ['活跃', active], ['锁定', locked], ['统计行', summary]]);
    const bunkerStatusRows = audits.map((item, index) => {
      const statusClass = item.status === 'active' ? 'bunker-active' : item.status === 'locked' ? 'bunker-locked' : 'bunker-summary';
      return `<tr><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td>${auditId(item.bunkerId)}</td><td><span class="audit-type ${statusClass}">${esc(item.statusLabel || '--')}</span></td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`;
    }).join('');
    table = auditTable(['时间','地堡编号','状态','操作'], bunkerStatusRows, '暂无地堡状态记录');
  } else if (category === 'base_destruction') {
    const totalDamage = audits.reduce((sum, item) => sum + Number(item.damage || 0), 0);
    const uniqueBuildings = new Set(audits.map((item) => item.entityId).filter(Boolean)).size;
    const uniquePlayers = new Set(audits.map((item) => item.steamId).filter(Boolean)).size;
    const typeCounts = audits.reduce((result, item) => { const key = item.typeLabel || '未记录'; result[key] = (result[key] || 0) + 1; return result; }, {});
    const chips = Object.entries(typeCounts).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([label, count]) => `<span>${esc(label)} <b>${count}</b></span>`).join('');
    stats = auditStats([['受击记录', audits.length], ['建筑数', uniqueBuildings], ['涉及玩家', uniquePlayers], ['伤害合计', auditNumber(totalDamage)]]);
    if (chips) stats += `<div class="gameplay-summary-chips">${chips}</div>`;
    table = auditTable(['时间','类型','建筑/容器','实体ID','玩家昵称','SteamID','武器/来源','伤害','坐标','操作'], audits.map((item, index) => {
      const highDamage = Number(item.damage) >= 100;
      return `<tr class="${highDamage ? 'sentry-high-damage-row' : ''}"><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td><span class="audit-type">${esc(item.typeLabel || '--')}</span></td><td>${esc(item.buildingName || '--')}</td><td>${auditId(item.entityId)}</td><td>${esc(item.playerName || '--')}</td><td>${auditId(item.steamId)}</td><td>${esc(item.weaponSource || '--')}</td><td>${esc(item.damage ?? '--')}</td><td>${auditLocation(item.location)}</td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`;
    }).join(''), '暂无基地建筑受击记录');
  } else if (category === 'rcon_stats') {
    const sourceCounts = audits.reduce((result, item) => { const key = item.sourceLabel || '未记录'; result[key] = (result[key] || 0) + 1; return result; }, {});
    const typeCounts = audits.reduce((result, item) => { const key = item.eventType || '未记录'; result[key] = (result[key] || 0) + 1; return result; }, {});
    const chips = Object.entries(typeCounts).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([label, count]) => `<span>${esc(label)} <b>${count}</b></span>`).join('');
    const meleeCount = audits.filter((item) => item.sourceLabel === '近战').length;
    const highDamage = audits.filter((item) => Number(item.damage) >= 100).length;
    const uniquePlayers = new Set(audits.map((item) => item.steamId).filter(Boolean)).size;
    stats = auditStats([['事件总数', audits.length], ['近战事件', meleeCount], ['高伤害(≥100)', highDamage], ['涉及玩家', uniquePlayers]]);
    if (chips) stats += `<div class="gameplay-summary-chips">${chips}</div>`;
    table = auditTable(['时间','来源','事件类型','目标类型','目标名称','目标Class','SteamID','伤害','血量前','血量后','命中部位','坐标','操作'], audits.map((item, index) => {
      const isMelee = item.sourceLabel === '近战';
      const isHighDamage = Number(item.damage) >= 100;
      const rowClass = isMelee || isHighDamage ? 'gameplay-risk-row' : '';
      return `<tr class="${rowClass}"><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td><span class="audit-type ${isMelee ? 'gameplay-risk-pill' : ''}">${esc(item.sourceLabel || '--')}</span></td><td>${esc(item.eventType || '--')}</td><td>${esc(item.targetType || '--')}</td><td>${esc(item.targetName || '--')}</td><td>${esc(item.targetClass || '--')}</td><td>${auditId(item.steamId)}</td><td>${esc(item.damage ?? '--')}</td><td>${esc(item.healthBefore ?? '--')}</td><td>${esc(item.healthAfter ?? '--')}</td><td>${esc(item.bone || '--')}</td><td>${auditLocation(item.location)}</td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`;
    }).join(''), '暂无RCON事件统计记录');
  } else if (category === 'kick') {
    const uniquePlayers = new Set(audits.map((item) => item.steamId).filter(Boolean)).size;
    const reasonCounts = audits.reduce((result, item) => { const key = item.reasonLabel || item.reason || '未记录'; result[key] = (result[key] || 0) + 1; return result; }, {});
    const mainReason = Object.entries(reasonCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || '未记录';
    stats = auditStats([['踢出事件', audits.length], ['涉及玩家', uniquePlayers], ['主要原因', mainReason]]);
    const chips = Object.entries(reasonCounts).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([label, count]) => `<span>${esc(label)} <b>${count}</b></span>`).join('');
    if (chips) stats += `<div class="gameplay-summary-chips">${chips}</div>`;
    table = auditTable(['时间', 'SteamID', '踢出原因', '玩家昵称', '操作'], audits.map((item, index) => `<tr><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td>${auditId(item.steamId)}</td><td><span class="audit-type">${esc(item.reasonLabel || item.reason || '--')}</span></td><td>${esc(item.playerName || '--')}</td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`).join(''), '暂无踢出记录');
  } else if (category === 'distance') {
    const distances = audits.map((item) => Number(item.distance)).filter(Number.isFinite);
    const maxDistance = distances.length ? Math.max(...distances).toFixed(1) + ' m' : '--';
    const avgDistance = distances.length ? (distances.reduce((a, b) => a + b, 0) / distances.length).toFixed(1) + ' m' : '--';
    const actions = audits.reduce((result, item) => { const key = item.action || '未记录'; result[key] = (result[key] || 0) + 1; return result; }, {});
    stats = auditStats([['超距事件', audits.length], ['平均距离', avgDistance], ['最大距离', maxDistance], ['动作类型', Object.keys(actions).length]]);
    const chips = Object.entries(actions).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([label, count]) => `<span>${esc(label)} <b>${count}</b></span>`).join('');
    if (chips) stats += `<div class="gameplay-summary-chips">${chips}</div>`;
    table = auditTable(['时间', '动作代码', '动作描述', '距离差', '玩家昵称', 'SteamID', '服务器坐标', '客户端坐标', '操作'], audits.map((item, index) => `<tr><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td>${esc(item.action || '--')}</td><td>${esc(item.actionDesc || '--')}</td><td>${Number.isFinite(Number(item.distance)) ? `${Number(item.distance).toFixed(1)} m` : '--'}</td><td>${esc(item.playerName || '--')}</td><td>${auditId(item.steamId)}</td><td>${auditLocation(item.serverLocation)}</td><td>${auditLocation(item.clientLocation)}</td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`).join(''), '暂无超距违规记录');
  } else if (category === 'ammo') {
    const weapons = audits.reduce((result, item) => { const key = item.weapon || '未记录'; result[key] = (result[key] || 0) + 1; return result; }, {});
    const mainWeapon = Object.entries(weapons).sort((a, b) => b[1] - a[1])[0]?.[0] || '未记录';
    const counts = audits.map((item) => Number(item.count)).filter(Number.isFinite);
    const maxCount = counts.length ? Math.max(...counts) : '--';
    stats = auditStats([['弹药异常', audits.length], ['主要武器', mainWeapon], ['最大子弹数', maxCount], ['涉及玩家', new Set(audits.map((item) => item.steamId).filter(Boolean)).size]]);
    const chips = Object.entries(weapons).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([label, count]) => `<span>${esc(label)} <b>${count}</b></span>`).join('');
    if (chips) stats += `<div class="gameplay-summary-chips">${chips}</div>`;
    table = auditTable(['时间', '武器名称', '检测到子弹数', '玩家昵称', 'SteamID', '坐标', '操作'], audits.map((item, index) => `<tr><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td>${esc(item.weapon || '--')}</td><td>${esc(item.count ?? '--')}</td><td>${esc(item.playerName || '--')}</td><td>${auditId(item.steamId)}</td><td>${auditLocation(item.location)}</td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`).join(''), '暂无弹药异常记录');
  } else if (category === 'ballistics') {
    const attackerDrifts = audits.map((item) => Number(item.attackerDrift)).filter(Number.isFinite);
    const victimDrifts = audits.map((item) => Number(item.victimDrift)).filter(Number.isFinite);
    const maxAttackerDrift = attackerDrifts.length ? Math.max(...attackerDrifts).toFixed(1) : '--';
    const maxVictimDrift = victimDrifts.length ? Math.max(...victimDrifts).toFixed(1) : '--';
    const weapons = audits.reduce((result, item) => { const key = item.weaponName || '未记录'; result[key] = (result[key] || 0) + 1; return result; }, {});
    stats = auditStats([['弹道异常', audits.length], ['最大攻击者漂移', maxAttackerDrift], ['最大受害者漂移', maxVictimDrift], ['涉及武器', Object.keys(weapons).length]]);
    const chips = Object.entries(weapons).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([label, count]) => `<span>${esc(label)} <b>${count}</b></span>`).join('');
    if (chips) stats += `<div class="gameplay-summary-chips">${chips}</div>`;
    table = auditTable(['时间', '武器/来源', '玩家昵称', 'SteamID', '攻击者漂移', '受害者漂移', '攻击者服务器坐标', '受害者服务器坐标', '原始内容', '操作'], audits.map((item, index) => `<tr><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td>${esc(item.weaponName || '--')}</td><td>${esc(item.playerName || '--')}</td><td>${auditId(item.steamId)}</td><td>${esc(item.attackerDrift ?? '--')}</td><td>${esc(item.victimDrift ?? '--')}</td><td>${auditLocation(item.serverAttackerLocation)}</td><td>${auditLocation(item.serverVictimLocation)}</td><td><button class="btn tiny" type="button" data-audit-detail="${index}">查看原文</button></td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`).join(''), '暂无弹道异常记录');
  } else if (category === 'other_violation') {
    stats = auditStats([['其他违规', audits.length], ['涉及玩家', new Set(audits.map((item) => item.steamId).filter(Boolean)).size]]);
    table = auditTable(['时间', '类型', '玩家昵称', '玩家编号', 'SteamID', '摘要', '原始内容', '操作'], audits.map((item, index) => `<tr><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td>${esc(item.type || item.typeLabel || '--')}</td><td>${esc(item.playerName || '--')}</td><td><code>${esc(item.playerNumber || '--')}</code></td><td>${auditId(item.steamId)}</td><td>${esc(item.summary || item.reason || '--')}</td><td>${esc(item.raw || '--')}</td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`).join(''), '暂无其他违规记录');
  } else if (category === 'loot_diagnostic') {
    const errorCount = audits.filter((item) => item.level === 'Error').length;
    const warningCount = audits.filter((item) => item.level === 'Warning').length;
    const categoryCounts = audits.reduce((result, item) => { const key = item.category || '未分类'; result[key] = (result[key] || 0) + 1; return result; }, {});
    const mainCategory = Object.entries(categoryCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || '--';
    stats = auditStats([['错误数', errorCount], ['警告数', warningCount], ['主要分类', mainCategory], ['总记录', audits.length]]);
    const levelPill = (level) => { const map = { Error: 'level-error', Log: 'level-log', Warning: 'level-warning', 'Game version': 'level-version' }; return `<span class="level-pill ${map[level] || 'level-log'}">${esc(level || '--')}</span>`; };
    const categoryPill = (cat) => `<span class="audit-type loot-cat">${esc(cat || '--')}</span>`;
    table = auditTable(['时间', '级别', '分类', '内容', '文件类型', '操作'], audits.map((item, index) => {
      const detailHtml = item.errorDetail ? (item.errorDetail.nodePath ? `<br><span class="muted">节点: ${esc(item.errorDetail.nodePath)} / 物品: ${esc(item.errorDetail.itemName)}</span>` : item.errorDetail.invalidItem ? `<br><span class="muted">无效物品: ${esc(item.errorDetail.invalidItem)}</span>` : item.errorDetail.failedFile ? `<br><span class="muted">解析失败: ${esc(item.errorDetail.failedFile)}</span>` : item.errorDetail.spawnerRef ? `<br><span class="muted">刷新点: ${esc(item.errorDetail.spawnerRef)} / 节点: ${esc(item.errorDetail.lootNode)}</span>` : item.errorDetail.message ? `<br><span class="muted">${esc(item.errorDetail.message)}</span>` : '') : '';
      return `<tr><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td>${levelPill(item.level)}</td><td>${categoryPill(item.category)}</td><td>${esc(item.content || '--')}${detailHtml}</td><td>${esc(item.fileType || '--')}</td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`;
    }).join(''), '暂无 Loot 诊断记录');
  } else if (category === 'raid_diagnostic') {
    const errorCount = audits.filter((item) => item.level === 'Error').length;
    const warningCount = audits.filter((item) => item.level === 'Warning').length;
    const categoryCounts = audits.reduce((result, item) => { const key = item.category || '未分类'; result[key] = (result[key] || 0) + 1; return result; }, {});
    const mainCategory = Object.entries(categoryCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || '--';
    stats = auditStats([['错误数', errorCount], ['警告数', warningCount], ['主要分类', mainCategory], ['总记录', audits.length]]);
    const levelPill = (level) => { const map = { Error: 'level-error', Log: 'level-log', Warning: 'level-warning', 'Game version': 'level-version' }; return `<span class="level-pill ${map[level] || 'level-log'}">${esc(level || '--')}</span>`; };
    const categoryPill = (cat) => `<span class="audit-type raid-cat">${esc(cat || '--')}</span>`;
    table = auditTable(['时间', '级别', '分类', '内容', '文件类型', '操作'], audits.map((item, index) => `<tr><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td>${levelPill(item.level)}</td><td>${categoryPill(item.category)}</td><td>${esc(item.content || '--')}</td><td>${esc(item.fileType || '--')}</td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`).join(''), '暂无突袭保护诊断记录');
  } else {
    stats = auditStats([['当前页变更', audits.length], ['旧所有者', new Set(audits.map((item) => item.oldOwnerSteamId).filter(Boolean)).size], ['新所有者', new Set(audits.map((item) => item.newOwnerSteamId).filter(Boolean)).size]]);
    table = auditTable(['时间', '认领人 SteamID', '被认领人 SteamID', '结果', '详情', '记录ID', '操作'], audits.map((item, index) => `<tr><td><code>${esc(formatGameLogTimestamp(item.timestamp))}</code></td><td>${auditId(item.oldOwnerSteamId)}</td><td>${auditId(item.newOwnerSteamId)}</td><td><span class="audit-type">所有权已变更</span></td><td>${esc(`${item.oldOwner?.playerName || item.oldOwnerSteamId || '--'} → ${item.newOwner?.playerName || item.newOwnerSteamId || '--'}`)}</td><td><code>${esc(item.recordId || '--')}</code></td><td><button class="btn tiny" type="button" data-audit-detail="${index}">详情</button></td></tr>`).join(''), '暂无队友认领记录');
  }
  $('#logOutput').innerHTML = `<section class="structured-audit"><header class="structured-audit-head"><div><h3>${esc(meta[0])}<span>${esc(meta[1])}</span><b>共 ${audits.length} 条</b></h3><p>${esc(meta[2])}</p></div>${gameLogSearchTools()}</header><div class="structured-audit-notice"><strong>重点提示</strong><span>${esc(meta[3])}</span></div>${stats}${table}</section>`;
  return true;
}
