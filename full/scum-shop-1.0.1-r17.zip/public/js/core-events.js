function closeOrReturnModal() {
  if ($('#modalBackdrop').classList.contains('lottery-prize-editor-modal') && typeof lotteryVersionModal === 'function') { lotteryVersionModal(); return; }
  closeModal();
}
$('#closeModal').addEventListener('click', closeOrReturnModal);
$('#cancelModal').addEventListener('click', closeOrReturnModal);
$('#modalBackdrop').addEventListener('click', (event) => { if (event.target === event.currentTarget && !event.currentTarget.classList.contains('modal-static-backdrop')) closeOrReturnModal(); });
$('#modalForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!state.modalSubmit) return;
  await withBusy($('#submitModal'), () => state.modalSubmit(event.currentTarget));
});
const sidebarBackdrop = document.createElement('button');
sidebarBackdrop.type = 'button';
sidebarBackdrop.className = 'sidebar-backdrop';
sidebarBackdrop.setAttribute('aria-label', '关闭菜单');
document.body.append(sidebarBackdrop);
function setAdminSidebar(open) {
  $('#sidebar').classList.toggle('open', open);
  sidebarBackdrop.classList.toggle('open', open);
  $('#menuToggle').setAttribute('aria-expanded', String(open));
  document.body.classList.toggle('sidebar-open', open);
}
document.addEventListener('keydown', (event) => {
  if (event.key !== 'Escape') return;
  if ($('#sidebar').classList.contains('open')) setAdminSidebar(false);
  else closeOrReturnModal();
});

$$('.nav-item').forEach((button) => button.addEventListener('click', () => { setAdminSidebar(false); showPage(button.dataset.page); }));
$$('[data-go]').forEach((button) => button.addEventListener('click', () => showPage(button.dataset.go)));
$('#menuToggle').setAttribute('aria-expanded', 'false');
$('#menuToggle').setAttribute('aria-controls', 'sidebar');
$('#menuToggle').addEventListener('click', () => setAdminSidebar(!$('#sidebar').classList.contains('open')));
sidebarBackdrop.addEventListener('click', () => setAdminSidebar(false));
$('#refreshPage').addEventListener('click', (event) => withBusy(event.currentTarget, () => loadPage(state.page)));

$('#modalForm').addEventListener('change', async (event) => {
  if (event.target.name === 'parentCategory' && event.currentTarget.elements.category) syncProductModalCategories();
  if (event.target.id === 'productImageFile' && event.target.files?.[0]) await withBusy($('[data-upload-product-image]'), async () => {
    const path = await uploadProductImage(event.target.files[0], event.currentTarget);
    if (!path) throw new Error('上传接口未返回图片路径');
    $('#modalForm').elements.imagePath.value = path;
    updateProductImagePreview(path);
    toast('商品图片已上传');
  });
  if (event.target.id === 'lotteryPoolImageFile' && event.target.files?.[0]) await withBusy($('[data-upload-lottery-image]'), async () => {
    const path = await uploadImage(event.target.files[0], '/api/lottery/pools/image');
    if (!path) throw new Error('上传接口未返回图片路径');
    $('#modalForm').elements.imagePath.value = path;
    updateLotteryImagePreview(path);
    toast('奖池图片已上传');
  });
  if (event.target.name === 'imagePath' && $('#lotteryPoolImagePreview')) updateLotteryImagePreview(event.target.value.trim());
  else if (event.target.name === 'imagePath') updateProductImagePreview(event.target.value.trim());
  if (event.target.name === 'rewardType') updateLotteryPrizeModalFields();
  if (event.target.name === 'ruleType') updateRewardThresholdField();
});

