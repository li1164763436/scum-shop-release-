const vehicleStatusNames = { active:'正常', stored:'停放', maintenance:'维修', lost:'丢失', destroyed:'损毁', retired:'退役', recovered:'已回收' };
const vehicleEditableStatusNames = { active:'正常', stored:'停放', maintenance:'维修', lost:'丢失', destroyed:'损毁', retired:'退役' };
const vehicleInsuranceNames = { none:'无保单', active:'已投保', expired:'已过期', suspended:'已暂停', claimed:'已索赔' };
const vehicleActionNames = { create:'创建档案', update:'更新档案', insurance_update:'更新保险', delete:'删除档案', sync_create:'同步创建', sync_update:'同步更新', sync_lost:'同步标记失联', sync_restore:'同步恢复' };
function vehicleDateInput(value) { if (!value) return ''; const dateValue = new Date(value); if (Number.isNaN(dateValue.getTime())) return ''; const local = new Date(dateValue.getTime() - dateValue.getTimezoneOffset() * 60000); return local.toISOString().slice(0,16); }
function vehiclePercent(value) { return value === null || value === undefined || value === '' ? '--' : `${Number(value).toFixed(0)}%`; }
function vehicleStatusBadge(status) { const tone = status === 'active' ? 'active' : status === 'lost' || status === 'destroyed' ? 'failed' : status === 'maintenance' ? 'pending' : 'inactive'; return `<span class="badge ${tone}">${esc(vehicleStatusNames[status] || status || '未知')}</span>`; }
function vehicleInsuranceBadge(status) { const value = status || 'none'; const tone = value === 'active' ? 'active' : value === 'expired' || value === 'suspended' ? 'failed' : value === 'claimed' ? 'pending' : 'inactive'; return `<span class="badge ${tone}">${esc(vehicleInsuranceNames[value] || value)}</span>`; }
function vehicleSyncBadge(vehicle) { const state = vehicle.sourceSyncState || 'manual'; const name = state === 'present' ? '已同步' : state === 'missing' ? '源中缺失' : '手动'; const tone = state === 'present' ? 'active' : state === 'missing' ? 'failed' : 'inactive'; return `<span class="badge ${tone}">${name}</span><small class="vehicle-sync-time">${esc(date(vehicle.sourceSynchronizedAt))}</small>`; }

async function loadVehicleManagement() {
  const root = $('#page-vehicle-management'); if (!root) return;
  bindVehicleManagementEvents(root);
  $('#vehicleRows').innerHTML = empty(9, '正在加载载具...', true);
  const strategyRows = $('#vehicleInsuranceStrategyRows'); if (strategyRows) strategyRows.innerHTML = empty(8, '正在加载保险策略...', true);
  try {
    state.vehiclePage = Math.max(Number(state.vehiclePage) || 1, 1);
    const params = new URLSearchParams({ search: $('#vehicleSearch').value.trim(), status: $('#vehicleStatusFilter').value, insuranceStatus: $('#vehicleInsuranceFilter').value, page:state.vehiclePage, pageSize:30 });
    const [vehicles, summary, strategies, insuranceProducts, insurancePurchases, syncStatus] = await Promise.all([api(`/api/vehicles?${params}`), api('/api/vehicles/summary'), api('/api/vehicles/insurance-strategies'), api('/api/vehicles/insurance-products'), api('/api/vehicles/insurance-purchases?pageSize=100'), api('/api/vehicles/sync-status')]);
    const automaticSync = syncStatus || { enabled:false, running:false, lastError:null };
    state.vehicles = list(vehicles, ['vehicles','items']);
    state.vehicleTotal = Number(vehicles?.total ?? state.vehicles.length);
    state.vehiclePage = Number(vehicles?.page ?? state.vehiclePage);
    state.vehiclePageSize = Number(vehicles?.pageSize ?? 30);
    state.vehicleInsuranceStrategies = list(strategies, ['strategies','items']);
    state.vehicleInsuranceProducts = list(insuranceProducts, ['products','items']);
    state.vehicleInsurancePurchases = list(insurancePurchases, ['purchases','items']);
    $('#vehicleTotalCount').textContent = number(summary.total);
    $('#vehicleActiveCount').textContent = number(summary.active);
    $('#vehicleInsuredCount').textContent = number(summary.insured);
    $('#vehicleAttentionCount').textContent = number(summary.attention);
    $('#vehicleSynchronizedCount').textContent = number(summary.synchronized);
    $('#vehicleLastSynchronizedAt').textContent = date(summary.lastSynchronizedAt || automaticSync.lastSuccessAt);
    const syncState = $('#vehicleSyncState');
    syncState.textContent = automaticSync.running ? '同步中' : automaticSync.lastError ? '同步异常' : automaticSync.enabled ? '运行中' : '已停止';
    syncState.className = automaticSync.lastError ? 'failed' : automaticSync.running ? 'pending' : automaticSync.enabled ? 'active' : 'inactive';
    syncState.title = automaticSync.lastError || '';
    $('#vehicleResultCount').textContent = `${number(state.vehicleTotal)} 辆载具`;
    const totalPages = Math.max(1, Math.ceil(state.vehicleTotal / state.vehiclePageSize));
    $('#vehiclePageStatus').textContent = `第 ${state.vehiclePage} / ${totalPages} 页`;
    $('#vehiclePreviousPage').disabled = state.vehiclePage <= 1;
    $('#vehicleNextPage').disabled = state.vehiclePage >= totalPages;
    renderVehicleInsuranceStrategies(state.vehicleInsuranceStrategies);
    renderVehicleInsuranceRows(state.vehicleInsurancePurchases, Number(insurancePurchases?.total ?? state.vehicleInsurancePurchases.length));
    $('#vehicleRows').innerHTML = state.vehicles.length ? state.vehicles.map((vehicle) => {
      const position = vehicle.gridCode || (vehicle.worldX !== null && vehicle.worldY !== null ? `X ${number(vehicle.worldX)} / Y ${number(vehicle.worldY)}` : '未记录');
      const owner = vehicle.ownerName || vehicle.ownerSteamId || '未绑定车主';
      return `<tr><td><div class="row-actions"><button class="btn secondary small" type="button" data-vehicle-detail="${vehicle.id}">详情</button><button class="btn secondary small" type="button" data-vehicle-edit="${vehicle.id}">编辑</button></div></td><td>${vehicleStatusBadge(vehicle.status)}</td><td>${vehicleSyncBadge(vehicle)}</td><td><div class="vehicle-identity"><strong>${esc(vehicle.displayName || vehicle.modelName)}</strong><span>${esc(vehicle.vehicleCode)} · ${esc(vehicle.vehicleType)}</span><small>${esc(vehicle.sourceType ? `自动同步 · ${vehicle.sourceAssetId || vehicle.sourceVehicleAlias || vehicle.modelName}` : (vehicle.plateNumber || vehicle.modelName))}</small></div></td><td><strong>${esc(owner)}</strong><small class="vehicle-steam">${esc(vehicle.ownerSteamId || '')}</small></td><td>${vehicleInsuranceBadge(vehicle.insuranceStatus)}<small class="vehicle-policy">${esc(vehicle.policyNumber || '无保单号')}</small></td><td><span class="vehicle-location">${esc(position)}</span><small>${esc(vehicle.locationNote || '无位置说明')}</small></td><td><span>${vehiclePercent(vehicle.conditionPercent)} / ${vehiclePercent(vehicle.fuelPercent)}</span></td><td>${esc(date(vehicle.updatedAt))}</td></tr>`;
    }).join('') : empty(9, '暂无载具档案');
    bindVehicleManagementEvents(root);
  } catch (error) {
    $('#vehicleRows').innerHTML = empty(9, error.message);
    if ($('#vehicleInsuranceStrategyRows')) $('#vehicleInsuranceStrategyRows').innerHTML = empty(8, error.message);
    ['vehicleTotalCount','vehicleActiveCount','vehicleInsuredCount','vehicleAttentionCount'].forEach((id) => $(`#${id}`).textContent = '--');
  }
}

function showVehicleSection(name) {
  const root = $('#page-vehicle-management'); if (!root) return;
  $$('[data-vehicle-panel]', root).forEach((button) => button.classList.toggle('active', button.dataset.vehiclePanel === name));
  $$('[data-vehicle-section]', root).forEach((section) => { section.hidden = section.dataset.vehicleSection !== name; });
}

function renderVehicleInsuranceRows(rows, total = rows.length) {
  const count = $('#vehicleInsuranceCount'), body = $('#vehicleInsuranceRows'); if (!count || !body) return;
  count.textContent = `${number(total)} 条保险记录`;
  body.innerHTML = rows.length ? rows.map((policy) => `<tr><td><strong>${esc(policy.productName || policy.strategyName || policy.vehicleType || '载具保险')}</strong><small>${esc(policy.vehicleCode || '独立保单')}</small></td><td>${esc(policy.ownerName || policy.ownerSteamId || '未绑定')}</td><td>${vehicleInsuranceBadge(policy.insuranceStatus)}</td><td>${esc(policy.policyNumber || '--')}</td><td>${number(policy.price)}</td><td>${esc(date(policy.startsAt))}</td><td>${esc(date(policy.expiresAt))}</td><td><button class="btn danger small" type="button" data-insurance-purchase-delete="${policy.id}">删除保单</button></td></tr>`).join('') : empty(8, '暂无保险记录');
}

function renderVehicleInsuranceStrategies(strategies) {
  const count = $('#vehicleInsuranceStrategyCount'), body = $('#vehicleInsuranceStrategyRows'); if (!count || !body) return;
  count.textContent = `${number(strategies.length)} 个策略`;
  body.innerHTML = strategies.length ? strategies.map((strategy) => `<tr><td><div class="row-actions"><button class="btn secondary small" type="button" data-insurance-strategy-edit="${strategy.id}">编辑</button><button class="btn danger small" type="button" data-insurance-strategy-delete="${strategy.id}">删除</button></div></td><td><strong>${esc(strategy.name)}</strong></td><td><strong>${esc(strategy.vehicleType)}</strong><small>${esc(strategy.vehicleCode || '未配置代码')}</small></td><td>${number(strategy.totalClaimLimit)} 次</td><td>${number(strategy.dailyClaimLimit)} 次</td><td>${number(strategy.durationDays)} 天</td><td><strong>${number(strategy.price)}</strong> 商城币</td><td><span class="badge ${strategy.enabled ? 'active' : 'inactive'}">${strategy.enabled ? '销售中' : '已停用'}</span></td></tr>`).join('') : empty(8, '暂无保险销售策略');
}

function vehicleInsuranceStrategyBody(strategy = {}) {
  const products = state.vehicleInsuranceProducts || [];
  return `<section class="vehicle-insurance-strategy-editor full"><div class="vehicle-form-grid">
    <label>保险名称<input name="name" maxlength="100" required value="${esc(strategy.name || '')}" placeholder="名称不可重复"></label>
    <label>载具类型<select name="productId" required><option value="">请选择载具商品</option>${products.map((product) => `<option value="${product.id}" data-vehicle-code="${esc(product.vehicleCode || '')}"${Number(strategy.productId) === Number(product.id) ? ' selected' : ''}>${esc(product.name)}${product.enabled ? '' : '（未上架）'}</option>`).join('')}</select></label>
    <label>载具代码<input name="vehicleCode" value="${esc(strategy.vehicleCode || '')}" readonly placeholder="选择载具类型后自动显示"></label>
    <label>总赔付次数限制<input name="totalClaimLimit" type="number" min="1" step="1" required value="${esc(strategy.totalClaimLimit ?? 1)}"></label>
    <label>每日赔付次数限制<input name="dailyClaimLimit" type="number" min="1" step="1" required value="${esc(strategy.dailyClaimLimit ?? 1)}"></label>
    <label>有效时长（天）<input name="durationDays" type="number" min="1" step="1" required value="${esc(strategy.durationDays ?? 30)}"></label>
    <label>购买条件<input name="purchaseCondition" maxlength="200" required value="${esc(strategy.purchaseCondition || '无需绑定载具')}" placeholder="显示在商城保单卡片中"></label>
    <label>售价（商城币）<input name="price" type="number" min="0" step="1" required value="${esc(strategy.price ?? 0)}"></label>
    <label class="vehicle-switch full"><input name="enabled" type="checkbox"${strategy.enabled === false ? '' : ' checked'}><span>允许玩家在商城自助购买此保险</span></label>
  </div><div class="vehicle-strategy-hint">达到总赔付次数或超过有效时长后，玩家购买的保险将不能继续赔付。</div></section>`;
}

function vehicleInsuranceStrategyModal(strategy = null) {
  openModal({ title:strategy ? `编辑保险策略 · ${strategy.name}` : '新增载具保险销售策略', description:'配置适用载具类型、赔付次数、有效时长和商城币售价。', submitText:'保存策略', body:vehicleInsuranceStrategyBody(strategy || {}), onSubmit:async(form) => {
    const f = form.elements, payload = { name:f.name.value.trim(), productId:Number(f.productId.value), totalClaimLimit:Number(f.totalClaimLimit.value), dailyClaimLimit:Number(f.dailyClaimLimit.value), durationDays:Number(f.durationDays.value), purchaseCondition:f.purchaseCondition.value.trim(), price:Number(f.price.value), enabled:f.enabled.checked };
    await api(strategy ? `/api/vehicles/insurance-strategies/${strategy.id}` : '/api/vehicles/insurance-strategies', { method:strategy ? 'PUT' : 'POST', body:JSON.stringify(payload) });
    toast(strategy ? '保险策略已更新' : '保险策略已新增'); closeModal(); await loadVehicleManagement(); showVehicleSection('insurance');
  }});
  $('#modalBackdrop').classList.add('centered-modal');
  const form = $('#modalForm'), productSelect = form?.elements.productId, codeInput = form?.elements.vehicleCode;
  const syncVehicleCode = () => { if (codeInput && productSelect) codeInput.value = productSelect.selectedOptions[0]?.dataset.vehicleCode || ''; };
  productSelect?.addEventListener('change', syncVehicleCode); syncVehicleCode();
}

function bindVehicleManagementEvents(root) {
  if (root.dataset.eventsBound) return; root.dataset.eventsBound = '1';
  $$('[data-vehicle-panel]', root).forEach((button) => button.addEventListener('click', () => showVehicleSection(button.dataset.vehiclePanel)));
  $('#createVehicleInsuranceStrategy').addEventListener('click', () => vehicleInsuranceStrategyModal());
  const reloadFirstPage = () => { state.vehiclePage = 1; loadVehicleManagement(); };
  $('#searchVehicles').addEventListener('click', reloadFirstPage);
  $('#vehicleSearch').addEventListener('keydown', (event) => { if (event.key === 'Enter') reloadFirstPage(); });
  $('#vehicleStatusFilter').addEventListener('change', reloadFirstPage);
  $('#vehicleInsuranceFilter').addEventListener('change', reloadFirstPage);
  $('#vehiclePreviousPage').addEventListener('click', () => { if (state.vehiclePage > 1) { state.vehiclePage -= 1; loadVehicleManagement(); } });
  $('#vehicleNextPage').addEventListener('click', () => { state.vehiclePage += 1; loadVehicleManagement(); });
  root.addEventListener('click', async (event) => {
    const strategyEdit = event.target.closest('[data-insurance-strategy-edit]');
    if (strategyEdit) return vehicleInsuranceStrategyModal((state.vehicleInsuranceStrategies || []).find((item) => item.id === Number(strategyEdit.dataset.insuranceStrategyEdit)));
    const strategyDelete = event.target.closest('[data-insurance-strategy-delete]');
    if (strategyDelete) { const strategy = (state.vehicleInsuranceStrategies || []).find((item) => item.id === Number(strategyDelete.dataset.insuranceStrategyDelete)); if (!confirm(`确认删除保险销售策略“${strategy?.name || ''}”？删除后仅停止新销售，已有保单和索赔不受影响。`)) return; await api(`/api/vehicles/insurance-strategies/${strategyDelete.dataset.insuranceStrategyDelete}`, { method:'DELETE' }); toast('保险销售策略已删除'); await loadVehicleManagement(); showVehicleSection('insurance'); return; }
    const policyDelete = event.target.closest('[data-insurance-purchase-delete]');
    if (policyDelete) { const policy = (state.vehicleInsurancePurchases || []).find((item) => item.id === Number(policyDelete.dataset.insurancePurchaseDelete)); if (!confirm(`确认删除玩家保单“${policy?.policyNumber || ''}”？删除后该保单立即失效，销售策略不受影响。`)) return; await api(`/api/vehicles/insurance-purchases/${policyDelete.dataset.insurancePurchaseDelete}`, { method:'DELETE' }); toast('玩家保单已删除'); await loadVehicleManagement(); showVehicleSection('insurance'); return; }
    const edit = event.target.closest('[data-vehicle-edit]'); if (edit) return vehicleEditorModal(state.vehicles.find((item) => item.id === Number(edit.dataset.vehicleEdit)));
    const detail = event.target.closest('[data-vehicle-detail]'); if (detail) return vehicleDetailModal(detail.dataset.vehicleDetail);
  });
}

function vehicleEditorBody(vehicle = {}) {
  const insuranceStatus = vehicle.insuranceStatus || 'none';
  const automatic = Boolean(vehicle.sourceType);
  const automaticAttribute = automatic ? ' readonly aria-readonly="true"' : '';
  return `<section class="vehicle-editor full">
    ${automatic ? '<div class="vehicle-sync-hint">档案编号、锁具所有者、载具类型、型号、世界坐标和最后发现时间由 SCUM.db / RCON 自动维护；管理员状态、别名、保险和备注仍可编辑。</div>' : ''}
    <div class="vehicle-form-grid">
      <label>档案编号<input name="vehicleCode" maxlength="64" required value="${esc(vehicle.vehicleCode || '')}" placeholder="例如 VH-0001"${automaticAttribute}></label>
      <label>状态<select name="status">${Object.entries(vehicleEditableStatusNames).map(([key,label]) => `<option value="${key}"${(vehicle.sourceStatus || vehicle.status) === key ? ' selected' : ''}>${label}</option>`).join('')}</select></label>
      <label>载具类型<input name="vehicleType" maxlength="80" required value="${esc(vehicle.vehicleType || '')}" placeholder="汽车 / 摩托 / 船只"${automaticAttribute}></label>
      <label>型号<input name="modelName" maxlength="120" required value="${esc(vehicle.modelName || '')}"${automaticAttribute}></label>
      <label>载具别名<input name="displayName" maxlength="120" value="${esc(vehicle.displayName || '')}"></label>
      <label>车牌 / 注册号<input name="plateNumber" maxlength="64" value="${esc(vehicle.plateNumber || '')}"></label>
      <label>车主SteamID<input name="ownerSteamId" maxlength="17" inputmode="numeric" value="${esc(vehicle.ownerSteamId || '')}"${automaticAttribute}></label>
      <label>车主名称<input name="ownerName" maxlength="100" value="${esc(vehicle.ownerName || '')}"${automaticAttribute}></label>
      <label>车况百分比<input name="conditionPercent" type="number" min="0" max="100" step="0.1" value="${esc(vehicle.conditionPercent ?? '')}"></label>
      <label>油量百分比<input name="fuelPercent" type="number" min="0" max="100" step="0.1" value="${esc(vehicle.fuelPercent ?? '')}"></label>
    </div>
    <h3>位置与地图标记</h3>
    <div class="vehicle-location-layout">
      <div class="vehicle-form-grid compact"><label>地图格<input name="gridCode" maxlength="16" value="${esc(vehicle.gridCode || '')}" placeholder="例如 B2"${automaticAttribute}></label><label>最后发现<input name="lastSeenAt" type="datetime-local" value="${vehicleDateInput(vehicle.lastSeenAt)}"${automaticAttribute}></label><label>X 坐标<input name="worldX" type="number" step="0.0001" value="${esc(vehicle.worldX ?? '')}"${automaticAttribute}></label><label>Y 坐标<input name="worldY" type="number" step="0.0001" value="${esc(vehicle.worldY ?? '')}"${automaticAttribute}></label><label>Z 坐标<input name="worldZ" type="number" step="0.0001" value="${esc(vehicle.worldZ ?? '')}"${automaticAttribute}></label><label>地图横向 %<input name="mapXPercent" type="number" min="0" max="100" step="0.0001" value="${esc(vehicle.mapXPercent ?? '')}"></label><label>地图纵向 %<input name="mapYPercent" type="number" min="0" max="100" step="0.0001" value="${esc(vehicle.mapYPercent ?? '')}"></label><label class="full">位置说明<input name="locationNote" maxlength="500" value="${esc(vehicle.locationNote || '')}"></label></div>
      <div class="vehicle-map-picker" id="vehicleMapPicker" title="点击地图设置标记"><img src="/shop/assets/teleport/scum-map-ultra.webp" alt="SCUM地图"><span id="vehicleMapMarker" hidden></span><small>点击地图设置标记位置</small></div>
    </div>
    <h3>管理员保险配置</h3>
    <div class="vehicle-form-grid"><label>保险状态<select name="insuranceStatus">${Object.entries(vehicleInsuranceNames).map(([key,label]) => `<option value="${key}"${insuranceStatus === key ? ' selected' : ''}>${label}</option>`).join('')}</select></label><label>保单编号<input name="policyNumber" maxlength="100" value="${esc(vehicle.policyNumber || '')}"></label><label>保险价值<input name="insuredValue" type="number" min="0" step="1" value="${esc(vehicle.insuredValue ?? '')}"></label><label>保费<input name="premiumAmount" type="number" min="0" step="1" value="${esc(vehicle.premiumAmount ?? '')}"></label><label>生效时间<input name="insuranceStartsAt" type="datetime-local" value="${vehicleDateInput(vehicle.insuranceStartsAt)}"></label><label>到期时间<input name="insuranceExpiresAt" type="datetime-local" value="${vehicleDateInput(vehicle.insuranceExpiresAt)}"></label><label class="full">保障范围<textarea name="coverageNote" maxlength="1000">${esc(vehicle.coverageNote || '')}</textarea></label><label class="full">保险备注<textarea name="insuranceNotes" maxlength="1000">${esc(vehicle.insuranceNotes || '')}</textarea></label><label class="full">载具备注<textarea name="notes" maxlength="2000">${esc(vehicle.notes || '')}</textarea></label></div>
    ${vehicle.id ? `<button class="btn danger vehicle-delete" type="button" data-delete-vehicle="${vehicle.id}">删除载具档案</button>` : ''}
  </section>`;
}

function optionalNumberInput(element) { return element.value === '' ? null : Number(element.value); }
function optionalDateInput(element) { return element.value ? new Date(element.value).toISOString() : null; }
function setupVehicleMapPicker() {
  const picker = $('#vehicleMapPicker'), marker = $('#vehicleMapMarker'), form = $('#modalForm'); if (!picker || !marker) return;
  const render = () => { const x = Number(form.elements.mapXPercent.value), y = Number(form.elements.mapYPercent.value); const visible = Number.isFinite(x) && Number.isFinite(y) && form.elements.mapXPercent.value !== '' && form.elements.mapYPercent.value !== ''; marker.hidden = !visible; if (visible) { marker.style.left = `${x}%`; marker.style.top = `${y}%`; } };
  picker.addEventListener('click', (event) => { const rect = picker.querySelector('img').getBoundingClientRect(); const x = Math.max(0, Math.min(100, (event.clientX - rect.left) / rect.width * 100)); const y = Math.max(0, Math.min(100, (event.clientY - rect.top) / rect.height * 100)); form.elements.mapXPercent.value = x.toFixed(4); form.elements.mapYPercent.value = y.toFixed(4); render(); });
  form.elements.mapXPercent.addEventListener('input', render); form.elements.mapYPercent.addEventListener('input', render); render();
}

function vehicleEditorModal(vehicle = null) {
  openModal({ title: vehicle ? `编辑载具 · ${vehicle.vehicleCode}` : '新增载具档案', description: '档案与保险均由管理员手动维护；地图点击仅记录标记百分比。', submitText: '保存载具', body: vehicleEditorBody(vehicle || {}), onSubmit: async (form) => {
    const f = form.elements;
    const payload = { vehicleCode:f.vehicleCode.value.trim(),status:f.status.value,vehicleType:f.vehicleType.value.trim(),modelName:f.modelName.value.trim(),displayName:f.displayName.value.trim(),plateNumber:f.plateNumber.value.trim(),ownerSteamId:f.ownerSteamId.value.trim(),ownerName:f.ownerName.value.trim(),conditionPercent:optionalNumberInput(f.conditionPercent),fuelPercent:optionalNumberInput(f.fuelPercent),gridCode:f.gridCode.value.trim(),worldX:optionalNumberInput(f.worldX),worldY:optionalNumberInput(f.worldY),worldZ:optionalNumberInput(f.worldZ),mapXPercent:optionalNumberInput(f.mapXPercent),mapYPercent:optionalNumberInput(f.mapYPercent),locationNote:f.locationNote.value.trim(),lastSeenAt:optionalDateInput(f.lastSeenAt),notes:f.notes.value.trim() };
    const saved = await api(vehicle ? `/api/vehicles/${vehicle.id}` : '/api/vehicles', { method: vehicle ? 'PUT' : 'POST', body: JSON.stringify(payload) });
    await api(`/api/vehicles/${saved.id}/insurance`, { method:'PUT', body:JSON.stringify({ status:f.insuranceStatus.value,policyNumber:f.policyNumber.value.trim(),insuredValue:optionalNumberInput(f.insuredValue),premiumAmount:optionalNumberInput(f.premiumAmount),startsAt:optionalDateInput(f.insuranceStartsAt),expiresAt:optionalDateInput(f.insuranceExpiresAt),coverageNote:f.coverageNote.value.trim(),notes:f.insuranceNotes.value.trim() }) });
    toast('载具档案已保存'); closeModal(); await loadVehicleManagement();
  }});
  setupVehicleMapPicker();
  $('[data-delete-vehicle]')?.addEventListener('click', async (event) => { if (!confirm('确认删除该载具档案？保险资料会一并删除，审计记录保留。')) return; await api(`/api/vehicles/${event.currentTarget.dataset.deleteVehicle}`, { method:'DELETE' }); toast('载具档案已删除'); closeModal(); await loadVehicleManagement(); });
}

async function vehicleDetailModal(id) {
  openModal({ title:'载具详情', description:'正在读取载具档案与审计记录', submitText:'关闭', body:'<div class="empty loading">正在加载...</div>', onSubmit:async()=>closeModal() });
  try {
    const data = await api(`/api/vehicles/${id}`), vehicle = data.vehicle, audits = data.audits || [];
    $('#modalTitle').textContent = vehicle.displayName || vehicle.modelName;
    $('#modalDescription').textContent = `${vehicle.vehicleCode} · ${vehicleStatusNames[vehicle.status] || vehicle.status}`;
    $('#modalBody').innerHTML = `<section class="vehicle-detail full"><div class="vehicle-detail-map"><img src="/shop/assets/teleport/scum-map-ultra.webp" alt="SCUM地图">${vehicle.mapXPercent !== null && vehicle.mapYPercent !== null ? `<span style="left:${vehicle.mapXPercent}%;top:${vehicle.mapYPercent}%"></span>` : ''}</div><dl><div><dt>车主</dt><dd>${esc(vehicle.ownerName || vehicle.ownerSteamId || '未绑定')}</dd></div><div><dt>类型 / 型号</dt><dd>${esc(vehicle.vehicleType)} / ${esc(vehicle.modelName)}</dd></div><div><dt>车牌</dt><dd>${esc(vehicle.plateNumber || '--')}</dd></div><div><dt>保险</dt><dd>${esc(vehicleInsuranceNames[vehicle.insuranceStatus || 'none'])} · ${esc(vehicle.policyNumber || '无保单号')}</dd></div><div><dt>坐标</dt><dd>${esc(vehicle.gridCode || '--')} · X ${esc(vehicle.worldX ?? '--')} / Y ${esc(vehicle.worldY ?? '--')} / Z ${esc(vehicle.worldZ ?? '--')}</dd></div><div><dt>最后发现</dt><dd>${esc(date(vehicle.lastSeenAt))}</dd></div><div><dt>档案来源</dt><dd>${esc(vehicle.sourceType ? `SCUM.db 上锁载具 #${vehicle.sourceVehicleId}` : '管理员手动维护')}</dd></div><div><dt>同步状态</dt><dd>${esc(vehicle.sourceSyncState === 'present' ? '已同步' : vehicle.sourceSyncState === 'missing' ? '源中缺失' : '手动')}</dd></div><div><dt>锁槽数量</dt><dd>${esc(vehicle.sourceLockSlots ?? '--')}</dd></div><div><dt>位置来源</dt><dd>${esc(vehicle.locationSource || '--')}</dd></div><div><dt>最后同步</dt><dd>${esc(date(vehicle.sourceSynchronizedAt))}</dd></div><div><dt>源缺失开始</dt><dd>${esc(date(vehicle.sourceMissingSince))}</dd></div><div class="wide"><dt>位置说明</dt><dd>${esc(vehicle.locationNote || '--')}</dd></div><div class="wide"><dt>备注</dt><dd>${esc(vehicle.notes || '--')}</dd></div></dl><h3>操作记录</h3><div class="vehicle-audit-list">${audits.length ? audits.map((audit) => `<article><strong>${esc(vehicleActionNames[audit.action] || audit.action)}</strong><span>${esc(audit.actorName || 'system')} · ${esc(date(audit.createdAt))}</span></article>`).join('') : '<div class="empty">暂无操作记录</div>'}</div></section>`;
  } catch (error) { $('#modalBody').innerHTML = `<div class="empty">${esc(error.message)}</div>`; }
}
