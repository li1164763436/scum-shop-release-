let accountLoadVersion = 0;

async function loadAccounts() {
  const loadVersion = ++accountLoadVersion;
  $('#accountRows').innerHTML = empty(7, '正在加载账户...', true);
  try {
    const search = $('#accountSearch').value.trim();
    const data = await api(`/api/accounts?search=${encodeURIComponent(search)}`);
    if (loadVersion !== accountLoadVersion) return;
    state.accounts = list(data, ['accounts', 'items']);
    const onlineCount = state.accounts.filter((account) => Boolean(account.online)).length;
    const balanceTotal = state.accounts.reduce((total, account) => total + Number(account.balance || 0), 0);
    $('#accountTotalCount').textContent = number(state.accounts.length);
    $('#accountOnlineCount').textContent = number(onlineCount);
    $('#accountBalanceTotal').textContent = number(balanceTotal);
    $('#accountResultCount').textContent = `${number(state.accounts.length)} 位玩家`;
    $('#accountRows').innerHTML = state.accounts.length ? state.accounts.map((account) => {
      const steamId = account.steamId;
      const displayName = account.characterName || account.steamName || account.username || '未绑定昵称';
      const userName = account.username || account.steamName || '--';
      const hasRegisteredAccount = Boolean(String(account.username || '').trim());
      const shopRoleBadge = account.role === 'super_admin' ? '<span class="badge failed">超级管理员</span>' : account.role === 'admin' ? '<span class="badge failed">后台管理员</span>' : hasRegisteredAccount ? '<span class="badge">商城玩家</span>' : '<span class="badge">未注册</span>';
      const gameAdminBadge = account.isAdmin
        ? '<span class="badge game-role-badge admin">游戏管理员</span>'
        : '<span class="badge game-role-badge player">普通玩家</span>';
      const promoteButton = '';
      const onlineBadge = account.online ? '<span class="badge active">在线</span>' : '<span class="badge inactive">离线</span>';
      const accountBadge = !hasRegisteredAccount ? '' : account.status === 'active' ? '<span class="badge active">账户正常</span>' : account.status ? `<span class="badge inactive">${esc(account.status)}</span>` : '<span class="badge inactive">账户状态未知</span>';
      const activity = account.online ? `在线 · ${esc(date(account.lastSeenAt))}` : account.lastSeenAt ? `最后出现 ${esc(date(account.lastSeenAt))}` : account.lastLogin ? `最后登录 ${esc(date(account.lastLogin))}` : '暂无在线记录';
      return `<tr><td><div class="row-actions"><button class="btn secondary account-action" data-account-menu="${esc(steamId)}" aria-expanded="false">操作</button>${promoteButton}</div></td><td><div class="account-badges">${shopRoleBadge}${gameAdminBadge}${onlineBadge}${accountBadge}</div></td><td><div class="account-identity"><strong>${esc(userName)}</strong><span>${esc(displayName)}</span></div></td><td><code>${esc(steamId)}</code></td><td><span class="account-activity">${activity}</span></td><td><strong class="member-level">等级：${number(account.memberLevel || 0)}</strong></td><td><span class="money">${number(account.balance)}</span></td></tr>`;
    }).join('') : empty(7, '暂无玩家账户');
  } catch (error) {
    if (loadVersion !== accountLoadVersion) return;
    $('#accountTotalCount').textContent = '--';
    $('#accountOnlineCount').textContent = '--';
    $('#accountBalanceTotal').textContent = '--';
    $('#accountResultCount').textContent = '0 位玩家';
    $('#accountRows').innerHTML = empty(7, error.message === '接口不存在' ? '玩家账户接口尚未启用' : error.message);
  }
}

function formatDuration(value) {
  const seconds = Number(value);
  if (!Number.isFinite(seconds) || seconds < 0) return '--';
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  return `${days ? `${days} 天 ` : ''}${hours ? `${hours} 小时 ` : ''}${minutes} 分钟`;
}

async function accountProfileModal(steamId) {
  openModal({
    title: '玩家操作面板', description: '玩家账号附加信息', submitText: '关闭',
    body: '<section class="account-profile full"><div class="empty loading">正在加载最新玩家详情...</div></section>',
    onSubmit: async () => closeModal()
  });
  $('#modalBackdrop').classList.add('centered-modal');
  $('#cancelModal').hidden = true;
  $('#submitModal').disabled = true;
  try {
    const account = await api(`/api/accounts/${encodeURIComponent(steamId)}`);
    const online = Boolean(account.online);
    const titles = list(account.titles).map((item) => `${item.titleName}${item.expiresAt ? `（至 ${date(item.expiresAt)}）` : ''}`).join('、') || '无';
    const squad = account.squad ? `${account.squad.squadName}（${account.squad.squadId}）` : '无';
    const shopAccount = account.username || '未注册';
    const shopLoginStatus = date(account.lastLogin);
    const adminIdentity = account.role === 'super_admin' ? '超级管理员' : account.role === 'admin' ? '后台管理员' : '商城玩家';
    const gameMoney = account.gameMoney === null || account.gameMoney === undefined ? '暂无' : number(account.gameMoney);
    const gameGold = account.gameGold === null || account.gameGold === undefined ? '暂无' : number(account.gameGold);
    const gameReputation = account.gameReputation === null || account.gameReputation === undefined ? '暂无' : number(account.gameReputation);
    $('#modalBody').innerHTML = `<section class="account-profile full"><div class="account-profile-title"><span>玩家资料</span></div><div class="account-profile-grid"><article><span>在线状态</span><strong class="${online ? 'online' : 'offline'}">${online ? '在线' : '离线'}</strong></article><article><span>最后游戏在线</span><strong>${esc(date(account.lastOnlineAt))}</strong></article><article><span>本次在线</span><strong>${online ? esc(formatDuration(account.currentSessionSeconds)) : '--'}</strong></article><article><span>累计在线</span><strong>${esc(formatDuration(account.totalOnlineSeconds))}</strong></article></div><dl><div><dt>商城账户</dt><dd>${esc(shopAccount)}</dd></div><div><dt>商城登录状态</dt><dd>${esc(shopLoginStatus)}</dd></div><div class='account-game-identity'><dt>游戏名<br>SteamID</dt><dd><strong>${esc(account.characterName || '--')}</strong><code>${esc(account.steamId || steamId)}</code></dd></div><div><dt>商城身份</dt><dd>${adminIdentity}</dd></div><div><dt>游戏身份</dt><dd>${account.isAdmin ? '游戏管理员' : '普通玩家'}</dd></div><div><dt>会员等级</dt><dd>${number(account.memberLevel || 0)}</dd></div><div><dt>商城币</dt><dd>${number(account.balance)}</dd></div><div><dt>游戏美金</dt><dd>${gameMoney}</dd></div><div><dt>游戏金条</dt><dd>${gameGold}</dd></div><div><dt>游戏声望</dt><dd>${gameReputation}</dd></div><div><dt>玩家称号</dt><dd>${esc(titles)}</dd></div><div><dt>玩家小队</dt><dd>${esc(squad)}</dd></div><div><dt>注册时间</dt><dd>${account.userCreatedAt ? esc(date(account.userCreatedAt)) : '未注册'}</dd></div></dl></section>`;
  } catch (error) {
    $('#modalBody').innerHTML = `<section class="account-profile full"><div class="empty">${esc(error.message)}</div></section>`;
    toast(error.message, true);
  } finally {
    $('#submitModal').disabled = false;
  }
}

function balanceModal(steamId = '') {
  $('#cancelModal').hidden = false;
  openModal({
    title: '调整商城币余额', description: '正数增加余额，负数扣减余额，所有调整应填写原因。', submitText: '确认调整',
    body: `<label class="full">玩家 SteamID<input name="steamId" value="${esc(steamId)}" required pattern="[0-9]{17}"></label><label>调整数量<input name="amount" type="number" step="1" required placeholder="例如 100 或 -50"></label><label class="full">调整原因<input name="note" required maxlength="255" placeholder="例如：活动奖励、人工补偿"></label>`,
    onSubmit: async (form) => {
      const values = Object.fromEntries(new FormData(form));
      await api(`/api/accounts/${encodeURIComponent(values.steamId)}/adjust`, { method: 'POST', body: JSON.stringify({ amount: Number(values.amount), note: values.note.trim() }) });
      toast('商城币余额已调整'); closeModal(); await loadAccounts();
    }
  });
}
async function accountGiftsModal(steamId) {
  openModal({ title: '礼包记录', description: `玩家 ${steamId}`, submitText: '关闭', body: '<section class="full"><div class="empty loading">正在加载礼包记录...</div></section>', onSubmit: async () => closeModal() });
  $('#modalBackdrop').classList.add('centered-modal');
  $('#cancelModal').hidden = true;
  const account = await api(`/api/accounts/${encodeURIComponent(steamId)}`);
  const claims = list(account.giftClaims);
  $('#modalBody').innerHTML = `<section class="modal-section full"><div class="table-wrap"><table><thead><tr><th>礼包</th><th>订单号</th><th>状态</th><th>支付</th><th>领取时间</th></tr></thead><tbody>${claims.length ? claims.map((item) => `<tr><td>${esc(item.giftName || '--')}</td><td><code>${esc(item.orderNo || '--')}</code></td><td>${status(item.status)}</td><td>${number(item.pricePaid)} 商城币</td><td>${esc(date(item.createdAt))}</td></tr>`).join('') : empty(5, '暂无礼包记录')}</tbody></table></div></section>`;
}

async function accountOrdersModal(steamId) {
  openModal({ title: '消费记录', description: `玩家 ${steamId}`, submitText: '关闭', body: '<section class="full"><div class="empty loading">正在加载消费记录...</div></section>', onSubmit: async () => closeModal() });
  $('#modalBackdrop').classList.add('centered-modal');
  $('#cancelModal').hidden = true;
  const account = await api(`/api/accounts/${encodeURIComponent(steamId)}`);
  const orders = list(account.orders);
  const sourceLabel = (value) => ({ shop: '商城', manual: '后台', gift: '礼包', redeem: '兑换码', lottery: '抽奖' }[value] || value || '--');
  const abnormalCount = orders.filter((item) => item.status !== 'completed').length;
  const orderStatus = (value) => value === 'completed' ? '<span class="badge account-order-status completed">已完成</span>' : '<span class="badge account-order-status abnormal">异常</span>';
  $('#modalBody').innerHTML = `<section class="account-consumption full"><div class="account-consumption-summary"><article><span>消费订单</span><strong>${number(account.orderStats?.orderCount)}</strong></article><article><span>累计消费</span><strong>${number(account.orderStats?.totalAmount)} 商城币</strong></article><article><span>累计收入</span><strong>${number(account.ledgerStats?.totalIncome)} 商城币</strong></article></div><div class="table-wrap account-consumption-table"><table><thead><tr><th>序号</th><th>订单号</th><th>商品明细</th><th>消费金额</th><th>状态</th><th>来源</th><th>消费时间</th></tr></thead><tbody>${orders.length ? orders.map((item, index) => { const orderNo = String(item.orderNo || '--'); const itemText = String(item.items || '--').replace(/\s+/g, ' '); const itemPreview = itemText.length > 15 ? `${itemText.slice(0, 15)}…` : itemText; return `<tr><td class="account-consumption-index">${index + 1}</td><td><button type="button" class="account-order-copy" data-copy-order="${esc(orderNo)}" title="${esc(orderNo)}，点击复制">${esc(orderNo.slice(0, 4))}</button></td><td class="account-consumption-items" title="${esc(itemText)}">${esc(itemPreview)}</td><td><strong class="money">${number(item.totalAmount)}</strong></td><td>${orderStatus(item.status)}</td><td>${esc(sourceLabel(item.source))}</td><td>${esc(date(item.createdAt))}</td></tr>`; }).join('') : empty(7, '暂无消费记录')}</tbody></table></div></section>`;
  const head = $('#modalTitle').closest('.modal-head');
  const tools = document.createElement('div');
  tools.className = 'account-consumption-title-tools';
  tools.innerHTML = `<span>异常订单</span><strong>${number(abnormalCount)}</strong>`;
  head.insertBefore(tools, $('#closeModal'));
}

function goldModal(steamId = '') {
  openModal({
    title: '调整游戏金条', description: '玩家必须在线，正数增加金条，负数减少金条。', submitText: '确认调整',
    body: `<label class="full">玩家 SteamID<input name="steamId" value="${esc(steamId)}" required pattern="[0-9]{17}"></label><label class="full">调整金条数量<input name="amount" type="number" step="1" required placeholder="例如 100 或 -50"></label>`,
    onSubmit: async (form) => {
      const values = Object.fromEntries(new FormData(form));
      await api(`/api/admin/players/${encodeURIComponent(values.steamId)}/gold`, { method: 'POST', body: JSON.stringify({ amount: Number(values.amount) }) });
      toast('游戏金条已调整');
      form.elements.amount.value = '';
      await loadAccounts();
    }
  });
  $('#modalBackdrop').classList.add('centered-modal');
  $('#cancelModal').hidden = true;
}
async function playerAttributesModal(steamId = '') {
  let data;
  try { data = await api(`/api/admin/players/${encodeURIComponent(steamId)}/attributes`); } catch (error) { toast(error.message); return; }
  const skills = data.skills || [];
  const attrs = data.attributes || {};
  const skillFields = skills.map((skill, index) => `<div class="skill-edit-card"><strong>${esc(skill.cnName || skill.name)}</strong><div class="skill-edit-fields"><label>等级<input name="skill_${index}_level" value="${skill.level}" data-original="${skill.level}" type="number" min="0" max="3" step="1"></label><label>经验<input name="skill_${index}_experience" value="${skill.experience}" data-original="${skill.experience}" type="number" min="0" max="10000000" step="any"></label></div></div>`).join('');
  const attrFields = ['strength','constitution','dexterity','intelligence'].map((key) => `<label>${{strength:'力量',constitution:'体质',dexterity:'敏捷',intelligence:'智力'}[key]}<input name="${key}" value="${attrs[key]}" data-original="${attrs[key]}" type="number" min="0" max="${key === 'strength' ? 8 : 5}" step="any" required></label>`).join('');
  openModal({ title: '修改玩家属性', description: '修改前玩家角色必须离线，仅提交手动修改的字段。', submitText: '保存修改', body: `<label class="full">SteamID<input name="steamId" value="${esc(steamId)}" readonly required pattern="[0-9]{17}"></label><div class="inline-form">${attrFields}</div><section class="modal-section full"><h4>技能等级与经验</h4>${skillFields}</section>`, onSubmit: async (form) => { const v=Object.fromEntries(new FormData(form)); const attributes=Object.fromEntries(['strength','constitution','dexterity','intelligence'].filter(k=>v[k] !== form.elements[k].dataset.original).map(k=>[k,Number(v[k])])); const changedSkills=skills.map((skill,index)=>({ name:skill.name, level:Number(v[`skill_${index}_level`]), experience:Number(v[`skill_${index}_experience`]), levelOriginal:form.elements[`skill_${index}_level`].dataset.original, experienceOriginal:form.elements[`skill_${index}_experience`].dataset.original })).filter(s=>String(s.level)!==s.levelOriginal || String(s.experience)!==s.experienceOriginal).map(({name,level,experience})=>({name,level,experience})); if (!Object.keys(attributes).length && !changedSkills.length) return; await api(`/api/admin/players/${encodeURIComponent(v.steamId)}/attributes`, { method:'POST', body:JSON.stringify({ attributes, skills: changedSkills }) }); toast('玩家属性和技能已修改'); closeModal(); } });
  $('#modalBackdrop').classList.add('centered-modal'); $('#cancelModal').hidden = true;
}
const ADMIN_PERMISSION_OPTIONS = [['overview','运行总览'],['commerce','商城管理'],['players','玩家管理'],['fulfillment','履约管理'],['operations','运维管理'],['system','系统配置']];
const adminPermissionFields = (selected = ADMIN_PERMISSION_OPTIONS.map(([key]) => key)) => ADMIN_PERMISSION_OPTIONS.map(([key,label]) => `<label class="account-admin-permission"><input type="checkbox" name="permission" value="${key}" ${selected.includes(key)?'checked':''}><span>${label}</span></label>`).join('');
async function accountLicenseManagementModal() {
  const admins = await api('/api/admin/users/authorized');
  openModal({ title:'授权管理',description:'按 SteamID 授权商城用户',submitText:'确认授权',body:`<section class="account-admin-authorize full"><label class="full">玩家 SteamID<input name="steamId" required pattern="[0-9]{17}" maxlength="17" inputmode="numeric" placeholder="请输入17位 SteamID"></label><fieldset class="account-admin-permissions"><legend>功能权限</legend>${adminPermissionFields()}</fieldset><div class="account-admin-list"><table><thead><tr><th>序号</th><th>商城账号</th><th>SteamID</th><th>授权时间</th><th>操作</th></tr></thead><tbody>${admins.length?admins.map((item,index)=>`<tr><td>${index+1}</td><td>${esc(item.username)}</td><td><code>${esc(item.steamId)}</code></td><td>${esc(date(item.authorizedAt))}</td><td><button type="button" class="btn secondary small" data-edit-admin="${item.id}" data-permissions="${esc(JSON.stringify(item.permissions))}">编辑</button> <button type="button" class="btn danger small" data-cancel-admin="${item.id}" data-steam-id="${esc(item.steamId)}">取消</button></td></tr>`).join(''):empty(5,'暂无后台管理员')}</tbody></table></div></section>`,onSubmit:async(form)=>{const steamId=form.elements.steamId.value.trim(),permissions=$$('input[name="permission"]:checked',form).map(input=>input.value);await api('/api/admin/users/authorize',{method:'POST',body:JSON.stringify({steamId,permissions})});toast('商城用户已授权为后台管理员');closeModal();await loadAccounts();}});
  $('#modalBackdrop').classList.add('centered-modal');
}
function editAdminPermissionsModal(button){const permissions=JSON.parse(button.dataset.permissions||'[]');openModal({title:'编辑管理员权限',submitText:'保存权限',body:`<fieldset class="account-admin-permissions full"><legend>功能权限</legend>${adminPermissionFields(permissions)}</fieldset>`,onSubmit:async(form)=>{const selected=$$('input[name="permission"]:checked',form).map(input=>input.value);await api('/api/admin/users/'+button.dataset.editAdmin+'/permissions',{method:'PUT',body:JSON.stringify({permissions:selected})});toast('管理员权限已更新');closeModal();}});$('#modalBackdrop').classList.add('centered-modal');}


$('#searchAccounts').addEventListener('click', loadAccounts);
$('#openAccountLicenseManagement')?.addEventListener('click', () => accountLicenseManagementModal().catch((error) => toast(error.message, true)));

$('#accountSearch').addEventListener('keydown', (event) => { if (event.key === 'Enter') loadAccounts(); });

async function handleAccountMenuClick(event) {
  const editAdmin = event.target.closest('[data-edit-admin]'); if (editAdmin) { editAdminPermissionsModal(editAdmin); return true; }
  const cancelAdmin = event.target.closest('[data-cancel-admin]'); if (cancelAdmin) { if (confirm('确认取消该后台管理员授权？')) { await api('/api/admin/users/'+cancelAdmin.dataset.cancelAdmin+'/demote',{method:'POST',body:JSON.stringify({confirmSteamId:cancelAdmin.dataset.steamId,reason:'通过后台授权管理取消权限'})}); toast('后台管理员授权已取消'); closeModal(); await loadAccounts(); } return true; }
  const copyOrder = event.target.closest('[data-copy-order]');
  if (copyOrder) {
    try { await navigator.clipboard.writeText(copyOrder.dataset.copyOrder); toast('订单号已复制'); }
    catch { toast('订单号复制失败', true); }
    return true;
  }
  const accountMenuButton = event.target.closest('[data-account-menu]');
  const accountMenu = $('#accountMenu');
  if (accountMenuButton) {
    const rect = accountMenuButton.getBoundingClientRect();
    accountMenu.dataset.steamId = accountMenuButton.dataset.accountMenu;
    accountMenu.hidden = false;
    accountMenu.style.left = `${Math.min(rect.left, window.innerWidth - accountMenu.offsetWidth - 12)}px`;
    accountMenu.style.top = `${Math.min(rect.bottom + 5, window.innerHeight - accountMenu.offsetHeight - 12)}px`;
    $$('[data-account-menu]').forEach((button) => button.setAttribute('aria-expanded', button === accountMenuButton ? 'true' : 'false'));
    return true;
  }
  const accountMenuAction = event.target.closest('[data-account-action]')?.dataset.accountAction;
  if (accountMenuAction) {
    const steamId = accountMenu.dataset.steamId;
    accountMenu.hidden = true;
    $$('[data-account-menu]').forEach((button) => button.setAttribute('aria-expanded', 'false'));
    if (accountMenuAction === 'profile') {
      await accountProfileModal(steamId);
    } else if (accountMenuAction === 'add-balance') balanceModal(steamId);
    else if (accountMenuAction === 'gifts') await accountGiftsModal(steamId);
    else if (accountMenuAction === 'orders') await accountOrdersModal(steamId);
    else if (accountMenuAction === 'add-coins') goldModal(steamId);
    else if (accountMenuAction === 'member') membershipModal(steamId);
    else if (accountMenuAction === 'pass') playerAttributesModal(steamId);
    else toast('该功能框架已预留，当前尚未接入业务');
    return true;
  }
  if (!accountMenu.hidden && !event.target.closest('#accountMenu')) {
    accountMenu.hidden = true;
    $$('[data-account-menu]').forEach((button) => button.setAttribute('aria-expanded', 'false'));
  }
}

async function handleBalanceClick(event) {
  const steamId = event.target.closest('[data-adjust]')?.dataset.adjust;
  if (steamId) balanceModal(steamId);
}

function handleBalanceCreateClick(event) {
  const action = event.target.closest('[data-action]')?.dataset.action;
  if (action === 'adjust-balance') balanceModal();
}








































