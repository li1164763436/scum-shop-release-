function setupRconPluginPanel() {
  $('#panelApiConfigForm')?.remove();
  const rconForm = $('#scumRconConfigForm');
  const policyForm = $('#rconPolicyConfigForm');
  if (!rconForm || !policyForm || $('#rconPluginPanel')) return;
  const capabilityPanel = $('#bridgeCapabilities');
  capabilityPanel?.remove();
  const discoveryMode = rconForm.elements.discoveryMode;
  const discoveryField = discoveryMode.closest('label');
  const fixedDiscoveryMode = document.createElement('input');
  fixedDiscoveryMode.type = 'hidden';
  fixedDiscoveryMode.name = 'discoveryMode';
  fixedDiscoveryMode.value = 'manual';
  discoveryField.replaceWith(fixedDiscoveryMode);
  const directoryField = rconForm.elements.scumGameDirectory.closest('label');
  const passwordField = rconForm.elements.rconPassword.closest('label');
  const hostField = rconForm.elements.rconHost.closest('label');
  const portField = rconForm.elements.rconPort.closest('label');
  if (hostField) hostField.firstChild.textContent = 'RCON 连接地址';
  if (portField) portField.firstChild.textContent = 'RCON 连接端口';
  if (passwordField && directoryField) directoryField.before(passwordField);
  directoryField.classList.remove('span-3');
  $('.field-hint', directoryField)?.remove();
  $('h3', rconForm).textContent = 'SCUM RCON 连接';
  $('#bridgeConfigDescription').textContent = '填写连接地址、连接端口、密码和游戏目录，保存后测试连接。';
  $('.config-card-index', policyForm).textContent = '04';
  $('h3', policyForm).textContent = '连接策略';
  $('.card-head p', policyForm).textContent = '控制连接超时和断线重连。';
  policyForm.elements.maxPacketSize.closest('label').hidden = true;
  const connectionStatus = document.createElement('p');
  connectionStatus.className = 'rcon-connection-status';
  connectionStatus.dataset.bridgeReason = '';
  connectionStatus.textContent = '正在读取连接状态';
  $('.form-actions', rconForm).after(connectionStatus);
  const panel = document.createElement('section');
  panel.id = 'rconPluginPanel';
  panel.className = 'card form-card rcon-config-card';
  panel.innerHTML = `<div class='card-head'><h3>RCON 插件文件</h3><button class='btn secondary' type='button' id='checkRconPlugins'>检查文件</button></div>`;
  panel.innerHTML += `<div class='plugin-toolbar'><span id='rconPluginDirectory'>未读取游戏目录</span><b id='rconPluginSummary'>等待检查</b></div>`;
  panel.innerHTML += `<div id='rconPluginFiles' class='plugin-files'><div class='empty'>请先检查插件文件</div></div>`;
  panel.innerHTML += `<div class='form-actions'><span class='save-note'>替换前自动备份原文件</span><span class='inline-fields'><button class='btn secondary' type='button' id='downloadRconPlugins'>下载文件</button><button class='btn primary' type='button' id='replaceRconPlugins'>替换文件</button></span></div>`;
  const rconLayout = document.createElement('div');
  rconLayout.className = 'rcon-main-grid';
  rconForm.before(rconLayout);
  rconLayout.append(rconForm, panel);
  $('#replaceRconPlugins').disabled = true;
  $('#checkRconPlugins').addEventListener('click', (event) => withBusy(event.currentTarget, inspectRconPlugins));
  $('#downloadRconPlugins').addEventListener('click', (event) => withBusy(event.currentTarget, () => updateRconPlugins('download')));
  $('#replaceRconPlugins').addEventListener('click', (event) => {
    if (window.confirm('确认备份并替换游戏目录中的 RCON 插件文件？')) withBusy(event.currentTarget, () => updateRconPlugins('replace'));
  });
}
function rconPluginDirectory() {
  return $('#scumRconConfigForm').elements.scumGameDirectory.value.trim();
}
function renderRconPlugins(data) {
  const current = data.files.filter((file) => file.matches).length;
  const downloaded = data.files.filter((file) => file.downloaded).length;
  $('#rconPluginDirectory').textContent = data.directory;
  $('#rconPluginSummary').textContent = `线上版本 ${data.version} · ${current}/${data.files.length} 个文件一致`;
  $('#replaceRconPlugins').disabled = downloaded !== data.files.length;
  $('#rconPluginFiles').innerHTML = data.files.map((file) => {
    const state = !file.installed ? '缺失' : file.matches ? '正常' : '需替换';
    const cache = file.downloaded ? '已下载' : '未下载';
    return `<article class='plugin-file ${file.matches ? 'ok' : 'bad'}'><strong>${esc(file.name)}</strong><span>${state}</span><small>${cache} · 本地 ${formatBytes(file.size)} / 线上 ${formatBytes(file.expectedSize)}</small><small>本地 SHA256：${esc(file.sha256 || '无')}</small><small>线上 SHA256：${esc(file.expectedSha256)}</small></article>`;
  }).join('');
}
async function inspectRconPlugins() {
  const query = new URLSearchParams({ directory: rconPluginDirectory() });
  const data = await api(`/api/rcon/plugins?${query}`);
  renderRconPlugins(data);
  return data;
}
async function updateRconPlugins(action) {
  const data = await api(`/api/rcon/plugins/${action}`, { method: 'POST', body: JSON.stringify({ directory: rconPluginDirectory() }) });
  renderRconPlugins(data);
  if (action === 'download') toast('插件文件已下载并校验');
  else if (data.sync?.status === 'completed') toast('插件文件已备份、替换并校验');
  else toast(data.sync?.message || '插件同步任务保持待处理状态');
}
setupRconPluginPanel();

async function loadVersionUpdate() {
  const data = await api('/api/admin/version-update/status');
  const card = $('#versionUpdateStatusCard');
  card.dataset.status = data.status || 'idle';
  state.versionUpdateStatus = data.status || 'idle';
  const progress = Math.max(0, Math.min(100, Number(data.progress || 0)));
  const downloading = data.status === 'downloading';
  const statusMessage = String(data.message || '');
  let message = data.message || '检查完成';
  let badge = '已检查';
  let mode = 'checked';
  let bar = 100;
  if (downloading) { const reusing = statusMessage.startsWith('已复用'); message = reusing ? '正在复用已存在的更新文件' : '正在下载更新文件'; badge = reusing ? '复用中' : '下载中'; mode = 'downloading'; bar = progress; }
  else if (data.status === 'preparing') { message = '正在准备下载文件'; badge = '准备中'; mode = 'downloading'; bar = progress; }
  else if (!data.status || data.status === 'idle') { const changed = Number(state.versionUpdateManifest?.changedFileCount || 0); message = changed > 0 ? `检查完成，有 ${changed} 个文件更新` : '检查完成，当前已是最新版本'; }
  else if (data.status === 'ready') { message = '下载完成，等待安装替换'; badge = '可安装'; mode = 'ready'; bar = 100; }
  else if (['applying', 'staging', 'stopping', 'backing_up', 'installing', 'starting', 'rollback'].includes(data.status)) { message = data.message || '正在安装更新'; badge = '安装中'; mode = 'installing'; bar = progress; }
  else if (data.status === 'completed') { message = '更新完成'; badge = '已完成'; mode = 'checked'; bar = 100; }
  else if (data.status === 'failed') { message = data.message || '更新失败'; badge = '失败'; mode = 'failed'; bar = 100; }
  card.className = `version-update-current-status ${mode}`;
  card.dataset.status = data.status || 'idle';
  $('#versionUpdateStatus').textContent = badge;
  $('#versionUpdateMessage').textContent = message;
  $('#versionUpdateStatusBar').style.width = `${bar}%`;
  $('#versionUpdateCurrentFile').textContent = `下载进度：${progress}%`;
  $('#versionUpdateStatusDetail').hidden = !downloading;
  $('#versionUpdateTime').textContent = date(data.updatedAt);
  $('#installVersionUpdate').disabled = data.status !== 'ready';
  $('#downloadVersionUpdate').disabled = !state.versionUpdateManifest?.updateAvailable || ['preparing', 'downloading', 'ready', 'applying', 'staging', 'stopping', 'backing_up', 'installing', 'starting', 'rollback'].includes(data.status);
  renderVersionUpdateFiles();
  return data;
}
function renderVersionUpdateFiles() {
  const files = [...(state.versionUpdateManifest?.files || [])].sort((left, right) => Number(left.matches) - Number(right.matches) || String(left.path).localeCompare(String(right.path), 'zh-CN'));
  const pageSize = 5;
  const pageCount = Math.max(1, Math.ceil(files.length / pageSize));
  state.versionUpdateFilePage = Math.max(1, Math.min(pageCount, Number(state.versionUpdateFilePage || 1)));
  const start = (state.versionUpdateFilePage - 1) * pageSize;
  const page = files.slice(start, start + pageSize);
  $('#versionUpdateFileList').innerHTML = page.length ? page.map(file => {
    const name = file.path.split('/').pop();
    const currentSize = formatBytes(file.localSize);
    const targetSize = formatBytes(file.size);
    const downloaded = !file.matches && ['ready', 'applying', 'staging', 'stopping', 'backing_up', 'installing', 'starting'].includes(state.versionUpdateStatus);
    const installState = file.matches ? { className: 'installed', label: '已安装' } : downloaded ? { className: 'downloaded', label: '已下载' } : { className: 'pending', label: '需更新' };
    return `<article class="version-update-file"><span class="version-update-install-state ${installState.className}">${installState.label}</span><div class="version-update-file-name"><strong title="${esc(file.path)}">${esc(name)}</strong></div><span class="version-update-file-size" title="${esc(currentSize)}">${currentSize}</span><span class="version-update-file-size version-update-file-target-size" title="${esc(targetSize)}">${targetSize}</span><code title="${esc(file.sha256)}">${esc(file.sha256)}</code></article>`;
  }).join('') : '<div class="empty">没有更新文件</div>';
  $('#versionUpdatePageInfo').textContent = `第 ${state.versionUpdateFilePage} / ${pageCount} 页 · 共 ${files.length} 个文件`;
  $('#versionUpdatePrevPage').disabled = state.versionUpdateFilePage <= 1;
  $('#versionUpdateNextPage').disabled = state.versionUpdateFilePage >= pageCount;
}
async function loadVersionUpdateManifest() {
  const data = await api('/api/admin/version-update/manifest');
  state.versionUpdateManifest = data;
  state.versionUpdateFilePage = 1;
  const releaseLabel = (version, revision) => `${version || '--'}${Number(revision) > 0 ? ` (r${revision})` : ''}`;
  $('#versionUpdateCurrentVersion').textContent = releaseLabel(data.currentVersion, data.currentReleaseRevision);
  $('#versionUpdateRemoteVersion').textContent = releaseLabel(data.latestVersion, data.latestReleaseRevision);
  $('#versionUpdateFileCount').textContent = `${data.changedFileCount || 0} / ${data.fileCount || 0}`;
  $('#versionUpdateCurrentChecksum').textContent = data.currentChecksum || '--';
  $('#versionUpdateRemoteChecksum').textContent = data.remoteChecksum || '--';
  $('#versionUpdateChangedCount').textContent = `${data.changedFileCount || 0} 个文件需要更新`;
  renderVersionUpdateFiles();
  if (['idle', 'completed', 'failed', undefined].includes($('#versionUpdateStatusCard')?.dataset.status)) {
    const changed = Number(data.changedFileCount || 0);
    $('#versionUpdateStatusCard').className = 'version-update-current-status checked';
    $('#versionUpdateStatus').textContent = '已检查';
    $('#versionUpdateMessage').textContent = changed > 0 ? `检查完成，有 ${changed} 个文件更新` : '检查完成，当前已是最新版本';
    $('#versionUpdateStatusBar').style.width = '100%';
    $('#versionUpdateStatusDetail').hidden = true;
  }
  $('#downloadVersionUpdate').disabled = !data.updateAvailable || ['preparing', 'downloading', 'ready', 'applying', 'staging', 'stopping', 'backing_up', 'installing', 'starting', 'rollback'].includes($('#versionUpdateStatusCard')?.dataset.status);
  return data;
}
async function openVersionUpdateConfig() {
  const modal = $('#versionUpdateConfigModal');
  modal.classList.add('open');
  modal.setAttribute('aria-hidden', 'false');
  await withBusy($('#reloadVersionUpdate'), () => Promise.all([loadVersionUpdateManifest(), loadVersionUpdate()]));
}
function closeVersionUpdateConfig() {
  $('#versionUpdateConfigModal').classList.remove('open');
  $('#versionUpdateConfigModal').setAttribute('aria-hidden', 'true');
}
async function pollVersionUpdateCard() {
  try {
    const data = await loadVersionUpdate();
    if (data.status === 'completed') { await loadVersionUpdateManifest().catch(() => {}); return; }
    if (['ready', 'failed'].includes(data.status)) return;
  } catch {
    const installing = ['applying', 'staging', 'stopping', 'backing_up', 'installing', 'starting', 'rollback'].includes($('#versionUpdateStatusCard')?.dataset.status);
    $('#versionUpdateMessage').textContent = installing ? '商城服务正在重启，等待恢复连接' : '下载状态读取失败，正在重试';
  }
  state.versionUpdateTimer = setTimeout(pollVersionUpdateCard, 1000);
}
async function downloadVersionUpdate(button) {
  await withBusy(button, async () => {
    const manifest = state.versionUpdateManifest || await loadVersionUpdateManifest();
    if (!manifest.updateAvailable) {
      window.alert(`当前版本 ${manifest.currentVersion} 已是最新版本。`);
      return;
    }
    try {
      await api('/api/admin/version-update/download', { method: 'POST' });
      clearTimeout(state.versionUpdateTimer);
      await loadVersionUpdate();
      state.versionUpdateTimer = setTimeout(pollVersionUpdateCard, 300);
    } catch (error) {
      $('#versionUpdateMessage').textContent = error.message;
      throw error;
    }
  });
}
async function installVersionUpdate(button) {
  if (!window.confirm('安装更新将关闭启动器和商城服务，安装完成后自动重新打开启动器并启动商城。是否继续？')) return;
  await withBusy(button, async () => {
    try {
      await api('/api/admin/version-update/install', { method: 'POST' });
      clearTimeout(state.versionUpdateTimer);
      await loadVersionUpdate();
      state.versionUpdateTimer = setTimeout(pollVersionUpdateCard, 300);
    } catch (error) {
      $('#versionUpdateMessage').textContent = error.message;
      $('#versionUpdateStatusCard').className = 'version-update-current-status failed';
      $('#versionUpdateStatus').textContent = '失败';
      $('#versionUpdateStatusBar').style.width = '100%';
      throw error;
    }
  });
}

async function loadLicenseAccount() {
  let data;
  try { data = await api('/api/license/status'); }
  catch (error) {
    if (error.status !== 404) throw error;
    const dashboard = await api('/api/dashboard');
    data = dashboard?.license ? { activated: true, ...dashboard.license } : { activated: false };
  }
  const activated = data.activated === true;
  const expiresAt = activated && data.expiresAt ? new Date(data.expiresAt) : null;
  const expired = Boolean(expiresAt && expiresAt.getTime() <= Date.now());
  const statePanel = $('#licenseAccountState');
  statePanel.className = `license-account-state ${!activated ? 'inactive' : expired ? 'expired' : 'active'}`;
  $('.license-account-badge', statePanel).className = `license-account-badge ${!activated ? 'inactive' : expired ? 'expired' : 'active'}`;
  $('.license-account-badge', statePanel).textContent = !activated ? '未授权' : expired ? '已过期' : '授权有效';
  $('strong', statePanel).textContent = !activated ? '商城程序尚未激活授权' : data.username || '--';
  $('small', statePanel).textContent = !activated ? '请通过启动授权页面完成账号连接' : expired ? '授权已超过有效期' : '授权验证正常';
  $('#licenseAccountUsername').textContent = activated ? data.username || '--' : '--';
  $('#licenseAccountStatus').textContent = !activated ? '未授权' : expired ? '已过期' : '有效';
  $('#licenseAccountExpiresAt').textContent = activated ? date(data.expiresAt) : '--';
  $('#licenseAccountVerifiedAt').textContent = activated ? date(data.lastVerifiedAt) : '--';
  $('#licenseAccountCenter').textContent = activated ? data.baseUrl || '--' : 'https://sq.scum0.cn';
  return data;
}

async function loadConfig() {
  try {
    state.config = await api('/api/config') || {};
    if (!state.products.length) {
      try { state.products = list(await api('/api/products'), ['products', 'items']); } catch { /* SKU 仍可手工安全输入。 */ }
    }
    fillConfigForms();
    await Promise.all([loadInstanceOptions(), loadBridgeStatus(), loadLicenseAccount()]);
    await loadHealth();
  } catch (error) { toast(error.message, true); }
}
function fillConfigForms() {
  const config = state.config;
  const basic = $('#basicConfigForm').elements;
  const mysql = config.mysql || {};
  const fulfillment = config.fulfillment || {};
  const backgroundForm = $('#websiteBackgroundForm');
  if (backgroundForm) {
    backgroundForm.elements.websiteBackgroundImage.value = config.website?.backgroundImage || '';
    backgroundForm.elements.websiteBackgroundFile.value = '';
  }
  basic.mysqlHost.value = mysql.host || '';
  basic.mysqlPort.value = mysql.port || 3306;
  basic.mysqlUser.value = mysql.user || '';
  basic.mysqlDatabase.value = mysql.database || '';
  basic.fulfillmentInstance.value = fulfillment.instanceId || '';
  basic.workerEnabled.checked = Boolean(fulfillment.workerEnabled);
  basic.workerPollMs.value = fulfillment.pollIntervalMs || 5000;
  basic.workerCommandIntervalMs.value = fulfillment.commandIntervalMs || 0;
  basic.workerMaxAttempts.value = fulfillment.maxAttempts || 5;
  const monitoring = config.monitoring || {};
  basic.monitoringEnabled.checked = monitoring.enabled !== false;
  basic.monitoringPollSeconds.value = Math.round((monitoring.pollIntervalMs || 10000) / 1000);
  basic.monitoringRetentionDays.value = monitoring.retentionDays || 7;
  $('#sitePortValue').value = location.port || (location.protocol === 'https:' ? '443' : '80');
  $('#mysqlPasswordState').textContent = mysql.hasPassword ? '（已配置）' : '（未配置）';
  $('#sharedSecretState').textContent = fulfillment.hasSharedSecret ? '（已配置）' : '（未配置）';

  const ggcon = config.ggcon || {};
  const rcon = $('#scumRconConfigForm').elements;
  rcon.discoveryMode.value = 'manual';
  rcon.rconHost.value = !ggcon.host || ggcon.host === '0.0.0.0' || ggcon.host === '::' ? '127.0.0.1' : ggcon.host;
  rcon.rconPort.value = ggcon.port || 0;
  rcon.scumGameDirectory.value = ggcon.gameDirectory || '';
  rcon.rconPassword.value = rcon.rconPassword.dataset.savedValue || '';
  const policy = $('#rconPolicyConfigForm').elements;
  policy.connectTimeoutMs.value = ggcon.connectTimeoutMs || 5000;
  policy.authTimeoutMs.value = ggcon.authTimeoutMs || 5000;
  policy.commandTimeoutMs.value = ggcon.commandTimeoutMs || 5000;
  policy.maxPacketSize.value = ggcon.maxPacketSize || 1048576;
  policy.reconnectEnabled.checked = config.reconnect?.enabled !== false;
  policy.maxAttempts.value = config.reconnect?.maxAttempts || 4;
  policy.baseDelayMs.value = config.reconnect?.baseDelayMs ?? 500;
  policy.maxDelayMs.value = config.reconnect?.maxDelayMs ?? 5000;
  $('#rconPasswordState').textContent = ggcon.hasPassword ? '（已自动读取）' : '（未配置）';
  $('#scumGameDirectoryState').textContent = ggcon.hasServerDirectory ? '（已配置）' : '（未配置）';
  const pipeMode = ggcon.mode === 'scum-shop-pipe';
  $$('#tcpRconFields input:not([name="scumGameDirectory"]), #tcpRconFields select, #rconPolicyConfigForm input[name="connectTimeoutMs"], #rconPolicyConfigForm input[name="authTimeoutMs"], #rconPolicyConfigForm input[name="commandTimeoutMs"], #rconPolicyConfigForm input[name="maxPacketSize"]').forEach((node) => { node.disabled = pipeMode; });
  $('#bridgeConfigDescription').textContent = pipeMode ? `当前为 SCUM 商城管道模式（端点 ${ggcon.endpointFile || 'runtime/bridge/endpoint.json'}），此页不会切换或覆盖模式。` : '当前为 Source TCP 模式，可配置本机 RCON 连接。';

}
async function loadInstanceOptions() {
  try {
    const data = await api('/api/gsm3/instances');
    state.instances = list(data, ['instances', 'items']);
    const select = $('#basicConfigForm').elements.fulfillmentInstance;
    const selected = select.value || state.config.fulfillment?.instanceId || '';
    select.innerHTML = '<option value="">手动 RCON 无需选择</option>' + state.instances.map((item) => `<option value="${esc(pick(item, ['id', 'instanceId']))}">${esc(pick(item, ['name'], '未命名实例'))}</option>`).join('');
    select.value = selected;
  } catch { /* 基础配置仍可在 GSM3 不可用时编辑。 */ }
}
async function saveConfig(partial) {
  const current = await api('/api/config');
  const payload = { ...current, ...state.config, ...partial };
  for (const key of Object.keys(partial)) {
    if (partial[key] && typeof partial[key] === 'object' && !Array.isArray(partial[key])) {
      payload[key] = { ...(current[key] || {}), ...(state.config[key] || {}), ...partial[key] };
    }
  }
  const saved = await api('/api/config', { method: 'PUT', body: JSON.stringify(payload) });
  state.config = saved || state.config;
  return Boolean(saved?.restartRequired);
}

async function testConnection(target, button) {
  await withBusy(button, async () => {
    const data = await api('/api/connections/test', { method: 'POST', body: JSON.stringify({ target }) });
    const result = data?.[target] || data;
    toast(result?.message || `${target === 'gsm3' ? 'GSM3' : 'SCUM 商城桥接'} 连接正常`, result?.ok === false && !result?.degraded);
    await Promise.all([loadBridgeStatus(), loadHealth()]);
  });
}

$('#basicConfigForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  await withBusy(event.submitter, async () => {
    const f = event.currentTarget.elements;
    const restartRequired = await saveConfig({
      website: { backgroundImage: state.config.website?.backgroundImage || '' },
      mysql: { host: f.mysqlHost.value.trim(), port: Number(f.mysqlPort.value), user: f.mysqlUser.value.trim(), database: f.mysqlDatabase.value.trim(), password: f.mysqlPassword.value },
      fulfillment: { instanceId: f.fulfillmentInstance.value, sharedSecret: f.sharedSecret.value, workerEnabled: f.workerEnabled.checked, pollIntervalMs: Number(f.workerPollMs.value), commandIntervalMs: Number(f.workerCommandIntervalMs.value), maxAttempts: Number(f.workerMaxAttempts.value) },
      monitoring: { enabled: f.monitoringEnabled.checked, pollIntervalMs: Number(f.monitoringPollSeconds.value) * 1000, retentionDays: Number(f.monitoringRetentionDays.value) },
    });
    f.mysqlPassword.value = ''; f.sharedSecret.value = ''; toast(restartRequired ? '数据库配置重启后生效' : '基础配置已保存'); await loadConfig();
  });
});

$('#generateRconPassword').addEventListener('click', () => {
  const f = $('#scumRconConfigForm').elements;
  f.rconPassword.value = generateRconPassword();
  delete f.rconPassword.dataset.savedValue;
  $('#rconPasswordState').textContent = '（待保存）';
});

$('#scumRconConfigForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  await withBusy(event.submitter, async () => {
    const f = event.currentTarget.elements;
    const rconPassword = f.rconPassword.value.trim();
    await saveConfig({ ggcon: { mode: 'source-tcp', discoveryMode: 'manual', serverDirectory: f.scumGameDirectory.value.trim(), host: f.rconHost.value.trim(), port: 28015, ...(rconPassword ? { password: rconPassword, syncPassword: true } : {}) } });
    if (rconPassword) f.rconPassword.dataset.savedValue = rconPassword;
    toast(rconPassword ? 'RCON 密钥已同步，请重启 SCUM 游戏服务端后再测试连接' : 'RCON 连接配置已保存');
    await loadConfig();
  });
});

$('#rconPolicyConfigForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  await withBusy(event.submitter, async () => {
    const f = event.currentTarget.elements;
    await saveConfig({
      ggcon: { connectTimeoutMs: Number(f.connectTimeoutMs.value), authTimeoutMs: Number(f.authTimeoutMs.value), commandTimeoutMs: Number(f.commandTimeoutMs.value), maxPacketSize: Number(f.maxPacketSize.value) },
      reconnect: { enabled: f.reconnectEnabled.checked, maxAttempts: Number(f.maxAttempts.value), baseDelayMs: Number(f.baseDelayMs.value), maxDelayMs: Number(f.maxDelayMs.value) }
    });
    toast('连接与超时配置已保存');
    await loadConfig();
  });
});




$('#downloadVersionUpdate')?.addEventListener('click', (event) => downloadVersionUpdate(event.currentTarget));
$('#installVersionUpdate')?.addEventListener('click', (event) => installVersionUpdate(event.currentTarget));
$('#versionUpdatePrevPage')?.addEventListener('click', () => { state.versionUpdateFilePage -= 1; renderVersionUpdateFiles(); });
$('#versionUpdateNextPage')?.addEventListener('click', () => { state.versionUpdateFilePage += 1; renderVersionUpdateFiles(); });
$('#closeVersionUpdateConfig')?.addEventListener('click', closeVersionUpdateConfig);


$('#reloadLicenseAccount')?.addEventListener('click', (event) => withBusy(event.currentTarget, loadLicenseAccount));

document.addEventListener('click', (event) => {
  const button = event.target.closest('[data-config-tab]');
  if (!button) return;
  const page = button.closest('#page-config');
  if (!page) return;
  $$('.tab', page).forEach((item) => item.classList.toggle('active', item === button));
  $$('.tab-panel', page).forEach((panel) => panel.classList.toggle('active', panel.id === `config-${button.dataset.configTab}`));
});
$$('[data-test]').forEach((button) => button.addEventListener('click', () => testConnection(button.dataset.test, button)));

$('#reloadVersionUpdate')?.addEventListener('click', (event) => withBusy(event.currentTarget, () => Promise.all([loadVersionUpdateManifest(), loadVersionUpdate()])));



