const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const state = {
  user: null,
  products: [],
  productFilters: { parent: '', category: '', search: '', page: 0 },
  account: null,
  orders: [],
  gifts: [],
  rewards: null,
  exchangeConfig: null,
  cloudWarehouse: null,
  cloudMarket: [],
  vehicleInsurance: { strategies: [], vehicles: [] },
  orderDetails: new Map(),
  purchase: null,
  activityPanel: 'lottery',
  quotes: [],
  portfolio: null,
  stockTrades: [],
  marketOverview: null,
  selectedStockId: null,
  stockReceipt: null,
  stockTradeFilter: 'all',
  stockQuoteFilter: 'all',
  stockHoldingSort: 'marketValue',
  stockCarousels: {
    quotes: { page: 0 },
    gainers: { page: 0 },
    losers: { page: 0 }
  },
  marketTimer: null,
  marketCountdownTimer: null,
  marketNextRefreshAt: 0,
  marketLoading: false,
  stockCandlePeriod: '5m',
  stockCandles: null,
  stockChartViews: {
    main: { visibleCount: 60, offset: 0, dragging: false, pointerId: null, startX: 0, startOffset: 0 },
    modal: { visibleCount: 60, offset: 0, dragging: false, pointerId: null, startX: 0, startOffset: 0 }
  },
  stockCandleLoading: false,
  stockCandleRequest: 0,
  stockCandleController: null,
  stockTradeDraft: null,
  challengeUntil: 0,
  challengeTimer: null,
  selectedLotteryPoolKey: null,
  profileSkills: [],
  selectedAttribute: 'strength',
  selectedPurchaseAttribute: 'strength',
  profileAttributes: {},
  purchaseAttributeQuantities: { strength: 0, constitution: 0, dexterity: 0, intelligence: 0 },
  attributePurchaseDraft: null,
  skillPurchaseDraft: null,
  selectedPurchaseSkills: new Set(),
  characterGrowthConfig: { attributePointPrice: 0, skillLevelPrice: 0 },
  lotteryPoolRequest: 0,
  lotteryRequest: 0,
  lotterySpinning: false,
  lotteryModes: {},
  lotteryPoolData: {},
  cloudInventorySelection: new Set(),
  pagination: {
    ledger: 0,
    orders: 0,
    rewards: 0,
    lottery: 0,
    holdings: 0,
    trades: 0
  }
};

const customerErrorByCode = {
  ACCOUNT_DISABLED: '该账户已停用，请联系管理员处理',
  ALREADY_REGISTERED: '该用户名或 Steam 账号已被注册',
  BUSINESS_UNAVAILABLE: '商城服务正在维护，请稍后再试',
  INSUFFICIENT_BALANCE: '商城币余额不足，请核对余额后再试',
  INVALID_CREDENTIALS: '用户名或密码错误，请重新输入',
  INVALID_GIFT_CODE: '兑换码无效或已失效，请核对后重试',
  INVALID_INPUT: '填写的信息有误，请检查后重试',
  INVALID_ORIGIN: '页面来源校验失败，请刷新页面后重试',
  NOT_FOUND: '没有找到相关内容，请刷新页面后重试',
  NOT_READY: '商城服务正在准备中，请稍后再试',
  PAYLOAD_TOO_LARGE: '提交的内容过大，请精简后重试',
  PLAYER_OFFLINE: '当前游戏角色不在线，请上线后重试',
  RATE_LIMITED: '操作过于频繁，请稍后再试',
  TELEPORT_FAILED: '传送失败，费用将按处理结果退回',
  TELEPORT_QUOTE_EXPIRED: '传送费用已失效，请重新计算',
  TELEPORT_QUOTE_REQUIRED: '请先重新计算传送距离和费用',
  COMMAND_RESULT_UNKNOWN: '操作结果暂时无法确认，已转人工核查',
  UNCERTAIN_DELIVERY: '操作结果暂时无法确认，已转人工核查'
};

function customerFallback(status, fallback) {
  if (status === 400 || status === 422) return '填写的信息有误，请检查后重试';
  if (status === 401) return '登录状态已失效，请重新登录';
  if (status === 403) return '当前账户不能执行此操作';
  if (status === 404) return '没有找到相关内容，请刷新页面后重试';
  if (status === 409) return '当前状态已发生变化，请刷新后重试';
  if (status === 423) return '该操作暂时不可用，请稍后重试';
  if (status === 413) return '提交的内容过大，请精简后重试';
  if (status === 429) return '操作过于频繁，请稍后再试';
  if (status === 0 || status >= 500) return '商城服务暂时不可用，请稍后重试';
  return fallback;
}

function chineseErrorMessage(value, fallback = '操作失败，请稍后重试', details = {}) {
  const message = String(value || '').trim();
  const safeFallback = customerErrorByCode[details.code] || customerFallback(Number(details.status), fallback);
  if (!message) return safeFallback;
  if (/timeout|timed out/i.test(message)) return '请求超时，请稍后重试';
  if (/unauthorized|forbidden|access denied/i.test(message)) return '当前账户不能执行此操作';
  if (/network|connection|socket|fetch failed/i.test(message)) return '网络连接失败，请稍后重试';
  const internalDetail = /(?:命令|数据库|堆栈|字段|接口|后端|服务端|部署|重启|duplicate\s+entry|(?:primary|foreign)\s+key|for\s+key\s+['"`\w]|\b(?:rcon|sql|mysql|http|api|json|error|exception|traceback|stack|errno|econn\w*|etimedout|spawn|command|column|table|constraint|node_modules|idempotency[-_ ]?key|request_?id|payload_?json|steam_id|inventory_id|undefined|null)\b|https?:\/\/|#[a-z]\w*|\b(?:select|insert|update|delete|create|alter|drop)\b|(?:[a-z]:\\|\\\\|\/[^\s]+\/[^\s]+\.(?:js|ts|py):\d+))/i;
  const gameCommand = /\b(?:Give|Set|Spawn|Teleport|Change|Destroy|Remove|Add)[A-Z][A-Za-z0-9_]*\b/;
  const unexpectedEnglish = /[a-z]{3,}/i.test(message.replace(/\b(?:SCUM|SteamID)\b/gi, ''));
  if (internalDetail.test(message) || gameCommand.test(message) || unexpectedEnglish || /[\r\n\u0000-\u001f]/u.test(message) || message.length > 160) return safeFallback;
  if (/[\u3400-\u9fff]/u.test(message)) return message;
  if (/not found|does not exist/i.test(message)) return '没有找到相关内容，请刷新页面后重试';
  return safeFallback;
}

const statusLabels = {
  pending: '待处理', processing: '发货中', completed: '已完成', failed: '失败',
  manual_review: '人工核查', cancelled: '已取消', waiting_instance: '等待服务器',
  waiting_offline: '等待下线', retry: '等待重试', success: '成功'
};

const ledgerLabels = {
  recharge: '余额充值', adjustment: '余额调整', purchase: '订单消费', refund: '订单退款',
  order: '订单消费', order_purchase: '订单消费', gift_purchase: '礼包购买', gift_reward: '礼包奖励', admin_adjustment: '管理员调整',
  lottery_win: '抽奖中奖', lottery_purchase: '抽奖消费', lottery_reward: '抽奖奖励', checkin_reward: '签到奖励', online_reward: '在线奖励',
  exchange: '余额兑换', account_exchange: '余额兑换', stock_buy: '股票买入', stock_sell: '股票卖出',
  cloud_market_buy: '云储市场购买', cloud_market_sell: '云储市场出售', cloud_pass_buy: '云储证购买',
  cloud_withdraw_fee: '云储取出手续费', cloud_withdraw_refund: '云储取出退款',
  character_growth_purchase: '属性技能购买', character_growth_refund: '属性技能退款', vehicle_insurance_purchase: '载具保险购买'
};
const giftTypeLabels = { normal: '普通礼包', private: '私人礼包', title: '称号礼包', squad: '小队礼包', monthly: '月度礼包', weekly: '周度礼包', quarterly: '季度礼包' };
const rewardTypeLabels = { daily_checkin: '每日签到', checkin_streak: '连续签到', checkin_total: '累计签到', online_total: '可信累计在线' };
const REGISTRATION_PASSWORD_ERROR = '密码须为 8-28 位，并包含大写字母、小写字母和数字';

function validRegistrationPassword(value) {
  return value.length >= 8 && value.length <= 28 && /[A-Z]/.test(value) && /[a-z]/.test(value) && /\d/.test(value);
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[char]);
}

function pick(obj, keys, fallback = '') {
  for (const key of keys) if (obj?.[key] !== undefined && obj?.[key] !== null) return obj[key];
  return fallback;
}

function asList(data, keys = []) {
  if (Array.isArray(data)) return data;
  for (const key of keys) if (Array.isArray(data?.[key])) return data[key];
  return [];
}

function number(value) {
  return new Intl.NumberFormat('zh-CN').format(Number(value) || 0);
}

function dateTime(value) {
  if (!value) return '—';
  const text = String(value);
  const date = /^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}/.test(text) && !/[zZ]|[+-]\d{2}:?\d{2}$/.test(text)
    ? new Date(`${text.replace(' ', 'T')}+08:00`)
    : new Date(value);
  return Number.isNaN(date.getTime()) ? text : new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }).format(date);
}

const PAGE_SIZE = 10;

function pageItems(items, name) {
  const totalPages = Math.max(1, Math.ceil(items.length / PAGE_SIZE));
  state.pagination[name] = Math.max(0, Math.min(state.pagination[name] || 0, totalPages - 1));
  const start = state.pagination[name] * PAGE_SIZE;
  return { items: items.slice(start, start + PAGE_SIZE), page: state.pagination[name], totalPages };
}

function paginationMarkup(name, totalPages, page) {
  if (totalPages <= 1) return '';
  return `<nav class="record-pagination" aria-label="记录分页"><button type="button" data-page-list="${name}" data-page-step="-1" ${page === 0 ? 'disabled' : ''}>上一页</button><span>第 ${page + 1} / ${totalPages} 页</span><button type="button" data-page-list="${name}" data-page-step="1" ${page >= totalPages - 1 ? 'disabled' : ''}>下一页</button></nav>`;
}

async function api(url, options = {}) {
  let response;
  try {
    response = await fetch(url, {
      ...options,
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json', ...(options.headers || {}) }
    });
  } catch (cause) {
    window.dispatchEvent(new CustomEvent('storefront:service-unavailable', { detail: { url, status: 0 } }));
    const error = new Error('商城服务暂时无法连接，请稍后重试');
    error.status = 0;
    error.cause = cause;
    throw error;
  }
  let body = null;
  try { body = await response.json(); } catch { body = null; }
  const serviceUnavailable = [502, 504].includes(response.status) || (response.status === 503 && (!body || body?.code === 'BUSINESS_UNAVAILABLE'));
  if (serviceUnavailable) window.dispatchEvent(new CustomEvent('storefront:service-unavailable', { detail: { url, status: response.status } }));
  const message = serviceUnavailable
    ? '商城服务暂时不可用，请稍后重试'
    : chineseErrorMessage(body?.message, '操作失败，请稍后重试', { code: body?.code, status: response.status });
  if (response.status === 401) {
    setUser(null);
    const error = new Error(message || '请先登录');
    error.status = 401;
    error.code = body?.code;
    throw error;
  }
  if (!response.ok || body?.success === false) {
    const error = new Error(message);
    error.status = response.status;
    error.code = body?.code;
    throw error;
  }
  return body && Object.prototype.hasOwnProperty.call(body, 'data') ? body.data : body;
}

function toast(message, type = 'success', title = type === 'error' ? '操作失败' : '操作完成') {
  const item = document.createElement('div');
  item.className = `toast ${type}`;
  const strong = document.createElement('strong');
  const span = document.createElement('span');
  strong.textContent = title;
  span.textContent = type === 'error' ? chineseErrorMessage(message) : message;
  item.append(strong, span);
  $('#toastRegion').append(item);
  window.setTimeout(() => item.remove(), 3800);
}
function purchaseResult(message, type = 'success') {
  const backdrop = document.createElement('div');
  backdrop.className = 'purchase-result-backdrop';
  backdrop.innerHTML = `<div class="purchase-result ${type}"><strong>${type === 'error' ? '购买失败' : '购买成功'}</strong><span>${escapeHtml(message)}</span><button class="button ghost" type="button">确定</button></div>`;
  backdrop.addEventListener('click', (event) => { if (event.target === backdrop || event.target.closest('button')) backdrop.remove(); });
  document.body.append(backdrop);
}

async function withBusy(button, action) {
  if (!button || button.disabled) return;
  button.disabled = true;
  button.classList.add('busy');
  try { return await action(); }
  finally { button.disabled = false; button.classList.remove('busy'); }
}

function emptyState(title, subtitle) {
  return `<div class="empty-row"><strong>${escapeHtml(title)}</strong><small>${escapeHtml(subtitle)}</small></div>`;
}

function setAccountMenu(open) {
  const menu = $('#accountMenu');
  menu.hidden = !open;
  $('#accountMenuButton').setAttribute('aria-expanded', String(open));
}

function setUser(user) {
  const wasAuthenticated = Boolean(state.user);
  state.user = user || null;
  syncActivityGuestView();
  if (!state.user) setAccountMenu(false);
  const authenticated = Boolean(state.user);
  $$('.auth-only').forEach((element) => { element.hidden = !authenticated; });
  $$('.guest-only').forEach((element) => { element.hidden = authenticated; });
  $('#adminPortalLink').hidden = !['admin', 'super_admin'].includes(state.user?.role);
  $('#chipRole').hidden = state.user?.role !== 'super_admin';
  if (authenticated) {
    const username = pick(user, ['username', 'name'], '幸存者');
    const steamId = pick(user, ['steamId', 'steamID', 'steam_id'], '—');
    const balance = pick(user, ['balance', 'coinBalance', 'coins'], 0);
    $('#chipUsername').textContent = username;
    $('#headerCoinBalance').textContent = number(balance);
    $('#accountUsername').textContent = username;
    $('#accountSteamId').textContent = steamId;
    $('#characterPurchaseSteamId').textContent = /^\d{17}$/.test(String(steamId)) ? steamId : '等待同步';
    $('#accountBalance').textContent = number(balance);
    $('#characterPurchaseBalance').textContent = number(balance);
    updateCharacterPurchaseAvailability();
    $$('[data-exchange-form]').forEach((form) => {
      if (form.elements.direction.value === 'coin_to_gold') {
        $('[data-exchange-balance]', form).textContent = number(balance);
      }
    });
  } else {
    stopMarketAutoRefresh();
    state.gifts = [];
    state.rewards = null;
    renderGifts();
    resetRewards();
    $('#redeemCodeForm')?.reset();
    $('#characterPurchaseSteamId').textContent = '等待同步';
    $('#characterPurchaseBalance').textContent = '0';
    updateCharacterPurchaseAvailability();
    $$('[data-exchange-form]').forEach((form) => form.reset());
    $$('[data-exchange-form]').forEach((form) => {
      $('[data-exchange-balance]', form).textContent = form.elements.direction.value === 'coin_to_gold' ? '0' : '—';
    });
    if (['#account', '#orders'].includes(location.hash)) showRoute('store', false);
  }
  if (authenticated && !wasAuthenticated && $('#page-activity').classList.contains('active')) showActivityPanel(state.activityPanel);
}

function normalizedUser(data) {
  const source = data?.user && typeof data.user === 'object' ? { ...data, ...data.user } : data;
  return source && typeof source === 'object' ? source : null;
}

function accountUser(data) {
  const account = data?.account && typeof data.account === 'object' ? data.account : data;
  if (!account || typeof account !== 'object') return null;
  return {
    ...state.user,
    ...account,
    balance: pick(account, ['balance', 'coinBalance', 'coins'], pick(data, ['balance', 'coinBalance', 'coins'], state.user?.balance || 0))
  };
}

async function loadMe() {
  try {
    const user = normalizedUser(await api('/api/shop/auth/me'));
    setUser(user);
    if (user) {
      await Promise.all([
        (async () => {
          try {
            const account = await api('/api/shop/account');
            if (!state.user || String(pick(state.user, ['steamId', 'steamID', 'steam_id'], '')) !== String(pick(user, ['steamId', 'steamID', 'steam_id'], ''))) return;
            state.account = account || {};
            setUser(accountUser(account));
          } catch (error) { if (error.status !== 401) console.warn('账户余额读取失败:', error.message); }
        })(),
        loadGifts()
      ]);
    }
  } catch (error) { if (error.status !== 401) console.warn('身份状态读取失败:', error.message); }
}

function syncActivityGuestView() {
  const guest = !state.user;
  $$('.activity-guest-message').forEach((message) => {
    message.hidden = !guest;
    message.parentElement.classList.toggle('activity-guest', guest);
  });
}

function showActivityPanel(panel, load = true) {
  const target = ['lottery', 'market', 'gifts', 'cloud', 'insurance', 'teleport'].includes(panel) ? panel : 'lottery';
  state.activityPanel = target;
  $$('.activity-panel').forEach((element) => {
    const panelId = target === 'cloud' ? 'cloudWarehouseSection' : target === 'teleport' ? 'page-teleport' : target === 'insurance' ? 'page-insurance' : `activity-panel-${target}`;
    const active = element.id === panelId;
    element.hidden = !active;
    element.classList.toggle('active', active);
  });
  $$('.activity-tab').forEach((button) => {
    const active = button.dataset.activityPanel === target;
    button.classList.toggle('active', active);
    button.setAttribute('aria-selected', String(active));
  });
  if (!state.user) {
    stopMarketAutoRefresh();
    if (target === 'gifts') renderGifts();
    return;
  }
  if (target === 'market') {
    stopMarketAutoRefresh({ invalidate: false });
    if (load) (target === 'market' ? loadMarket : loadLottery)();
  } else {
    stopMarketAutoRefresh();
  }
  if (target === 'cloud') {
    showCloudPage('warehouse');
    if (load) Promise.all([loadCloudWarehouse(), loadCloudMarket()]);
  }
  if (target === 'lottery' && load) loadLottery();
  if (target === 'insurance' && load) loadVehicleInsurance();
  if (target === 'teleport') {
    const mapImage = $('#teleportMapImage');
    if (mapImage?.dataset.src && !mapImage.src) mapImage.src = mapImage.dataset.src;
    if (load) loadTeleportMapData().catch(() => {});
  }
  if (target === 'gifts') {
    renderGifts();
    if (load) loadGifts();
  }
}

function showAccountSection(section = 'accountProfileSection') {
  const target = document.getElementById(section)?.classList.contains('account-panel') ? section : 'accountProfileSection';
  $$('.account-panel').forEach((panel) => { panel.hidden = panel.id !== target; });
  $$('[data-account-section]').forEach((button) => button.classList.toggle('active', button.dataset.accountSection === target));
}

function showRoute(route, updateHash = true, options = {}) {
  const legacyActivityPanel = route === 'lottery' || route === 'market' ? route : null;
  const requested = legacyActivityPanel ? 'activity' : route;
  if (['account', 'orders'].includes(requested) && !state.user && options.pending !== true) {
    showRoute('store', false);
    openAuth('login');
    return;
  }
  const target = ['store', 'activity', 'account', 'orders', 'membership'].includes(requested) ? requested : 'store';
  $$('.page').forEach((page) => page.classList.toggle('active', page.id === `page-${target}`));
  $$('.nav-link').forEach((link) => link.classList.toggle('active', link.dataset.route === target));
  $('#mainNav').classList.remove('open');
  $('#menuToggle').setAttribute('aria-expanded', 'false');
  if (updateHash || legacyActivityPanel) history.replaceState(null, '', `#${target}`);
  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (target === 'activity') showActivityPanel(legacyActivityPanel || state.activityPanel, options.pending !== true);
  else stopMarketAutoRefresh();
  if (options.pending === true) return;
  if (target === 'account') { showAccountSection(); Promise.allSettled([loadAccount(), loadRewardStatus(), loadExchangeConfig()]); }
  if (target === 'orders') loadOrders();
  if (target === 'membership') loadMembershipPage();
}

let pendingCloudBulkConfirm = null;

function confirmCloudBulk({ title, description, danger = false, confirmLabel = '确认' }) {
  const modal = $('#cloudBulkConfirmModal');
  if (pendingCloudBulkConfirm) closeModal(modal);
  $('#cloudBulkConfirmTitle').textContent = title;
  $('#cloudBulkConfirmDescription').textContent = description;
  const confirm = $('#confirmCloudBulk');
  confirm.textContent = confirmLabel;
  confirm.classList.toggle('danger', danger);
  confirm.classList.toggle('primary', !danger);
  openModal(modal);
  return new Promise((resolve) => { pendingCloudBulkConfirm = resolve; });
}

function openModal(modal) {
  modal.hidden = false;
  document.body.style.overflow = 'hidden';
  window.setTimeout(() => $('input, button, [tabindex="0"]', modal)?.focus(), 30);
}

function resetCloudRecycleModal({ clearInput = true } = {}) {
  const input = $('#cloudRecycleItemId');
  if (clearInput && input) input.value = '';
  const feedback = $('#cloudRecycleFeedback');
  if (feedback) { feedback.hidden = true; feedback.textContent = ''; }
  const itemInfo = $('#cloudRecycleItemInfo');
  if (itemInfo) itemInfo.hidden = true;
  const image = $('#cloudRecycleItemImage');
  if (image) { image.src = ''; image.hidden = true; }
  const details = $('#cloudRecycleItemDetails');
  if (details) details.replaceChildren();
}

function openCloudRecycleModal() {
  const input = $('#cloudRecycleItemId');
  const itemInfo = $('#cloudRecycleItemInfo');
  const hint = document.querySelector('.cloud-recycle-hint');
  const hintImage = hint?.querySelector('img[data-src]');
  if (hintImage && !hintImage.src) hintImage.src = hintImage.dataset.src;
  const layout = document.querySelector('.cloud-recycle-layout');
  if (itemInfo && layout && itemInfo.parentElement !== layout) layout.appendChild(itemInfo);
  const actions = document.querySelector('.cloud-recycle-content .modal-actions');
  if (actions && layout && actions.parentElement !== layout) layout.appendChild(actions);
  const quota = $('#cloudRecycleQuota');
  if (quota) quota.textContent = `今日剩余额度：${number(state.cloudWarehouse?.quota?.remaining ?? 0)}`;
  if (!input) return;
  resetCloudRecycleModal({ clearInput: false });
  openModal($('#cloudRecycleModal'));
}

async function queryCloudRecycleItem(button) {
  const itemId = $('#cloudRecycleItemId').value.trim();
  const feedback = $('#cloudRecycleFeedback');
  const itemInfo = $('#cloudRecycleItemInfo');
  const itemInfoValue = $('#cloudRecycleItemInfoValue');
  feedback.hidden = true;
  if (!itemId || itemId.length > 80) {
    feedback.textContent = '请输入有效的库存编号';
    feedback.hidden = false;
    $('#cloudRecycleItemId').focus();
    return;
  }
  await withBusy(button, async () => {
    $('#cloudRecycleModal').dataset.queried = 'true';
    if (itemInfoValue) itemInfoValue.textContent = itemId;
    try {
      const result = await api('/api/shop/cloud-warehouse/recycle/inspect', { method: 'POST', body: JSON.stringify({ itemId }) });
      const item = result?.data || result || {};
      result.data = item;
      if (itemInfoValue) itemInfoValue.textContent = item.itemName || item.itemCode || itemId;
      const image = $('#cloudRecycleItemImage');
      if (image) { image.src = item.imagePath || ''; image.hidden = !item.imagePath; }
      const details = $('#cloudRecycleItemDetails');
      if (details) details.textContent = `物品名称：${result.data.itemName}；物品代码：${result.data.itemCode}；耐久：${result.data.health ?? '-'} / ${result.data.maxHealth ?? '-'}；使用次数：${result.data.uses ?? '-'} / ${result.data.maxUses ?? '-'}；脏度：${result.data.dirtiness ?? '-'}；所在容器：${result.data.container || '-'}`;
      if (details) details.textContent = [
        `物品名称：${item.itemName || '-'}`, `物品代码：${item.itemCode || '-'}`, `耐久：${item.health ?? '-'}`,
        `使用次数：${item.uses ?? '-'} / ${item.maxUses ?? '-'}`, `脏度：${item.dirtiness ?? '-'}`, `所在容器：${item.container || '-'}`
      ].join('  |  ');
      if (details) {
        details.replaceChildren();
        const fields = [
          ['物品名称', item.itemName || '-'], ['物品代码', item.itemCode || '-'], ['库存编号', item.itemId || itemId],
          ['所在容器', item.container || '-'], ['耐久', item.health ?? '-'], ['使用次数', item.uses === null || item.uses === undefined ? '-' : item.maxUses === null || item.maxUses === undefined ? item.uses : `${item.uses} / ${item.maxUses}`],
          ['脏度', item.dirtiness ?? '-']
        ];
        for (const [label, value] of fields) {
          const field = document.createElement('div');
          field.className = 'cloud-recycle-detail-field';
          const name = document.createElement('span');
          const content = document.createElement('b');
          name.textContent = label;
          content.textContent = String(value);
          field.append(name, content);
          details.appendChild(field);
        }
      }
      if (itemInfo) itemInfo.hidden = false;
      return;
      closeModal($('#cloudRecycleModal'));
      toast('回收成功');
      await loadCloudWarehouse();
    } catch (error) {
      const message = error.status === 404 && error.code === 'NOT_FOUND'
        ? '当前暂不支持物品回收，请稍后再试'
        : chineseErrorMessage(error.message, '物品信息读取失败，请稍后重试');
      feedback.textContent = message;
      feedback.hidden = false;
      toast(message, 'error');
    }
  });
}

async function confirmCloudRecycle(button) {
  const itemId = $('#cloudRecycleItemId').value.trim();
  const feedback = $('#cloudRecycleFeedback');
  if (!itemId) {
    feedback.textContent = '请输入库存编号';
    feedback.hidden = false;
    return;
  }
  await withBusy(button, async () => {
    try {
      feedback.hidden = true;
      await api('/api/shop/cloud-warehouse/recycle', { method: 'POST', body: JSON.stringify({ itemId }) });
      closeModal($('#cloudRecycleModal'));
      toast('回收成功');
      await loadCloudWarehouse();
    } catch (error) {
      const message = chineseErrorMessage(error.message, '回收失败，请稍后重试');
      feedback.textContent = message;
      feedback.hidden = false;
      toast(message, 'error');
    }
  });
}

function resetStockChartModal() {
  const identity = $('#stockChartModalIdentity'), summary = $('#stockChartModalSummary'), canvas = $('#stockChartModalCanvas');
  if (identity) identity.textContent = '—';
  if (summary) summary.textContent = '选择股票后读取 K 线';
  if (canvas) canvas.innerHTML = emptyState('选择行情查看 K 线', '等待选择行情');
}

function closeModal(modal) {
  if (!modal) return;
  if (modal.id === 'cloudBulkConfirmModal' && pendingCloudBulkConfirm) {
    const resolve = pendingCloudBulkConfirm;
    pendingCloudBulkConfirm = null;
    resolve(false);
  }
  modal.hidden = true;
  if (modal.id === 'cloudRecycleModal') {
    resetCloudRecycleModal({ clearInput: modal.dataset.queried === 'true' });
    delete modal.dataset.queried;
  }
  if (modal.id === 'stockChartModal') resetStockChartModal();
  if ($$('.modal-backdrop:not([hidden])').length === 0) document.body.style.overflow = '';
}

function switchAuth(tab) {
  if (tab === 'change' && !state.user) tab = 'login';
  $('#authTabs').hidden = tab === 'change';
  $$('[data-auth-tab]').forEach((button) => button.classList.toggle('active', button.dataset.authTab === tab));
  for (const [mode, id] of Object.entries({ login: 'loginForm', register: 'registerForm', reset: 'resetPasswordForm', change: 'changePasswordForm' })) {
    const form = $(`#${id}`);
    form.hidden = mode !== tab;
    if (mode !== tab) form.reset();
  }
  $('#authTitle').textContent = { login: '幸存者登录', register: '建立幸存者档案', reset: '忘记密码', change: '修改密码' }[tab];
  $('#authDescription').textContent = { login: '输入档案凭据以访问账户与订单。', register: '绑定 SteamID，并通过游戏内验证码确认身份。', reset: '', change: '' }[tab];
}

function openAuth(tab = 'login') {
  setAccountMenu(false);
  switchAuth(tab);
  openModal($('#authModal'));
}

async function login(form, button) {
  await withBusy(button, async () => {
    const values = Object.fromEntries(new FormData(form));
    try {
      const data = await api('/api/shop/auth/login', { method: 'POST', body: JSON.stringify({ username: values.username.trim(), password: values.password }) });
      const loginUser = normalizedUser(data);
      setUser(loginUser);
      await loadMe();
      closeModal($('#authModal')); form.reset(); toast('身份验证通过，欢迎返回补给站');
    } catch (error) { toast(error.message, 'error'); }
  });
}

async function register(form, button) {
  const values = Object.fromEntries(new FormData(form));
  if (!validRegistrationPassword(values.password)) { toast(REGISTRATION_PASSWORD_ERROR, 'error'); form.elements.password.focus(); return; }
  if (!validRegistrationPassword(values.confirmPassword)) { toast(REGISTRATION_PASSWORD_ERROR, 'error'); form.elements.confirmPassword.focus(); return; }
  if (values.password !== values.confirmPassword) { toast('两次输入的密码不一致', 'error'); form.elements.confirmPassword.focus(); return; }
  await withBusy(button, async () => {
    try {
      const data = await api('/api/shop/auth/register', { method: 'POST', body: JSON.stringify({ username: values.username.trim(), password: values.password, steamId: values.steamId.trim(), verificationCode: values.verificationCode.trim() }) });
      setUser(normalizedUser(data));
      await loadMe();
      closeModal($('#authModal'));
      form.reset();
      toast('档案已建立，注册成功');
    } catch (error) { toast(error.message, 'error'); }
  });
}

async function logout(options = {}) {
  const automatic = options?.automatic === true;
  const action = async () => {
    try { await api('/api/shop/auth/logout', { method: 'POST', body: '{}' }); }
    catch (error) {
      if (error.status !== 401 && !automatic) { toast(error.message, 'error'); return; }
    }
    setUser(null); state.account = null; state.orders = []; state.gifts = []; state.rewards = null; state.quotes = []; state.portfolio = null; state.stockTrades = []; state.stockReceipt = null; state.pagination = { ledger: 0, orders: 0, rewards: 0, lottery: 0, holdings: 0, trades: 0 }; state.orderDetails.clear(); showRoute('store'); toast(automatic ? '页面 10 分钟无操作，已自动退出' : '已安全退出幸存者档案');
  };
  if (automatic) return action();
  return withBusy($('#logoutButton'), action);
}

async function savePassword(form, button, mode) {
  const values = Object.fromEntries(new FormData(form));
  if (!validRegistrationPassword(values.password)) { toast(REGISTRATION_PASSWORD_ERROR, 'error'); return; }
  if (values.password !== values.confirmPassword) { toast('两次输入的密码不一致', 'error'); return; }
  await withBusy(button, async () => {
    try {
      await api(`/api/shop/auth/${mode}-password`, { method: 'POST', body: JSON.stringify(values) });
      form.reset();
      setUser(null); state.account = null;
      showRoute('store');
      switchAuth('login');
      toast('密码已更新，请重新登录');
    } catch (error) { toast(error.message, 'error'); }
  });
}
