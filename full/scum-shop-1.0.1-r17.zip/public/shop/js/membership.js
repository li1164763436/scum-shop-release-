function resetRewards(message = '登录后可查看奖励状态') {
  $('#rewardCheckedToday').textContent = '—';
  $('#rewardStreakDays').textContent = '—';
  $('#rewardTotalDays').textContent = '—';
  $('#rewardOnlineTotal').textContent = '—';
  $('#rewardNextOnline').innerHTML = `<span>下一在线奖励</span><strong>${escapeHtml(message)}</strong>`;
  $('#rewardClaimList').innerHTML = emptyState('暂无奖励状态', '奖励状态暂不可用');
  $('#checkinButton').disabled = true;
  $('#checkinButton').textContent = '立即签到';
}
async function loadRewardStatus() {
  if (!state.user) { resetRewards(); return; }
  state.pagination.rewards = 0;
  $('#rewardCheckedToday').textContent = '读取中';
  $('#checkinButton').disabled = true;
  $('#checkinButton').textContent = '状态读取中';
  try {
    state.rewards = await api('/api/shop/rewards/status') || {};
    renderRewards();
  } catch (error) {
    state.rewards = null;
    resetRewards('奖励状态暂不可用');
    if (error.status !== 401) toast('奖励状态读取失败，请稍后重试', 'error');
  }
}
function renderRewards() {
  const data = state.rewards || {};
  const latest = data.latestCheckin || {};
  const checked = Boolean(data.checkedInToday);
  $('#rewardCheckedToday').textContent = checked ? '今日已签到' : '今日未签到';
  $('#rewardStreakDays').textContent = number(latest.streakDays || 0);
  $('#rewardTotalDays').textContent = number(latest.totalDays || 0);
  $('#rewardOnlineTotal').textContent = duration(data.onlineTotalSeconds);
  $('#checkinButton').disabled = checked;
  $('#checkinButton').textContent = checked ? '今日已签到' : '立即签到';
  const claimableOnline = asList(data, ['claimableOnlineRewards']);
  const next = data.nextOnlineReward;
  const nextCheckin = data.nextCheckinReward;
  $('#rewardNextOnline').innerHTML = claimableOnline.length
    ? `<span>在线奖励已达标</span><strong>可领取 ${number(claimableOnline.length)} 项奖励</strong><button class="button primary online-reward-claim" id="claimOnlineRewardButton" type="button">立即领取</button>`
    : next
      ? `<span>下一在线奖励</span><strong>${escapeHtml(next.coinAmount != null ? `${number(next.coinAmount)} 商城币` : next.productName || next.giftName || '在线奖励')}</strong><small>门槛 ${escapeHtml(duration(next.threshold))} · 还需 ${escapeHtml(duration(next.remainingSeconds))}</small>`
      : nextCheckin
        ? `<span>下一签到奖励</span><strong>${number(nextCheckin.coinAmount)} 商城币</strong><small>${nextCheckin.ruleType === 'checkin_streak' ? `连续签到满 ${number(nextCheckin.threshold)} 天` : nextCheckin.ruleType === 'checkin_total' ? `累计签到满 ${number(nextCheckin.threshold)} 天` : '下次每日签到'} · 还需 ${number(nextCheckin.remainingDays)} 天</small>`
        : '<span>下一奖励</span><strong>暂无可领取的奖励规则</strong><small>请等待管理员配置奖励</small>';
  $('#claimOnlineRewardButton')?.addEventListener('click', claimOnlineRewards);
  const claims = asList(data, ['recentClaims', 'claims', 'items']);
  if (!claims.length) { $('#rewardClaimList').innerHTML = emptyState('暂时没有奖励记录', '暂无可领取奖励'); return; }
  const page = pageItems(claims, 'rewards');
  $('#rewardClaimList').innerHTML = page.items.map((claim) => {
    const type = rewardTypeLabels[claim.ruleType] || '其他奖励';
    const threshold = claim.ruleType === 'online_total' ? duration(claim.threshold) : `${number(claim.threshold)} 天`;
    const rawStatus = String(claim.status || 'pending').toLowerCase();
    return `<article class="reward-claim-row"><span><small>奖励规则</small><strong>${escapeHtml(type)}</strong><em>${escapeHtml(threshold)}</em></span><span><small>奖励内容</small><strong>${escapeHtml(claim.coinAmount != null ? `${number(claim.coinAmount)} 商城币` : claim.giftName || '礼包奖励')}</strong></span><span><small>订单</small><strong>${escapeHtml(claim.coinAmount != null ? '直接入账' : claim.orderNo || claim.orderId ? '奖励订单已生成' : '待生成')}</strong></span><span><small>状态 / 时间</small><i class="status ${escapeHtml(rawStatus)}">${escapeHtml(statusLabels[rawStatus] || '状态待确认')}</i><em>${escapeHtml(dateTime(claim.createdAt))}</em></span></article>`;
  }).join('') + paginationMarkup('rewards', page.totalPages, page.page);
}
async function checkIn() {
  await withBusy($('#checkinButton'), async () => {
    try {
      const result = await api('/api/shop/checkins', { method: 'POST', headers: { 'Idempotency-Key': uuid() }, body: '{}' });
      const count = asList(result, ['claims']).length;
      toast(count ? `签到成功，已生成 ${count} 项奖励` : '签到成功，今日记录已更新');
      state.orderDetails.clear();
      await Promise.all([loadRewardStatus(), loadAccount(), loadOrders()]);
    } catch (error) {
      toast(error.status === 401 ? '登录状态已失效，请重新登录' : error.status === 409 ? '签到状态冲突，请刷新后重试' : '签到失败，请稍后重试', 'error');
      if (error.status === 401) openAuth('login');
    }
  });
  if (state.rewards) renderRewards();
}

async function claimOnlineRewards() {
  const button = $('#claimOnlineRewardButton');
  await withBusy(button, async () => {
    try {
      const result = await api('/api/shop/rewards/online/claim', { method: 'POST', headers: { 'Idempotency-Key': uuid() }, body: '{}' });
      const count = asList(result, ['claims']).length;
      toast(count ? `在线奖励领取成功，共 ${count} 项` : '当前没有待领取的在线奖励');
      state.orderDetails.clear();
      await Promise.all([loadRewardStatus(), loadAccount(), loadOrders()]);
    } catch (error) {
      toast(error.status === 401 ? '登录状态已失效，请重新登录' : chineseErrorMessage(error.message, '在线奖励领取失败，请稍后重试'), 'error');
      if (error.status === 401) openAuth('login');
    }
  });
}

async function loadMembershipPage() {
  try {
    const [strategies, policy] = await Promise.all([api('/api/shop/membership/strategies'), api('/api/shop/membership/policy')]);
    const currentLevel = Number(state.user?.memberLevel || 0);
    const allStrategies = (Array.isArray(strategies?.data) ? strategies.data : (Array.isArray(strategies) ? strategies : [])).filter((item) => Number(item.level) > 0);
    const data = currentLevel > 0 ? allStrategies.filter((item) => Number(item.level) >= currentLevel) : allStrategies;
    $('#membershipLevelsGrid').innerHTML = data.length ? data.map((item, index) => { const level=Number(item.level); const action=!state.user?'登录后开通':currentLevel===level?'立即续费':currentLevel>0&&level>currentLevel?'补差升级':'立即开通'; const disabled=!state.user?false:currentLevel===0&&policy.openEnabled===false||currentLevel===level&&policy.renewalEnabled===false||level>currentLevel&&currentLevel>0&&policy.upgradeStrategy==='forbid'; return `<article class="membership-level-card membership-color-${index % 6}"><h2>${escapeHtml(item.title)}</h2><div class="membership-card-body"><div class="membership-card-summary"><strong>会员等级：${number(level)}级</strong><span>开通金额：<b class="membership-price">${number(item.openingAmount)} 商城币</b></span><span>开通周期：${number(item.periodDays)}天</span></div><div class="membership-card-benefits"><span>赠送商城币：${number(item.giftTokens)}</span><span>购物折扣：${number(item.shoppingDiscount)}%</span><span>礼包折扣：${number(item.giftDiscount)}%</span><span>传送折扣：${number(item.teleportDiscount)}%</span><span>在线加成：${number(item.onlineBonus)}%</span><span>充值加成：${number(item.rechargeBonus)}%</span><span>每日传送：${number(item.dailyTeleports)}次</span><span>签到赠送：${number(item.checkinBonus)}商城币</span></div></div>${item.extraHint ? `<div class="membership-card-hint">${escapeHtml(item.extraHint)}</div>` : ''}<button class="button primary full" type="button" data-buy-membership="${level}" ${disabled?'disabled':''}>${disabled?'当前策略不可用':action}</button></article>`; }).join('') : '<div class="empty-row"><strong>暂无可用会员策略</strong><small>正在连接会员服务</small></div>';
  } catch (error) {
    $('#membershipLevelsGrid').innerHTML = `<div class="empty-row"><strong>${escapeHtml(chineseErrorMessage(error.message, '会员策略读取失败，请稍后重试'))}</strong><small>会员服务暂不可用</small></div>`;
  }
}
async function purchaseMembership(level, button) {
  if (!state.user) { openAuth('login'); return; }
  if (!window.confirm('确认使用商城币购买该会员等级？')) return;
  await withBusy(button, async () => { const data=await api('/api/shop/membership/purchase/'+encodeURIComponent(level),{method:'POST',headers:{'Idempotency-Key':uuid()},body:'{}'}); toast(`会员已生效，实际支付 ${number(data.price)} 商城币`); await loadMe(); await loadMembershipPage(); });
}
