function setupCloudPages() {
  const panel = $('.cloud-warehouse-panel');
  if (!panel || panel.dataset.cloudPagesReady) return;
  const nav = $('.cloud-mode-tabs', panel);
  const route = $('.cloud-warehouse-route', panel);
  const workspace = $('.cloud-workspace', panel);
  const market = $('.cloud-market-empty', panel);
  const pass = $('.cloud-pass-section', panel);
  if (![nav, route, workspace, market, pass].every(Boolean)) return;

  const warehousePage = document.createElement('section');
  warehousePage.className = 'cloud-page active';
  warehousePage.id = 'cloud-page-warehouse';
  warehousePage.style.display = 'grid';
  warehousePage.style.gap = '16px';
  route.parentNode.insertBefore(warehousePage, route);
  warehousePage.append(route, workspace);

  const marketPage = document.createElement('section');
  marketPage.className = 'cloud-page';
  marketPage.id = 'cloud-page-market';
  marketPage.hidden = true;
  marketPage.style.display = 'grid';
  marketPage.style.gap = '16px';
  market.parentNode.insertBefore(marketPage, market);
  marketPage.append(route.cloneNode(true), market);

  $$('button', nav).forEach((button, index) => {
    button.disabled = false;
    button.dataset.cloudPage = index === 1 ? 'market' : 'warehouse';
    button.setAttribute('aria-controls', `cloud-page-${button.dataset.cloudPage}`);
    button.setAttribute('aria-selected', String(index === 0));
  });
  panel.dataset.cloudPagesReady = 'true';
  setupCloudInventoryPagination();
}

function renderCloudInventoryPage() {
  const list = $('[data-cloud-inventory-list]');
  if (!list) return;
  const rows = $$('.cloud-inventory-group', list);
  const pageSize = 6;
  const pageCount = Math.max(1, Math.ceil(rows.length / pageSize));
  const currentPage = Math.min(Number(list.dataset.page || 0), pageCount - 1);
  list.dataset.page = String(currentPage);
  rows.forEach((row, index) => { row.hidden = index < currentPage * pageSize || index >= (currentPage + 1) * pageSize; });
  const empty = $('[data-cloud-inventory-empty]', list);
  if (empty) empty.hidden = rows.length > 0;
  const summary = $('[data-cloud-inventory-summary]');
  const status = $('[data-cloud-inventory-page-status]');
  const previous = $('[data-cloud-inventory-page="previous"]');
  const next = $('[data-cloud-inventory-page="next"]');
  if (summary) summary.textContent = `共 ${rows.length} 条，每页 ${pageSize} 条`;
  if (status) status.textContent = `${currentPage + 1} / ${pageCount}`;
  if (previous) previous.disabled = currentPage === 0;
  if (next) next.disabled = currentPage >= pageCount - 1;
}

function ammoBoxCapacity(code) {
  const value = String(code || '');
  if (!/Ammobox/i.test(value)) return null;
  if (/50BMG/i.test(value)) return 10;
  if (/(?:12_Gauge|30-06|Cal_22|7_92x57|7_62x54|Cal_308|Cal_338)/i.test(value)) return 20;
  return 30;
}
function cloudPackageLabel(item) {
  const quantity = Number(item.availableQuantity ?? item.remainingQuantity ?? item.quantity ?? 0);
  const capacity = item.itemMaxQuantity ?? ammoBoxCapacity(item.itemCode);
  if (item.itemStackable && capacity) return '1 盒';
  if (item.itemStackable && /(?:bag|sack|pouch|袋|包)/i.test(`${item.itemCode || ''} ${item.itemName || ''}`)) return '1 袋';
  if (item.itemStackable) return `1 堆`;
  return `${number(quantity)} 件`;
}
function cloudPackageType(item) {
  const value = `${item.itemCode || ''} ${item.itemName || ''}`;
  if (/Ammobox|盒/i.test(value)) return '盒';
  if (/bag|sack|袋/i.test(value)) return '袋';
  if (/pouch|pack|包/i.test(value)) return '包';
  return '组';
}
function cloudUsageLabel(item) {
  const quantity = Number(item.itemUses ?? 0);
  if (item.itemStackable) return item.itemMaxUses === null || item.itemMaxUses === undefined
    ? `使用次数 ${number(quantity)}`
    : `使用次数 ${number(quantity)} / ${number(item.itemMaxUses)}`;
  const uses = item.itemUses === null || item.itemUses === undefined ? '未记录' : number(item.itemUses);
  const maxUses = item.itemMaxUses === null || item.itemMaxUses === undefined ? '未记录' : number(item.itemMaxUses);
  return `使用次数 ${uses} / ${maxUses}`;
}
function cloudContainerCount(item) {
  if (!item.itemStackable) return Number(item.availableQuantity ?? item.quantity ?? 0);
  return Number(item.availableQuantity ?? item.quantity ?? 0) > 0 ? 1 : 0;
}
function cloudInfoDisplay(item) {
  const blank = (field) => item[field] === null || item[field] === undefined ? null : number(item[field]);
  const healthValue = Number(item.itemHealth);
  const details = [];
  if (item.itemHealth !== null && item.itemHealth !== undefined) details.push(`耐久 ${Math.round(healthValue) === 100 ? '100' : healthValue.toFixed(1)}%`);
  const uses = blank('itemUses');
  if (uses !== null) details.push(`使用次数 ${item.itemMaxUses === null || item.itemMaxUses === undefined ? uses : `${uses} / ${blank('itemMaxUses')}`}`);
  const dirtiness = blank('itemDirtiness');
  if (dirtiness !== null) details.push(`脏度 ${dirtiness}`);
  return details.join('\n');
}
function cloudInfoLegacy(item) {
  return cloudInfoDisplay(item);
}
function cloudInfoLabel(item) { return cloudInfoDisplay(item); }

function setupCloudInventoryPagination() {
  const list = $('[data-cloud-inventory-list]');
  if (!list || list.dataset.paginationReady) return;
  list.dataset.paginationReady = 'true';
  list.dataset.page = '0';
  new MutationObserver(() => renderCloudInventoryPage()).observe(list, { childList: true });
  renderCloudInventoryPage();
}

function showCloudPage(page = 'warehouse') {
  setupCloudPages();
  const target = ['warehouse', 'market'].includes(page) ? page : 'warehouse';
  $$('.cloud-page').forEach((panel) => {
    const active = panel.id === `cloud-page-${target}`;
    panel.hidden = !active;
    panel.classList.toggle('active', active);
  });
  $$('[data-cloud-page]').forEach((button) => {
    const active = button.dataset.cloudPage === target;
    button.classList.toggle('active', active);
    button.setAttribute('aria-selected', String(active));
    const status = $('span', button);
    if (status) status.hidden = !active;
  });
  if (target === 'market') loadCloudMarket();
}

function cloudInventoryRows(batches) {
  return batches.map((item) => {
    const listed = Number(item.reservedQuantity) > 0, available = Number(item.availableQuantity) > 0, tradeable = listed || available;
    return `<div class="cloud-inventory-row${state.cloudInventorySelection.has(Number(item.id)) ? ' selected' : ''}" data-cloud-inventory-row="${item.id}" role="group" tabindex="0" aria-label="库存序号 ${number(item.id)}，${state.cloudInventorySelection.has(Number(item.id)) ? '已选中' : '未选中'}；按回车或空格切换选择"><span><strong>${number(item.id)}</strong></span><span>${escapeHtml(item.sourceItemId || item.id)}</span><span>${escapeHtml(cloudInfoLabel(item))}</span><span><strong>${escapeHtml(cloudPackageLabel(item))}</strong></span><span class="cloud-inventory-status ${tradeable ? 'available' : 'unavailable'}">${tradeable ? '可交易' : '不可交易'}</span><span class="cloud-inventory-status ${listed ? 'listed' : 'unlisted'}">${listed ? '已上架' : '未上架'}</span><span>${escapeHtml(dateTime(item.createdAt))}</span><span class="cloud-inventory-actions"><button class="button line" type="button" data-cloud-list="${item.id}" data-item-name="${escapeHtml(item.itemName || '未知物品')}" data-max="${item.availableQuantity}" data-stackable="${item.itemStackable ? '1' : '0'}"${available ? '' : ' disabled'}>上架</button><button class="button ghost" type="button" data-cloud-withdraw="${item.id}" data-max="${item.itemStackable ? 1 : item.availableQuantity}" data-internal-quantity="${item.availableQuantity}" data-stackable="${item.itemStackable ? '1' : '0'}" data-package="${cloudPackageType(item)}"${available ? '' : ' disabled'}>取出</button><button class="button danger" type="button" data-cloud-destroy="${item.id}"${available && !listed ? '' : ' disabled'}>销毁</button></span></div>`;
  }).join('');
}

function openCloudListingPrice(inventoryIds, itemName, bulkMode) {
  const modal = $('#cloudListingPriceModal');
  modal.dataset.bulkMode = bulkMode ? '1' : '0';
  $('.cloud-listing-price-hint', modal).textContent = bulkMode ? '填写单价和数量，成交后卖方出手续费。' : '填写单价，成交后卖家出手续费。';
  modal.dataset.inventoryIds = JSON.stringify(inventoryIds);
  $('#cloudListingItemName').textContent = itemName || '未知物品';
  $('#cloudListingStock').textContent = number(inventoryIds.length);
  $('#cloudListingQuantityInput').max = String(inventoryIds.length);
  $('#cloudListingQuantityInput').value = bulkMode ? String(inventoryIds.length) : '1';
  $('#cloudListingQuantityInput').closest('.cloud-listing-input-card').hidden = !bulkMode;
  const warning = $('#cloudListingWarning');
  warning.classList.toggle('single', !bulkMode);
  warning.textContent = bulkMode ? '当前价格扣除手续费后没有有效收益，请提高单价或减少上架数量。' : '当前价格扣除手续费后没有有效收益，请提高单价。';
  if (bulkMode) $('.cloud-listing-price-layout', modal).after(warning);
  else $('#cloudListingFeeHint').after(warning);
  $('#cloudListingPriceInput').value = '';
  renderCloudListingEstimate();
  openModal(modal);
}

function renderCloudListingEstimate() {
  const price = Number($('#cloudListingPriceInput')?.value);
  const quantity = Number($('#cloudListingQuantityInput')?.value);
  const feeBps = Number(state.cloudWarehouse?.settings?.feeBps || 0);
  const configuredMinimumFee = Number(state.cloudWarehouse?.settings?.minimumFee || 0);
  const feeRate = feeBps;
  const minimumFee = feeBps > 0 ? configuredMinimumFee : 0;
  const total = Number.isSafeInteger(price) && price >= 2 ? price * quantity : 0;
  const fee = total > 0 ? Math.max(minimumFee, Math.ceil(price * feeBps / 100)) * quantity : 0;
  $('#cloudListingFeeHint').textContent = `卖方手续费 ${feeRate}%，最低 ${minimumFee} 商城币`;
  $('#cloudListingTotal').textContent = total > 0 ? number(total) : '—';
  $('#cloudListingFee').textContent = total > 0 ? number(fee) : '—';
  $('#cloudListingNet').textContent = total > 0 ? number(Math.max(0, total - fee)) : '—';
  $('#cloudListingWarning').hidden = total < 1 || total - fee > 0;
}

function cloudSelectedInventoryIds(inventoryIds) {
  const selected = state.cloudInventorySelection;
  return selected.size ? inventoryIds.filter((id) => selected.has(Number(id))) : inventoryIds;
}

function updateCloudInventorySelectionStatus() {
  const count = state.cloudInventorySelection.size;
  $('#cloudInventorySelectionStatus').textContent = count ? `已选择 ${number(count)} 件；批量操作仅作用于选中且可操作的物品` : '点击库存行选择；未选择时默认全部可操作物品';
}

function toggleCloudInventorySelection(row) {
  const id = Number(row.dataset.cloudInventoryRow);
  const selected = !state.cloudInventorySelection.has(id);
  if (selected) state.cloudInventorySelection.add(id);
  else state.cloudInventorySelection.delete(id);
  row.classList.toggle('selected', selected);
  row.setAttribute('aria-label', `库存序号 ${number(id)}，${selected ? '已选中' : '未选中'}；按回车或空格切换选择`);
  updateCloudInventorySelectionStatus();
}

function renderCloudInventoryDetailPage() {
  const modal = $('#cloudInventoryDetailModal');
  const batches = state.cloudInventoryGroups?.[Number(modal.dataset.groupIndex)] || [];
  const pageSize = 6;
  const pageCount = Math.max(1, Math.ceil(batches.length / pageSize));
  const page = Math.min(Math.max(0, Number(modal.dataset.page || 0)), pageCount - 1);
  modal.dataset.page = String(page);
  $('#cloudInventoryDetailRows').innerHTML = cloudInventoryRows(batches.slice(page * pageSize, (page + 1) * pageSize));
  updateCloudInventorySelectionStatus();
  $('#cloudInventoryDetailPageStatus').textContent = `${page + 1} / ${pageCount}`;
  $('[data-cloud-inventory-detail-page="previous"]', modal).disabled = page === 0;
  $('[data-cloud-inventory-detail-page="next"]', modal).disabled = page >= pageCount - 1;
  $$('[data-cloud-list]', $('#cloudInventoryDetailRows')).forEach((button) => {
    const listing = (state.cloudMarket || []).find((item) => Number(item.inventoryId) === Number(button.dataset.cloudList) && item.sellerSteamId === state.user?.steamId);
    if (!listing) return;
    button.removeAttribute('data-cloud-list');
    button.dataset.cloudCancel = String(listing.id);
    button.dataset.inventoryId = String(listing.inventoryId);
    button.textContent = '下架';
    button.disabled = false;
  });
}

function cloudEligibleBatches(batches) {
  return batches.filter((item) => item.status === 'active' && Number(item.reservedQuantity) === 0 && Number(item.availableQuantity) > 0);
}

function openCloudInventoryDetail(index) {
  const batches = state.cloudInventoryGroups?.[Number(index)];
  if (!batches?.length) return;
  state.cloudInventorySelection.clear();
  $('#cloudInventoryDetailModal').dataset.groupIndex = String(index);
  const first = batches[0];
  $('#cloudInventoryDetailModal').dataset.groupKey = String(first.itemCode || first.itemName);
  $('#cloudInventoryDetailTitle').textContent = first.itemName;
  $('#cloudInventoryDetailCount').textContent = `共 ${batches.length} 件`;
  $('#cloudInventoryDetailCode').textContent = first.itemCode || '无物品代码';
  const listedCount = batches.filter((item) => Number(item.reservedQuantity) > 0).length;
  const listedBadge = $('#cloudInventoryDetailListed');
  listedBadge.textContent = `${listedCount} 已上架`;
  listedBadge.hidden = listedCount < 1;
  const eligibleIds = cloudEligibleBatches(batches).map((item) => Number(item.id));
  const withdrawAll = $('#cloudInventoryWithdrawAll');
  const destroyAll = $('#cloudInventoryDestroyAll');
  withdrawAll.dataset.cloudWithdrawAll = eligibleIds.join(',');
  withdrawAll.dataset.itemName = first.itemName || '未知物品';
  withdrawAll.disabled = eligibleIds.length < 1;
  destroyAll.dataset.cloudDestroyAll = eligibleIds.join(',');
  destroyAll.dataset.itemName = first.itemName || '未知物品';
  destroyAll.disabled = eligibleIds.length < 1;
  const image = $('#cloudInventoryDetailImage');
  const placeholder = $('#cloudInventoryDetailImagePlaceholder');
  image.src = first.imagePath || '';
  image.alt = first.itemName || '物品图片';
  image.hidden = !first.imagePath;
  placeholder.hidden = Boolean(first.imagePath);
  $('#cloudInventoryDetailModal').dataset.page = '0';
  renderCloudInventoryDetailPage();
  openModal($('#cloudInventoryDetailModal'));
}

function refreshCloudInventoryDetailModal() {
  const modal = $('#cloudInventoryDetailModal');
  if (!modal || modal.hidden || !modal.dataset.groupKey) return;
  const index = (state.cloudInventoryGroups || []).findIndex((batches) => String(batches[0]?.itemCode || batches[0]?.itemName) === modal.dataset.groupKey);
  if (index < 0) { closeModal(modal); return; }
  openCloudInventoryDetail(index);
}

function renderCloudWarehouse() {
  const data = state.cloudWarehouse || {}, items = asList(data, ['inventory']);
  const inventorySearch = String(state.cloudInventorySearch || '').trim().toLowerCase();
  const header = $('.cloud-list-head');
  if (header) header.innerHTML = '<span>物品名称</span><span>库存编号</span><span>物品规格</span><span>物品信息</span><span>数量</span><span>操作</span>';
  renderCloudPasses(data);
  const groups = new Map();
  for (const item of items) {
    const key = item.itemCode || item.itemName;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(item);
  }
  state.cloudInventoryGroups = [...groups.values()].filter((batches) => !inventorySearch || batches.some((item) => [item.itemName,item.itemCode,item.sourceItemId].some((value) => String(value || '').toLowerCase().includes(inventorySearch))));
  $('#cloudInventoryCount').textContent = groups.size + ' 种物品 / ' + items.length + ' 个批次';
  $('#cloudInventoryTotal').textContent = number(items.length);
  $('#cloudBaseQuota').textContent = number(data.quota?.remaining ?? pick(data.settings, ['dailyBaseQuota'], 0)) + ' / ' + number(data.quota?.total ?? pick(data.settings, ['dailyBaseQuota'], 0));
  const list = $('[data-cloud-inventory-list]');
  const attribute = (value) => value === null || value === undefined ? '未记录' : number(value);
  list.innerHTML = items.length ? state.cloudInventoryGroups.map((batches, groupIndex) => {
    const first = batches[0];
    const available = batches.reduce((sum, item) => sum + cloudContainerCount(item), 0);
    const total = batches.reduce((sum, item) => sum + (item.itemStackable ? 1 : Number(item.quantity || 0)), 0);
    const quantityUnit = String(cloudPackageLabel(first)).replace(/^\s*[0-9.]+\s*/, '') || '件';
    const quantityLabel = `${number(batches.length)} ${quantityUnit}`;
    const image = first.imagePath
      ? `<img src="${escapeHtml(first.imagePath)}" alt="${escapeHtml(first.itemName)}" loading="lazy">`
      : `<span class="cloud-inventory-card-placeholder">暂无图片</span>`;
    const eligibleIds = cloudEligibleBatches(batches).map((item) => item.id);
    const encodedIds = eligibleIds.join(',');
    const actions = eligibleIds.length ? `<div class="cloud-inventory-card-actions"><button class="button ghost" type="button" data-cloud-withdraw-all="${encodedIds}" data-item-name="${escapeHtml(first.itemName)}">一键取出</button><button class="button danger" type="button" data-cloud-destroy-all="${encodedIds}" data-item-name="${escapeHtml(first.itemName)}">一键销毁</button></div>` : '';
    return `<article class="cloud-inventory-group"><button class="cloud-inventory-card" type="button" data-cloud-inventory-detail="${groupIndex}"><span class="cloud-inventory-card-image">${image}</span><span class="cloud-inventory-card-meta"><span class="cloud-inventory-card-copy"><small>物品名称</small><strong>${escapeHtml(first.itemName)}</strong></span><span class="cloud-inventory-card-quantity"><small>物品数量</small><strong>${quantityLabel}</strong></span></span><span class="cloud-inventory-card-toggle">查看明细</span></button>${actions}</article>`;
  }).join('') : '<p data-cloud-inventory-empty>暂无库存记录</p>';
  list.dataset.page = '0';
  renderCloudInventoryPage();
}

async function loadCloudWarehouse() {
  try { state.cloudWarehouse = await api('/api/shop/cloud-warehouse'); renderCloudWarehouse(); }
  catch (error) { toast(error.message, 'error'); }
}

function renderCloudPasses(data) {
  $('#cloudPassRemaining').textContent = `今日剩余 ${number(data.quota?.remaining || 0)}`;
  $('#cloudPassPlans').innerHTML = (data.passPlans || []).map((plan) => {
    const purchases = (data.passes || []).filter((item) => item.passType === plan.passType);
    const latest = purchases[purchases.length - 1];
    const name = plan.passType === 'normal' ? '普通云储证' : '高级云储证';
    return `<article${plan.passType === 'premium' ? ' class="premium"' : ''}><h4>${name}</h4><p>${number(plan.price)} 商城币 · ${number(plan.durationDays)} 天 · 每日增加 ${number(plan.dailyQuota)} 额度</p>${latest ? `<p class="cloud-pass-active"><strong>已开通</strong><span>有效期：${dateTime(latest.expiresAt)}</span></p><button class="button ghost" type="button" disabled>已开通</button>` : `<p>未开通</p><button class="button ghost" type="button" data-cloud-pass-buy="${plan.passType}"${plan.enabled ? '' : ' disabled'}>${plan.enabled ? '商城币购买' : '暂未开放'}</button>`}</article>`;
  }).join('');
}

function renderCloudMarket() {
  const items = state.cloudMarket;
  $('#cloudMarketCount').textContent = number(items.length);
  $('#cloudListingCount').textContent = `挂单 ${number(items.length)}`;
  $('#cloudMarketFee').textContent = `${Number(pick(state.cloudWarehouse?.settings, ['feeBps'], 0))}%`;
  const groups = new Map();
  for (const item of items) {
    const name = item.itemName || item.itemCode;
    if (!groups.has(name)) groups.set(name, []);
    groups.get(name).push(item);
  }
  const attribute = (value, suffix = '') => value === null || value === undefined ? '未知' : `${number(value)}${suffix}`;
  state.cloudMarketGroups = [...groups.entries()];
  $('#cloudMarketRows').innerHTML = items.length ? state.cloudMarketGroups.map(([name, listings], groupIndex) => {
    const first = listings[0];
    const image = first.imagePath ? `<img src="${escapeHtml(first.imagePath)}" alt="${escapeHtml(name)}" loading="lazy">` : '<span class="cloud-inventory-card-placeholder">暂无图片</span>';
    const rows = listings.map((item) => {
      const health = item.itemHealth === null || item.itemHealth === undefined ? '未知' : `${Number(item.itemHealth) === 100 ? '100' : Number(item.itemHealth).toFixed(1)}%`;
      const info = cloudInfoDisplay(item);
      const seller = item.sellerSteamId === state.user?.steamId ? `${item.sellerName || '我的账号'}（我的挂单）` : item.sellerName || item.sellerSteamId;
      const action = item.sellerSteamId === state.user?.steamId ? `<button class="button ghost" type="button" data-cloud-cancel="${item.id}">撤单</button>` : `<button class="button primary" type="button" data-cloud-buy="${item.id}" data-max="${item.remainingQuantity}" data-price="${item.unitPrice}">购买</button>`;
      return `<div class="cloud-market-row"><span>${escapeHtml(name)}</span><span><code>${escapeHtml(item.itemCode)}</code><small>挂单编号：${number(item.id)}</small></span><span>${escapeHtml(info)}</span><span>${escapeHtml(item.sourceItemId || '无')}</span><span>${number(item.unitPrice)} 商城币</span><span>${escapeHtml(seller)}</span><span>${action}</span></div>`;
    }).join('');
    return `<article class="cloud-market-group cloud-inventory-group"><button class="cloud-inventory-card" type="button" data-cloud-market-detail="${groupIndex}"><span class="cloud-inventory-card-image">${image}</span><span class="cloud-inventory-card-meta"><span class="cloud-inventory-card-copy"><small>物品名称</small><strong>${escapeHtml(name)}</strong></span><span class="cloud-inventory-card-quantity"><small>市场卖单</small><strong>${number(listings.length)} 条</strong></span></span><span class="cloud-inventory-card-toggle">查看卖单</span></button></article>`;
  }).join('') : '<p><strong>暂无可交易物品</strong><small>当前没有玩家上架商品</small></p>';
}

function openCloudMarketDetail(index) {
  const group = state.cloudMarketGroups?.[Number(index)];
  if (!group) return;
  const [name, listings] = group, first = listings[0];
  const modal = $('#cloudMarketDetailModal');
  modal.dataset.groupIndex = String(index);
  modal.dataset.page = '0';
  $('#cloudMarketDetailTitle').textContent = name;
  $('#cloudMarketDetailCount').textContent = `共 ${listings.length} 条卖单`;
  $('#cloudMarketDetailCode').textContent = first.itemCode || '无物品代码';
  const image = $('#cloudMarketDetailImage'), placeholder = $('#cloudMarketDetailImagePlaceholder');
  image.src = first.imagePath || ''; image.alt = name; image.hidden = !first.imagePath; placeholder.hidden = Boolean(first.imagePath);
  renderCloudMarketDetailPage();
  openModal(modal);
}

function renderCloudMarketDetailPage() {
  const modal = $('#cloudMarketDetailModal');
  const group = state.cloudMarketGroups?.[Number(modal?.dataset.groupIndex)];
  if (!modal || !group) return;
  const listings = group[1], pageSize = 8, pageCount = Math.max(1, Math.ceil(listings.length / pageSize));
  const page = Math.min(Math.max(0, Number(modal.dataset.page || 0)), pageCount - 1);
  modal.dataset.page = String(page);
  $('#cloudMarketDetailRows').innerHTML = listings.slice(page * pageSize, (page + 1) * pageSize).map((item) => {
    const info = cloudInfoDisplay(item).split('\n').filter(Boolean).map((value) => `<span>${escapeHtml(value)}</span>`).join('');
    const seller = item.sellerSteamId === state.user?.steamId ? `${item.sellerName || '我的账户'}（我的挂单）` : item.sellerName || item.sellerSteamId;
    const action = item.sellerSteamId === state.user?.steamId ? '' : `<button class="button primary" type="button" data-cloud-buy="${item.id}" data-max="${item.remainingQuantity}" data-price="${item.unitPrice}">购买</button>`;
    return `<div class="cloud-market-row"><span class="cloud-market-listing-id">#${number(item.id)}</span><span class="cloud-market-item-info">${info || '<span>无</span>'}</span><span>${escapeHtml(item.sourceItemId || '无')}</span><span>${number(item.unitPrice)} 商城币</span><span>${escapeHtml(seller)}</span><span>${action}</span></div>`;
  }).join('');
  $('#cloudMarketDetailPageStatus').textContent = `${page + 1} / ${pageCount}`;
  $('[data-cloud-market-detail-page="previous"]', modal).disabled = page === 0;
  $('[data-cloud-market-detail-page="next"]', modal).disabled = page >= pageCount - 1;
}

async function loadCloudMarket() {
  try { state.cloudMarket = await api(`/api/shop/cloud-market?search=${encodeURIComponent($('#cloudMarketSearch')?.value || '')}`); renderCloudMarket(); }
  catch (error) { toast(error.message, 'error'); }
}

function renderGifts() {
  const gifts = state.gifts || [];
  if (!state.user) { $('#giftList').innerHTML = emptyState('登录后可查看可领取礼包', '请先登录'); return; }
  if (!gifts.length) { $('#giftList').innerHTML = emptyState('暂无可领取礼包', '暂无可用礼包'); return; }
  $('#giftList').innerHTML = gifts.map((gift) => {
    const items = asList(gift, ['items']);
    const itemCards = items.slice(0, 4).map((item) => `<span class="gift-product"><i>${item.type === 'coin' ? '币' : '物'}</i>${item.imagePath ? `<img src="${escapeHtml(item.imagePath)}" alt="">` : ''}<b>×${number(item.quantity)}</b></span>`).join('');
    const hoverCards = items.map((item) => `<span class="gift-hover-product"><i>${item.type === 'coin' ? '币' : '物'}</i>${item.imagePath ? `<img src="${escapeHtml(item.imagePath)}" alt="">` : ''}<b>×${number(item.quantity)}</b></span>`).join('');
    const more = items.length > 4 ? '<button class="gift-product-more" type="button" data-gift-items-toggle aria-expanded="false" aria-label="查看全部礼包内容">...</button>' : '';
    const member = gift.memberMode === 'exact' ? `会员等级 = ${number(gift.memberLevel)}` : `会员等级 ≥ ${number(gift.memberLevel)}`;
    return `<article class="shop-gift-card"><div class="gift-cover">${gift.imagePath ? `<img src="${escapeHtml(gift.imagePath)}" alt="${escapeHtml(gift.name)}">` : '<span>礼包</span>'}<small>${escapeHtml(giftTypeLabels[gift.type] || '其他礼包')}</small></div><div class="shop-gift-copy"><h3>${escapeHtml(gift.name)}</h3><p>${escapeHtml(gift.description || '暂无礼包说明')}</p><div class="gift-stats"><span><b>${escapeHtml(member.replace('会员等级 ', ''))}</b><small>会员等级</small></span><span><b>${number(gift.remainingTotal)}</b><small>总剩余</small></span><span><b>${number(gift.remainingToday)}</b><small>今日剩余</small></span></div><div class="shop-gift-items">${itemCards || '<span class="gift-empty-content">暂无商品明细</span>'}${more}${items.length ? `<span class="gift-items-hover" aria-hidden="true">${hoverCards}</span>` : ''}</div>${gift.claimReason ? `<div class="gift-claim-reason">${escapeHtml(chineseErrorMessage(gift.claimReason, '当前暂不可领取'))}</div>` : ''}</div><div class="gift-claim-actions"><div class="gift-price">${Number(gift.price) === 0 ? '免费' : `${number(gift.price)} <em>商城币</em>`}</div><button class="button primary" type="button" data-claim-gift="${escapeHtml(gift.id)}" ${gift.claimable ? '' : 'disabled'}>${gift.claimable ? '领取礼包' : '暂不可领'}</button></div></article>`;
  }).join('');
  $$('#giftList .gift-product img, #giftList .gift-hover-product img').forEach((image) => image.addEventListener('error', () => { image.hidden = true; }, { once: true }));
}
async function loadGifts() {
  if (!state.user) return;
  try {
    state.gifts = asList(await api('/api/shop/gifts'), ['gifts', 'items']);
    renderGifts();
  } catch (error) {
    if (error.status === 401) return;
    state.gifts = [];
    $('#giftList').innerHTML = emptyState(chineseErrorMessage(error.message, '礼包读取失败，请稍后重试'), '礼包读取失败');
  }
}
async function claimGift(id, button) {
  await withBusy(button, async () => {
    try {
      const data = await api(`/api/shop/gifts/${encodeURIComponent(id)}/claim`, { method: 'POST', headers: { 'Idempotency-Key': uuid() }, body: '{}' });
      const orderNo = pick(data, ['orderNo', 'order_no'], '');
      const gift = state.gifts.find((item) => String(item.id) === String(id));
      toast(`${gift?.name || '礼包'}${orderNo ? `订单 ${orderNo} ` : ''}已进入发放队列`);
      state.orderDetails.clear();
      await loadMe();
      await loadOrders();
    } catch (error) { toast(error.message, 'error'); }
  });
}
async function claimRedeemCode(form, button) {
  const input = form.elements.code;
  const code = input.value.trim();
  if (!code) { input.reportValidity(); return; }
  await withBusy(button, async () => {
    try {
      const data = await api('/api/shop/redeem-codes/claim', { method: 'POST', headers: { 'Idempotency-Key': uuid() }, body: JSON.stringify({ code }) });
      input.value = '';
      state.orderDetails.clear();
      const orderNo = pick(data, ['orderNo', 'order_no'], '');
      toast(orderNo ? `兑换成功，订单 ${orderNo} 已进入发放队列` : '兑换成功，奖励已进入发放队列');
      await Promise.all([loadAccount(), loadOrders()]);
    } catch (error) {
      toast(error.message, 'error');
      if (error.status === 401) openAuth('login');
    }
  });
}

function lotteryPools() { return state.activities.flatMap((activity) => asList(activity, ['pools']).map((pool) => ({ ...pool, activityId: activity.id }))); }
function lotteryPoolKey(pool) { return `${pool.activityId}:${pool.id}`; }
function lotteryPoolMarkup(pool) {
  return `<section class="activityCard lotteryWheelCard"><div class="activityCardHead"><div><small>奖池</small><h2 id="lotteryPoolTitle">${escapeHtml(pool.name || '抽奖')}</h2><p>奖品由营地管理员上架，抽奖结果请以领取记录为准。</p></div></div><div id="lotteryPoolContent" class="lotteryPoolContent">${emptyState('正在读取奖品','正在读取奖品')}</div><div class="lotteryPoolPicker"><h3>选择奖池</h3><div class="lotteryPoolCards">${lotteryPools().map((item) => `<button type="button" class="lotteryPoolCard${lotteryPoolKey(item) === lotteryPoolKey(pool) ? ' active' : ''}" data-lottery-pool="${escapeHtml(lotteryPoolKey(item))}" aria-pressed="${lotteryPoolKey(item) === lotteryPoolKey(pool)}">${item.imagePath ? `<img src="${escapeHtml(item.imagePath)}" alt="${escapeHtml(item.name)}" loading="lazy">` : '<span class="lotteryPoolImagePlaceholder" aria-hidden="true">暂无图片</span>'}<span class="lotteryPoolCardName">${escapeHtml(item.name)}</span><span class="lotteryPoolCardFree" data-lottery-free="${escapeHtml(lotteryPoolKey(item))}">${state.user ? '免费剩余 加载中' : '登录后查看免费次数'}</span></button>`).join('')}</div></div></section>`;
}
function renderLottery() {
  state.lotteryPoolRequest += 1;
  const pools = lotteryPools();
  if (!pools.length) {
    state.selectedLotteryPoolKey = null;
    $('#activityLotteryList').innerHTML = emptyState('当前没有可用奖池', '暂无可用奖池');
  } else {
    const selected = pools.find((pool) => lotteryPoolKey(pool) === state.selectedLotteryPoolKey) || pools[0];
    state.selectedLotteryPoolKey = lotteryPoolKey(selected);
    $('#activityLotteryList').innerHTML = lotteryPoolMarkup(selected);
  }
}
function renderLotteryPool(pool, data) {
  state.lotteryPoolData[lotteryPoolKey(pool)] = data;
  updateLotteryCardFree(pool, data);
  const content = $('#lotteryPoolContent');
  if (!content) return;
  const prizes = asList(data?.version, ['prizes']);
  if (!prizes.length) { content.innerHTML = emptyState('当前奖池暂无奖品', '暂无奖品'); return; }
  const colors = ['#d5f24b','#d8683c','#80bd55','#d8ca54','#6bc1bd','#b58cff'];
  const step = 360 / prizes.length;
  const gradient = `conic-gradient(${prizes.map((_, index) => `${colors[index % colors.length]} ${index * step}deg ${(index + 1) * step}deg`).join(',')})`;
  const densePrizeLabels = prizes.length > 10;
  const prizeRadius = prizes.length >= 16 ? 30 : prizes.length >= 12 ? 33 : prizes.length > 10 ? 35 : 38;
  const prizeFontSize = prizes.length >= 16 ? 9 : prizes.length >= 12 ? 10 : 11;
  const count = state.lotteryModes[lotteryPoolKey(pool)] === 10 ? 10 : 1;
  const price = count === 10 ? data.tenPrice : data.singlePrice;
  const action = state.user ? `<button class="button primary" data-draw="${escapeHtml(data.id)}:${count}" data-activity-id="${escapeHtml(pool.activityId)}"${data.version ? '' : ' disabled'}>${count === 10 ? '十连抽' : '单抽'} ${number(price)}</button>` : '<button class="button primary" type="button" data-auth-open="login">登录后抽奖</button>';
  content.innerHTML = `<div class="lotteryWheelWrap"><span class="lotteryWheelPointer" aria-hidden="true"></span><div class="lotteryWheel${densePrizeLabels ? ' denseLabels' : ''}" role="img" aria-label="${escapeHtml(pool.name)}奖品转盘" style="--wheel-gradient:${gradient};--lottery-prize-font:${prizeFontSize}px">${prizes.map((prize, index) => { const fullName=String(prize.name||'奖品'),shortName=fullName.length>10?`${fullName.slice(0,9)}…`:fullName,prizeAngle=(index+.5)*360/prizes.length,prizeRotation=prizeAngle>180?prizeAngle+90:prizeAngle-90; return `<span class="lotteryWheelPrize" title="${escapeHtml(fullName)}" data-prize-id="${escapeHtml(prize.id)}" data-reward-type="${escapeHtml(prize.rewardType || '')}" data-gift-id="${escapeHtml(prize.giftId || '')}" data-product-id="${escapeHtml(prize.productId || '')}" style="--prize-rotation:${prizeRotation}deg;left:${50 + prizeRadius * Math.sin((index + .5) * 2 * Math.PI / prizes.length)}%;top:${50 - prizeRadius * Math.cos((index + .5) * 2 * Math.PI / prizes.length)}%"><b>${escapeHtml(shortName)}</b><small>× ${escapeHtml(prize.quantityText || (prize.rewardType==='gift'?'1 份':'数量未记录'))}</small></span>`; }).join('')}<i>${action}</i></div></div>`;
}
function updateLotteryCardFree(pool, data) {
  const label = $$('[data-lottery-free]').find((item) => item.dataset.lotteryFree === lotteryPoolKey(pool));
  if (label) { const count=state.lotteryModes[lotteryPoolKey(pool)]===10?10:1; label.textContent = `${count===10?'十连抽':'单抽'} · 点击切换`; label.dataset.lotteryMode=lotteryPoolKey(pool); label.setAttribute('role','button'); label.setAttribute('tabindex','0'); }
}
async function loadLotteryCardFree(pool, request) {
  try {
    const data = await api(`/api/shop/lottery/pools/${pool.id}?activityId=${encodeURIComponent(pool.activityId)}`);
    if (request === state.lotteryRequest) updateLotteryCardFree(pool, data);
  } catch (error) {
    if (request !== state.lotteryRequest) return;
    const label = $$('[data-lottery-free]').find((item) => item.dataset.lotteryFree === lotteryPoolKey(pool));
    if (label) label.textContent = '幸运度抽奖';
  }
}
async function loadLotteryPool(pool) {
  const request = ++state.lotteryPoolRequest;
  $('#lotteryPoolTitle').textContent = pool.name || '抽奖';
  $('#lotteryPoolContent').innerHTML = emptyState('正在读取奖品', '正在读取奖品');
  const path = state.user ? `/api/shop/lottery/pools/${pool.id}` : `/api/shop/lottery/pools/${pool.id}/public`;
  try {
    const data = await api(`${path}?activityId=${encodeURIComponent(pool.activityId)}`);
    if (request !== state.lotteryPoolRequest || state.selectedLotteryPoolKey !== lotteryPoolKey(pool)) return;
    renderLotteryPool(pool, data);
  } catch (error) {
    const content = $('#lotteryPoolContent');
    if (request === state.lotteryPoolRequest && state.selectedLotteryPoolKey === lotteryPoolKey(pool) && content) content.innerHTML = emptyState(chineseErrorMessage(error.message, '奖品读取失败，请稍后重试'), '奖品读取失败');
  }
}
async function loadLottery() {
  const request = ++state.lotteryRequest;
  state.lotteryPoolRequest += 1;
  state.pagination.lottery = 0;
  try {
    const activities = await api('/api/shop/activities/current');
    if (request !== state.lotteryRequest) return;
    if (request !== state.lotteryRequest) return;
    state.activities = asList(activities);
    renderLottery();
    const pool = lotteryPools().find((item) => lotteryPoolKey(item) === state.selectedLotteryPoolKey);
    await Promise.all([
      ...(pool ? [loadLotteryPool(pool)] : []),
      ...(state.user ? lotteryPools().filter((item) => lotteryPoolKey(item) !== state.selectedLotteryPoolKey).map((item) => loadLotteryCardFree(item, request)) : [])
    ]);
  } catch(error) {
    if (request !== state.lotteryRequest) return;
    state.lotteryPoolRequest += 1;
    $('#activityLotteryList').innerHTML = emptyState(chineseErrorMessage(error.message, '活动读取失败，请稍后重试'), '活动读取失败');
  }
}
async function drawLottery(poolId,button){
  if(!state.user||state.lotterySpinning||!button)return;
  const count=Number(button.dataset.draw.split(':')[1]);
  if(![1,10].includes(count))return;
  state.lotterySpinning=true;
  document.body.classList.add('lotteryDrawing');
  button.disabled=true;
  button.classList.add('busy');
  const wheel=$('.lotteryWheel'),requestKey=button.dataset.requestKey||(button.dataset.requestKey=uuid());
  wheel?.classList.add('spinning');
  try{
    const activityId=button.dataset.activityId;
    const result=await api(`/api/shop/lottery/pools/${poolId}/draw`,{method:'POST',headers:{'Idempotency-Key':requestKey},body:JSON.stringify({count,activityId})});
    delete button.dataset.requestKey;
    const draws=result.draws||[],winner=draws[0],prizes=wheel?[...wheel.querySelectorAll('.lotteryWheelPrize')]:[];
    const prize=winner?(prizes.find((item)=>winner.prizeId&&String(item.dataset.prizeId)===String(winner.prizeId))||prizes.find((item)=>winner.giftId&&String(item.dataset.giftId)===String(winner.giftId))||prizes.find((item)=>item.dataset.rewardType===String(winner.rewardType||'')&&item.querySelector('b')?.textContent===winner.name)||prizes.find((item)=>item.querySelector('b')?.textContent===winner.name)):null;
    if(wheel&&winner&&prizes.length){
      const targetPrize=prize||prizes[0],index=prizes.indexOf(targetPrize),segmentCenter=(index+.5)*360/prizes.length,targetAngle=(360-segmentCenter+360)%360;
      wheel.style.setProperty('--target-rotation','0deg');
      wheel.getBoundingClientRect();
      await new Promise((resolve)=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
      wheel.classList.add('settle');
      wheel.style.setProperty('--target-rotation',`${1440+targetAngle}deg`);
      await new Promise((resolve)=>window.setTimeout(resolve,3300));
      targetPrize.classList.add('winner');
    }
    $('#lotteryResultContent').innerHTML=draws.map((draw)=>`<div class="lotteryResultPrize"><strong>${escapeHtml(draw.name)}</strong><span class="lottery-result-quantity">数量：${escapeHtml(draw.quantityText||'数量未记录')}</span><span>${escapeHtml(draw.rarity||'普通奖品')}</span></div>`).join('');
    openModal($('#lotteryResultModal'));
    toast(`抽奖完成：${draws.map((draw)=>draw.name).join('、')}`);
    await Promise.all([loadLottery(),loadMe(),loadAccount()]);
  }catch(error){toast(error.message,'error');}
  finally{
    state.lotterySpinning=false;
    document.body.classList.remove('lotteryDrawing');
    button.disabled=false;
    button.classList.remove('busy');
    wheel?.classList.remove('spinning','settle');
  }
}
function stockAnnouncementStorageKey(){return 'stock-announcement-shown:'+String(state.user?.steamId||state.user?.id||'guest')}
function openStockAnnouncement(item){if(!item)return;$('#stockAnnouncementModalTitle').textContent=item.title||'市场公告';$('#stockAnnouncementModalTime').textContent=dateTime(item.startsAt||item.createdAt);$('#stockAnnouncementModalContent').textContent=item.content||'';openModal($('#stockAnnouncementModal'))}
function maybeOpenStockAnnouncement(){const item=asList(state.marketOverview,['announcements'])[0];if(!item)return;let shownAt=0;try{shownAt=Number(JSON.parse(localStorage.getItem(stockAnnouncementStorageKey())||'{}').shownAt||0)}catch{}if(Date.now()-shownAt<24*60*60*1000)return;try{localStorage.setItem(stockAnnouncementStorageKey(),JSON.stringify({shownAt:Date.now(),announcementId:item.id}))}catch{}openStockAnnouncement(item)}
function marketIsActive(){return Boolean(state.user&&state.activityPanel==='market'&&$('#page-activity').classList.contains('active')&&!$('#activity-panel-market').hidden);}
function reducedStockMotion(){return Boolean(window.matchMedia?.('(prefers-reduced-motion: reduce)').matches);}
function stockCarouselPageCount(itemCount){return Math.max(0,Math.ceil(itemCount/3)-1);}
function setStockCarouselPage(name,page,itemCount,{instant=false}={}){const carousel=state.stockCarousels[name],track=$(`[data-stock-track="${name}"]`),lastPage=stockCarouselPageCount(itemCount);if(!carousel||!track)return;carousel.page=Math.max(0,Math.min(page,lastPage));track.classList.toggle('stockListTrackReset',instant);track.style.transform=`translateY(calc(var(--stock-list-page-height) * -${carousel.page}))`;if(instant)requestAnimationFrame(()=>track.classList.remove('stockListTrackReset'));}
function rebuildStockCarousel(name,itemCount,preferredIndex=-1){const preferredPage=preferredIndex>=0?Math.floor(preferredIndex/3):state.stockCarousels[name].page;setStockCarouselPage(name,preferredPage,itemCount,{instant:true});}
function scrollStockCarousel(name,delta){const viewport=$(`[data-stock-carousel="${name}"]`),itemCount=Number(viewport?.dataset.stockItemCount||0),carousel=state.stockCarousels[name],direction=delta>0?1:-1,next=carousel.page+direction,lastPage=stockCarouselPageCount(itemCount);if(next<0||next>lastPage)return false;setStockCarouselPage(name,next,itemCount);return true;}
function invalidateStockCandles({clear=false}={}){state.stockCandleRequest+=1;state.stockCandleController?.abort();state.stockCandleController=null;state.stockCandleLoading=false;if(clear){state.stockCandles=null;state.selectedStockId=null;$('#stockChartExpand').disabled=true;if(!$('#stockChartModal').hidden)closeModal($('#stockChartModal'));if($('#stockChartSummary'))$('#stockChartSummary').textContent='选择股票后读取 K 线';if($('#stockChart'))$('#stockChart').innerHTML=emptyState('选择行情查看 K 线','等待选择行情');}}
function stopMarketAutoRefresh({invalidate=true}={}){clearTimeout(state.marketTimer);clearInterval(state.marketCountdownTimer);state.marketTimer=null;state.marketCountdownTimer=null;state.marketNextRefreshAt=0;if(invalidate)invalidateStockCandles({clear:true});if($('#stockRefreshCountdown'))$('#stockRefreshCountdown').textContent='已停止';}
function marketRefreshSeconds(){const periods=state.quotes.map((stock)=>Number(stock.periodSeconds)).filter((value)=>Number.isFinite(value)&&value>0);return Math.max(15,Math.min(60,periods.length?Math.min(...periods):30));}
function marketChartClosed(){const market=state.marketOverview?.market;if(!market)return false;if(!market.isOpen)return true;const parts=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:market.timezone||'Asia/Shanghai',weekday:'short',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(new Date()).map((part)=>[part.type,part.value])),day={Mon:1,Tue:2,Wed:3,Thu:4,Fri:5,Sat:6,Sun:7}[parts.weekday],time=`${parts.hour}:${parts.minute}`;return(Array.isArray(market.tradingDays)&&!market.tradingDays.includes(day))||(market.openTime&&time<market.openTime)||(market.closeTime&&time>=market.closeTime);}
function startMarketAutoRefresh(){
  stopMarketAutoRefresh({invalidate:false});
  if(!marketIsActive())return;
  if(marketChartClosed()){
    if(state.stockCandles){
      invalidateStockCandles();
      renderStockCandles();
    }
    if($('#stockRefreshCountdown'))$('#stockRefreshCountdown').textContent='市场已闭市';
    const seconds=marketRefreshSeconds();
    state.marketTimer=setTimeout(()=>{if(marketIsActive())void loadMarket({silent:true});},seconds*1000);
    return;
  }
  const seconds=marketRefreshSeconds();
  state.marketNextRefreshAt=Date.now()+seconds*1000;
  const tick=()=>{
    if(!marketIsActive()){stopMarketAutoRefresh();return;}
    if(marketChartClosed()){startMarketAutoRefresh();return;}
    $('#stockRefreshCountdown').textContent=`${Math.max(0,Math.ceil((state.marketNextRefreshAt-Date.now())/1000))} 秒`;
  };
  tick();
  state.marketCountdownTimer=setInterval(tick,1000);
  state.marketTimer=setTimeout(()=>{if(marketIsActive())void loadMarket({silent:true});},seconds*1000);
}
function stockMath(stock,quantity){const price=Number(stock.currentPrice),feeBps=Number(stock.feeBps);if(!Number.isSafeInteger(quantity)||quantity<1||!Number.isSafeInteger(price)||price<1||!Number.isSafeInteger(feeBps)||feeBps<0)return null;const gross=price*quantity;if(!Number.isSafeInteger(gross))return null;const feeProduct=gross*feeBps;if(!Number.isSafeInteger(feeProduct))return null;const fee=Math.ceil(feeProduct/10000),buyNet=gross+fee,sellNet=gross-fee;if(!Number.isSafeInteger(buyNet)||!Number.isSafeInteger(sellNet))return null;return{gross,fee,buyNet,sellNet};}
function maxBuyFor(stock,balance){const price=Number(stock.currentPrice);if(!Number.isSafeInteger(balance)||balance<price)return 0;let low=0,high=Math.min(Math.floor(balance/price),Math.floor(Number.MAX_SAFE_INTEGER/price));while(low<high){const mid=Math.ceil((low+high)/2),estimate=stockMath(stock,mid);if(estimate&&estimate.buyNet<=balance)low=mid;else high=mid-1;}return low;}
function renderStockTradeEstimate(){const draft=state.stockTradeDraft,output=$('#stockTradeEstimate'),confirm=$('#confirmStockTrade');if(!draft||!output||!confirm)return;const stock=state.quotes.find((item)=>Number(item.id)===Number(draft.stockId));if(!stock){output.innerHTML='<span class="stockLoss">当前股票已不在行情中</span>';confirm.disabled=true;return;}const quantity=Number($('#stockTradeQuantity').value),estimate=stockMath(stock,quantity),holding=asList(state.portfolio,['items']).find((item)=>Number(item.stockId)===Number(stock.id)),maxBuy=maxBuyFor(stock,Number(state.portfolio?.balance||0)),maxSell=Number(holding?.quantity||0),open=Boolean(state.marketOverview?.market?.isOpen),tradable=open&&!stock.paused;if(!estimate){output.innerHTML='<span class="stockLoss"><small>数量校验</small><b>请输入正整数数量</b></span>';confirm.disabled=true;return;}const settlement=draft.direction==='buy'?estimate.buyNet:estimate.sellNet,withinLimit=draft.direction==='buy'?quantity<=maxBuy:quantity<=maxSell;output.innerHTML=`<span><small>方向 / 代码</small><b>${draft.direction==='buy'?'买入':'卖出'} ${escapeHtml(stock.code)}</b></span><span><small>成交总额</small><b>${number(estimate.gross)}</b></span><span><small>手续费</small><b>${number(estimate.fee)}</b></span><span><small>${draft.direction==='buy'?'买入扣款':'卖出到账'}</small><b>${number(settlement)}</b></span><span><small>最大可买</small><b>${number(maxBuy)}</b></span><span><small>最大可卖</small><b>${number(maxSell)}</b></span>`;confirm.disabled=!tradable||!withinLimit;$('#stockTradeWarning').textContent=!open?'证券市场当前闭市':stock.paused?'该股票当前暂停交易':!withinLimit?`数量超过最大可${draft.direction==='buy'?'买':'卖'}范围`:'最终成交价与结算金额以确认结果为准。';}
function quoteItems(){const watched=new Set(asList(state.marketOverview,['watchlist']).map(Number));return state.stockQuoteFilter==='watchlist'?state.quotes.filter((stock)=>watched.has(Number(stock.id))):state.quotes;}
function stockRankItems(direction){const multiplier=direction==='gainers'?-1:1;return [...state.quotes].sort((a,b)=>{const change=Number(a.lastChangeBps||0)-Number(b.lastChangeBps||0);return change?change*multiplier:String(a.code||'').localeCompare(String(b.code||''));});}
function carouselRows(items,row){return items.map(row).join('');}
function renderQuotes(){const open=Boolean(state.marketOverview?.market?.isOpen),items=quoteItems(),viewport=$('#stockQuoteList'),track=$('[data-stock-track="quotes"]');viewport.dataset.stockItemCount=String(items.length);track.innerHTML=items.length?carouselRows(items,(stock)=>{const paused=Boolean(stock.paused),disabled=paused||!open,selected=Number(stock.id)===Number(state.selectedStockId);return`<article class="stockQuoteRow${selected?' selected':''}${paused?' paused':''}" data-stock-select="${escapeHtml(stock.id)}" tabindex="0" aria-label="选择 ${escapeHtml(stock.code)}"><button type="button" class="stockQuoteCode" data-stock-code="${escapeHtml(stock.id)}">${escapeHtml(stock.code)}</button><div class="stockTradeActions"><button class="button line" data-stock-trade="${escapeHtml(stock.id)}:buy"${disabled?' disabled':''}>买入</button><button class="button ghost" data-stock-trade="${escapeHtml(stock.id)}:sell"${disabled?' disabled':''}>卖出</button><button class="button ghost" data-stock-detail="${escapeHtml(stock.id)}">详情</button></div></article>`;}):emptyState(state.stockQuoteFilter==='watchlist'?'暂无自选股':'当前没有已启用股票','暂无行情');const selectedIndex=items.findIndex((stock)=>Number(stock.id)===Number(state.selectedStockId));rebuildStockCarousel('quotes',items.length,selectedIndex);}
function renderStockRank(name,items){const viewport=$(`#stock${name==='gainers'?'Gainers':'Losers'}`),track=$(`[data-stock-track="${name}"]`);viewport.dataset.stockItemCount=String(items.length);track.innerHTML=items.length?carouselRows(items,(stock,index)=>{const change=Number(stock.lastChangeBps||0);return`<article class="stockRankRow${Number(stock.id)===Number(state.selectedStockId)?' selected':''}" data-stock-select="${escapeHtml(stock.id)}" tabindex="0" aria-label="选择 ${escapeHtml(stock.code)}"><b>${index%items.length+1}</b><strong>${escapeHtml(stock.code)}</strong><span class="${change>=0?'stockGain':'stockLoss'}">${change>0?'+':''}${(change/100).toFixed(2)}%</span></article>`;}):emptyState('暂无数据','暂无数据');rebuildStockCarousel(name,items.length);}
function renderStockCarousels(){renderStockRank('gainers',stockRankItems('gainers'));renderStockRank('losers',stockRankItems('losers'));}
function renderMarketSummary(){const market=state.marketOverview?.market||{};$('#stockMarketName').textContent=market.name||'股市';$('#stockRiskStatement').textContent=market.riskStatement||'';$('#stockMarketStatus').textContent=market.isOpen?'开市':'闭市';$('#stockTradingHours').textContent=`${market.openTime||'—'} - ${market.closeTime||'—'}（北京时间）`;$('#stockNextOpen').textContent=market.isOpen?'交易中':dateTime(market.nextOpenAt);$('#stockLastRefresh').textContent=dateTime(new Date());}
function renderHoldings(){const items=asList(state.portfolio,['items']).map((item)=>{const cost=Number(item.averageCost)*Number(item.quantity),profit=Number(item.unrealizedProfit),returnRate=cost>0?profit/cost:0,weight=Number(state.portfolio?.marketValue)>0?Number(item.marketValue)/Number(state.portfolio.marketValue):0;return{...item,cost,profit,returnRate,weight};});const key=state.stockHoldingSort;items.sort((a,b)=>Number(b[key])-Number(a[key]));if(!items.length){$('#stockHoldingList').innerHTML=emptyState('暂无持仓','暂无持仓');return;}const page=pageItems(items,'holdings');const head='<div class="stockHoldingHead"><span>股票代码</span><span>股票名称</span><span>数量</span><span>成本总额</span><span>市值</span><span>交易时间</span><span>收益率</span><span>仓位</span></div>';const rows=page.items.map((item)=>'<article class="stockHoldingRow"><span><b>'+escapeHtml(item.code)+'</b></span><span><strong>'+escapeHtml(item.name)+'</strong></span><span><b>'+number(item.quantity)+'</b></span><span><b>'+number(item.cost)+'</b><small>成交价 '+number(item.lastTradePrice??item.averageCost)+'</small></span><span><b>'+number(item.marketValue)+'</b><small>现价 '+number(item.currentPrice)+'</small></span><span><time>'+escapeHtml(dateTime(item.lastTradeAt))+'</time></span><span class="'+(item.returnRate>=0?'stockGain':'stockLoss')+'"><b>'+((item.returnRate*100).toFixed(2))+'%</b></span><span><b>'+((item.weight*100).toFixed(2))+'%</b></span></article>').join('');$('#stockHoldingList').innerHTML='<div class="stockHoldingTable">'+head+rows+'</div>'+paginationMarkup('holdings',page.totalPages,page.page);}
function renderTrades(){const items=state.stockTrades.filter((item)=>state.stockTradeFilter==='all'||item.direction===state.stockTradeFilter);if(!items.length){$('#stockTradeList').innerHTML=emptyState(state.stockTradeFilter==='all'?'暂无交易记录':'暂无该方向交易','暂无交易记录');return;}const page=pageItems(items,'trades');$('#stockTradeList').innerHTML=page.items.map((item)=>`<article class="stockTradeRow"><span><small>${escapeHtml(item.code)} · ${escapeHtml(item.name)}</small><strong class="${item.direction==='buy'?'stockLoss':'stockGain'}">${item.direction==='buy'?'买入':'卖出'} ${number(item.quantity)} 股</strong></span><span>成交价 <b>${number(item.price)}</b><small>总额 ${number(item.grossAmount)}</small></span><span>手续费 <b>${number(item.fee)}</b><small>净结算 ${number(item.netAmount)}</small></span><span>成交后余额 <b>${number(item.balanceAfter)}</b><small>持仓 ${number(item.holdingAfter)}</small></span><time>${escapeHtml(dateTime(item.createdAt))}</time></article>`).join('')+paginationMarkup('trades',page.totalPages,page.page);}
function renderReceipt(){const item=state.stockReceipt;if(!item)return;$('#stockReceiptStatus').textContent=item.idempotent?'幂等重放':'已成交';$('#stockReceiptStatus').className=`status ${item.idempotent?'pending':'success'}`;$('#stockTradeReceipt').innerHTML=`<span><small>成交编号</small><b>#${number(item.id)}</b></span><span><small>方向 / 标的</small><b>${item.direction==='buy'?'买入':'卖出'} ${escapeHtml(item.code)} · ${escapeHtml(item.name)}</b></span><span><small>数量 / 成交价</small><b>${number(item.quantity)} 股 / ${number(item.price)}</b></span><span><small>手续费 / 净额</small><b>${number(item.fee)} / ${number(item.netAmount)}</b></span><span><small>成交后余额 / 持仓</small><b>${number(item.balanceAfter)} / ${number(item.holdingAfter)} 股</b></span><span><small>报价版本 / 时间</small><b>v${number(item.priceVersion)} · ${escapeHtml(dateTime(item.priceTimeSnapshot||item.createdAt))}</b></span>`;}
function candleTime(value,period){const options=period==='1d'?{month:'2-digit',day:'2-digit'}:{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false};return new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',...options}).format(new Date(value));}
function validCandles(data){const market=state.marketOverview?.market||{},zone=market.timezone||'Asia/Shanghai',days=Array.isArray(market.tradingDays)?new Set(market.tradingDays.map(Number)):null,period=state.stockCandlePeriod;return asList(data,['candles']).map((item)=>({startAt:item.startAt,endAt:item.endAt,open:Number(item.open),high:Number(item.high),low:Number(item.low),close:Number(item.close),volume:Number(item.volume),turnover:Number(item.turnover)})).filter((item)=>item.startAt&&[item.open,item.high,item.low,item.close,item.volume,item.turnover].every(Number.isSafeInteger)&&item.open>0&&item.high>=Math.max(item.open,item.close)&&item.low<=Math.min(item.open,item.close)&&item.low>0&&item.volume>=0&&item.turnover>=0).filter((item)=>!(item.open===item.high&&item.high===item.low&&item.low===item.close&&item.volume===0&&item.turnover===0)).filter((item)=>{if(!days)return true;const start=new Date(item.startAt),end=new Date(item.endAt||item.startAt),parts=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:zone,weekday:'short',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(start).map((part)=>[part.type,part.value])),endParts=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:zone,weekday:'short',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(end).map((part)=>[part.type,part.value])),day={Mon:1,Tue:2,Wed:3,Thu:4,Fri:5,Sat:6,Sun:7}[parts.weekday],endDay={Mon:1,Tue:2,Wed:3,Thu:4,Fri:5,Sat:6,Sun:7}[endParts.weekday];if(!days.has(day)||!days.has(endDay))return false;if(period==='1d')return true;const time=`${parts.hour}:${parts.minute}`,endTime=`${endParts.hour}:${endParts.minute}`;return (!market.openTime||time>=market.openTime)&&(!market.closeTime||endTime<=market.closeTime);});}
function stockCandleSessionKey(candle){if(state.stockCandlePeriod==='1d')return'daily';const zone=state.marketOverview?.market?.timezone||'Asia/Shanghai',parts=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date(candle.startAt)).map((part)=>[part.type,part.value]));return`${parts.year}-${parts.month}-${parts.day}`;}
function stockPolylineSegments(candles,values,point,attributes){const segments=[];let current=[],previousKey=null;const flush=()=>{if(current.length>1)segments.push(current);current=[];};candles.forEach((candle,index)=>{const value=values[index],key=stockCandleSessionKey(candle);if(value===null||!Number.isFinite(value)){flush();previousKey=key;return;}if(current.length&&key!==previousKey)flush();current.push(point(value,index));previousKey=key;});flush();return segments.map((points)=>`<polyline points="${points.join(' ')}" ${attributes}/>`).join('');}
function stockPriceDomain(candles,currentPrice=null){const prices=[...candles.flatMap((item)=>[item.high,item.low]),Number(currentPrice)].filter((value)=>Number.isFinite(value)&&value>0),highest=Math.max(...prices),lowest=Math.min(...prices),range=highest-lowest;if(range>0){const padding=Math.max(range*.12,.25);return{min:Math.max(.01,lowest-padding),max:highest+padding,highest,lowest};}const minimumSpan=Math.max(2,Math.abs(highest)*.02),half=minimumSpan/2;return{min:Math.max(.01,highest-half),max:highest+half,highest,lowest};}
function stockPriceTicks(domain,count=5){const step=(domain.max-domain.min)/(count-1),values=Array.from({length:count},(_,index)=>domain.max-step*index);let precision=0,labels=values.map((value)=>value.toFixed(precision));while(new Set(labels).size<labels.length&&precision<6){precision+=1;labels=values.map((value)=>value.toFixed(precision));}return values.map((value,index)=>({value,label:labels[index].replace(/\.0+$/,'')}));}
function stockPriceY(price,domain,top,bottom){return top+(domain.max-price)*(bottom-top)/(domain.max-domain.min);}
function stockCandleBody(open,close,y,minHeight=3){const openY=y(open),closeY=y(close),realTop=Math.min(openY,closeY),realHeight=Math.abs(openY-closeY);return{top:realTop-(Math.max(minHeight,realHeight)-realHeight)/2,height:Math.max(minHeight,realHeight),doji:open===close,priceY:openY};}
function stockCandleNotice(stock,candles){if(!stock?.lastPricedAt)return'暂无价格事件，当前为初始参考价；自动定价周期完成或人工调价后产生波动';return candles.every((item)=>item.open===item.high&&item.high===item.low&&item.low===item.close)?'当前周期价格未发生变化':'';}
function stockChartDefaultVisible(){return 60;}
function resetStockChartViews(intervalSeconds){const visibleCount=stockChartDefaultVisible(intervalSeconds);for(const view of Object.values(state.stockChartViews)){view.visibleCount=visibleCount;view.offset=0;view.dragging=false;view.pointerId=null;}}
function stockChartWindow(candles,view){const visibleCount=Math.max(1,Math.min(candles.length,view.visibleCount||candles.length)),offset=Math.max(0,Math.min(view.offset||0,candles.length-visibleCount)),end=candles.length-offset;view.visibleCount=visibleCount;view.offset=offset;return{visible:candles.slice(end-visibleCount,end),start:end-visibleCount,end};}
function stockCandleSummary(candles,stock){const latest=candles[candles.length-1],first=candles[0],highest=Math.max(...candles.map((item)=>item.high)),lowest=Math.min(...candles.map((item)=>item.low)),amplitude=highest-lowest,amplitudeRate=lowest>0?amplitude/lowest*100:0,currentPrice=Number(stock?.currentPrice||latest.close),changeRate=first.open>0?(currentPrice-first.open)/first.open*100:0,notice=stockCandleNotice(stock,candles);return`最新价 ${number(currentPrice)} · 涨跌幅 ${changeRate>0?'+':''}${changeRate.toFixed(2)}% · 开 ${number(latest.open)} · 高 ${number(latest.high)} · 低 ${number(latest.low)} · 收 ${number(latest.close)} · 区间最高 ${number(highest)} · 最低 ${number(lowest)} · 振幅 ${number(amplitude)} / ${amplitudeRate.toFixed(2)}% · 成交量 ${number(latest.volume)} · 成交额 ${number(latest.turnover)}${notice?` · ${notice}`:''}`;}
function stockTimeTicks(visible,x,height){const count=Math.min(7,visible.length),indexes=Array.from({length:count},(_,position)=>Math.round(position*(visible.length-1)/Math.max(1,count-1)));return indexes.map((index,position)=>`<text x="${x(index)}" y="${height-12}" text-anchor="${position===0?'start':position===count-1?'end':'middle'}" class="stockChartAxis">${escapeHtml(candleTime(visible[index].startAt,state.stockCandlePeriod))}</text>`).join('');}
function stockMovingAverages(candles,periods=[5,10,20,60]) {
  return periods.map((period) => {
    let sum=0;
    const values=candles.map((candle,index) => {
      sum+=candle.close;
      if(index>=period)sum-=candles[index-period].close;
      return index+1>=period?sum/period:null;
    });
    return {period,values};
  });
}
function stockChartOverlays(candles,windowData,x,y,width,left,right,top,priceBottom) {
  const colors=['#efb800','#ec40c8','#289cde','#258b36'];
  const averages=stockMovingAverages(candles);
  const lines=averages.map((average,index) => {
    const values=average.values.slice(windowData.start,windowData.end),line=stockPolylineSegments(windowData.visible,values,(value,position)=>`${x(position)},${Math.max(top,Math.min(priceBottom,y(value)))}`,`fill="none" stroke="${colors[index]}" stroke-width="1.2"`);
    const latest=average.values[windowData.end-1];
    return `${state.stockChartAverage===false?'':line}<text x="${left+index*160}" y="16" class="stockChartAverageLabel" fill="${colors[index]}">MA${average.period}: ${latest===null?'—':latest.toFixed(2)}</text>`;
  }).join('');
  const visible=windowData.visible;
  const highest=Math.max(...visible.map((item)=>item.high)),lowest=Math.min(...visible.map((item)=>item.low));
  const labels=[{price:highest,index:visible.findIndex((item)=>item.high===highest),offset:-8},{price:lowest,index:visible.findIndex((item)=>item.low===lowest),offset:16}].map((mark) => {
    const cx=x(mark.index),cy=y(mark.price),toLeft=cx>(width-left-right)/2+left,end=cx+(toLeft?-24:24);
    return `<line x1="${cx}" y1="${cy}" x2="${end}" y2="${cy}" class="stockChartExtremeLine"/><text x="${end}" y="${Math.max(top+12,Math.min(priceBottom-2,cy+mark.offset))}" text-anchor="${toLeft?'end':'start'}" class="stockChartExtremeLabel">${escapeHtml(number(mark.price))}</text>`;
  }).join('');
  const grid=Array.from({length:5},(_,index)=>{const cx=left+(index+1)*(width-left-right)/6;return `<line x1="${cx}" y1="${top}" x2="${cx}" y2="${priceBottom}" class="stockChartGrid"/>`;}).join('');
  return grid+lines+labels;
}
function stockChartIndicator(candles,kind) {
  return candles.map((item,index) => {
    if(kind==='rsi') {
      if(index<14)return null;
      let gains=0,losses=0;
      for(let position=index-13;position<=index;position+=1){const change=candles[position].close-candles[position-1].close;gains+=Math.max(0,change);losses+=Math.max(0,-change);}
      return gains+losses===0?50:gains/(gains+losses)*100;
    }
    if(index<19)return null;
    const prices=candles.slice(index-19,index+1).map((candle)=>(candle.high+candle.low+candle.close)/3),mean=prices.reduce((sum,price)=>sum+price,0)/20,deviation=prices.reduce((sum,price)=>sum+Math.abs(price-mean),0)/20;
    return deviation?(prices[19]-mean)/(.015*deviation):0;
  });
}
function stockChartLowerPanels(candles,windowData,x,width,left,right,volumeTop,bottom,height) {
  const averages=stockMovingAverages(candles.map((item)=>({close:item.volume})),[5,10]),maxVolume=Math.max(1,...windowData.visible.map((item)=>item.volume)),volumeY=(value)=>bottom-value*(bottom-volumeTop)/maxVolume;
  const lines=averages.map((average,index)=>stockPolylineSegments(windowData.visible,average.values.slice(windowData.start,windowData.end),(value,position)=>`${x(position)},${Math.max(volumeTop,volumeY(value))}`,`fill="none" stroke="${index?'#e333c7':'#666'}" stroke-width="1"`)).join('');
  const latest=windowData.visible[windowData.visible.length-1],legend=`<text x="${left}" y="${volumeTop-8}" class="stockChartVolumeLegend">成交量 ${escapeHtml(number(latest.volume))}${averages.map((average)=>` · 均量${average.period} ${average.values[windowData.end-1]===null?'—':number(average.values[windowData.end-1])}`).join('')}</text>`;
  const values=stockChartIndicator(candles,state.stockChartIndicator||'cci').slice(windowData.start,windowData.end),valid=values.filter((value)=>value!==null),min=Math.min(-100,...valid),max=Math.max(100,...valid),panelTop=bottom+32,panelBottom=height-32,indicatorY=(value)=>panelTop+(max-value)*(panelBottom-panelTop)/(max-min);
  const indicatorLine=stockPolylineSegments(windowData.visible,values,(value,index)=>`${x(index)},${indicatorY(value)}`,'fill="none" stroke="#92999f" stroke-width="1"'),label=state.stockChartIndicator==='rsi'?'RSI':'CCI',last=values[values.length-1];
  return legend+lines+`<line x1="${left}" y1="${panelTop}" x2="${width-right}" y2="${panelTop}" class="stockChartGrid"/><line x1="${left}" y1="${indicatorY(0)}" x2="${width-right}" y2="${indicatorY(0)}" class="stockChartGrid"/><text x="${left}" y="${panelTop-8}" class="stockChartAxis">${label}: ${last===null?'—':last.toFixed(2)}</text>${indicatorLine}`;
}
function adjustStockChartZoom(viewName,direction) {
  const view=state.stockChartViews[viewName],total=validCandles(state.stockCandles).length;
  if(!total)return;
  view.visibleCount=Math.max(Math.min(30,total),Math.min(total,view.visibleCount+(direction==='out'?1:-1)*Math.max(1,Math.ceil(view.visibleCount*.2))));
  view.offset=Math.min(view.offset,Math.max(0,total-view.visibleCount));
  renderStockCandles();
}
function renderCandleChart(container,candles,{large=false,viewName=large?'modal':'main'}={}){const stock=state.quotes.find((item)=>Number(item.id)===Number(state.selectedStockId)),view=state.stockChartViews[viewName],windowData=stockChartWindow(candles,view),visible=windowData.visible,currentPrice=Number(stock?.currentPrice||visible[visible.length-1].close),domain=stockPriceDomain(visible,currentPrice),width=large?1200:900,height=large?760:540,left=62,right=70,top=22,priceBottom=large?490:315,volumeTop=large?520:335,bottom=large?610:395,plotWidth=width-left-right,maxVolume=Math.max(1,...visible.map((item)=>item.volume)),x=(index)=>left+(index+.5)*plotWidth/visible.length,y=(price)=>stockPriceY(price,domain,top,priceBottom),volumeY=(volume)=>bottom-volume*(bottom-volumeTop)/maxVolume,bodyWidth=Math.max(1,Math.min(large?8:6,plotWidth/visible.length*.62)),priceTicks=stockPriceTicks(domain),grid=priceTicks.map((tick)=>{const gy=y(tick.value);return`<line x1="${left}" y1="${gy}" x2="${width-right}" y2="${gy}" class="stockChartGrid"/><text x="${left-8}" y="${gy+4}" text-anchor="end" class="stockChartAxis">${escapeHtml(tick.label)}</text>`;}).join(''),ticks=stockTimeTicks(visible,x,height),marks=visible.map((item,index)=>{const cx=x(index),className=item.close>=item.open?'stockCandleUp':'stockCandleDown',body=stockCandleBody(item.open,item.close,y),tooltip=`${new Date(item.startAt).toLocaleString('zh-CN',{hour12:false})} 开 ${number(item.open)} 高 ${number(item.high)} 低 ${number(item.low)} 收 ${number(item.close)} 成交量 ${number(item.volume)} 成交额 ${number(item.turnover)}`,bodyMark=body.doji?`<line x1="${cx-bodyWidth/2}" y1="${body.priceY}" x2="${cx+bodyWidth/2}" y2="${body.priceY}" class="${className} stockCandleDoji"/>`:`<rect x="${cx-bodyWidth/2}" y="${body.top}" width="${bodyWidth}" height="${body.height}" class="${className}"/>`;return`<g class="stockCandleMark" tabindex="0"><title>${escapeHtml(tooltip)}</title><line x1="${cx}" y1="${y(item.high)}" x2="${cx}" y2="${y(item.low)}" class="${className}"/>${bodyMark}<rect x="${cx-bodyWidth/2}" y="${volumeY(item.volume)}" width="${bodyWidth}" height="${Math.max(1,bottom-volumeY(item.volume))}" class="${className} stockVolumeBar"/></g>`;}).join(''),currentY=y(currentPrice),label=`${stock?.code||'股票'} ${stock?.name||''} K线图`;container.innerHTML=`<svg class="stockChartSvg${large?' stockChartSvgLarge':''}" viewBox="0 0 ${width} ${height}" role="img" aria-label="${escapeHtml(label)}" data-chart-svg data-view-name="${viewName}">${grid}<line x1="${left}" y1="${priceBottom}" x2="${width-right}" y2="${priceBottom}" class="stockChartGrid"/><line x1="${left}" y1="${bottom}" x2="${width-right}" y2="${bottom}" class="stockChartGrid"/>${marks}${stockChartLowerPanels(candles,windowData,x,width,left,right,volumeTop,bottom,height)}${stockChartOverlays(candles,windowData,x,y,width,left,right,top,priceBottom)}${ticks}<line x1="${left}" y1="${currentY}" x2="${width-right}" y2="${currentY}" class="stockCurrentPriceLine"/><rect x="${width-right+4}" y="${currentY-11}" width="64" height="22" rx="3" class="stockCurrentPriceLabel"/><text x="${width-right+36}" y="${currentY+4}" text-anchor="middle" class="stockCurrentPriceText">${escapeHtml(number(currentPrice))}</text><g class="stockCrosshair" data-crosshair style="display:none;pointer-events:none"><line data-cross-x y1="${top}" y2="${bottom}" class="stockCrosshairLine"/><line data-cross-y x1="${left}" x2="${width-right}" class="stockCrosshairLine"/><circle data-cross-dot r="4" class="stockCrosshairDot"/><g data-cross-tooltip class="stockChartTooltip"><rect width="210" height="116" rx="0"/><text x="10" y="18" data-tip-time></text><text x="10" y="36" data-tip-ohlc></text><text x="10" y="54" data-tip-close></text><text x="10" y="72" data-tip-volume></text><text x="10" y="88" data-tip-turnover></text><text x="10" y="106" data-tip-change></text></g></g><rect x="${left}" y="${top}" width="${plotWidth}" height="${bottom-top}" class="stockChartInteraction" data-chart-interaction/></svg>`;bindCandleChart(container,{candles,visible,viewName,width,left,right,top,bottom,priceBottom,plotWidth,x,y});return visible;}
function bindCandleChart(container,chart){const svg=$('[data-chart-svg]',container),surface=$('[data-chart-interaction]',container),view=state.stockChartViews[chart.viewName],cross=$('[data-crosshair]',container);if(!svg||!surface)return;const point=(event)=>{const rect=svg.getBoundingClientRect();return{x:(event.clientX-rect.left)*chart.width/rect.width,y:(event.clientY-rect.top)*(Number(svg.viewBox.baseVal.height)||430)/rect.height};};surface.addEventListener('wheel',(event)=>{event.preventDefault();const total=chart.candles.length,min=Math.min(30,total),old=view.visibleCount,newCount=Math.max(min,Math.min(total,old+(event.deltaY>0?Math.max(1,Math.ceil(old*.2)):-Math.max(1,Math.ceil(old*.2)))));if(newCount===old)return;const p=point(event),ratio=Math.max(0,Math.min(1,(p.x-chart.left)/chart.plotWidth)),oldStart=total-view.offset-old,anchor=oldStart+ratio*old,newStart=anchor-ratio*newCount;view.visibleCount=newCount;view.offset=view.offset===0?0:Math.max(0,Math.min(total-newCount,Math.round(total-newCount-newStart)));renderStockCandles();},{passive:false});surface.addEventListener('pointerdown',(event)=>{if(event.button!==0)return;view.dragging=true;view.pointerId=event.pointerId;view.startX=event.clientX;view.startOffset=view.offset;surface.setPointerCapture(event.pointerId);container.classList.add('dragging');});surface.addEventListener('pointermove',(event)=>{const p=point(event);if(view.dragging&&event.pointerId===view.pointerId){const rect=svg.getBoundingClientRect(),distance=event.clientX-view.startX,delta=Math.round(distance/(rect.width*chart.plotWidth/chart.width)*view.visibleCount);view.offset=Math.max(0,Math.min(chart.candles.length-view.visibleCount,view.startOffset+delta));svg.style.transform=`translateX(${distance}px)`;return;}const index=Math.max(0,Math.min(chart.visible.length-1,Math.round((p.x-chart.left)/chart.plotWidth*chart.visible.length-.5))),item=chart.visible[index],cx=chart.x(index),cy=chart.y(item.close),tooltipX=Math.min(chart.width-chart.right-215,Math.max(chart.left+5,p.x+12)),tooltipY=Math.min(chart.bottom-120,Math.max(chart.top+5,p.y+12));cross.style.display='';$('[data-cross-x]',cross).setAttribute('x1',cx);$('[data-cross-x]',cross).setAttribute('x2',cx);$('[data-cross-y]',cross).setAttribute('y1',cy);$('[data-cross-y]',cross).setAttribute('y2',cy);$('[data-cross-dot]',cross).setAttribute('cx',cx);$('[data-cross-dot]',cross).setAttribute('cy',cy);$('[data-cross-tooltip]',cross).setAttribute('transform',`translate(${tooltipX} ${tooltipY})`);$('[data-tip-time]',cross).textContent=new Date(item.startAt).toLocaleString('zh-CN',{hour12:false});$('[data-tip-ohlc]',cross).textContent=`开 ${number(item.open)}  高 ${number(item.high)}  低 ${number(item.low)}`;$('[data-tip-close]',cross).textContent=`收 ${number(item.close)}`;$('[data-tip-volume]',cross).textContent=`成交量 ${number(item.volume)}`;$('[data-tip-turnover]',cross).textContent=`成交额 ${number(item.turnover)}`;const change=item.close-item.open;$('[data-tip-change]',cross).textContent=`涨跌 ${change>=0?'+':''}${number(change)} / ${(item.open?change/item.open*100:0).toFixed(2)}%`;});const endDrag=(event)=>{if(event.pointerId!==view.pointerId)return;view.dragging=false;view.pointerId=null;svg.style.transform='';container.classList.remove('dragging');renderStockCandles();};surface.addEventListener('pointerup',endDrag);surface.addEventListener('pointercancel',endDrag);surface.addEventListener('pointerleave',()=>{if(!view.dragging)cross.style.display='none';});}
function setStockChartState(title,subtitle){$('#stockChartSummary').textContent=title;$('#stockChart').innerHTML=emptyState(title,subtitle);if(!$('#stockChartModal').hidden){$('#stockChartModalSummary').textContent=title;$('#stockChartModalCanvas').innerHTML=emptyState(title,subtitle);}}
function renderStockCandles(){const data=state.stockCandles,candles=validCandles(data),expand=$('#stockChartExpand'),stock=state.quotes.find((item)=>Number(item.id)===Number(state.selectedStockId));$$('[data-stock-period]').forEach((button)=>button.classList.toggle('active',button.dataset.stockPeriod===state.stockCandlePeriod));expand.disabled=!candles.length;if(!candles.length){setStockChartState(data?'当前周期暂无有效 K 线':'选择股票后读取 K 线',data?'暂无 K 线数据':'等待选择行情');return;}const mainVisible=renderCandleChart($('#stockChart'),candles,{viewName:'main'});$('#stockChartSummary').textContent=stockCandleSummary(mainVisible,stock);if(!$('#stockChartModal').hidden){$('#stockChartModalIdentity').textContent=`${stock?.code||''} · ${stock?.name||''}`;const modalVisible=renderCandleChart($('#stockChartModalCanvas'),candles,{large:true,viewName:'modal'});$('#stockChartModalSummary').textContent=stockCandleSummary(modalVisible,stock);}}
function openStockChartModal(){const candles=validCandles(state.stockCandles),stock=state.quotes.find((item)=>Number(item.id)===Number(state.selectedStockId));if(!stock||!candles.length||state.stockCandleLoading)return;$('#stockChartModalIdentity').textContent=`${stock.code||''} · ${stock.name||''}`;openModal($('#stockChartModal'));renderStockCandles();}
function stockCandleRequestLimit(stockId,period){const cached=Number(state.stockCandles?.stockId)===stockId&&state.stockCandles?.period===period&&asList(state.stockCandles,['candles']).length;return period==='5m'&&!cached?10000:1000;}
function mergeStockCandleHistory(data,stockId,period){if(!data)return{candles:[]};if(Number(state.stockCandles?.stockId)!==stockId||state.stockCandles?.period!==period)return data;const merged=new Map([...asList(state.stockCandles,['candles']),...asList(data,['candles'])].map((candle)=>[candle.startAt,candle]));return{...data,candles:[...merged.values()].sort((a,b)=>new Date(a.startAt)-new Date(b.startAt)).slice(-10000)};}
async function loadStockCandles(){const stockId=Number(state.selectedStockId),period=state.stockCandlePeriod,limit=stockCandleRequestLimit(stockId,period);if(!stockId||!state.user||!marketIsActive())return;if(marketChartClosed()&&Number(state.stockCandles?.stockId)===stockId&&state.stockCandles?.period===period){renderStockCandles();return;}invalidateStockCandles();const request=state.stockCandleRequest,controller=new AbortController();state.stockCandleController=controller;state.stockCandleLoading=true;$('#stockChartExpand').disabled=true;setStockChartState('正在读取 K 线...','正在读取 K 线');try{const data=await api(`/api/shop/market/stocks/${encodeURIComponent(stockId)}/candles?period=${encodeURIComponent(period)}&limit=${limit}`,{signal:controller.signal});if(request!==state.stockCandleRequest||stockId!==Number(state.selectedStockId)||period!==state.stockCandlePeriod)return;if(marketChartClosed()&&Number(state.stockCandles?.stockId)===stockId&&state.stockCandles?.period===period){renderStockCandles();return;}state.stockCandles=mergeStockCandleHistory(data,stockId,period);renderStockCandles();}catch(error){if(error.name==='AbortError'||request!==state.stockCandleRequest)return;state.stockCandles=null;$('#stockChartExpand').disabled=true;const legacy=error.status===404||error.code==='INVALID_PERIOD';setStockChartState(legacy?'当前暂不支持该 K 线周期':chineseErrorMessage(error.message, 'K 线读取失败，请稍后重试'),legacy?'该周期暂不可用':'K 线读取失败');}finally{if(request===state.stockCandleRequest){state.stockCandleLoading=false;state.stockCandleController=null;}}}
function selectMarketStock(stockId){const id=Number(stockId);if(!state.quotes.some((stock)=>Number(stock.id)===id))return;if(state.stockQuoteFilter==='watchlist'&&!quoteItems().some((stock)=>Number(stock.id)===id)){state.stockQuoteFilter='all';$$('[data-stock-filter]').forEach((button)=>button.classList.toggle('active',button.dataset.stockFilter==='all'));}state.selectedStockId=id;state.stockCandles=null;resetStockChartViews();renderQuotes();renderStockCarousels();renderStockDetail();loadStockCandles();}
function selectedHolding(stockId){return asList(state.portfolio,['items']).find((item)=>Number(item.stockId)===Number(stockId));}
function renderStockDetail(){const stock=state.quotes.find((item)=>Number(item.id)===Number(state.selectedStockId));if(!stock){$('#stockDetail').innerHTML='<span>选择行情查看详情</span>';return;}const change=Number(stock.lastChange||0),changeBps=Number(stock.lastChangeBps||0),status=stock.paused?'暂停':state.marketOverview?.market?.isOpen?'可交易':'闭市';$('#stockDetail').innerHTML=`<strong>${escapeHtml(stock.code)}</strong><span>${escapeHtml(stock.name)}</span><b>${number(stock.currentPrice)}</b><i class="${change>=0?'stockGain':'stockLoss'}">${change>0?'+':''}${number(change)} / ${changeBps>0?'+':''}${(changeBps/100).toFixed(2)}%</i><em>${escapeHtml(status)}</em>`;}
function renderStockDetailModal(){const stock=state.quotes.find((item)=>Number(item.id)===Number(state.selectedStockId)),content=$('#stockDetailModalContent'),watchButton=$('#stockDetailWatchButton');if(!stock){content.innerHTML='<span class="stockLoss"><small>状态</small><b>当前股票已不在行情中</b></span>';watchButton.disabled=true;return;}const relative=Math.round((Number(stock.currentPrice)/Number(stock.basePrice)-1)*10000),holding=selectedHolding(stock.id),watched=new Set(asList(state.marketOverview,['watchlist']).map(Number)),status=stock.paused?'暂停交易':state.marketOverview?.market?.isOpen?'可交易':'市场闭市';content.innerHTML=`<span><small>股票</small><b>${escapeHtml(stock.code)} · ${escapeHtml(stock.name)}</b></span><span><small>当前价 / 基准价</small><b>${number(stock.currentPrice)} / ${number(stock.basePrice)}（${(relative/100).toFixed(2)}%）</b></span><span class="stockModalWide"><small>说明</small><b>${escapeHtml(stock.description||'暂无说明')}</b></span><span><small>交易状态</small><b>${escapeHtml(status)}</b></span><span><small>最近来源</small><b>${stock.lastSource==='manual'?'人为调价':'自动定价'}</b></span><span><small>最近周期成交</small><b>${number(stock.volumeQuantity)} 件 / ${number(stock.volumeAmount)} 币</b></span><span><small>信号</small><b>成交 ${(Number(stock.volumeChangeBps)/100).toFixed(2)}% · 随机 ${(Number(stock.randomChangeBps)/100).toFixed(2)}%</b></span><span><small>手续费</small><b>${(Number(stock.feeBps)/100).toFixed(2)}%</b></span><span><small>周期</small><b>${number(stock.periodSeconds)} 秒</b></span><span><small>持仓</small><b>${number(holding?.quantity||0)} 股</b></span><span><small>自选状态</small><b>${watched.has(Number(stock.id))?'已加入自选':'未加入自选'}</b></span><span><small>更新时间</small><b>${escapeHtml(dateTime(stock.lastPricedAt||stock.updatedAt))}</b></span>`;watchButton.disabled=false;watchButton.dataset.stockWatchModal=String(stock.id);watchButton.textContent=watched.has(Number(stock.id))?'取消自选':'加入自选';}
function openStockDetail(stockId){selectMarketStock(stockId);renderStockDetailModal();openModal($('#stockDetailModal'));}
function openStockTrade(stockId,direction){if(!state.user){openAuth('login');toast('登录后才能进行股市交易','error','需要登录');return;}const stock=state.quotes.find((item)=>Number(item.id)===Number(stockId));if(!stock)return;state.stockTradeDraft={stockId:Number(stockId),direction:direction==='sell'?'sell':'buy'};$('#stockTradeModalTitle').textContent=direction==='sell'?'确认卖出':'确认买入';$('#stockTradeModalIdentity').innerHTML=`<strong>${escapeHtml(stock.code)}</strong><span>${escapeHtml(stock.name)}</span><b>${direction==='sell'?'卖出':'买入'}</b>`;$('#stockTradeQuantity').value='1';renderStockTradeEstimate();openModal($('#stockTradeModal'));}
function renderMarket(){const portfolio=state.portfolio||{balance:0,marketValue:0,totalAssets:0,items:[]},overview=state.marketOverview||{},index=overview.index||{};$('#stockBalance').textContent=number(portfolio.balance);$('#stockMarketValue').textContent=number(portfolio.marketValue);$('#stockTotalAssets').textContent=number(portfolio.totalAssets);$('#stockPortfolioCost').textContent=number(portfolio.portfolioCost);$('#stockUnrealizedProfit').textContent=`${number(portfolio.unrealizedProfit)}（${(Number(portfolio.unrealizedReturnBps||0)/100).toFixed(2)}%）`;$('#stockRealizedProfit').textContent=number(portfolio.realizedProfit);$('#stockTotalFees').textContent=number(portfolio.totalFees);$('#stockIndexValue').textContent=Number(index.value||1000).toFixed(2);$('#stockIndexChange').textContent=`${Number(index.changeBps)>0?'+':''}${(Number(index.changeBps||0)/100).toFixed(2)}% · 涨${number(index.riseCount)} 跌${number(index.fallCount)} 平${number(index.flatCount)}`;renderStockCarousels();$('#stockAnnouncements').innerHTML=asList(overview,['announcements']).map((item)=>`<button type="button" class="stockAnnouncementRow" data-stock-announcement-id="${escapeHtml(item.id)}"><span><strong>${escapeHtml(item.title)}</strong><small>点击查看公告内容</small></span><time>${escapeHtml(dateTime(item.startsAt||item.createdAt))}</time></button>`).join('')||emptyState('暂无市场公告','暂无市场公告');$('#stockRiskList').innerHTML=asList(portfolio,['risks']).map((item)=>`<article class="stockHoldingRow"><strong>${escapeHtml(item.code)}</strong><span>${escapeHtml(chineseErrorMessage(item.message, '当前存在需关注的交易风险'))}</span></article>`).join('')||emptyState('当前未触发额外风险提示','暂无风险提示');renderMarketSummary();renderQuotes();renderStockDetail();renderHoldings();renderTrades();renderReceipt();if(!$('#stockDetailModal').hidden)renderStockDetailModal();if(!$('#stockTradeModal').hidden)renderStockTradeEstimate();}
function marketError(error){state.quotes=[];state.portfolio=null;state.marketOverview=null;state.stockTrades=[];$('#stockBalance').textContent='—';$('#stockMarketValue').textContent='—';$('#stockTotalAssets').textContent='—';$('#stockLastRefresh').textContent='失败';$('[data-stock-track="quotes"]').innerHTML=emptyState(chineseErrorMessage(error.message,'行情读取失败，请稍后重试'),'行情读取失败');$('[data-stock-track="gainers"]').innerHTML=emptyState(chineseErrorMessage(error.message,'行情读取失败，请稍后重试'),'行情读取失败');$('[data-stock-track="losers"]').innerHTML=emptyState(chineseErrorMessage(error.message,'行情读取失败，请稍后重试'),'行情读取失败');$('#stockHoldingList').innerHTML=emptyState(chineseErrorMessage(error.message,'持仓读取失败，请稍后重试'),'持仓读取失败');$('#stockTradeList').innerHTML=emptyState(chineseErrorMessage(error.message,'交易记录读取失败，请稍后重试'),'交易记录读取失败');$('#stockDetail').innerHTML=emptyState(chineseErrorMessage(error.message,'详情读取失败，请稍后重试'),'详情读取失败');if(!$('#stockDetailModal').hidden)renderStockDetailModal();if(!$('#stockTradeModal').hidden)renderStockTradeEstimate();}
async function loadMarket({silent=false}={}){if(state.marketLoading)return;if(!silent){$('[data-stock-track="quotes"]').innerHTML=emptyState('正在读取市场行情','正在读取行情');$('[data-stock-track="gainers"]').innerHTML=emptyState('正在读取排行榜','正在读取排行榜');$('[data-stock-track="losers"]').innerHTML=emptyState('正在读取排行榜','正在读取排行榜');$('#stockHoldingList').innerHTML=emptyState(state.user?'正在读取持仓':'登录后查看个人持仓',state.user?'正在读取持仓':'请先登录');$('#stockTradeList').innerHTML=emptyState(state.user?'正在读取交易记录':'登录后查看个人交易记录',state.user?'正在读取交易记录':'请先登录');}state.marketLoading=true;try{const overview=await api(state.user?'/api/shop/market/overview':'/api/shop/market/public-overview'),trades=state.user?await api('/api/shop/market/trades?limit=50'):[];state.marketOverview=overview||{};state.quotes=asList(overview,['quotes']);state.portfolio=overview?.portfolio||{balance:0,marketValue:0,totalAssets:0,items:[]};state.stockTrades=asList(trades).slice(0,50);if(!state.quotes.some((stock)=>Number(stock.id)===Number(state.selectedStockId)))state.selectedStockId=state.quotes[0]?.id||null;renderMarket();if(!silent)maybeOpenStockAnnouncement();if(state.selectedStockId)loadStockCandles();}catch(error){marketError(error);}finally{state.marketLoading=false;if(!marketIsActive())return;startMarketAutoRefresh();}}
async function tradeStock(button){const draft=state.stockTradeDraft;if(!draft)return;const stock=state.quotes.find((item)=>Number(item.id)===Number(draft.stockId)),quantity=Number($('#stockTradeQuantity').value);if(!state.marketOverview?.market?.isOpen){toast('证券市场当前闭市','error');renderStockTradeEstimate();return;}if(!stock||stock.paused){toast('该股票当前暂停交易','error');renderStockTradeEstimate();return;}const estimate=stockMath(stock,quantity);if(!estimate){toast('请输入正整数交易数量','error');renderStockTradeEstimate();return;}await withBusy(button,async()=>{try{const result=await api(`/api/shop/market/stocks/${stock.id}/${draft.direction}`,{method:'POST',headers:{'Idempotency-Key':uuid()},body:JSON.stringify({quantity})});state.stockReceipt=result;closeModal($('#stockTradeModal'));state.stockTradeDraft=null;renderReceipt();openModal($('#stockReceiptPanel'));toast(result.idempotent?'交易请求已按原成交回执返回':'交易已成交');await Promise.all([loadMarket(),loadMe()]);}catch(error){toast(error.message,'error');}});}
