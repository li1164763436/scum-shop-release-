const INSURANCE_VEHICLES_PER_PAGE = 6;
let insuranceVehiclePage = 1;
let insuranceVehicleGroups = [];
let insuranceStrategyGroups = [];
let selectedInsuranceVehicleId = null;
let selectedInsuranceStrategyId = null;
let pendingInsuranceStrategyId = null;

function insuranceStatusLabel(status) {
  return ({ active: '保障中', expired: '已到期', suspended: '已暂停' })[status] || '未知';
}

function activeInsurancePolicy(policy) {
  return policy.insuranceStatus === 'active' && (!policy.expiresAt || new Date(policy.expiresAt).getTime() > Date.now());
}

function lockedVehicleName(vehicle) {
  return vehicle.displayName || vehicle.modelName || vehicle.vehicleType || `载具 #${vehicle.sourceVehicleId || vehicle.vehicleId}`;
}

function insuranceCoordinate(value) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return '—';
  return parsed.toFixed(2).replace(/\.00$/, '').replace(/(\.\d)0$/, '$1');
}

function insuranceGameCoordinates(vehicle) {
  if (vehicle.worldX == null || vehicle.worldY == null || vehicle.worldZ == null) return '暂不可用';
  return `X：${insuranceCoordinate(vehicle.worldX)} Y：${insuranceCoordinate(vehicle.worldY)} Z:${insuranceCoordinate(vehicle.worldZ)}`;
}

function normalizedInsuranceVehicleCode(value) {
  return String(value || '').trim().toLowerCase().replace(/^#spawnvehicle\s+/, '').replace(/^vehicle:/, '');
}

function insuranceVehicleGroupKey(vehicle) {
  return normalizedInsuranceVehicleCode(vehicle.sourceAssetId || vehicle.sourceVehicleAlias || vehicle.vehicleType || vehicle.modelName || vehicle.vehicleCode || vehicle.vehicleId);
}

function insuranceProductForVehicle(vehicle, products) {
  const candidates = [vehicle.sourceAssetId, vehicle.sourceVehicleAlias, vehicle.vehicleCode, vehicle.vehicleType, vehicle.modelName]
    .map(normalizedInsuranceVehicleCode)
    .filter(Boolean);
  return products.find((product) => candidates.includes(normalizedInsuranceVehicleCode(product.itemId))) || null;
}

function groupedInsuranceVehicles(vehicles, products) {
  const groups = new Map();
  vehicles.forEach((vehicle) => {
    const key = insuranceVehicleGroupKey(vehicle);
    if (!groups.has(key)) {
      const product = insuranceProductForVehicle(vehicle, products);
      groups.set(key, { key, name: product?.name || lockedVehicleName(vehicle), product, vehicles: [] });
    }
    groups.get(key).vehicles.push(vehicle);
  });
  return [...groups.values()];
}

function insuranceProductForStrategy(strategy, products) {
  const byProductId = products.find((product) => strategy.productId && String(product.productId) === String(strategy.productId));
  if (byProductId) return byProductId;
  const candidates = [strategy.vehicleCode, strategy.vehicleType].map(normalizedInsuranceVehicleCode).filter(Boolean);
  return products.find((product) => candidates.includes(normalizedInsuranceVehicleCode(product.itemId))) || null;
}

function groupedInsuranceStrategies(strategies, products) {
  const groups = new Map();
  strategies.forEach((strategy) => {
    const key = strategy.productId ? `product:${strategy.productId}` : normalizedInsuranceVehicleCode(strategy.vehicleCode || strategy.vehicleType) || `strategy:${strategy.id}`;
    if (!groups.has(key)) {
      const product = insuranceProductForStrategy(strategy, products);
      groups.set(key, { key, name: product?.name || strategy.vehicleType || strategy.name, product, strategies: [] });
    }
    groups.get(key).strategies.push(strategy);
  });
  return [...groups.values()];
}

function insuranceVehicleGroupCovered(group) {
  const policies = (state.vehicleInsurance?.policies || []).filter(activeInsurancePolicy);
  const vehicleCodes = group.vehicles.flatMap((vehicle) => [vehicle.sourceAssetId, vehicle.sourceVehicleAlias, vehicle.vehicleCode, vehicle.vehicleType, vehicle.modelName])
    .map(normalizedInsuranceVehicleCode)
    .filter(Boolean);
  return policies.some((policy) => vehicleCodes.includes(normalizedInsuranceVehicleCode(policy.vehicleCode)));
}

function vehicleClaimState(claim) {
  const status = claim?.fulfillmentStatus;
  if (!status) return { label: '立即索赔', disabled: false, tone: 'primary' };
  if (status === 'completed' || status === 'succeeded') return { label: '已赔付', disabled: true, tone: 'secondary' };
  if (status === 'uncertain') return { label: '需人工核验', disabled: true, tone: 'secondary' };
  if (status === 'failed' || status === 'cancelled') return { label: '重新索赔', disabled: false, tone: 'primary' };
  return { label: '等待移除旧车', disabled: true, tone: 'secondary' };
}

function latestInsuranceClaims() {
  const result = new Map();
  (state.vehicleInsurance?.claims || []).forEach((claim) => {
    if (!result.has(String(claim.vehicleId))) result.set(String(claim.vehicleId), claim);
  });
  return result;
}

function insuranceResponseData(data) {
  return {
    strategies: data.strategies || [],
    policies: data.policies || [],
    vehicles: data.vehicles || [],
    claims: data.claims || [],
    vehicleProducts: data.vehicleProducts || state.vehicleInsurance?.vehicleProducts || []
  };
}

function renderInsuranceVehicleCards() {
  const list = $('#insuranceVehicleList');
  const pagination = $('#insuranceVehiclePagination');
  if (!list || !pagination) return;
  const vehicles = state.vehicleInsurance?.vehicles || [];
  const products = state.vehicleInsurance?.vehicleProducts || [];
  insuranceVehicleGroups = groupedInsuranceVehicles(vehicles, products);
  const pages = Math.max(1, Math.ceil(insuranceVehicleGroups.length / INSURANCE_VEHICLES_PER_PAGE));
  insuranceVehiclePage = Math.min(Math.max(1, insuranceVehiclePage), pages);
  const start = (insuranceVehiclePage - 1) * INSURANCE_VEHICLES_PER_PAGE;
  const visible = insuranceVehicleGroups.slice(start, start + INSURANCE_VEHICLES_PER_PAGE);

  list.innerHTML = visible.length ? visible.map((group, offset) => {
    const index = start + offset;
    const image = group.product?.imagePath
      ? `<img src="${escapeHtml(group.product.imagePath)}" alt="${escapeHtml(group.name)}" loading="lazy">`
      : '<div class="insurance-vehicle-placeholder" aria-hidden="true"><span>SCUM</span><small>载具</small></div>';
    const covered = insuranceVehicleGroupCovered(group);
    return `<article class="insurance-vehicle-card" data-insurance-group="${index}" tabindex="0" role="button" aria-label="查看 ${escapeHtml(group.name)} 明细"><div class="insurance-vehicle-image">${image}</div><div class="insurance-vehicle-card-body"><h4>${escapeHtml(group.name)}</h4><div class="insurance-vehicle-card-facts"><div class="insurance-vehicle-card-meta"><span>数量</span><strong>${number(group.vehicles.length)}</strong></div><div class="insurance-vehicle-coverage ${covered ? 'insured' : 'uninsured'}"><span class="insurance-coverage-dot" aria-hidden="true"></span>${covered ? '已投保' : '未投保'}</div></div><button class="button ghost insurance-detail-button" type="button" data-insurance-group="${index}"><span>查看明细</span><span class="insurance-detail-arrow" aria-hidden="true">›</span></button></div></article>`;
  }).join('') : '<div class="insurance-shop-empty"><strong>暂无载具</strong><small>载具将根据 SCUM 载具同步结果显示；没有载具也可以购买保险</small></div>';

  pagination.hidden = insuranceVehicleGroups.length <= INSURANCE_VEHICLES_PER_PAGE;
  $('#insuranceVehiclePageStatus').textContent = `第 ${insuranceVehiclePage} / ${pages} 页`;
  $('#insuranceVehiclePrevious').disabled = insuranceVehiclePage <= 1;
  $('#insuranceVehicleNext').disabled = insuranceVehiclePage >= pages;
}

function renderInsuranceStrategyCards(strategies, products) {
  const list = $('#insuranceStrategyList');
  if (!list) return;
  insuranceStrategyGroups = groupedInsuranceStrategies(strategies, products);
  list.innerHTML = insuranceStrategyGroups.length ? insuranceStrategyGroups.map((group, index) => {
    const image = group.product?.imagePath
      ? `<img src="${escapeHtml(group.product.imagePath)}" alt="${escapeHtml(group.name)}" loading="lazy">`
      : '<div class="insurance-vehicle-placeholder" aria-hidden="true"><span>SCUM</span><small>载具</small></div>';
    return `<article class="insurance-plan-vehicle-card" data-insurance-strategy-group="${index}" tabindex="0" role="button" aria-label="查看 ${escapeHtml(group.name)} 可购买保单"><div class="insurance-plan-vehicle-image">${image}</div><div class="insurance-plan-vehicle-body"><div class="insurance-plan-vehicle-info"><h4><span>载具名称：</span>${escapeHtml(group.name)}</h4><div class="insurance-plan-vehicle-count"><span>可投保类型：</span><strong>${number(group.strategies.length)}</strong><small>种</small></div></div><button class="button ghost insurance-plan-detail-button" type="button" data-insurance-strategy-group="${index}"><span>查看明细</span><span aria-hidden="true">›</span></button></div></article>`;
  }).join('') : '<div class="insurance-shop-empty"><strong>暂无在售保险</strong><small>请等待管理员配置保险销售策略</small></div>';
}

function selectInsuranceStrategy(strategyId) {
  selectedInsuranceStrategyId = strategyId;
  const list = $('#insuranceStrategyDetailList');
  list?.querySelectorAll('[data-insurance-policy-option]').forEach((option) => {
    const selected = String(option.dataset.insurancePolicyOption) === String(strategyId);
    option.classList.toggle('selected', selected);
    option.setAttribute('aria-checked', String(selected));
  });
  const purchase = $('#insuranceStrategyPurchaseSelected');
  if (purchase) purchase.disabled = strategyId == null;
}

function openInsuranceStrategyDetail(index) {
  const group = insuranceStrategyGroups[Number(index)];
  if (!group) return;
  selectedInsuranceStrategyId = group.strategies[0]?.id ?? null;
  $('#insuranceStrategyDetailTitle').textContent = group.name;
  $('#insuranceStrategyDetailSummary').textContent = `同载具已合并 ${group.strategies.length} 份可购买保单`;
  $('#insuranceStrategyDetailImage').innerHTML = group.product?.imagePath
    ? `<img src="${escapeHtml(group.product.imagePath)}" alt="${escapeHtml(group.name)}">`
    : '<div class="insurance-vehicle-placeholder" aria-hidden="true"><span>SCUM</span><small>载具</small></div>';
  $('#insuranceStrategyDetailList').innerHTML = group.strategies.map((strategy, strategyIndex) => `<article class="insurance-policy-option${strategyIndex === 0 ? ' selected' : ''}" data-insurance-policy-option="${strategy.id}" tabindex="0" role="radio" aria-checked="${strategyIndex === 0}"><div class="insurance-policy-option-heading"><div><small>保单 ${String(strategyIndex + 1).padStart(2, '0')}</small><h4>${escapeHtml(strategy.name)}</h4></div><div class="insurance-policy-duration"><strong>${number(strategy.durationDays)}</strong><span>天</span></div></div><div class="insurance-policy-benefits"><span>累计赔付<strong>${number(strategy.totalClaimLimit)} 次</strong></span><span>每日赔付<strong>${number(strategy.dailyClaimLimit)} 次</strong></span><span>购买条件<strong>${escapeHtml(strategy.purchaseCondition || '无需绑定载具')}</strong></span></div><div class="insurance-policy-purchase"><small>保单价格</small><strong>${number(strategy.price)}<em>商城币</em></strong></div></article>`).join('');
  selectInsuranceStrategy(selectedInsuranceStrategyId);
  openModal($('#insuranceStrategyDetailModal'));
}

function renderActiveInsurancePolicies(policies) {
  const list = $('#insuranceActivePolicyList');
  if (!list) return;
  const active = policies.filter(activeInsurancePolicy);
  list.innerHTML = active.length ? active.map((policy) => `<article class="insurance-active-policy"><div><small>${escapeHtml(policy.policyNumber)}</small><strong>${escapeHtml(policy.strategyName || '载具保险')}</strong><span>${escapeHtml(policy.vehicleType || policy.vehicleCode || '适用载具')} · 至 ${escapeHtml(dateTime(policy.expiresAt))}</span></div><button class="button ghost" type="button" data-insurance-policy-detail="${policy.id}">查看详情</button></article>`).join('') : '<div class="insurance-shop-empty"><strong>暂无生效保单</strong><small>购买保险后将在这里查看保障详情</small></div>';
}

function openInsurancePolicyDetail(policyId) {
  const policy = (state.vehicleInsurance?.policies || []).find((item) => String(item.id) === String(policyId));
  if (!policy || !activeInsurancePolicy(policy)) { toast('该保单已到期或不可用', 'error'); return; }
  const remaining = Math.max(0, Number(policy.totalClaimLimit || 0) - Number(policy.totalClaimsUsed || 0));
  const dailyRemaining = Math.max(0, Number(policy.dailyClaimLimit || 0) - Number(policy.dailyClaimsUsed || 0));
  $('#insurancePolicyDetailTitle').textContent = policy.strategyName || '载具保险';
  $('#insurancePolicyDetailSummary').textContent = `保单号 ${policy.policyNumber} · 当前保障中`;
  $('#insurancePolicyDetailGrid').innerHTML = [
    ['保单状态', insuranceStatusLabel(policy.insuranceStatus)],
    ['保障载具', policy.vehicleType || policy.vehicleCode || '—'],
    ['载具代码', policy.vehicleCode || '—'],
    ['购买价格', `${number(policy.price)} 商城币`],
    ['生效时间', dateTime(policy.startsAt)],
    ['到期时间', dateTime(policy.expiresAt)],
    ['累计赔付', `${number(policy.totalClaimsUsed || 0)} / ${number(policy.totalClaimLimit)} 次`],
    ['累计剩余', `${number(remaining)} 次`],
    ['今日赔付', `${number(policy.dailyClaimsUsed || 0)} / ${number(policy.dailyClaimLimit)} 次`],
    ['今日剩余', `${number(dailyRemaining)} 次`],
    ['购买条件', policy.purchaseCondition || '无需绑定载具', 'wide']
  ].map(([label, value, width]) => `<div class="${width || ''}"><span>${label}</span><strong>${escapeHtml(String(value))}</strong></div>`).join('');
  openModal($('#insurancePolicyDetailModal'));
}

function renderVehicleInsurance() {
  const root = $('#page-insurance');
  if (!root) return;
  const data = state.vehicleInsurance || { strategies: [], policies: [], vehicles: [], claims: [], vehicleProducts: [] };
  const strategies = data.strategies || [];
  const policies = data.policies || [];
  const vehicles = data.vehicles || [];
  $('#insuranceBalance').textContent = number(state.user?.balance || 0);
  $('#insuranceVehicleCount').textContent = number(vehicles.length);
  $('#insuranceActiveCount').textContent = number(policies.filter(activeInsurancePolicy).length);
  renderActiveInsurancePolicies(policies);
  renderInsuranceVehicleCards();
  renderInsuranceStrategyCards(strategies, data.vehicleProducts || []);
}

function renderInsuranceVehicleDetail() {
  const group = insuranceVehicleGroups.find((item) => item.vehicles.some((vehicle) => String(vehicle.vehicleId) === String(selectedInsuranceVehicleId)));
  if (!group) return;
  const vehicle = group.vehicles.find((item) => String(item.vehicleId) === String(selectedInsuranceVehicleId)) || group.vehicles[0];
  selectedInsuranceVehicleId = vehicle.vehicleId;
  const claims = latestInsuranceClaims();
  const claim = claims.get(String(vehicle.vehicleId));
  const claimState = vehicleClaimState(claim);
  $('#insuranceVehicleDetailTitle').textContent = group.name;
  $('#insuranceVehicleDetailSummary').textContent = `同型号载具 ${group.vehicles.length} 辆 · 请选择需要索赔的载具`;
  $('#insuranceVehicleDetailImage').innerHTML = group.product?.imagePath
    ? `<img src="${escapeHtml(group.product.imagePath)}" alt="${escapeHtml(group.name)}">`
    : '<div class="insurance-vehicle-placeholder" aria-hidden="true"><span>SCUM</span><small>载具</small></div>';
  $('#insuranceVehicleDetailChoices').innerHTML = group.vehicles.map((item, index) => {
    const itemClaim = claims.get(String(item.vehicleId));
    const itemClaimState = vehicleClaimState(itemClaim);
    const active = String(item.vehicleId) === String(vehicle.vehicleId);
    return `<button class="insurance-vehicle-choice${active ? ' active' : ''}" type="button" role="option" aria-selected="${active}" data-insurance-vehicle-choice="${escapeHtml(String(item.vehicleId))}"><span class="insurance-vehicle-choice-index">${String(index + 1).padStart(2, '0')}</span><span class="insurance-vehicle-choice-content"><small>载具编号</small><strong>${escapeHtml(String(item.sourceVehicleId || item.vehicleId || '—'))}</strong></span><span class="insurance-vehicle-choice-status">${escapeHtml(itemClaim ? itemClaimState.label : '可选择')}</span></button>`;
  }).join('');
  $('#insuranceVehicleDetailGrid').innerHTML = [
    ['载具名称', lockedVehicleName(vehicle)],
    ['载具编号', String(vehicle.sourceVehicleId || vehicle.vehicleId || '—')],
    ['游戏坐标', insuranceGameCoordinates(vehicle), 'wide'],
    ['最后同步', dateTime(vehicle.sourceSynchronizedAt || vehicle.lastSeenAt)],
    ['索赔状态', claim ? `${claimState.label}${claim.claimNumber ? ` · ${claim.claimNumber}` : ''}` : '未提交索赔']
  ].map(([label, value, width]) => `<div class="${width || ''}"><span>${label}</span><strong>${escapeHtml(String(value))}</strong></div>`).join('');
  const button = $('#insuranceVehicleClaimConfirm');
  button.dataset.insuranceClaim = String(vehicle.vehicleId);
  button.textContent = claimState.label;
  button.className = `button ${claimState.tone}`;
  button.disabled = claimState.disabled;
}

function openInsuranceVehicleDetail(groupIndex) {
  const group = insuranceVehicleGroups[Number(groupIndex)];
  if (!group?.vehicles.length) return;
  selectedInsuranceVehicleId = group.vehicles[0].vehicleId;
  renderInsuranceVehicleDetail();
  openModal($('#insuranceVehicleDetailModal'));
}

function openInsurancePurchase(strategyId) {
  const strategy = (state.vehicleInsurance?.strategies || []).find((item) => String(item.id) === String(strategyId));
  if (!strategy) { toast('保险方案不存在或已停止销售', 'error'); return; }
  pendingInsuranceStrategyId = strategy.id;
  const detailModal = $('#insuranceStrategyDetailModal');
  if (detailModal && !detailModal.hidden) closeModal(detailModal);
  $('#insurancePurchaseTitle').textContent = strategy.name;
  $('#insurancePurchaseDescription').textContent = '购买时无需拥有或选择载具，保险自购买成功后立即生效。';
  $('#insurancePurchaseSummary').innerHTML = `<div><span>保险价格</span><strong>${number(strategy.price)} 商城币</strong></div><div><span>有效时长</span><strong>${number(strategy.durationDays)} 天</strong></div><div><span>累计赔付</span><strong>${number(strategy.totalClaimLimit)} 次</strong></div><div><span>每日赔付</span><strong>${number(strategy.dailyClaimLimit)} 次</strong></div>`;
  openModal($('#insurancePurchaseModal'));
}

async function submitInsuranceClaim(button) {
  const vehicle = (state.vehicleInsurance?.vehicles || []).find((item) => String(item.vehicleId) === String(button.dataset.insuranceClaim));
  if (!vehicle) { toast('索赔载具不存在或已离开上锁载具列表', 'error'); closeModal($('#insuranceVehicleDetailModal')); return; }
  button.disabled = true;
  button.textContent = '提交索赔...';
  try {
    const requestKey = `vehicle-insurance-claim-${Date.now()}-${globalThis.crypto?.randomUUID?.() || Math.random().toString(16).slice(2)}`;
    const data = await api('/api/shop/vehicle-insurance/claim', { method: 'POST', headers: { 'Idempotency-Key': requestKey }, body: JSON.stringify({ vehicleId: vehicle.vehicleId }) });
    state.vehicleInsurance = insuranceResponseData(data);
    closeModal($('#insuranceVehicleDetailModal'));
    renderVehicleInsurance();
    toast(`索赔已进入自动处理，索赔单：${data.claim.claimNumber}`);
  } catch (error) {
    toast(chineseErrorMessage(error.message, '保险操作失败，请稍后重试'), 'error');
    renderInsuranceVehicleDetail();
  }
}

async function submitInsurancePurchase(button) {
  const strategy = (state.vehicleInsurance?.strategies || []).find((item) => String(item.id) === String(pendingInsuranceStrategyId));
  if (!strategy) { toast('保险方案不存在或已停止销售', 'error'); closeModal($('#insurancePurchaseModal')); return; }
  button.disabled = true;
  button.textContent = '购买中...';
  try {
    const requestKey = `vehicle-insurance-${Date.now()}-${globalThis.crypto?.randomUUID?.() || Math.random().toString(16).slice(2)}`;
    const data = await api('/api/shop/vehicle-insurance/purchase', { method: 'POST', headers: { 'Idempotency-Key': requestKey }, body: JSON.stringify({ strategyId: strategy.id }) });
    state.vehicleInsurance = insuranceResponseData(data);
    setUser({ ...state.user, balance: data.receipt.balanceAfter });
    closeModal($('#insurancePurchaseModal'));
    renderVehicleInsurance();
    toast(`保险购买成功，保单号：${data.receipt.policyNumber}`);
  } catch (error) {
    toast(chineseErrorMessage(error.message, '保险操作失败，请稍后重试'), 'error');
  } finally {
    button.disabled = false;
    button.textContent = '确认购买';
  }
}

async function loadVehicleInsurance() {
  const root = $('#page-insurance');
  if (!root || !state.user) return;
  root.classList.add('loading');
  try {
    state.vehicleInsurance = await api('/api/shop/vehicle-insurance');
    insuranceVehiclePage = 1;
    renderVehicleInsurance();
  } catch (error) {
    $('#insuranceVehicleList').innerHTML = `<div class="insurance-shop-empty"><strong>保险数据读取失败</strong><small>${escapeHtml(chineseErrorMessage(error.message, '请稍后重试'))}</small></div>`;
  } finally { root.classList.remove('loading'); }
}

function bindVehicleInsuranceEvents() {
  const root = $('#page-insurance');
  if (!root || root.dataset.insuranceBound) return;
  root.dataset.insuranceBound = 'true';
  root.addEventListener('click', async (event) => {
    const policyDetail = event.target.closest('[data-insurance-policy-detail]');
    if (policyDetail) { openInsurancePolicyDetail(policyDetail.dataset.insurancePolicyDetail); return; }
    if (event.target.closest('#insuranceReload')) { await loadVehicleInsurance(); return; }
    if (event.target.closest('#insuranceVehiclePrevious')) { insuranceVehiclePage -= 1; renderInsuranceVehicleCards(); return; }
    if (event.target.closest('#insuranceVehicleNext')) { insuranceVehiclePage += 1; renderInsuranceVehicleCards(); return; }
    const groupTarget = event.target.closest('[data-insurance-group]');
    if (groupTarget) { openInsuranceVehicleDetail(groupTarget.dataset.insuranceGroup); return; }
    const strategyGroupTarget = event.target.closest('[data-insurance-strategy-group]');
    if (strategyGroupTarget) openInsuranceStrategyDetail(strategyGroupTarget.dataset.insuranceStrategyGroup);
  });
  root.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter' && event.key !== ' ') return;
    if (event.target.matches('.insurance-vehicle-card')) {
      event.preventDefault();
      openInsuranceVehicleDetail(event.target.dataset.insuranceGroup);
    }
    if (event.target.matches('.insurance-plan-vehicle-card')) {
      event.preventDefault();
      openInsuranceStrategyDetail(event.target.dataset.insuranceStrategyGroup);
    }
  });
  const strategyDetailList = $('#insuranceStrategyDetailList');
  strategyDetailList?.addEventListener('click', (event) => {
    const option = event.target.closest('[data-insurance-policy-option]');
    if (option) selectInsuranceStrategy(option.dataset.insurancePolicyOption);
  });
  strategyDetailList?.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter' && event.key !== ' ') return;
    const option = event.target.closest('[data-insurance-policy-option]');
    if (!option) return;
    event.preventDefault();
    selectInsuranceStrategy(option.dataset.insurancePolicyOption);
  });
  $('#insuranceStrategyPurchaseSelected')?.addEventListener('click', (event) => {
    if (!event.currentTarget.disabled && selectedInsuranceStrategyId != null) openInsurancePurchase(selectedInsuranceStrategyId);
  });
  $('#insuranceVehicleDetailChoices')?.addEventListener('click', (event) => {
    const choice = event.target.closest('[data-insurance-vehicle-choice]');
    if (!choice) return;
    selectedInsuranceVehicleId = choice.dataset.insuranceVehicleChoice;
    renderInsuranceVehicleDetail();
  });
  $('#insuranceVehicleClaimConfirm')?.addEventListener('click', (event) => {
    if (!event.currentTarget.disabled) submitInsuranceClaim(event.currentTarget);
  });
  $('#insurancePurchaseConfirm')?.addEventListener('click', (event) => {
    if (!event.currentTarget.disabled) submitInsurancePurchase(event.currentTarget);
  });
}

bindVehicleInsuranceEvents();
