document.addEventListener('click', async (event) => {
  if (await handleProductCategoryClick(event)) return;
  if (await handleMembershipClick(event)) return;
  if (await handleAccountMenuClick(event)) return;
  if (await handleLotteryDraftClick(event)) return;
  handleProductCreateClick(event);
  handleRedeemCreateClick(event);
  handleRewardCreateClick(event);
  handleBalanceCreateClick(event);
  if (await handleManualActionClick(event)) return;
  if (await handleGiftClick(event)) return;
  await handleRedeemClick(event);
  await handleRewardClick(event);
  await handleProductClick(event);
  await handleLotteryPoolClick(event);
  await handleBalanceClick(event);
  await handleTaskClick(event);
  await handleAnnouncementClick(event);

});

window.addEventListener('beforeunload', () => {
  if (state.monitorTimer) clearInterval(state.monitorTimer);
});
const adminPagePermissions = { dashboard:'overview', products:'commerce', 'starter-gift':'commerce', 'redeem-codes':'commerce', rewards:'commerce', 'activities-lottery':'commerce', 'stock-market':'commerce', 'cloud-warehouse':'commerce', accounts:'players', membership:'players', 'vehicle-management':'players', 'teleport-management':'players', orders:'fulfillment', 'game-claims':'fulfillment', announcements:'fulfillment', operations:'operations', 'store-settings':'operations', gateway:'operations', config:'system', 'domain-access':'system' };
function canAccessAdminPage(name) {
  if (name === 'domain-access') return state.currentUser?.role === 'super_admin';
  return state.currentUser?.role === 'super_admin' || new Set(state.currentUser?.adminPermissions || []).has(adminPagePermissions[name]);
}
function applyAdminNavigationPermissions() {
  const superAdmin = state.currentUser?.role === 'super_admin';
  const identity = $('#adminIdentity');
  if (identity && state.currentUser) {
    identity.hidden = false;
    $('#adminIdentityName').textContent = state.currentUser.username || '--';
    $('#adminIdentityRole').textContent = superAdmin ? '超级管理员' : '后台管理员';
  }
  const logout = $('#adminLogout');
  if (logout) logout.hidden = !state.currentUser;
  const licenseButton = $('#openAccountLicenseManagement');
  if (licenseButton) licenseButton.hidden = !superAdmin;
  $$('.nav-item[data-page]').forEach((button) => { button.hidden = !canAccessAdminPage(button.dataset.page); });
  $$('.nav-group').forEach((group) => { group.hidden = !$('.nav-item[data-page]:not([hidden])', group); });
}
$('#adminLogout')?.addEventListener('click', async () => {
  const button = $('#adminLogout');
  if (button) button.disabled = true;
  try {
    await api('/api/admin/auth/logout', { method: 'POST', body: '{}' }, false);
    state.currentUser = null;
    location.href = '/shop/';
  } catch (error) {
    if (button) button.disabled = false;
    toast(error.message || '退出登录失败');
  }
});
async function initialize() {
  initializeTablePagination();
  const mount = document.getElementById('pageMount');
  if (mount) mount.hidden = true;
  try { await requestAdminLogin(); } catch {}
  applyAdminNavigationPermissions();
  const hashPage = decodeURIComponent(window.location.hash.slice(1));
  const savedPage = pages[hashPage] ? hashPage : sessionStorage.getItem('admin-current-page') || localStorage.getItem('admin-current-page');
  const fallbackPage = $('.nav-item[data-page]:not([hidden])')?.dataset.page;
  showPage(pages[savedPage] && canAccessAdminPage(savedPage) ? savedPage : fallbackPage);
  if (mount) mount.hidden = false;
  if (state.page !== 'dashboard') loadHealth();
}
window.addEventListener('hashchange', () => {
  const page = decodeURIComponent(window.location.hash.slice(1));
  if (pages[page] && canAccessAdminPage(page) && page !== state.page) showPage(page);
});
initialize();
setInterval(loadHealth, 30000);
