import { buildMessageCommand, isSteamId64 } from './command-policy.js';
import { randomUUID } from 'node:crypto';
import { ServiceError } from './commerce-service.js';
import { sendDeliveryNotification } from './delivery-notification.js';
import { formatGameMessage } from './game-message.js';

function positive(value, name, max = 1000000) {
  const number = Number(value);
  if (!Number.isSafeInteger(number) || number < 1 || number > max) throw new ServiceError(`${name}必须是 1-${max} 的整数`);
  return number;
}
function id(value, name = '编号') { return positive(value, name, Number.MAX_SAFE_INTEGER); }
function batchIds(value, max = 100) {
  if (!Array.isArray(value) || value.length < 1 || value.length > max) throw new ServiceError(`库存编号必须是 1-${max} 项数组`);
  const result = [...new Set(value.map((item) => id(item, '库存编号')))];
  if (result.length !== value.length) throw new ServiceError('库存编号不能重复');
  return result;
}
function steam(value) { const result = String(value || ''); if (!isSteamId64(result)) throw new ServiceError('SteamID 格式无效'); return result; }
function text(value, name, max) { const result = String(value || '').trim(); if (!result || result.length > max) throw new ServiceError(`${name}长度必须为 1-${max}`); return result; }
function code(value) { const result = text(value, '物品代码', 80); if (!/^[A-Za-z0-9_]+$/.test(result)) throw new ServiceError('物品代码格式无效'); return result; }
function rows(value) { return Array.isArray(value) ? value : []; }
function duplicate(error) { return error?.code === 'ER_DUP_ENTRY' || error?.errno === 1062; }
function feePercent(value) { const number = Number(value || 0); return number > 100 ? number / 100 : number; }
function marketFee(gross, value, minimum = 0) { return Math.max(Number(minimum || 0), Math.ceil(Number(gross) * feePercent(value) / 100)); }
function quotaDay() {
  const date = new Date(Date.now() + 8 * 60 * 60 * 1000).toISOString().slice(0, 10);
  const start = new Date(`${date}T00:00:00+08:00`);
  return { date, start, end: new Date(start.getTime() + 24 * 60 * 60 * 1000) };
}
function inventoryRow(row) {
  const numeric = ['itemHealth','itemMaxHealth','itemDirtiness','itemUses','itemMaxUses','itemRadiationAmount','itemWeight','itemWaterWeight','itemExternalWeight','itemTotalWeight'];
  const stackable = Boolean(row.itemStackable);
  const storedQuantity = Number(row.quantity);
  const quantity = stackable ? 1 : storedQuantity;
  const result = { ...row, id: Number(row.id), quantity, reservedQuantity: Number(row.reservedQuantity), availableQuantity: quantity - Number(row.reservedQuantity) };
  for (const name of numeric) result[name] = row[name] === null || row[name] === undefined ? null : Number(row[name]);
  if (stackable && result.itemUses === null) result.itemUses = storedQuantity;
  if (result.itemMaxUses === null && row.configMaxUses !== null && row.configMaxUses !== undefined) result.itemMaxUses = Number(row.configMaxUses);
  result.itemStackable = stackable;
  return result;
}
function listingRow(row) {
  const result = { ...row, id: Number(row.id), inventoryId: Number(row.inventoryId), quantity: Number(row.quantity), remainingQuantity: Number(row.remainingQuantity), unitPrice: Number(row.unitPrice), feeBps: Number(row.feeBps) };
  for (const name of ['itemHealth', 'itemMaxHealth', 'itemUses', 'itemMaxUses', 'itemMaxQuantity', 'itemDirtiness']) result[name] = row[name] === null || row[name] === undefined ? null : Number(row[name]);
  result.itemStackable = Boolean(row.itemStackable);
  return result;
}
function responseText(result) {
  const value = result?.response ?? result?.data?.response ?? result ?? '';
  return value && typeof value === 'object' && value !== result ? responseText(value) : String(value);
}
function assertRconDeliveryResult(result) {
  const status = String(result?.status ?? result?.data?.status ?? '').toLowerCase();
  const uncertain = result?.uncertainDelivery === true || result?.data?.uncertainDelivery === true || ['uncertain', 'uncertain_delivery'].includes(status);
  const failed = result?.success === false || result?.data?.success === false || ['failed', 'failure', 'error'].includes(status);
  if (!uncertain && !failed) return;
  const error = new Error(responseText(result) || (uncertain ? 'RCON 投递结果不确定' : 'RCON 命令执行失败'));
  error.uncertainDelivery = uncertain;
  throw error;
}
function responseFields(result) {
  return new Map(responseText(result).split(/\r?\n/).map((line) => {
    const separator = line.indexOf('=');
    return separator < 0 ? [] : [line.slice(0, separator), line.slice(separator + 1)];
  }).filter((parts) => parts.length === 2));
}
function optionalNumber(fields, name) {
  const value = fields.get(name);
  if (value === undefined || value === '' || value === 'null') return null;
  const number = Number(value);
  if (!Number.isFinite(number)) throw new ServiceError(`物品快照字段 ${name} 无效`, 502, 'INVALID_RCON_RESPONSE');
  return number;
}
function optionalInteger(fields, name) {
  const value = optionalNumber(fields, name);
  if (value === null) return null;
  if (!Number.isSafeInteger(value) || value < 0) throw new ServiceError(`物品快照字段 ${name} 无效`, 502, 'INVALID_RCON_RESPONSE');
  return value;
}
function optionalBase64(fields, name) {
  const value = fields.get(name);
  if (value === undefined || value === '') return null;
  if (value.length > 3000000 || !/^[A-Za-z0-9+/]*={0,2}$/.test(value)) throw new ServiceError(`物品快照字段 ${name} 无效`, 502, 'INVALID_RCON_RESPONSE');
  return value;
}
function discreteUsageOnly(snapshot) {
  const fields = typeof snapshot === 'string' ? JSON.parse(snapshot) : snapshot;
  const xml = Buffer.from(fields?.item_xml_base64 || '', 'base64').toString('utf8');
  return /<Component\b[^>]*\bName\s*=\s*(["'])DiscreteUsage\1/.test(xml) &&
    !/<Component\b[^>]*\bName\s*=\s*(["'])Stackable\1/.test(xml);
}
function itemSnapshot(fields) {
  if (fields.get('item_snapshot_version') !== '1') throw new ServiceError('RCON 未返回完整物品快照，请更新游戏端组件', 502, 'INCOMPLETE_ITEM_SNAPSHOT');
  const stackable = fields.get('item_stackable') === 'true' && !discreteUsageOnly(Object.fromEntries(fields));
  const quantity = optionalInteger(fields, 'item_quantity');
  const maxQuantity = null;
  if (fields.get('item_snapshot_complete') !== 'true' || (stackable && quantity === null)) throw new ServiceError('RCON 未返回可堆叠物品运行时数量，禁止回收', 502, 'INCOMPLETE_ITEM_SNAPSHOT');
  if (stackable && (quantity === null || quantity < 0 || quantity > 1000000)) throw new ServiceError('物品快照数量无效', 502, 'INVALID_RCON_RESPONSE');
  const snapshot = Object.fromEntries(fields);
  return {
    quantity: 1,
    health: optionalNumber(fields, 'item_health'),
    maxHealth: optionalNumber(fields, 'item_max_health'),
    dirtiness: optionalNumber(fields, 'item_dirtiness'),
    uses: stackable ? quantity : optionalInteger(fields, 'item_uses'),
    maxUses: optionalInteger(fields, 'item_max_uses'),
    maxQuantity,
    stackable,
    radiationAmount: optionalNumber(fields, 'item_radiation_amount'),
    weight: optionalNumber(fields, 'item_weight'),
    waterWeight: optionalNumber(fields, 'item_water_weight'),
    externalWeight: optionalNumber(fields, 'item_external_weight'),
    totalWeight: optionalNumber(fields, 'item_total_weight'),
    xmlBase64: optionalBase64(fields, 'item_xml_base64'),
    bodyDamageBase64: optionalBase64(fields, 'item_body_damage_base64'),
    json: JSON.stringify(snapshot)
  };
}
function percent(value, fallback) {
  const number = value === null || value === undefined ? fallback : Number(value);
  if (!Number.isFinite(number) || number < 0 || number > 100) throw new ServiceError('物品恢复属性超出游戏允许范围', 409, 'UNSUPPORTED_ITEM_ATTRIBUTES');
  return String(Number(number.toFixed(4)));
}
function destroyRefundQuote(batch, product, settings) {
  const stackable = Boolean(batch.itemStackable), quantity = stackable ? 1 : Math.max(1, Number(batch.quantity || 0));
  const health = batch.itemHealth === null || batch.itemHealth === undefined ? 100 : Number(batch.itemHealth);
  const maxHealth = batch.itemMaxHealth === null || batch.itemMaxHealth === undefined ? 100 : Number(batch.itemMaxHealth);
  const healthFactor = Number.isFinite(health) && Number.isFinite(maxHealth) && maxHealth > 0 ? Math.max(0, Math.min(1, health / maxHealth)) : 1;
  const productPrice = Number(product?.price), grantAmount = Math.max(1, Number(product?.grantAmount || 1));
  const priceBased = Number.isSafeInteger(productPrice) && productPrice > 0;
  const unitRefund = priceBased ? Math.max(1, Math.floor((productPrice / grantAmount) * (settings.destroyRefundPercent / 100) * healthFactor)) : settings.destroyFallbackRefund;
  return { refund: unitRefund * quantity, unitRefund, quantity, priceBased, productPrice: priceBased ? productPrice : null, grantAmount: priceBased ? grantAmount : null, healthFactor };
}

export class CloudWarehouseService {
  constructor(db, { clients = null, logger = null } = {}) { this.db = db; this.clients = clients; this.logger = logger; }

  async notify(steamId, itemName, itemCode, quantity, action) {
    try {
      const { config, ggcon } = await this.clients();
      if (!config?.fulfillment?.notifyOnSuccess) return;
      const names = rows(await this.db.query("SELECT name FROM products WHERE item_id=? AND name<>'' ORDER BY enabled DESC,id DESC LIMIT 1", [itemCode]));
      await sendDeliveryNotification({ db: this.db, config, ggcon, steamId, orderName: names[0]?.name || itemName || itemCode, quantity, action });
    } catch (error) { this.logger?.warn('云储成功通知发送失败', { steamId, action, error: error.message }); }
  }

  async notifyRecycleFailure(steamId, itemId, errorCode) {
    try {
      const { config, ggcon } = await this.clients();
      const reason = errorCode === 'OWNERSHIP_REJECTED' ? '物品未在上锁箱子内' : '回收插件失效，请联系管理员';
      const text = formatGameMessage(config, `回收失败：${reason}`);
      const limit = config.commandPolicy.allowedMessageLength;
      const command = buildMessageCommand({ global: true, message: text.slice(0, limit) }, config.commandPolicy);
      await ggcon.command(command, { retry: false, priority: 'high' });
    } catch (error) { this.logger?.warn('云储回收失败通知发送失败', { steamId, itemId, error: error.message }); }
  }

  async recycleRestrictions(client = this.db) {
    return rows(await client.query("SELECT r.item_code AS itemCode,COALESCE(NULLIF(r.item_name,''),(SELECT p.name FROM products p WHERE (p.item_id=r.item_code OR p.item_id=CONCAT(r.item_code,'_ES')) AND p.name<>'' ORDER BY p.enabled DESC,p.id DESC LIMIT 1),r.item_code) AS itemName,r.reason,r.enabled,r.created_at AS createdAt FROM cloud_recycle_restrictions r ORDER BY itemName,r.item_code")).map((item)=>({ ...item, enabled:Boolean(item.enabled) }));
  }

  async recycleControlSettings(client = this.db) {
    const row = rows(await client.query("SELECT cloud_recycle_control_enabled AS enabled FROM `系统配置` WHERE setting_key='default'"))[0];
    return { enabled: row ? Boolean(row.enabled) : true };
  }

  async setRecycleControlEnabled(value, actorId) {
    if (typeof value !== 'boolean') throw new ServiceError('回收管制开关无效');
    await this.db.query("INSERT INTO `系统配置` (setting_key,cloud_recycle_control_enabled,cloud_updated_by_user_id) VALUES ('default',?,?) ON DUPLICATE KEY UPDATE cloud_recycle_control_enabled=VALUES(cloud_recycle_control_enabled),cloud_updated_by_user_id=VALUES(cloud_updated_by_user_id)", [value,actorId || null]);
    return this.recycleControlSettings();
  }

  async saveRecycleRestriction(input, actorId) {
    const itemCode = code(input?.itemCode).replace(/_ES$/i, ''), itemName = text(input?.itemName || itemCode, '物品名称', 100), reason = text(input?.reason, '管制原因', 500), enabled = input?.enabled !== false;
    await this.db.query('INSERT INTO cloud_recycle_restrictions (item_code,item_name,reason,enabled,created_by_user_id) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE item_name=VALUES(item_name),reason=VALUES(reason),enabled=VALUES(enabled),created_by_user_id=VALUES(created_by_user_id)', [itemCode,itemName,reason,enabled,actorId || null]);
    return this.recycleRestrictions();
  }

  async deleteRecycleRestriction(value) {
    const itemCode = code(value).replace(/_ES$/i, '');
    await this.db.query('DELETE FROM cloud_recycle_restrictions WHERE item_code=?', [itemCode]);
    return this.recycleRestrictions();
  }

  async setRecycleRestrictionEnabled(value, enabled) {
    const itemCode = code(value).replace(/_ES$/i, '');
    if (typeof enabled !== 'boolean') throw new ServiceError('单项管制开关无效');
    await this.db.query('UPDATE cloud_recycle_restrictions SET enabled=? WHERE item_code=?', [enabled,itemCode]);
    return this.recycleRestrictions();
  }

  async assertRecycleAllowed(itemCode, client = this.db) {
    if (!(await this.recycleControlSettings(client)).enabled) return;
    const restricted = rows(await client.query('SELECT item_code FROM cloud_recycle_restrictions WHERE item_code=? AND enabled=1 LIMIT 1', [itemCode]))[0];
    if (restricted) throw new ServiceError('该物品已被回收管制，禁止回收', 409, 'RECYCLE_RESTRICTED');
  }

  async passPlans(client = this.db) {
    const plans = rows(await client.query('SELECT pass_type AS passType,enabled,price,duration_days AS durationDays,daily_quota AS dailyQuota FROM cloud_pass_plans'));
    return ['normal','premium'].map((passType) => {
      const plan = plans.find((item) => item.passType === passType);
      return { passType, enabled: Boolean(plan?.enabled), price: Number(plan?.price || 0), durationDays: Number(plan?.durationDays || 30), dailyQuota: Number(plan?.dailyQuota || 0) };
    });
  }

  async savePassPlans(input) {
    if (!Array.isArray(input) || input.length !== 2 || input.some((plan) => !plan || typeof plan !== 'object') || new Set(input.map((plan) => plan.passType)).size !== 2) throw new ServiceError('请配置两种云储证');
    const plans = input.map((plan) => {
      if (!['normal','premium'].includes(plan.passType) || typeof plan.enabled !== 'boolean') throw new ServiceError('云储证类型或开关无效');
      const price = Number(plan.price), dailyQuota = Number(plan.dailyQuota);
      if (!Number.isSafeInteger(price) || price < 0 || price > 100000000 || !Number.isSafeInteger(dailyQuota) || dailyQuota < 0 || dailyQuota > 100000) throw new ServiceError('价格或每日额度无效');
      return { ...plan, price, dailyQuota, durationDays: positive(plan.durationDays, '有效天数', 3650) };
    });
    await this.db.transaction(async (tx) => {
      for (const plan of plans) await tx.query('INSERT INTO cloud_pass_plans (pass_type,enabled,price,duration_days,daily_quota) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE enabled=VALUES(enabled),price=VALUES(price),duration_days=VALUES(duration_days),daily_quota=VALUES(daily_quota)', [plan.passType,plan.enabled,plan.price,plan.durationDays,plan.dailyQuota]);
    });
    return this.passPlans();
  }

  async passes(steamId, client = this.db) {
    return rows(await client.query('SELECT id,pass_type AS passType,daily_quota AS dailyQuota,starts_at AS startsAt,expires_at AS expiresAt FROM cloud_pass_purchases WHERE steam_id=? AND expires_at>UTC_TIMESTAMP(3) ORDER BY starts_at,id', [steam(steamId)]));
  }

  async buyPass(steamId, passType, requestKey) {
    const owner = steam(steamId), key = text(requestKey, '购买请求编号', 100);
    if (!['normal','premium'].includes(passType)) throw new ServiceError('云储证类型无效');
    return this.db.transaction(async (tx) => {
      const account = rows(await tx.query('SELECT \`商城币余额\` AS balance FROM \`商城用户\` WHERE \`SteamID\`=? FOR UPDATE', [owner]))[0];
      if (!account) throw new ServiceError('玩家账户不存在', 404, 'NOT_FOUND');
      const existing = rows(await tx.query('SELECT id,steam_id AS steamId,pass_type AS passType,balance_after AS balanceAfter,expires_at AS expiresAt FROM cloud_pass_purchases WHERE request_key=?', [key]))[0];
      if (existing) {
        if (existing.steamId !== owner || existing.passType !== passType) throw new ServiceError('购买请求编号已被使用', 409, 'IDEMPOTENCY_CONFLICT');
        return { ...existing, idempotent: true };
      }
      const plan = (await this.passPlans(tx)).find((item) => item.passType === passType);
      if (!plan.enabled) throw new ServiceError('该云储证暂未开放', 409, 'PASS_DISABLED');
      if (Number(account.balance) < plan.price) throw new ServiceError('商城币余额不足', 409, 'INSUFFICIENT_BALANCE');
      const latest = rows(await tx.query('SELECT expires_at AS expiresAt FROM cloud_pass_purchases WHERE steam_id=? AND pass_type=? ORDER BY expires_at DESC LIMIT 1', [owner,passType]))[0];
      const startsAt = new Date(Math.max(Date.now(), latest ? new Date(latest.expiresAt).getTime() : 0));
      const expiresAt = new Date(startsAt.getTime() + plan.durationDays * 86400000), balanceAfter = Number(account.balance) - plan.price;
      const result = await tx.query('INSERT INTO cloud_pass_purchases (request_key,steam_id,pass_type,price,daily_quota,starts_at,expires_at,balance_after) VALUES (?,?,?,?,?,?,?,?)', [key,owner,passType,plan.price,plan.dailyQuota,startsAt,expiresAt,balanceAfter]);
      await tx.query('UPDATE \`商城用户\` SET \`商城币余额\`=? WHERE \`SteamID\`=?', [balanceAfter,owner]);
      await tx.query("INSERT INTO coin_ledger (steam_id,amount,balance_after,type,reference_type,reference_id,note) VALUES (?,?,?,'cloud_pass_buy','cloud_pass',?,?)", [owner,-plan.price,balanceAfter,String(result.insertId),passType === 'normal' ? '购买普通云储证' : '购买高级云储证']);
      return { id: Number(result.insertId), passType, startsAt, expiresAt, balanceAfter, idempotent: false };
    });
  }

  async passQuota(steamId, client = this.db) {
    const result = rows(await client.query('SELECT COALESCE(SUM(daily_quota),0) AS extra FROM cloud_pass_purchases WHERE steam_id=? AND starts_at<=UTC_TIMESTAMP(3) AND expires_at>UTC_TIMESTAMP(3)', [steamId]))[0];
    return Number(result?.extra || 0);
  }

  async settings(client = this.db) {
    const row = rows(await client.query("SELECT cloud_market_enabled AS marketEnabled,cloud_fee_bps AS feeBps,cloud_minimum_fee AS minimumFee,cloud_withdraw_fee AS withdrawFee,cloud_daily_base_quota AS dailyBaseQuota,cloud_destroy_refund_percent AS destroyRefundPercent,cloud_destroy_fallback_refund AS destroyFallbackRefund,updated_at AS updatedAt FROM `系统配置` WHERE setting_key='default'"))[0];
    return row ? { ...row, marketEnabled: Boolean(row.marketEnabled), feeBps: feePercent(row.feeBps), minimumFee: Number(row.minimumFee || 0), withdrawFee: Number(row.withdrawFee || 0), dailyBaseQuota: Number(row.dailyBaseQuota), destroyRefundPercent: Number(row.destroyRefundPercent ?? 20), destroyFallbackRefund: Number(row.destroyFallbackRefund ?? 2) } : { marketEnabled: true, feeBps: 3, minimumFee: 1, withdrawFee: 0, dailyBaseQuota: 10, destroyRefundPercent: 20, destroyFallbackRefund: 2 };
  }

  async saveSettings(input, actorId) {
    const withdrawFee = Number(input?.withdrawFee ?? 0);
    const minimumFee = Number(input?.minimumFee ?? 0);
    const destroyRefundPercent = Number(input?.destroyRefundPercent ?? 20);
    const destroyFallbackRefund = Number(input?.destroyFallbackRefund ?? 2);
    if (!Number.isSafeInteger(withdrawFee) || withdrawFee < 0 || withdrawFee > 100000000) throw new ServiceError('取出手续费必须是 0-100000000 的整数');
    if (!Number.isSafeInteger(minimumFee) || minimumFee < 0 || minimumFee > 100000000) throw new ServiceError('最低手续费必须是 0-100000000 的整数');
    if (!Number.isInteger(destroyRefundPercent) || destroyRefundPercent < 0 || destroyRefundPercent > 100) throw new ServiceError('销毁返还比例必须是 0-100 的整数');
    if (!Number.isSafeInteger(destroyFallbackRefund) || destroyFallbackRefund < 0 || destroyFallbackRefund > 100000000) throw new ServiceError('无售价返还必须是 0-100000000 的整数');
    const marketEnabled = input?.marketEnabled !== false, feeBps = Number(input?.feeBps), dailyBaseQuota = Number(input?.dailyBaseQuota);
    if (!Number.isInteger(feeBps) || feeBps < 0 || feeBps > 100) throw new ServiceError('手续费基点必须是 0-100 的整数，数值直接对应百分比');
    if (!Number.isInteger(dailyBaseQuota) || dailyBaseQuota < 0 || dailyBaseQuota > 100000) throw new ServiceError('每日基础额度必须是 0-100000 的整数');
    await this.db.query("INSERT INTO `系统配置` (setting_key,cloud_market_enabled,cloud_fee_bps,cloud_minimum_fee,cloud_daily_base_quota,cloud_withdraw_fee,cloud_destroy_refund_percent,cloud_destroy_fallback_refund,cloud_updated_by_user_id) VALUES ('default',?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE cloud_market_enabled=VALUES(cloud_market_enabled),cloud_fee_bps=VALUES(cloud_fee_bps),cloud_minimum_fee=VALUES(cloud_minimum_fee),cloud_daily_base_quota=VALUES(cloud_daily_base_quota),cloud_withdraw_fee=VALUES(cloud_withdraw_fee),cloud_destroy_refund_percent=VALUES(cloud_destroy_refund_percent),cloud_destroy_fallback_refund=VALUES(cloud_destroy_fallback_refund),cloud_updated_by_user_id=VALUES(cloud_updated_by_user_id)", [marketEnabled, feeBps, minimumFee, dailyBaseQuota, withdrawFee, destroyRefundPercent, destroyFallbackRefund, actorId || null]);
    return this.settings();
  }

  async inventory(steamId, client = this.db) {
    return rows(await client.query("SELECT b.id,b.steam_id AS steamId,b.source_item_id AS sourceItemId,b.item_code AS itemCode,COALESCE((SELECT p.name FROM products p WHERE (p.item_id=b.item_code OR p.item_id=REGEXP_REPLACE(b.item_code,'_ES$','')) AND p.name<>'' ORDER BY p.enabled DESC,p.id DESC LIMIT 1),b.item_name) AS itemName,(SELECT p.image_path FROM products p WHERE (p.item_id=b.item_code OR p.item_id=REGEXP_REPLACE(b.item_code,'_ES$','')) AND p.image_path IS NOT NULL AND p.image_path<>'' ORDER BY p.enabled DESC,p.id DESC LIMIT 1) AS imagePath,b.quantity,b.reserved_quantity AS reservedQuantity,b.item_health AS itemHealth,b.item_max_health AS itemMaxHealth,b.item_dirtiness AS itemDirtiness,b.item_uses AS itemUses,b.item_max_uses AS itemMaxUses,(SELECT p.max_uses FROM products p WHERE (p.item_id=b.item_code OR p.item_id=REGEXP_REPLACE(b.item_code,'_ES$','')) AND p.max_uses IS NOT NULL ORDER BY p.enabled DESC,p.id DESC LIMIT 1) AS configMaxUses,b.item_stackable AS itemStackable,b.item_radiation_amount AS itemRadiationAmount,b.item_weight AS itemWeight,b.item_water_weight AS itemWaterWeight,b.item_external_weight AS itemExternalWeight,b.item_total_weight AS itemTotalWeight,b.status,b.created_at AS createdAt,b.updated_at AS updatedAt FROM cloud_inventory_batches b WHERE b.steam_id=? AND b.status<>'empty' AND (b.item_stackable=1 OR b.quantity>0) ORDER BY b.id DESC", [steam(steamId)])).map(inventoryRow);
  }

  async bulkInventoryPreview(steamId, input) {
    const owner = steam(steamId), inventoryIds = batchIds(input?.inventoryIds);
    const selected = (await this.inventory(owner)).filter((item) => inventoryIds.includes(item.id));
    if (selected.length !== inventoryIds.length) throw new ServiceError('部分库存不存在或已取出', 409, 'INVENTORY_UNAVAILABLE');
    if (new Set(selected.map((item) => item.itemCode)).size !== 1) throw new ServiceError('一键操作只能选择同一种物品', 409, 'MIXED_INVENTORY');
    if (selected.some((item) => item.status !== 'active' || Number(item.reservedQuantity) !== 0 || Number(item.availableQuantity) < 1)) throw new ServiceError('部分库存已锁定、上架或不可操作', 409, 'INVENTORY_UNAVAILABLE');
    return { owner, inventoryIds, selected };
  }

  async withdrawManyPreview(steamId, input) {
    const { inventoryIds, selected } = await this.bulkInventoryPreview(steamId, input);
    const { withdrawFee } = await this.settings();
    const feeUnits = Math.ceil(inventoryIds.length / 10);
    return { inventoryIds, itemCode: selected[0].itemCode, itemName: selected[0].itemName, itemCount: inventoryIds.length, itemsPerFeeUnit: 10, feeUnits, unitFee: withdrawFee, fee: feeUnits * withdrawFee };
  }

  async withdrawMany(steamId, input) {
    const owner = steam(steamId), preview = await this.withdrawManyPreview(owner, input), operationId = randomUUID();
    if (!this.clients) throw new ServiceError('RCON 服务未就绪', 503, 'WITHDRAW_UNAVAILABLE');
    if (preview.fee > 0) await this.db.transaction(async (tx) => {
      const account = rows(await tx.query('SELECT \`SteamID\` AS steamId,\`商城币余额\` AS balance FROM \`商城用户\` WHERE \`SteamID\`=? FOR UPDATE', [owner]))[0];
      if (!account || Number(account.balance) < preview.fee) throw new ServiceError('商城币余额不足，无法支付一键取出手续费', 409, 'INSUFFICIENT_BALANCE');
      const balanceAfter = Number(account.balance) - preview.fee;
      await tx.query('UPDATE \`商城用户\` SET \`商城币余额\`=? WHERE \`SteamID\`=?', [balanceAfter, owner]);
      await tx.query("INSERT INTO coin_ledger (steam_id,amount,balance_after,type,reference_type,reference_id,note) VALUES (?,?,?,'cloud_withdraw_fee','cloud_inventory_bulk',?,?)", [owner, -preview.fee, balanceAfter, operationId, `一键取出 ${preview.itemCount} 件，按每 10 件 1 个计费单位收取 ${preview.fee} 商城币`]);
    });
    const completed = [], uncertain = [], failed = [];
    for (const [index, inventoryId] of preview.inventoryIds.entries()) {
      try {
        const result = await this.withdraw(owner, inventoryId, {}, { withdrawFee: 0, notify: false });
        completed.push({ ...result, sequence: index + 1 });
      } catch (error) {
        const result = { inventoryId, sequence: index + 1, code: error.code || 'WITHDRAW_FAILED', message: error.message || '取出失败' };
        if (error.code === 'WITHDRAW_UNCERTAIN') uncertain.push(result); else failed.push(result);
      }
    }
    if (completed.length > 0) await this.notify(owner, preview.itemName, preview.itemCode, completed.length, '一键取出完成');
    const billableCount = completed.length + uncertain.length;
    const actualFeeUnits = billableCount ? Math.ceil(billableCount / 10) : 0;
    const actualFee = actualFeeUnits * preview.unitFee, refund = preview.fee - actualFee;
    if (refund > 0) await this.db.transaction(async (tx) => {
      const account = rows(await tx.query('SELECT \`SteamID\` AS steamId,\`商城币余额\` AS balance FROM \`商城用户\` WHERE \`SteamID\`=? FOR UPDATE', [owner]))[0];
      if (!account) throw new ServiceError('玩家账户不存在', 404, 'ACCOUNT_NOT_FOUND');
      const balanceAfter = Number(account.balance) + refund;
      await tx.query('UPDATE \`商城用户\` SET \`商城币余额\`=? WHERE \`SteamID\`=?', [balanceAfter, owner]);
      await tx.query("INSERT INTO coin_ledger (steam_id,amount,balance_after,type,reference_type,reference_id,note) VALUES (?,?,?,'cloud_withdraw_refund','cloud_inventory_bulk',?,?)", [owner, refund, balanceAfter, operationId, `一键取出失败 ${failed.length} 件，退回多收手续费 ${refund} 商城币`]);
    });
    return { operationId, itemCode: preview.itemCode, itemName: preview.itemName, requested: preview.itemCount, completed: completed.length, uncertain: uncertain.length, failed: failed.length, feeUnits: actualFeeUnits, fee: actualFee, refund, results: completed, uncertainItems: uncertain, failedItems: failed };
  }

  async destroyManyPreview(steamId, input) {
    const { inventoryIds, selected } = await this.bulkInventoryPreview(steamId, input);
    const items = await Promise.all(inventoryIds.map((inventoryId) => this.destroyPreview(steamId, inventoryId)));
    return { inventoryIds, itemCode: selected[0].itemCode, itemName: selected[0].itemName, itemCount: items.length, refund: items.reduce((sum, item) => sum + Number(item.refund || 0), 0), items };
  }

  async destroyMany(steamId, input) {
    const preview = await this.destroyManyPreview(steamId, input), completed = [], failed = [];
    for (const inventoryId of preview.inventoryIds) {
      try { completed.push(await this.destroy(steamId, inventoryId)); }
      catch (error) { failed.push({ inventoryId, code: error.code || 'DESTROY_FAILED', message: error.message || '销毁失败' }); }
    }
    return { itemCode: preview.itemCode, itemName: preview.itemName, requested: preview.itemCount, completed: completed.length, failed: failed.length, refund: completed.reduce((sum, item) => sum + Number(item.refund || 0), 0), results: completed, failedItems: failed };
  }

  async destroyProduct(itemCode, client = this.db) {
    return rows(await client.query("SELECT price,grant_amount AS grantAmount FROM products WHERE enabled=1 AND currency_type='coin' AND price>0 AND REGEXP_REPLACE(item_id,'_ES$','')=REGEXP_REPLACE(?,'_ES$','') ORDER BY id DESC LIMIT 1", [itemCode]))[0] || null;
  }

  async destroyPreview(steamId, inventoryId) {
    const owner = steam(steamId), batchId = id(inventoryId, '库存编号');
    const batch = rows(await this.db.query('SELECT id,steam_id AS steamId,item_code AS itemCode,item_name AS itemName,quantity,reserved_quantity AS reservedQuantity,item_health AS itemHealth,item_max_health AS itemMaxHealth,item_stackable AS itemStackable,status FROM cloud_inventory_batches WHERE id=?', [batchId]))[0];
    if (!batch || batch.steamId !== owner) throw new ServiceError('库存不存在', 404, 'NOT_FOUND');
    if (batch.status !== 'active' || Number(batch.reservedQuantity) !== 0 || (!batch.itemStackable && Number(batch.quantity) < 1)) throw new ServiceError('该库存已锁定、上架或不可销毁', 409, 'INVENTORY_UNAVAILABLE');
    const [settings, product] = await Promise.all([this.settings(), this.destroyProduct(batch.itemCode)]);
    return { id: batchId, itemCode: batch.itemCode, itemName: batch.itemName, ...destroyRefundQuote(batch, product, settings), destroyRefundPercent: settings.destroyRefundPercent, destroyFallbackRefund: settings.destroyFallbackRefund };
  }

  async destroy(steamId, inventoryId) {
    const owner = steam(steamId), batchId = id(inventoryId, '库存编号');
    return this.db.transaction(async (tx) => {
      const batch = rows(await tx.query('SELECT id,steam_id AS steamId,item_code AS itemCode,item_name AS itemName,quantity,reserved_quantity AS reservedQuantity,item_health AS itemHealth,item_max_health AS itemMaxHealth,item_stackable AS itemStackable,status FROM cloud_inventory_batches WHERE id=? FOR UPDATE', [batchId]))[0];
      if (!batch || batch.steamId !== owner) throw new ServiceError('库存不存在', 404, 'NOT_FOUND');
      if (batch.status === 'empty') {
        const prior = rows(await tx.query("SELECT amount,balance_after AS balanceAfter FROM coin_ledger WHERE steam_id=? AND reference_type='cloud_destroy_refund' AND reference_id=? LIMIT 1", [owner, String(batchId)]))[0];
        if (prior) return { id: batchId, itemCode: batch.itemCode, itemName: batch.itemName, refund: Number(prior.amount), balanceAfter: Number(prior.balanceAfter), status: 'completed', idempotent: true };
      }
      if (batch.status !== 'active' || Number(batch.reservedQuantity) !== 0 || (!batch.itemStackable && Number(batch.quantity) < 1)) throw new ServiceError('该库存已锁定、上架或不可销毁', 409, 'INVENTORY_UNAVAILABLE');
      const settings = await this.settings(tx), product = await this.destroyProduct(batch.itemCode, tx), quote = destroyRefundQuote(batch, product, settings);
      await tx.query('INSERT INTO \`商城用户\` (\`SteamID\`,\`商城币余额\`) VALUES (?,0) ON DUPLICATE KEY UPDATE \`SteamID\`=VALUES(\`SteamID\`)', [owner]);
      const account = rows(await tx.query('SELECT \`SteamID\` AS steamId,\`商城币余额\` AS balance FROM \`商城用户\` WHERE \`SteamID\`=? FOR UPDATE', [owner]))[0];
      const balanceAfter = Number(account.balance) + quote.refund;
      if (!Number.isSafeInteger(balanceAfter)) throw new ServiceError('返还金额超出系统限制', 409, 'BALANCE_OVERFLOW');
      await tx.query("UPDATE cloud_inventory_batches SET status='empty',quantity=0,reserved_quantity=0 WHERE id=?", [batchId]);
      await tx.query('UPDATE \`商城用户\` SET \`商城币余额\`=? WHERE \`SteamID\`=?', [balanceAfter, owner]);
      await tx.query('INSERT INTO coin_ledger (steam_id,amount,balance_after,type,reference_type,reference_id,note) VALUES (?,?,?,?,?,?,?)', [owner, quote.refund, balanceAfter, 'cloud_destroy_refund', 'cloud_destroy_refund', String(batchId), `销毁云储库存 ${batchId}：${batch.itemName}；${quote.priceBased ? `商城售价返还 ${settings.destroyRefundPercent}%` : `无售价固定返还 ${settings.destroyFallbackRefund}`}；计价数量 ${quote.quantity}`]);
      return { id: batchId, itemCode: batch.itemCode, itemName: batch.itemName, ...quote, balanceAfter, status: 'completed', idempotent: false };
    });
  }

  async quota(steamId, client = this.db) {
    const owner = steam(steamId), day = quotaDay(), settings = await this.settings(client);
    const result = rows(await client.query('SELECT COUNT(*) AS used FROM cloud_inventory_batches WHERE steam_id=? AND source_item_id IS NOT NULL AND created_at>=? AND created_at<?', [owner, day.start, day.end]))[0];
    const used = Number(result?.used || 0);
    const extra = await this.passQuota(owner, client), total = settings.dailyBaseQuota + extra;
    return { date: day.date, base: settings.dailyBaseQuota, extra, total, used, remaining: Math.max(0, total - used) };
  }

  async recycle(steamId, itemId) {
    const owner = steam(steamId), sourceItemId = String(id(itemId, '物品ID'));
    const existing = rows(await this.db.query('SELECT id,steam_id AS steamId,status FROM cloud_inventory_batches WHERE source_item_id=? LIMIT 1', [sourceItemId]))[0];
    if (existing) {
      if (existing.steamId !== owner) throw new ServiceError('该物品ID已被其他仓库登记', 409, 'DUPLICATE_ITEM');
      if (existing.status === 'locked') throw new ServiceError('该物品回收结果待人工核验', 409, 'RECYCLE_UNCERTAIN');
      return { ...(await this.inventory(owner)).find((item) => item.id === Number(existing.id)), idempotent: true };
    }
    if (!this.clients) throw new ServiceError('RCON 服务未就绪', 503, 'RECYCLE_UNAVAILABLE');
    const { ggcon } = await this.clients();
    let ownership;
    try { ownership = await ggcon.command(`QuerySavedItemOwner ${sourceItemId} ${owner}`); }
    catch (error) { throw new ServiceError(error.message || '物品归属校验失败', 409, 'OWNERSHIP_REJECTED'); }
    const fields = responseFields(ownership);
    if (fields.get('item_id') !== sourceItemId || fields.get('saved_item_owner_match') !== 'true') throw new ServiceError('物品归属校验结果无效', 409, 'OWNERSHIP_REJECTED');
    let itemClass;
    try { itemClass = code(fields.get('item_class')); }
    catch { throw new ServiceError('物品归属接口未返回有效类别', 502, 'INVALID_RCON_RESPONSE'); }
    const itemCode = itemClass.replace(/_ES$/i, '');
    if (!/^[A-Za-z0-9_]{1,80}$/.test(itemCode)) throw new ServiceError('物品类别无法用于游戏生成', 409, 'UNSUPPORTED_ITEM_CLASS');
    await this.assertRecycleAllowed(itemCode);
    const snapshot = itemSnapshot(fields);
    const batchId = await this.db.transaction(async (tx) => {
      await tx.query('INSERT INTO \`商城用户\` (\`SteamID\`,\`商城币余额\`) VALUES (?,0) ON DUPLICATE KEY UPDATE \`SteamID\`=VALUES(\`SteamID\`)', [owner]);
      await tx.query('SELECT \`SteamID\` AS steam_id FROM \`商城用户\` WHERE \`SteamID\`=? FOR UPDATE', [owner]);
      const day = quotaDay(), settings = await this.settings(tx);
      const used = rows(await tx.query('SELECT id FROM cloud_inventory_batches WHERE steam_id=? AND source_item_id IS NOT NULL AND created_at>=? AND created_at<? FOR UPDATE', [owner, day.start, day.end])).length;
      if (used >= settings.dailyBaseQuota + await this.passQuota(owner, tx)) throw new ServiceError('今日云储额度已用完，无法继续存入物品', 409, 'CLOUD_QUOTA_EXCEEDED');
      const result = await tx.query("INSERT INTO cloud_inventory_batches (steam_id,source_item_id,item_code,item_name,quantity,item_health,item_max_health,item_dirtiness,item_uses,item_max_uses,item_max_quantity,item_stackable,item_radiation_amount,item_weight,item_water_weight,item_external_weight,item_total_weight,item_xml_base64,item_body_damage_base64,item_snapshot_json,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'locked')", [owner, sourceItemId, itemCode, itemCode, snapshot.quantity, snapshot.health, snapshot.maxHealth, snapshot.dirtiness, snapshot.uses, snapshot.maxUses, snapshot.maxQuantity, snapshot.stackable, snapshot.radiationAmount, snapshot.weight, snapshot.waterWeight, snapshot.externalWeight, snapshot.totalWeight, snapshot.xmlBase64, snapshot.bodyDamageBase64, snapshot.json]);
      return Number(result.insertId);
    }).catch((error) => { if (duplicate(error)) throw new ServiceError('该物品ID已入库', 409, 'DUPLICATE_ITEM'); throw error; });
    try {
      const removed = await ggcon.command(`RemoveSavedOwnedItem ${sourceItemId} ${owner} CONFIRM`, { retry: false });
      if (responseFields(removed).get('remove_saved_owned_item') !== 'executed') throw new Error('移除接口未返回明确成功结果');
    } catch (error) {
      if (error?.uncertainDelivery) throw new ServiceError('物品移除结果不确定，已锁定记录等待人工核验', 503, 'RECYCLE_UNCERTAIN');
      await this.db.query("DELETE FROM cloud_inventory_batches WHERE id=? AND status='locked'", [batchId]);
      throw new ServiceError(error.message || '物品移除失败', 409, 'REMOVE_REJECTED');
    }
    await this.db.query("UPDATE cloud_inventory_batches SET status='active' WHERE id=? AND status='locked'", [batchId]);
    await this.notify(owner, itemCode, itemCode, snapshot.quantity, '回收成功');
    return (await this.inventory(owner)).find((item) => item.id === batchId);
  }

  async inspect(steamId, itemId) {
    const owner = steam(steamId), sourceItemId = String(id(itemId, '物品ID'));
    if (!this.clients) throw new ServiceError('RCON 服务未就绪', 503, 'RECYCLE_UNAVAILABLE');
    const { ggcon } = await this.clients();
    let ownership;
    try { ownership = await ggcon.command(`QuerySavedItemOwner ${sourceItemId} ${owner}`); }
    catch (error) { throw new ServiceError(error.message || '物品归属校验失败', 409, 'OWNERSHIP_REJECTED'); }
    const fields = responseFields(ownership);
    if (fields.get('item_id') !== sourceItemId || fields.get('saved_item_owner_match') !== 'true') throw new ServiceError('物品归属校验结果无效', 409, 'OWNERSHIP_REJECTED');
    const itemClass = code(fields.get('item_class'));
    const itemCode = itemClass.replace(/_ES$/i, '');
    await this.assertRecycleAllowed(itemCode);
    const snapshot = itemSnapshot(fields);
    const product = rows(await this.db.query("SELECT name,image_path AS imagePath FROM products WHERE item_id=? AND name<>'' ORDER BY enabled DESC,id DESC LIMIT 1", [itemCode]))[0] || {};
    const containerClass = fields.get('locked_container_class') || '';
    const containerId = fields.get('locked_container_id') || '';
    return { itemId: sourceItemId, itemName: product.name || itemCode, itemCode, imagePath: product.imagePath || null, health: snapshot.health, maxHealth: snapshot.maxHealth, uses: snapshot.uses, maxUses: snapshot.maxUses, dirtiness: snapshot.dirtiness, container: [containerClass, containerId && `#${containerId}`].filter(Boolean).join(' ') || '未识别', stackable: snapshot.stackable };
  }

  async addInventory(input, actorId) {
    const owner = steam(input?.steamId), itemCode = code(input?.itemCode), itemName = text(input?.itemName || itemCode, '物品名称', 100), quantity = positive(input?.quantity, '数量'), sourceItemId = input?.sourceItemId ? text(input.sourceItemId, '物品ID', 80) : null;
    await this.db.query('INSERT INTO \`商城用户\` (\`SteamID\`,\`商城币余额\`) VALUES (?,0) ON DUPLICATE KEY UPDATE \`SteamID\`=VALUES(\`SteamID\`)', [owner]);
    try {
      const result = await this.db.query('INSERT INTO cloud_inventory_batches (steam_id,source_item_id,item_code,item_name,quantity,created_by_user_id) VALUES (?,?,?,?,?,?)', [owner, sourceItemId, itemCode, itemName, quantity, actorId || null]);
      return (await this.inventory(owner)).find((item) => item.id === Number(result.insertId));
    } catch (error) { if (duplicate(error)) throw new ServiceError('该物品ID已入库', 409, 'DUPLICATE_ITEM'); throw error; }
  }

  async market({ search = '', limit = 100 } = {}) {
    const safeLimit = Math.min(Math.max(Number(limit) || 100, 1), 500), keyword = String(search || '').trim();
    const itemName = "COALESCE((SELECT p.name FROM products p WHERE p.item_id=l.item_code AND p.name<>'' ORDER BY p.enabled DESC,p.id DESC LIMIT 1),l.item_name)";
    const imagePath = "(SELECT p.image_path FROM products p WHERE (p.item_id=l.item_code OR p.item_id=REGEXP_REPLACE(l.item_code,'_ES$','')) AND p.image_path IS NOT NULL AND p.image_path<>'' ORDER BY p.enabled DESC,p.id DESC LIMIT 1)";
    const where = keyword ? ` AND (${itemName} LIKE ? OR l.item_code LIKE ?)` : '', params = keyword ? [`%${keyword}%`, `%${keyword}%`] : [];
    return rows(await this.db.query(`SELECT l.id,l.inventory_id AS inventoryId,l.seller_steam_id AS sellerSteamId,COALESCE(NULLIF(a.\`游戏名称\`,''),NULLIF(a.\`登录账号\`,''),l.seller_steam_id) AS sellerName,l.item_code AS itemCode,${itemName} AS itemName,${imagePath} AS imagePath,b.source_item_id AS sourceItemId,l.quantity,l.remaining_quantity AS remainingQuantity,l.unit_price AS unitPrice,l.fee_bps AS feeBps,l.status,b.item_health AS itemHealth,b.item_max_health AS itemMaxHealth,b.item_uses AS itemUses,COALESCE(b.item_max_uses,(SELECT p.max_uses FROM products p WHERE (p.item_id=l.item_code OR p.item_id=REGEXP_REPLACE(l.item_code,'_ES$','')) AND p.max_uses IS NOT NULL ORDER BY p.enabled DESC,p.id DESC LIMIT 1)) AS itemMaxUses,b.item_max_quantity AS itemMaxQuantity,b.item_dirtiness AS itemDirtiness,b.item_stackable AS itemStackable,l.created_at AS createdAt,l.updated_at AS updatedAt FROM cloud_market_listings l JOIN cloud_inventory_batches b ON b.id=l.inventory_id LEFT JOIN \`商城用户\` a ON a.\`SteamID\`=l.seller_steam_id WHERE l.status='active' AND l.remaining_quantity>0${where} ORDER BY itemName,l.unit_price,l.id LIMIT ${safeLimit}`, params)).map(listingRow);
  }

  async list(steamId, inventoryId, input) {
    const owner = steam(steamId), batchId = id(inventoryId, '库存编号'), unitPrice = positive(input?.unitPrice, '单价', Number.MAX_SAFE_INTEGER);
    const settings = await this.settings();
    if (!settings.marketEnabled) throw new ServiceError('交易中心未开放', 409, 'MARKET_DISABLED');
    const fee = marketFee(unitPrice, settings.feeBps, settings.minimumFee);
    if (unitPrice <= fee) throw new ServiceError('上架单价必须大于手续费', 409, 'PRICE_NOT_GREATER_THAN_FEE');
    return this.db.transaction(async (tx) => {
      const batch = rows(await tx.query('SELECT id,steam_id AS steamId,item_code AS itemCode,item_name AS itemName,quantity,reserved_quantity AS reservedQuantity,item_stackable AS itemStackable,status FROM cloud_inventory_batches WHERE id=? FOR UPDATE', [batchId]))[0];
      if (!batch || batch.steamId !== owner) throw new ServiceError('库存不存在', 404, 'NOT_FOUND');
      const storedQuantity = Boolean(batch.itemStackable) ? 1 : Number(batch.quantity), quantity = 1;
      if (batch.status !== 'active' || Number(batch.reservedQuantity) > 0 || storedQuantity < 1) throw new ServiceError('可上架库存不足', 409, 'INSUFFICIENT_INVENTORY');
      const result = await tx.query('INSERT INTO cloud_market_listings (inventory_id,seller_steam_id,item_code,item_name,quantity,remaining_quantity,unit_price,fee_bps,minimum_fee) VALUES (?,?,?,?,?,?,?,?,?)', [batchId, owner, batch.itemCode, batch.itemName, quantity, quantity, unitPrice, settings.feeBps, settings.minimumFee]);
      await tx.query('UPDATE cloud_inventory_batches SET reserved_quantity=? WHERE id=?', [storedQuantity, batchId]);
      return { id: Number(result.insertId), inventoryId: batchId, itemCode: batch.itemCode, itemName: batch.itemName, quantity, remainingQuantity: quantity, unitPrice, feeBps: settings.feeBps, status: 'active' };
    });
  }

  async withdraw(steamId, inventoryId, input, options = {}) {
    const owner = steam(steamId), batchId = id(inventoryId, '库存编号'), quantity = 1;
    if (!this.clients) throw new ServiceError('RCON 服务未就绪', 503, 'WITHDRAW_UNAVAILABLE');
    const settings = await this.settings();
    const withdrawFee = options.withdrawFee === undefined ? settings.withdrawFee : Number(options.withdrawFee);
    const withdrawalId = randomUUID();
    const reserved = await this.db.transaction(async (tx) => {
      const batch = rows(await tx.query('SELECT id,steam_id AS steamId,source_item_id AS sourceItemId,item_code AS itemCode,item_name AS itemName,quantity,reserved_quantity AS reservedQuantity,item_health AS itemHealth,item_max_health AS itemMaxHealth,item_dirtiness AS itemDirtiness,item_uses AS itemUses,item_stackable AS itemStackable,item_snapshot_json AS itemSnapshotJson,status FROM cloud_inventory_batches WHERE id=? FOR UPDATE', [batchId]))[0];
      if (!batch || batch.steamId !== owner) throw new ServiceError('库存不存在', 404, 'NOT_FOUND');
      if (batch.status !== 'active' || Number(batch.reservedQuantity) !== 0) throw new ServiceError('可取出库存不足', 409, 'INSUFFICIENT_INVENTORY');
      const storedQuantity = Number(batch.quantity);
      const storedSnapshot = typeof batch.itemSnapshotJson === 'string' ? JSON.parse(batch.itemSnapshotJson) : batch.itemSnapshotJson;
      const vehicle = storedSnapshot?.actionType === 'spawn_vehicle';
      const stackable = Boolean(batch.itemStackable) && !discreteUsageOnly(batch.itemSnapshotJson);
      const inventoryQuantity = stackable ? 1 : storedQuantity;
      if (!batch.itemSnapshotJson && batch.sourceItemId) throw new ServiceError('该库存没有完整物品快照，禁止按默认满属性取出', 409, 'INCOMPLETE_ITEM_SNAPSHOT');
      if (withdrawFee > 0) {
        const account = rows(await tx.query('SELECT \`SteamID\` AS steamId,\`商城币余额\` AS balance FROM \`商城用户\` WHERE \`SteamID\`=? FOR UPDATE', [owner]))[0];
        if (!account || Number(account.balance) < withdrawFee) throw new ServiceError('商城币余额不足，无法支付取出手续费', 409, 'INSUFFICIENT_BALANCE');
        const balanceAfter = Number(account.balance) - withdrawFee;
        await tx.query('UPDATE \`商城用户\` SET \`商城币余额\`=? WHERE \`SteamID\`=?', [balanceAfter, owner]);
        await tx.query('INSERT INTO coin_ledger (steam_id,amount,balance_after,type,reference_type,reference_id,note) VALUES (?,?,?,?,?,?,?)', [owner, -withdrawFee, balanceAfter, 'cloud_withdraw_fee', 'cloud_withdraw_fee', withdrawalId, `取出手续费：库存 ${batchId} × ${quantity}`]);
      }
      if (vehicle) {
        if (storedQuantity !== 1) throw new ServiceError('载具库存数量无效', 409, 'INVALID_VEHICLE_INVENTORY');
        await tx.query('UPDATE cloud_inventory_batches SET reserved_quantity=1 WHERE id=?', [batchId]);
        return { itemCode: code(batch.itemCode), itemName: batch.itemName, inventoryQuantity: 1, vehicle: true };
      }
      if (!batch.itemSnapshotJson) {
        await tx.query('UPDATE cloud_inventory_batches SET reserved_quantity=? WHERE id=?', [inventoryQuantity, batchId]);
        return { itemCode: code(batch.itemCode), itemName: batch.itemName, inventoryQuantity, spawnCount: 1, uses: null, health: null, dirtiness: null, legacy: true };
      }
      const hasStoredUses = batch.itemUses !== null && batch.itemUses !== undefined;
      const uses = hasStoredUses ? Number(batch.itemUses) : 0;
      if (!Number.isSafeInteger(uses) || uses < 0 || uses > 10000) throw new ServiceError('物品剩余次数无法恢复', 409, 'UNSUPPORTED_ITEM_ATTRIBUTES');
      const health = batch.itemHealth === null || batch.itemHealth === undefined ? null : Number(batch.itemHealth);
      await tx.query('UPDATE cloud_inventory_batches SET reserved_quantity=? WHERE id=?', [inventoryQuantity, batchId]);
      const dirtiness = percent(batch.itemDirtiness, 0);
      return { itemCode: code(batch.itemCode), itemName: batch.itemName, inventoryQuantity, spawnCount: 1, stackCount: stackable ? (hasStoredUses ? uses : storedQuantity) : null, uses: stackable ? 0 : uses, health: percent(health, 100), dirtiness: String(Number(dirtiness) / 100) };
    });
    try {
      const { ggcon } = await this.clients();
      const command = reserved.vehicle
        ? `#SpawnVehicle ${reserved.itemCode} 1 Location ${owner}`
        : reserved.legacy
        ? `SpawnItem ${reserved.itemCode} 1 Location ${owner}`
        : `SpawnItemForPlayer ${owner} ${reserved.itemCode} 1 Uses ${reserved.uses} Health ${reserved.health} Dirtiness ${reserved.dirtiness}${reserved.stackCount === null ? '' : ` StackCount ${reserved.stackCount}`} CONFIRM`;
      const result = await ggcon.command(command, { retry: false });
      assertRconDeliveryResult(result);
      if (reserved.vehicle ? !responseText(result).split(/\r?\n/).includes('spawn_vehicle_for_player=executed') : responseFields(result).get('spawn_item_for_player') !== 'executed') throw new Error('生成接口未返回明确成功结果');
    } catch (error) {
      if (error?.uncertainDelivery) throw new ServiceError('物品取出结果不确定，库存已锁定等待人工核验', 503, 'WITHDRAW_UNCERTAIN');
      await this.db.transaction(async (tx) => {
        await tx.query('UPDATE cloud_inventory_batches SET reserved_quantity=0 WHERE id=? AND reserved_quantity=?', [batchId, reserved.inventoryQuantity]);
        if (withdrawFee > 0) {
          const account = rows(await tx.query('SELECT \`SteamID\` AS steamId,\`商城币余额\` AS balance FROM \`商城用户\` WHERE \`SteamID\`=? FOR UPDATE', [owner]))[0];
          if (!account) throw new ServiceError('退款账户不存在', 409, 'NOT_FOUND');
          const balanceAfter = Number(account.balance) + withdrawFee;
          await tx.query('UPDATE \`商城用户\` SET \`商城币余额\`=? WHERE \`SteamID\`=?', [balanceAfter, owner]);
          await tx.query('INSERT INTO coin_ledger (steam_id,amount,balance_after,type,reference_type,reference_id,note) VALUES (?,?,?,?,?,?,?)', [owner, withdrawFee, balanceAfter, 'cloud_withdraw_refund', 'cloud_withdraw_refund', withdrawalId, '取出失败退还手续费']);
        }
      });
      throw new ServiceError(error.message || '物品取出失败', 409, 'WITHDRAW_REJECTED');
    }
    await this.db.query("UPDATE cloud_inventory_batches SET status='empty',quantity=0,reserved_quantity=0 WHERE id=? AND reserved_quantity=?", [batchId, reserved.inventoryQuantity]);
    if (options.notify !== false) await this.notify(owner, reserved.itemName, reserved.itemCode, quantity, '取出成功');
    return { id: batchId, itemCode: reserved.itemCode, itemName: reserved.itemName, quantity, fee: withdrawFee, status: 'completed' };
  }

  async cancel(steamId, listingId, admin = false) {
    const owner = admin ? null : steam(steamId), target = id(listingId, '挂单编号');
    return this.db.transaction(async (tx) => {
      const listing = rows(await tx.query('SELECT id,inventory_id AS inventoryId,seller_steam_id AS sellerSteamId,remaining_quantity AS remainingQuantity,status FROM cloud_market_listings WHERE id=? FOR UPDATE', [target]))[0];
      if (!listing || (!admin && listing.sellerSteamId !== owner)) throw new ServiceError('挂单不存在', 404, 'NOT_FOUND');
      if (listing.status !== 'active') throw new ServiceError('挂单状态不可撤销', 409, 'INVALID_STATE');
      await tx.query("UPDATE cloud_market_listings SET status='cancelled' WHERE id=?", [target]);
      await tx.query('UPDATE cloud_inventory_batches SET reserved_quantity=0 WHERE id=?', [listing.inventoryId]);
      return { id: target, status: 'cancelled' };
    });
  }

  async buy(steamId, listingId, input, requestKey) {
    const buyer = steam(steamId), target = id(listingId, '挂单编号'), quantity = 1, key = text(requestKey, 'Idempotency-Key', 100);
    const existing = rows(await this.db.query('SELECT id,listing_id AS listingId,buyer_steam_id AS buyerSteamId,quantity FROM cloud_market_trades WHERE request_key=?', [key]))[0];
    if (existing) {
      if (existing.buyerSteamId !== buyer || Number(existing.listingId) !== target || Number(existing.quantity) !== quantity) throw new ServiceError('Idempotency-Key 已被其他请求使用', 409, 'IDEMPOTENCY_CONFLICT');
      return { ...existing, idempotent: true };
    }
    const settings = await this.settings();
    if (!settings.marketEnabled) throw new ServiceError('交易中心未开放', 409, 'MARKET_DISABLED');
    try {
      return await this.db.transaction(async (tx) => {
        const listing = rows(await tx.query('SELECT id,inventory_id AS inventoryId,seller_steam_id AS sellerSteamId,item_code AS itemCode,item_name AS itemName,remaining_quantity AS remainingQuantity,unit_price AS unitPrice,fee_bps AS feeBps,minimum_fee AS minimumFee,status FROM cloud_market_listings WHERE id=? FOR UPDATE', [target]))[0];
        if (!listing || listing.status !== 'active') throw new ServiceError('挂单不存在或已结束', 404, 'NOT_FOUND');
        if (listing.sellerSteamId === buyer) throw new ServiceError('不能购买自己的挂单', 409, 'SELF_TRADE');
        if (Number(listing.remainingQuantity) < 1) throw new ServiceError('可售数量不足', 409, 'INSUFFICIENT_LISTING');
        await tx.query('INSERT INTO \`商城用户\` (\`SteamID\`,\`商城币余额\`) VALUES (?,0),(?,0) ON DUPLICATE KEY UPDATE \`SteamID\`=VALUES(\`SteamID\`)', [buyer, listing.sellerSteamId]);
        const accounts = rows(await tx.query('SELECT \`SteamID\` AS steamId,\`商城币余额\` AS balance FROM \`商城用户\` WHERE \`SteamID\` IN (?,?) FOR UPDATE', [buyer, listing.sellerSteamId]));
        const buyerAccount = accounts.find((item) => item.steamId === buyer), sellerAccount = accounts.find((item) => item.steamId === listing.sellerSteamId);
        const gross = Number(listing.unitPrice) * quantity;
        if (!Number.isSafeInteger(gross)) throw new ServiceError('交易金额超出安全范围');
        const fee = marketFee(gross, listing.feeBps, listing.minimumFee), sellerNet = gross - fee;
        if (gross <= fee) throw new ServiceError('成交总价必须大于手续费', 409, 'PRICE_NOT_GREATER_THAN_FEE');
        if (Number(buyerAccount.balance) < gross) throw new ServiceError('商城币余额不足', 409, 'INSUFFICIENT_BALANCE');
        const buyerAfter = Number(buyerAccount.balance) - gross, sellerAfter = Number(sellerAccount.balance) + sellerNet;
        const result = await tx.query('INSERT INTO cloud_market_trades (request_key,listing_id,seller_steam_id,buyer_steam_id,item_code,item_name,quantity,unit_price,gross_amount,fee,seller_net,buyer_balance_after,seller_balance_after) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)', [key,target,listing.sellerSteamId,buyer,listing.itemCode,listing.itemName,quantity,listing.unitPrice,gross,fee,sellerNet,buyerAfter,sellerAfter]);
        await tx.query('UPDATE \`商城用户\` SET \`商城币余额\`=? WHERE \`SteamID\`=?', [buyerAfter,buyer]);
        await tx.query('UPDATE \`商城用户\` SET \`商城币余额\`=? WHERE \`SteamID\`=?', [sellerAfter,listing.sellerSteamId]);
        await tx.query("UPDATE cloud_market_listings SET remaining_quantity=0,status='sold' WHERE id=?", [target]);
        await tx.query("UPDATE cloud_inventory_batches SET steam_id=?,reserved_quantity=0,status='active' WHERE id=?", [buyer,listing.inventoryId]);
        await tx.query("INSERT INTO coin_ledger (steam_id,amount,balance_after,type,reference_type,reference_id,note) VALUES (?,?,?,'cloud_market_buy','cloud_trade_buy',?,?),(?,?,?,'cloud_market_sell','cloud_trade_sell',?,?)",[buyer,-gross,buyerAfter,String(result.insertId),`购买 ${listing.itemName} × ${quantity}`,listing.sellerSteamId,sellerNet,sellerAfter,String(result.insertId),`出售 ${listing.itemName} × ${quantity}`]);
        return { id:Number(result.insertId), listingId:target, quantity, grossAmount:gross, fee, sellerNet, buyerBalanceAfter:buyerAfter, idempotent:false };
      });
    } catch (error) {
      if (!duplicate(error)) throw error;
      const trade = rows(await this.db.query('SELECT id,listing_id AS listingId,quantity,gross_amount AS grossAmount,fee,seller_net AS sellerNet,buyer_balance_after AS buyerBalanceAfter FROM cloud_market_trades WHERE request_key=?',[key]))[0];
      if (!trade) throw error;
      return { ...trade, idempotent:true };
    }
  }

  async trades(steamId = null, limit = 100) {
    const safe = Math.min(Math.max(Number(limit)||100,1),500), where = steamId ? ' WHERE t.buyer_steam_id=? OR t.seller_steam_id=?' : '', params = steamId ? [steam(steamId),steamId] : [];
    return rows(await this.db.query(`SELECT t.id,t.listing_id AS listingId,t.seller_steam_id AS sellerSteamId,COALESCE(NULLIF(sa.\`游戏名称\`,''),NULLIF(sa.\`登录账号\`,''),t.seller_steam_id) AS sellerName,t.buyer_steam_id AS buyerSteamId,COALESCE(NULLIF(ba.\`游戏名称\`,''),NULLIF(ba.\`登录账号\`,''),t.buyer_steam_id) AS buyerName,t.item_code AS itemCode,t.item_name AS itemName,t.quantity,t.unit_price AS unitPrice,t.gross_amount AS grossAmount,t.fee,t.seller_net AS sellerNet,t.created_at AS createdAt FROM cloud_market_trades t LEFT JOIN \`商城用户\` sa ON sa.\`SteamID\`=t.seller_steam_id LEFT JOIN \`商城用户\` ba ON ba.\`SteamID\`=t.buyer_steam_id${where} ORDER BY t.id DESC LIMIT ${safe}`,params));
  }

  async listingLogs(limit = 300) {
    const safe = Math.min(Math.max(Number(limit)||300,1),500);
    return rows(await this.db.query(`SELECT l.id,l.inventory_id AS inventoryId,l.seller_steam_id AS sellerSteamId,COALESCE(NULLIF(a.\`游戏名称\`,''),NULLIF(a.\`登录账号\`,''),l.seller_steam_id) AS sellerName,l.item_code AS itemCode,l.item_name AS itemName,l.quantity,l.unit_price AS unitPrice,l.status,l.created_at AS createdAt FROM cloud_market_listings l LEFT JOIN \`商城用户\` a ON a.\`SteamID\`=l.seller_steam_id ORDER BY l.id DESC LIMIT ${safe}`));
  }

  async adminOverview(query = {}) {
    const steamId = String(query.steamId || '').trim();
    const search = String(query.search || '').trim().slice(0,255);
    const searchWhere = search ? " AND (b.item_name LIKE ? OR b.item_code LIKE ? OR b.steam_id LIKE ? OR EXISTS (SELECT 1 FROM \`商城用户\` a WHERE a.\`SteamID\`=b.steam_id AND (a.\`游戏名称\` LIKE ? OR a.\`登录账号\` LIKE ?)) OR EXISTS (SELECT 1 FROM products p WHERE (p.item_id=b.item_code OR p.item_id=REGEXP_REPLACE(b.item_code,'_ES$','')) AND p.name LIKE ?))" : '';
    const params = search ? Array(6).fill('%'+search+'%') : [];
    const inventorySql = [
      "SELECT b.id,b.steam_id AS steamId,b.source_item_id AS sourceItemId,b.item_code AS itemCode,(SELECT CASE WHEN COUNT(*)=0 THEN NULL WHEN SUM(l.status='active' AND l.remaining_quantity>0)>0 THEN 'active' WHEN SUM(l.status='sold')>0 THEN 'sold' ELSE 'cancelled' END FROM cloud_market_listings l WHERE l.inventory_id=b.id) AS tradeStatus,",
      "COALESCE((SELECT p.name FROM products p WHERE (p.item_id=b.item_code OR p.item_id=REGEXP_REPLACE(b.item_code,'_ES$','')) AND p.name<>'' ORDER BY p.enabled DESC,p.id DESC LIMIT 1),b.item_name) AS itemName,",
      "(SELECT p.image_path FROM products p WHERE (p.item_id=b.item_code OR p.item_id=REGEXP_REPLACE(b.item_code,'_ES$','')) AND p.image_path IS NOT NULL AND p.image_path<>'' ORDER BY p.enabled DESC,p.id DESC LIMIT 1) AS imagePath,",
      "b.item_health AS itemHealth,b.item_uses AS itemUses,b.item_max_uses AS itemMaxUses,b.item_dirtiness AS itemDirtiness,",
      "COALESCE(NULLIF(a.\`游戏名称\`,''),NULLIF(a.\`登录账号\`,''),b.steam_id) AS playerName,",
      "b.quantity,b.reserved_quantity AS reservedQuantity,b.status,b.created_at AS createdAt,b.updated_at AS updatedAt",
      "FROM cloud_inventory_batches b LEFT JOIN \`商城用户\` a ON a.\`SteamID\`=b.steam_id WHERE 1=1", searchWhere,
      "ORDER BY b.id DESC LIMIT 200"
    ].filter(Boolean).join(' ');
    const inventory = steamId ? await this.inventory(steamId) : rows(await this.db.query(inventorySql,params)).map(inventoryRow);
    const stats = rows(await this.db.query("SELECT (SELECT COUNT(DISTINCT steam_id) FROM cloud_inventory_batches WHERE status<>'empty') AS warehouses,(SELECT COUNT(*) FROM cloud_inventory_batches WHERE status<>'empty') AS inventory,(SELECT COUNT(*) FROM cloud_market_listings WHERE status='active') AS listings,(SELECT COALESCE(SUM(remaining_quantity),0) FROM cloud_market_listings WHERE status='active') AS marketOrders,(SELECT COUNT(*) FROM cloud_market_trades) AS trades"))[0] || {};
    return { settings:await this.settings(), stats:Object.fromEntries(Object.entries(stats).map(([key,value])=>[key,Number(value)])), inventory, listings:await this.market({limit:200}), listingLogs:await this.listingLogs(300), trades:await this.trades(null,300) };
  }
}
