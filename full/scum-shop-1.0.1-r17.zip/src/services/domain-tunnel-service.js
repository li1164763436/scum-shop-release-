import fs from 'node:fs/promises';
import path from 'node:path';
import { execFile as nodeExecFile, spawn as nodeSpawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { promisify } from 'node:util';
import { LICENSE_PRODUCT_CODE } from './license-client.js';

const execFile = promisify(nodeExecFile);
const DEFAULT_GATEWAY_URL = 'https://domains.scum0.cn/v1/tunnel/enroll';
const DEFAULT_RETRY_BASE_MS = 1000;
const DEFAULT_RETRY_MAX_MS = 60000;

export class DomainTunnelError extends Error {
  constructor(message, code = 'DOMAIN_TUNNEL_FAILED', options) {
    super(message, options);
    this.name = 'DomainTunnelError';
    this.code = code;
  }
}

function fail(message, code, cause) {
  return new DomainTunnelError(message, code, cause ? { cause } : undefined);
}

function parseUrl(value, label) {
  let url;
  try { url = new URL(String(value || '')); }
  catch (error) { throw fail(`${label}无效`, 'DOMAIN_TUNNEL_CONFIG_INVALID', error); }
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash) {
    throw fail(`${label}必须使用 HTTPS`, 'DOMAIN_TUNNEL_CONFIG_INVALID');
  }
  return url;
}

function allowedGatewayHosts(value) {
  const hosts = String(value || 'domains.scum0.cn').split(',').map((item) => item.trim().toLowerCase()).filter(Boolean);
  if (!hosts.length || hosts.some((host) => !/^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?(?::\d{1,5})?$/i.test(host))) {
    throw fail('Gateway 主机白名单无效', 'DOMAIN_TUNNEL_CONFIG_INVALID');
  }
  return new Set(hosts);
}

function gatewayConfiguration(env) {
  const enrollUrl = parseUrl(env.DOMAIN_TUNNEL_GATEWAY_URL || DEFAULT_GATEWAY_URL, 'Gateway 地址');
  const hosts = allowedGatewayHosts(env.DOMAIN_TUNNEL_GATEWAY_ALLOWED_HOSTS);
  if (!hosts.has(enrollUrl.host.toLowerCase())) throw fail('Gateway 地址不在白名单中', 'DOMAIN_TUNNEL_CONFIG_INVALID');
  return { enrollUrl, statusUrl: new URL('/v1/tunnel/status', enrollUrl) };
}

function readUint32(buffer, offset) {
  if (offset + 4 > buffer.length) throw fail('公钥格式无效', 'DOMAIN_TUNNEL_PUBLIC_KEY_INVALID');
  return buffer.readUInt32BE(offset);
}

function readSshString(buffer, offset) {
  const length = readUint32(buffer, offset);
  const start = offset + 4;
  const end = start + length;
  if (end > buffer.length) throw fail('公钥格式无效', 'DOMAIN_TUNNEL_PUBLIC_KEY_INVALID');
  return { value: buffer.subarray(start, end), offset: end };
}

export function parseEd25519PublicKey(input) {
  const fields = String(input || '').trim().split(/\s+/);
  if (fields.length < 2 || fields[0] !== 'ssh-ed25519' || !/^[A-Za-z0-9+/]+={0,2}$/.test(fields[1])) {
    throw fail('公钥格式无效', 'DOMAIN_TUNNEL_PUBLIC_KEY_INVALID');
  }
  let blob;
  try { blob = Buffer.from(fields[1], 'base64'); }
  catch (error) { throw fail('公钥格式无效', 'DOMAIN_TUNNEL_PUBLIC_KEY_INVALID', error); }
  const algorithm = readSshString(blob, 0);
  const key = readSshString(blob, algorithm.offset);
  if (algorithm.value.toString('ascii') !== 'ssh-ed25519' || key.value.length !== 32 || key.offset !== blob.length) {
    throw fail('公钥格式无效', 'DOMAIN_TUNNEL_PUBLIC_KEY_INVALID');
  }
  return {
    publicKey: `ssh-ed25519 ${fields[1]}`,
    fingerprint: `SHA256:${createHash('sha256').update(blob).digest('base64').replace(/=+$/, '')}`
  };
}

export function validateKnownHostsLine(line, sshHost, sshPort) {
  const fields = String(line || '').trim().split(/\s+/);
  const expectedHost = `[${sshHost}]:${sshPort}`;
  if (fields.length !== 3 || fields[0] !== expectedHost || fields[1] !== 'ssh-ed25519') {
    throw fail('Gateway known_hosts 绑定无效', 'DOMAIN_TUNNEL_KNOWN_HOSTS_INVALID');
  }
  parseEd25519PublicKey(`${fields[1]} ${fields[2]}`);
  return `${fields.join(' ')}\n`;
}

function integer(value, minimum, maximum, code = 'DOMAIN_TUNNEL_RESPONSE_INVALID') {
  if (!Number.isInteger(value) || value < minimum || value > maximum) throw fail('Tunnel 响应格式无效', code);
  return value;
}

function text(value, maximum = 8192, code = 'DOMAIN_TUNNEL_RESPONSE_INVALID') {
  if (typeof value !== 'string' || !value || value.length > maximum) throw fail('Tunnel 响应格式无效', code);
  return value;
}

function validateEnrollment(body) {
  const data = body?.data;
  if (body?.success !== true || !data || typeof data !== 'object' || Array.isArray(data)) throw fail('授权中心注册响应无效', 'DOMAIN_TUNNEL_ENROLLMENT_INVALID');
  const expiresAt = Date.parse(data.expiresAt);
  if (!Number.isFinite(expiresAt) || expiresAt <= Date.now()) throw fail('授权中心注册码已失效', 'DOMAIN_TUNNEL_ENROLLMENT_INVALID');
  return { enrollmentCode: text(data.enrollmentCode, 2048, 'DOMAIN_TUNNEL_ENROLLMENT_INVALID'), expiresAt };
}

function validateGateway(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw fail('Gateway 响应无效', 'DOMAIN_TUNNEL_GATEWAY_INVALID');
  const sshHost = text(body.sshHost, 253, 'DOMAIN_TUNNEL_GATEWAY_INVALID');
  if (!/^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/i.test(sshHost)) throw fail('Gateway SSH 主机无效', 'DOMAIN_TUNNEL_GATEWAY_INVALID');
  const sshUser = text(body.sshUser, 32, 'DOMAIN_TUNNEL_GATEWAY_INVALID');
  if (!/^[a-z_][a-z0-9_-]{0,31}$/i.test(sshUser)) throw fail('Gateway SSH 用户无效', 'DOMAIN_TUNNEL_GATEWAY_INVALID');
  return {
    state: text(body.state, 32, 'DOMAIN_TUNNEL_GATEWAY_INVALID'),
    statusToken: text(body.statusToken, 8192, 'DOMAIN_TUNNEL_GATEWAY_INVALID'),
    sshHost,
    sshPort: integer(body.sshPort, 1, 65535, 'DOMAIN_TUNNEL_GATEWAY_INVALID'),
    sshUser,
    remotePort: integer(body.remotePort, 1, 65535, 'DOMAIN_TUNNEL_GATEWAY_INVALID'),
    knownHostsLine: text(body.knownHostsLine, 16384, 'DOMAIN_TUNNEL_GATEWAY_INVALID')
  };
}

function statusAuthorized(body) {
  return ['authorized', 'ready'].includes(String(body?.state || '').toLowerCase());
}

function statusReady(body) {
  const state = String(body?.state || '').toLowerCase();
  const status = String(body?.status || '').toLowerCase();
  return state === 'ready' && status === 'healthy';
}

function statusFailed(body) {
  return ['failed', 'rejected', 'expired', 'disabled'].includes(String(body?.state || '').toLowerCase());
}

function optionalDomain(value) {
  if (value === null || value === undefined || value === '') return null;
  const domain = String(value).trim().toLowerCase();
  if (domain.length > 253 || !domain.split('.').every((label) => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i.test(label))) {
    throw fail('Gateway 域名状态无效', 'DOMAIN_TUNNEL_GATEWAY_INVALID');
  }
  return domain;
}

function normalizeDomainStatus(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw fail('Gateway 响应无效', 'DOMAIN_TUNNEL_GATEWAY_INVALID');
  const managedHost = optionalDomain(body.managedHost);
  let customDomain = null;
  if (body.customDomain !== null && body.customDomain !== undefined) {
    if (typeof body.customDomain !== 'object' || Array.isArray(body.customDomain)) throw fail('Gateway 域名状态无效', 'DOMAIN_TUNNEL_GATEWAY_INVALID');
    const state = text(body.customDomain.state, 32, 'DOMAIN_TUNNEL_GATEWAY_INVALID').toLowerCase();
    if (!/^[a-z][a-z0-9_]{0,31}$/.test(state)) throw fail('Gateway 域名状态无效', 'DOMAIN_TUNNEL_GATEWAY_INVALID');
    customDomain = { domain: optionalDomain(body.customDomain.domain), state };
    if (!customDomain.domain) throw fail('Gateway 域名状态无效', 'DOMAIN_TUNNEL_GATEWAY_INVALID');
  }
  return {
    connectionState: text(body.state, 32, 'DOMAIN_TUNNEL_GATEWAY_INVALID').toLowerCase(),
    tunnelStatus: text(body.status, 32, 'DOMAIN_TUNNEL_GATEWAY_INVALID').toLowerCase(),
    managedDomain: managedHost ? { domain: managedHost, enabled: body.managedEnabled === true } : null,
    customDomain,
    updatedAt: new Date().toISOString()
  };
}

export class DomainTunnelService {
  constructor({
    root,
    localPort = 3090,
    licenseStore,
    logger,
    env = process.env,
    fetchImpl = globalThis.fetch,
    fsImpl = fs,
    execFileImpl = execFile,
    spawnImpl = nodeSpawn,
    platform = process.platform,
    timers = globalThis,
    random = Math.random,
    processImpl = process
  } = {}) {
    this.root = path.resolve(root || '.');
    this.localPort = integer(Number(localPort), 1, 65535, 'DOMAIN_TUNNEL_CONFIG_INVALID');
    this.licenseStore = licenseStore;
    this.logger = logger;
    this.env = env;
    this.fetchImpl = fetchImpl;
    this.fs = fsImpl;
    this.execFile = execFileImpl;
    this.spawn = spawnImpl;
    this.platform = platform;
    this.timers = timers;
    this.random = random;
    this.process = processImpl;
    this.exitHandler = null;
    this.keyDirectory = path.join(this.root, 'runtime', 'secrets', 'domain-tunnel');
    this.keyPath = path.join(this.keyDirectory, 'id_ed25519');
    this.publicKeyPath = `${this.keyPath}.pub`;
    this.knownHostsPath = path.join(this.keyDirectory, 'known_hosts');
    this.running = false;
    this.loopPromise = null;
    this.child = null;
    this.requestControllers = new Set();
    this.statusContext = null;
    this.latestStatus = null;
    this.delayTimer = null;
    this.delayResolve = null;
  }

  start() {
    if (this.running) return this.loopPromise;
    this.running = true;
    this.exitHandler = () => {
      this.running = false;
      if (this.child && this.child.exitCode === null) this.child.kill();
    };
    this.process.once('exit', this.exitHandler);
    this.loopPromise = this.supervise().catch((error) => {
      this.log('error', 'Domain tunnel supervisor 意外停止', error?.code || 'DOMAIN_TUNNEL_SUPERVISOR_FAILED');
    });
    return this.loopPromise;
  }

  async stop() {
    if (!this.running && !this.loopPromise) return;
    this.running = false;
    if (this.exitHandler) this.process.removeListener('exit', this.exitHandler);
    this.exitHandler = null;
    for (const controller of this.requestControllers) controller.abort();
    this.requestControllers.clear();
    if (this.delayTimer !== null) this.timers.clearTimeout(this.delayTimer);
    this.delayTimer = null;
    this.delayResolve?.();
    this.delayResolve = null;
    const child = this.child;
    this.child = null;
    if (child && child.exitCode === null) child.kill();
    const loop = this.loopPromise;
    if (loop) await loop;
    this.loopPromise = null;
    this.latestStatus = null;
  }

  log(level, message, errorCode) {
    this.logger?.[level]?.(message, { component: 'domain-tunnel', ...(errorCode ? { errorCode } : {}) });
  }

  async supervise() {
    let failures = 0;
    while (this.running) {
      try {
        const identity = await this.ensureIdentity();
        const license = await this.licenseStore.read();
        const authorizationUrl = parseUrl(new URL('/api/v1/client/gateway-tunnel-enrollment', license.baseUrl).toString(), '授权中心地址');
        const gateway = gatewayConfiguration(this.env);
        const enrollmentBody = await this.requestJson(authorizationUrl, {
          method: 'POST',
          headers: { 'content-type': 'application/json', accept: 'application/json' },
          body: JSON.stringify({ licenseToken: license.licenseToken, productCode: LICENSE_PRODUCT_CODE, publicKeyFingerprint: identity.fingerprint })
        });
        const enrollment = validateEnrollment(enrollmentBody);
        const tunnel = validateGateway(await this.requestJson(gateway.enrollUrl, {
          method: 'POST',
          headers: { 'content-type': 'application/json', accept: 'application/json' },
          body: JSON.stringify({ code: enrollment.enrollmentCode, publicKey: identity.publicKey })
        }));
        this.statusContext = { statusUrl: gateway.statusUrl, statusToken: tunnel.statusToken };
        const knownHosts = validateKnownHostsLine(tunnel.knownHostsLine, tunnel.sshHost, tunnel.sshPort);
        await this.fs.writeFile(this.knownHostsPath, knownHosts, { encoding: 'utf8', mode: 0o600 });
        await this.waitUntilAuthorized(gateway.statusUrl, tunnel.statusToken);
        if (!this.running) break;
        failures = 0;
        await this.connectTunnel(tunnel, gateway.statusUrl);
      } catch (error) {
        this.latestStatus = null;
        if (!this.running) break;
        failures += 1;
        this.log('warn', 'Domain tunnel 暂不可用，将自动重试', error?.code || 'DOMAIN_TUNNEL_FAILED');
        await this.delay(this.retryDelay(failures));
      }
    }
  }

  retryDelay(failures) {
    const base = Number(this.env.DOMAIN_TUNNEL_RETRY_BASE_MS) || DEFAULT_RETRY_BASE_MS;
    const maximum = Number(this.env.DOMAIN_TUNNEL_RETRY_MAX_MS) || DEFAULT_RETRY_MAX_MS;
    const capped = Math.min(maximum, base * (2 ** Math.min(Math.max(failures - 1, 0), 16)));
    return Math.max(0, Math.round(capped * (0.8 + this.random() * 0.4)));
  }

  currentDomainStatus() {
    return this.latestStatus || {
      connectionState: this.running ? 'connecting' : 'stopped',
      tunnelStatus: this.running ? 'pending' : 'stopped',
      managedDomain: null,
      customDomain: null,
      updatedAt: new Date().toISOString()
    };
  }

  async domainStatus() {
    if (!this.statusContext) return this.currentDomainStatus();
    const body = await this.requestJson(this.statusContext.statusUrl, {
      method: 'GET',
      headers: { accept: 'application/json', authorization: `Bearer ${this.statusContext.statusToken}` }
    });
    this.latestStatus = normalizeDomainStatus(body);
    return this.latestStatus;
  }

  delay(milliseconds) {
    if (!this.running || milliseconds <= 0) return Promise.resolve();
    return new Promise((resolve) => {
      this.delayResolve = resolve;
      this.delayTimer = this.timers.setTimeout(() => {
        this.delayTimer = null;
        this.delayResolve = null;
        resolve();
      }, milliseconds);
      this.delayTimer?.unref?.();
    });
  }

  async ensureIdentity() {
    await this.fs.mkdir(this.keyDirectory, { recursive: true, mode: 0o700 });
    if (this.platform === 'win32') {
      await this.assertSystemIdentity();
      await this.secureKeyDirectory();
    } else {
      await this.fs.chmod(this.keyDirectory, 0o700);
    }
    let privateExists = true;
    try { await this.fs.access(this.keyPath); } catch (error) { if (error?.code === 'ENOENT') privateExists = false; else throw error; }
    if (!privateExists) {
      await this.execFile('ssh-keygen.exe', ['-t', 'ed25519', '-N', '', '-f', this.keyPath], { windowsHide: true });
    }
    await this.securePrivateKey();
    let publicText;
    try { publicText = await this.fs.readFile(this.publicKeyPath, 'utf8'); }
    catch (error) {
      if (error?.code !== 'ENOENT') throw error;
      const result = await this.execFile('ssh-keygen.exe', ['-y', '-f', this.keyPath], { windowsHide: true });
      publicText = String(result?.stdout || '');
      await this.fs.writeFile(this.publicKeyPath, `${publicText.trim()}\n`, { encoding: 'utf8', mode: 0o644 });
    }
    return parseEd25519PublicKey(publicText);
  }

  async assertSystemIdentity() {
    const identity = await this.execFile('whoami.exe', ['/user', '/fo', 'csv', '/nh'], { windowsHide: true });
    if (!/(?:^|[^0-9])S-1-5-18(?:[^0-9]|$)/i.test(String(identity?.stdout || ''))) {
      throw fail('Domain tunnel 私钥只允许 SYSTEM 身份初始化', 'DOMAIN_TUNNEL_SYSTEM_REQUIRED');
    }
  }

  async secureKeyDirectory() {
    const options = { windowsHide: true };
    await this.execFile('icacls.exe', [this.keyDirectory, '/reset'], options);
    await this.execFile('icacls.exe', [this.keyDirectory, '/grant:r', '*S-1-5-18:(OI)(CI)(F)'], options);
    await this.execFile('icacls.exe', [this.keyDirectory, '/setowner', '*S-1-5-18'], options);
    await this.execFile('icacls.exe', [this.keyDirectory, '/inheritance:r'], options);
  }

  async securePrivateKey() {
    if (this.platform !== 'win32') {
      await this.fs.chmod(this.keyPath, 0o600);
      return;
    }
    const options = { windowsHide: true };
    await this.execFile('icacls.exe', [this.keyPath, '/reset'], options);
    await this.execFile('icacls.exe', [this.keyPath, '/grant:r', '*S-1-5-18:(F)'], options);
    await this.execFile('icacls.exe', [this.keyPath, '/setowner', '*S-1-5-18'], options);
    await this.execFile('icacls.exe', [this.keyPath, '/inheritance:r'], options);
  }

  async requestJson(url, options) {
    if (typeof this.fetchImpl !== 'function') throw fail('当前 Node.js 不支持 tunnel 请求', 'DOMAIN_TUNNEL_FETCH_UNAVAILABLE');
    const controller = new AbortController();
    this.requestControllers.add(controller);
    const timeoutMs = Number(this.env.DOMAIN_TUNNEL_REQUEST_TIMEOUT_MS) || 10000;
    const timeout = this.timers.setTimeout(() => controller.abort(), timeoutMs);
    timeout?.unref?.();
    let response;
    try {
      response = await this.fetchImpl(url, { ...options, redirect: 'error', signal: controller.signal });
      if (!response?.ok) throw fail('Tunnel 上游拒绝请求', 'DOMAIN_TUNNEL_UPSTREAM_REJECTED');
      return await response.json();
    } catch (error) {
      if (error instanceof DomainTunnelError) throw error;
      if (error?.name === 'AbortError') throw fail('Tunnel 请求超时', 'DOMAIN_TUNNEL_REQUEST_TIMEOUT', error);
      throw fail('Tunnel 网络请求失败', 'DOMAIN_TUNNEL_NETWORK_ERROR', error);
    } finally {
      this.timers.clearTimeout(timeout);
      this.requestControllers.delete(controller);
    }
  }

  async waitForStatus(statusUrl, statusToken, accepted) {
    while (this.running) {
      const body = await this.requestJson(statusUrl, {
        method: 'GET',
        headers: { accept: 'application/json', authorization: `Bearer ${statusToken}` }
      });
      this.latestStatus = normalizeDomainStatus(body);
      if (accepted(body)) return;
      if (statusFailed(body)) throw fail('Gateway 拒绝 tunnel', 'DOMAIN_TUNNEL_GATEWAY_REJECTED');
      await this.delay(Number(this.env.DOMAIN_TUNNEL_STATUS_INTERVAL_MS) || 2000);
    }
  }

  waitUntilAuthorized(statusUrl, statusToken) {
    return this.waitForStatus(statusUrl, statusToken, statusAuthorized);
  }

  waitUntilReady(statusUrl, statusToken) {
    return this.waitForStatus(statusUrl, statusToken, statusReady);
  }

  async connectTunnel(tunnel, statusUrl) {
    this.log('info', 'Domain tunnel 正在连接');
    const sshExit = this.runSsh(tunnel);
    const unexpectedExit = sshExit.then(() => { throw fail('SSH tunnel 已退出', 'DOMAIN_TUNNEL_SSH_EXITED'); });
    try {
      await Promise.race([this.waitUntilReady(statusUrl, tunnel.statusToken), unexpectedExit]);
      if (!this.running) return;
      this.log('info', 'Domain tunnel 已连接');
      await unexpectedExit;
    } catch (error) {
      const child = this.child;
      if (child && child.exitCode === null) child.kill();
      await sshExit.catch(() => {});
      throw error;
    }
  }

  runSsh(tunnel) {
    if (this.child) throw fail('SSH tunnel 已在运行', 'DOMAIN_TUNNEL_SINGLE_INSTANCE');
    const args = [
      '-NT',
      '-R', `127.0.0.1:${tunnel.remotePort}:127.0.0.1:${this.localPort}`,
      '-p', String(tunnel.sshPort),
      '-i', this.keyPath,
      '-o', 'StrictHostKeyChecking=yes',
      '-o', `UserKnownHostsFile=${this.knownHostsPath}`,
      '-o', 'ExitOnForwardFailure=yes',
      '-o', 'BatchMode=yes',
      '-o', 'IdentitiesOnly=yes',
      '-o', 'PreferredAuthentications=publickey',
      '-o', 'PasswordAuthentication=no',
      '-o', 'KbdInteractiveAuthentication=no',
      '-o', 'GSSAPIAuthentication=no',
      '-o', 'ServerAliveInterval=15',
      '-o', 'ServerAliveCountMax=3',
      `${tunnel.sshUser}@${tunnel.sshHost}`
    ];
    return new Promise((resolve, reject) => {
      let child;
      try { child = this.spawn('ssh.exe', args, { shell: false, windowsHide: true, stdio: 'ignore' }); }
      catch (error) { reject(fail('无法启动 SSH tunnel', 'DOMAIN_TUNNEL_SSH_START_FAILED', error)); return; }
      this.child = child;
      let settled = false;
      const finish = (error) => {
        if (settled) return;
        settled = true;
        if (this.child === child) this.child = null;
        if (error) reject(error); else resolve();
      };
      child.once('error', (error) => finish(fail('SSH tunnel 进程错误', 'DOMAIN_TUNNEL_SSH_START_FAILED', error)));
      child.once('exit', () => finish());
    });
  }
}

export const domainTunnelInternals = {
  DEFAULT_GATEWAY_URL,
  gatewayConfiguration,
  validateEnrollment,
  validateGateway,
  normalizeDomainStatus,
  statusAuthorized,
  statusReady
};
