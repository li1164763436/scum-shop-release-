import { joinUrl, requestWithPolicy } from './http.js';
import { SourceRconClient } from './source-rcon-client.js';
import { resolveScumRconConfig } from './scum-rcon-config.js';
import { assertScumRconSuccess, parseListPlayers, parsePlayerEconomy } from './scum-rcon-parser.js';
import { ScumShopPipeClient } from './scum-shop-pipe-client.js';
import { formatRconAccessMessage, rconCommandName } from './rcon-command-description.js';
import { redact } from '../utils/redactor.js';

function authHeaders(config) {
  const key = config.apiKey;
  if (!key) return { Accept: 'application/json' };
  switch (config.apiKeyMode) {
    case 'authorization-bearer': return { Authorization: `Bearer ${key}`, Accept: 'application/json' };
    case 'authorization-apikey': return { Authorization: `ApiKey ${key}`, Accept: 'application/json' };
    case 'api-key': return { 'Api-Key': key, Accept: 'application/json' };
    default: return { 'X-API-Key': key, Accept: 'application/json' };
  }
}

function normalizePlayers(payload) {
  const list = Array.isArray(payload) ? payload : (payload.players || payload.data || payload.onlinePlayers || []);
  return list.map((player) => ({
    steamId: String(player.steamId ?? player.steamID ?? player.steam_id ?? player.id ?? ''),
    characterName: player.characterName ?? player.character ?? player.name ?? '',
    steamName: player.steamName ?? player.steam_name ?? player.profileName ?? '',
    isAdmin: Boolean(player.isAdmin ?? player.admin),
    money: player.money ?? player.gameMoney ?? player.accountBalance ?? null,
    gold: player.gold ?? player.gameGold ?? null
  })).filter((player) => player.steamId);
}

class LegacyHttpClient {
  constructor(config, reconnect) { this.config = config; this.reconnect = reconnect; }
  async request(method, path, data, retry = this.reconnect) {
    const response = await requestWithPolicy({ method, url: joinUrl(this.config.baseUrl, path), headers: authHeaders(this.config), data, timeout: this.config.timeoutMs }, retry);
    return response.data;
  }
  async health(options = {}) {
    try { return await this.request('get', '/health'); }
    catch (error) { if (error?.response?.status !== 404) throw error; await this.players(); return { status: 'ok' }; }
  }
  async players() { return normalizePlayers(await this.request('get', '/players.json')); }
  async command(command, { retry = true } = {}) {
    const data = await this.request('post', '/command', { command }, retry ? this.reconnect : { enabled: false });
    return { success: data?.success !== false, status: data?.status || 'success', response: data };
  }
  close() {}
}

export class GgconClient {
  constructor(config, reconnect, { gsm3, instanceId, logger, clock = () => Date.now(), playerCacheMs = 1000 } = {}) {
    this.config = config;
    this.reconnect = reconnect;
    this.gsm3 = gsm3;
    this.instanceId = instanceId;
    this.logger = logger;
    this.clock = clock;
    this.playerCacheMs = Math.max(0, Number(playerCacheMs) || 0);
    this.playerCache = null; this.playerPending = { normal: null, high: null }; this.economyCache = null; this.economyPending = null;
    this.client = config.mode === 'http-legacy'
      ? new LegacyHttpClient(config, reconnect)
      : (config.mode === 'scum-shop-pipe' ? new ScumShopPipeClient(config) : null);
    this.initializing = null;
    this.capabilityCache = null;
    this.capabilityPending = null;
  }

  async source() {
    if (this.client) return this.client;
    if (!this.initializing) this.initializing = resolveScumRconConfig(this.config, { gsm3: this.gsm3, instanceId: this.instanceId })
      .then((resolved) => (this.client = new SourceRconClient(resolved, this.reconnect)))
      .catch((error) => { this.initializing = null; throw error; });
    return this.initializing;
  }

  async health(options = {}) {
    if (this.config.mode === 'http-legacy' || this.config.mode === 'scum-shop-pipe') return this.client.health();
    await this.players(options);
    return { status: 'ok', protocol: 'source-tcp' };
  }

  async capabilities() {
    if (this.config.mode !== 'source-tcp') return this.queryCapabilities();
    if (this.capabilityCache && this.clock() - this.capabilityCache.at < 30000) return { ...this.capabilityCache.value };
    if (!this.capabilityPending) this.capabilityPending = this.queryCapabilities().then((value) => {
      this.capabilityCache = { at: this.clock(), value };
      return value;
    }).finally(() => { this.capabilityPending = null; });
    return { ...(await this.capabilityPending) };
  }

  async queryCapabilities() {
    if (this.config.mode === 'scum-shop-pipe') return this.client.capabilities();
    if (this.config.mode === 'source-tcp') {
      const result = await this.command('help');
      const text = String(result.response || '');
      const native = text.startsWith('OpenSCUM-RCON commands:');
      const vehicleToTerritoryFlag = /\bTeleportOwnedVehicleToTerritoryFlag\b/.test(text);
      const vehicleToPlayer = /\bTeleportOwnedVehicleToPlayer\b/.test(text);
      const vehicleToPlayerInTerritory = /\bTeleportOwnedVehicleToPlayerInTerritory\b/.test(text);
      const vehicleToPlayerLongDistance = /\bTeleportOwnedVehicleToPlayerLongDistance\b/.test(text);
      const vehicleToCoordinates = /\bTeleportOwnedVehicleToCoordinates\b/.test(text);
      return { health: true, capabilities: native, players: /\bListPlayers\b/.test(text), listFlags: /\bListFlags\b/.test(text), command: native, giveItem: /\bSpawnItem\b/.test(text), privateMessage: /\bSendChat\b/.test(text), recycle: /\bQuerySavedItemOwner\b/.test(text) && /\bRemoveSavedOwnedItem\b/.test(text), playerAdmin: /\bKickPlayer\b/.test(text), teleportPlayerToCoordinates: /\bTeleportPlayerToCoordinates\b/.test(text), teleportPlayerToPlayer: /\bTeleportPlayerToPlayer\b/.test(text), teleportPlayerToOwnedVehicle: /\bTeleportPlayerToOwnedVehicle\b/.test(text), teleportPlayerToTerritoryFlag: /\bTeleportPlayerToTerritoryFlag\b/.test(text), teleportOwnedVehicleToTerritoryFlag: vehicleToTerritoryFlag, teleportOwnedVehicleToPlayer: vehicleToPlayer, teleportOwnedVehicleToPlayerInTerritory: vehicleToPlayerInTerritory, teleportOwnedVehicleToPlayerLongDistance: vehicleToPlayerLongDistance, teleportOwnedVehicleToCoordinates: vehicleToCoordinates };
    }
    return { health: true, capabilities: false, players: true, command: true };
  }

  async players({ includeEconomy = false, priority = 'normal' } = {}) {
    if (this.config.mode === 'http-legacy' || this.config.mode === 'scum-shop-pipe') return this.client.players();
    if (!includeEconomy) return (await this.basePlayers(priority)).players.map((player) => ({ ...player }));
    if (this.economyCache && this.clock() - this.economyCache.at < this.playerCacheMs) return this.economyCache.players.map((player) => ({ ...player }));
    if (!this.economyPending) this.economyPending = (async () => {
      const base = await this.basePlayers(priority);
      const players = base.players.map((player) => ({ ...player }));
      if (/^player=\d+,name=/m.test(base.response)) for (const player of players) {
        try {
          const economyOptions = priority === 'high' ? { retry: false, priority, skipHealth: true } : { retry: false, skipHealth: true };
          const economy = await this.command('QueryPlayerEconomy ' + player.steamId, economyOptions);
          Object.assign(player, parsePlayerEconomy(economy.response, player.steamId));
        } catch (error) {
          this.logger?.warn('玩家经济数据读取失败，保留在线状态', { component: 'rcon', steamId: player.steamId, errorCode: error?.code || error?.name || 'PLAYER_ECONOMY_FAILED' });
        }
      }
      this.economyCache = { at: this.clock(), players };
      return players;
    })().finally(() => { this.economyPending = null; });
    return (await this.economyPending).map((player) => ({ ...player }));
  }

  async basePlayers(priority = 'normal') {
    if (this.playerCache && this.clock() - this.playerCache.at < this.playerCacheMs) return this.playerCache;
    const queue = priority === 'high' ? 'high' : 'normal';
    if (!this.playerPending[queue]) this.playerPending[queue] = (async () => {
      const result = await this.command('#ListPlayers', { priority });
      const value = { at: this.clock(), response: result.response, players: parseListPlayers(result.response) };
      this.playerCache = value;
      return value;
    })().finally(() => { this.playerPending[queue] = null; });
    return this.playerPending[queue];
  }

  async command(command, options = {}) {
    const started = Date.now();
    try {
      const result = await this.executeCommand(command, options);
      this.logAccess(command, started, 'success');
      return result;
    } catch (error) {
      this.logAccess(command, started, 'failed', error?.code || error?.name);
      throw error;
    }
  }

  logAccess(command, started, status, errorCode) {
    const commandText = String(command).trim();
    const commandName = rconCommandName(commandText);
    const details = redact({ component: 'rcon', event: 'rcon_access', command: commandText, status, durationMs: Date.now() - started, ...(errorCode ? { errorCode } : {}) });
    const message = formatRconAccessMessage(commandText, status);
    const routineRead = /^(?:#?ListPlayers|#?Location|#?ListFlags|QueryPlayerEconomy|help)$/i.test(commandName);
    if (status === 'failed') this.logger?.warn?.(message, details);
    else if (routineRead) this.logger?.debug?.(message, details);
    else this.logger?.info?.(message, details);
    if (!this.logger) console.log(`[RCON] ${JSON.stringify({ message, ...details })}`);
  }

  async executeCommand(command, options = {}) {
    if (this.config.mode === 'scum-shop-pipe') return this.client.command(command, options);
    if (options.skipHealth !== true && !/^#?ListPlayers$/i.test(String(command).trim())) await this.health({ priority: options.priority });
    if (this.config.mode === 'http-legacy') return this.client.command(command, options);
    const client = await this.source();
    const response = await client.command(command, options);
    assertScumRconSuccess(response);
    return { success: true, status: 'success', response };
  }

  close() { this.playerCache = null; this.playerPending = { normal: null, high: null }; this.economyCache = null; this.capabilityCache = null; this.client?.close(); }
}
