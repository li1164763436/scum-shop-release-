function safeSnapshotError(error) {
  return String(error?.message || error?.code || '传送位置采集失败')
    .replace(/[A-Za-z]:\\[^\r\n]*/g, '[路径已隐藏]')
    .replace(/\b(?:password|token|secret|api[-_]?key)\s*[=:]\s*[^\s,;]+/gi, 'credential=***')
    .replace(/[\u0000-\u001f\u007f]/g, ' ')
    .trim()
    .slice(0, 500) || '传送位置采集失败';
}

function sourceStatus(configured) {
  return { configured, running: false, lastStartedAt: null, lastSuccessAt: null, lastCompletedAt: null, lastError: null, lastResult: null };
}

export class TeleportEntitySnapshotWorker {
  constructor({ store, playerProvider = null, flagProvider = null, logger, activityGate = null, intervalMs, playerIntervalMs = 10000, flagIntervalMs = 60000, idleIntervalMs = 900000, clock = () => Date.now(), setTimeout: setTimer = globalThis.setTimeout, clearTimeout: clearTimer = globalThis.clearTimeout }) {
    this.store = store;
    this.playerProvider = playerProvider;
    this.flagProvider = flagProvider;
    this.logger = logger;
    this.activityGate = activityGate;
    this.playerIntervalMs = Math.max(5000, Number(intervalMs ?? playerIntervalMs) || 10000);
    this.flagIntervalMs = Math.max(this.playerIntervalMs, Number(flagIntervalMs) || 60000);
    this.idleIntervalMs = Math.max(this.flagIntervalMs, Number(idleIntervalMs) || 900000);
    this.intervalMs = this.playerIntervalMs;
    this.clock = clock;
    this.setTimer = setTimer;
    this.clearTimer = clearTimer;
    this.timer = null;
    this.activeTick = null;
    this.stopped = true;
    this.unsubscribeActivity = null;
    this.player = sourceStatus(Boolean(playerProvider));
    this.flags = sourceStatus(Boolean(flagProvider));
  }

  status() {
    return {
      enabled: !this.stopped,
      running: Boolean(this.activeTick),
      polling: Boolean(this.timer),
      intervalMs: this.playerIntervalMs,
      playerIntervalMs: this.playerIntervalMs,
      flagIntervalMs: this.flagIntervalMs,
      idleIntervalMs: this.idleIntervalMs,
      storefrontActive: this.activityGate?.isActive?.() ?? true,
      player: { ...this.player },
      flags: { ...this.flags }
    };
  }

  async start() {
    if (!this.stopped) return this.status();
    this.stopped = false;
    this.unsubscribeActivity = this.activityGate?.onActivate?.(() => this.wake()) || null;
    void this.tick();
    return this.status();
  }

  wake() {
    if (this.stopped) return;
    if (this.timer) this.clearTimer(this.timer);
    this.timer = null;
    void this.tick();
  }

  schedule() {
    if (this.stopped || this.timer || (!this.playerProvider && !this.flagProvider)) return;
    const delay = this.activityGate && !this.activityGate.isActive() ? this.idleIntervalMs : this.intervalMs;
    this.timer = this.setTimer(() => { this.timer = null; void this.tick(); }, delay);
    this.timer?.unref?.();
  }

  async collectPlayer() {
    if (!this.playerProvider) return null;
    const sampledAt = new Date(this.clock()).toISOString();
    this.player.running = true;
    this.player.lastStartedAt = sampledAt;
    try {
      const result = await this.playerProvider.collect();
      const players = Array.isArray(result?.players) ? result.players : [];
      const offlineSteamIds = Array.isArray(result?.offlineSteamIds) ? result.offlineSteamIds : [];
      const savedPlayers = players.map((player) => this.store.upsertPlayer({ ...player, observedAt: player.observedAt || result?.observedAt || sampledAt }));
      offlineSteamIds.forEach((steamId) => this.store.removePlayer(steamId));
      await this.store.persistPlayers?.(savedPlayers, offlineSteamIds);
      if (result?.squadSnapshotComplete === true) await this.store.persistSquads?.(result.squads, { complete: true });
      if (result?.available === false) {
        this.store.setCapability?.('playerLocation', false);
        throw Object.assign(new Error('在线玩家位置命令全部失败'), { code: 'TELEPORT_PLAYER_LOCATION_UNAVAILABLE' });
      }
      if (result?.available === true) this.store.setCapability?.('playerLocation', true);
      this.player.lastSuccessAt = new Date(this.clock()).toISOString();
      this.player.lastError = null;
      this.player.lastResult = { players: players.length, removed: offlineSteamIds.length };
      return this.player.lastResult;
    } catch (error) {
      this.store.setCapability?.('playerLocation', false);
      this.player.lastError = safeSnapshotError(error);
      this.logger?.warn?.('传送人物位置采集失败', { component: 'teleport-entity-snapshot', source: 'player', errorCode: error?.code || error?.name || 'TELEPORT_PLAYER_SNAPSHOT_FAILED' });
      return null;
    } finally {
      this.player.running = false;
      this.player.lastCompletedAt = new Date(this.clock()).toISOString();
    }
  }

  async collectFlags() {
    if (!this.flagProvider) return null;
    const sampledAt = new Date(this.clock()).toISOString();
    this.flags.running = true;
    this.flags.lastStartedAt = sampledAt;
    try {
      const result = await this.flagProvider.collect();
      const saved = this.store.replaceFlags(result?.flags, { complete: result?.complete === true, observedAt: result?.observedAt || sampledAt });
      await this.store.persistFlags?.();
      this.flags.lastSuccessAt = new Date(this.clock()).toISOString();
      this.flags.lastError = null;
      this.flags.lastResult = saved;
      return saved;
    } catch (error) {
      this.store.setCapability?.('flagLocation', false);
      this.flags.lastError = safeSnapshotError(error);
      this.logger?.warn?.('传送领地旗位置采集失败', { component: 'teleport-entity-snapshot', source: 'flags', errorCode: error?.code || error?.name || 'TELEPORT_FLAG_SNAPSHOT_FAILED' });
      return null;
    } finally {
      this.flags.running = false;
      this.flags.lastCompletedAt = new Date(this.clock()).toISOString();
    }
  }

  flagCollectionDue() {
    if (!this.flagProvider || !this.flags.lastStartedAt) return Boolean(this.flagProvider);
    const elapsed = this.clock() - Date.parse(this.flags.lastStartedAt);
    return !Number.isFinite(elapsed) || elapsed >= this.flagIntervalMs;
  }

  async tick() {
    if (this.stopped || this.activeTick) return this.activeTick;
    const collections = [];
    if (this.playerProvider) collections.push(this.collectPlayer());
    if (this.flagCollectionDue()) collections.push(this.collectFlags());
    this.activeTick = Promise.all(collections).finally(() => {
      this.activeTick = null;
      this.schedule();
    });
    return this.activeTick;
  }

  async stopAndDrain() {
    this.stopped = true;
    this.unsubscribeActivity?.();
    this.unsubscribeActivity = null;
    if (this.timer) this.clearTimer(this.timer);
    this.timer = null;
    if (this.activeTick) await this.activeTick;
    return this.status();
  }
}

export { safeSnapshotError as safeTeleportSnapshotError };
