import crypto from 'node:crypto';
import { isSteamId64 } from './command-policy.js';
import { authInternals, hashPassword } from './auth-service.js';

export async function hasInitialSuperAdmin(db) {
  const states = await db.query("SELECT state_key FROM bootstrap_states WHERE state_key='initial_super_admin' AND completed_at IS NOT NULL LIMIT 1");
  if (states.length) return true;
  const admins = await db.query("SELECT `商城用户编号` AS id FROM `商城用户` WHERE `用户角色` IN ('admin','super_admin') LIMIT 1");
  return admins.length > 0;
}

export async function assertInitialSuperAdminBinding(db, identity, { allowLegacy = false } = {}) {
  if (!identity?.username || !identity?.licenseId) throw new Error('授权中心未返回完整的账号和许可证信息');
  let names;
  try { names = authInternals.normalizeUsername(identity.username); }
  catch { throw new Error('授权中心账号格式无效'); }
  const licenseId = String(identity.licenseId).trim();
  const bindings = await db.query("SELECT b.`授权账号`,b.`授权账号规范值`,b.`许可证ID`,b.`商城用户编号`,b.`SteamID`,u.`登录账号` AS username,u.`登录账号规范值` AS normalized,u.`SteamID` AS userSteamId,u.`用户角色` AS role,u.`账户状态` AS status FROM `授权账号绑定` b JOIN `商城用户` u ON u.`商城用户编号`=b.`商城用户编号` WHERE b.`绑定状态`='active'");
  if (!bindings.length) throw new Error(allowLegacy ? '旧安装必须重新认证授权账号后完成超级管理员接管' : '当前许可证尚未完成超级管理员固定绑定');
  if (bindings.length !== 1) throw new Error('本机存在多个活动授权绑定，已拒绝启动');
  const binding = bindings[0].授权账号规范值 === names.normalized && bindings[0].许可证ID === licenseId ? bindings[0] : null;
  if (!binding) throw new Error('当前授权账号或许可证与本机固定绑定不一致');
  if (binding.status !== 'active') throw new Error('固定绑定的商城用户已被停用');
  if (binding.role !== 'super_admin') throw new Error('固定绑定的商城用户已不再是 super_admin');
  if (binding.normalized !== names.normalized || binding.userSteamId !== binding.SteamID || !isSteamId64(binding.SteamID)) throw new Error('固定绑定的商城账号或 SteamID 已不一致');
  await db.query('UPDATE `授权账号绑定` SET `最后验证时间`=CURRENT_TIMESTAMP(3) WHERE `商城用户编号`=?', [binding.商城用户编号]);
  return { userId: binding.商城用户编号, username: binding.username, steamId: binding.SteamID, role: binding.role };
}

function sessionToken() {
  const token = crypto.randomBytes(32).toString('base64url');
  return { token, hash: crypto.createHash('sha256').update(token).digest('hex') };
}

export async function recoverLegacySuperAdmin(db, input, authorization) {
  if (!authorization?.username || !authorization?.licenseId) throw new Error('授权中心未返回完整的账号和许可证信息');
  let names;
  try { names = authInternals.normalizeUsername(authorization.username); }
  catch { throw new Error('授权中心账号格式无效'); }
  const licenseId = String(authorization.licenseId).trim();
  if (!licenseId || licenseId.length > 100) throw new Error('许可证标识无效');
  let password = authInternals.validateRegistrationPassword(input?.password);
  const credentials = await hashPassword(password);
  password = null;

  try {
    return await db.transaction(async (tx) => {
      const historical = await tx.query('SELECT `绑定编号` FROM `授权账号绑定` FOR UPDATE');
      if (historical.length) throw new Error('本机已存在固定绑定历史，不能执行旧安装接管');
      const admins = await tx.query("SELECT `商城用户编号` AS id,`登录账号` AS username,`登录账号规范值` AS normalized,`SteamID` AS steamId,`用户角色` AS role,`账户状态` AS status FROM `商城用户` WHERE `用户角色`='super_admin' FOR UPDATE");
      if (admins.length !== 1) throw new Error('旧安装必须恰好存在一个超级管理员才能接管');
      const admin = admins[0];
      if (admin.status !== 'active') throw new Error('待接管的商城超级管理员已被停用');
      if (!isSteamId64(admin.steamId)) throw new Error('待接管的商城超级管理员未绑定有效 SteamID');
      const occupied = await tx.query('SELECT `商城用户编号` AS id FROM `商城用户` WHERE `登录账号规范值`=? AND `商城用户编号`<>? FOR UPDATE', [names.normalized, admin.id]);
      if (occupied.length) throw new Error('授权账号已被其他商城用户占用，不能接管');
      await tx.query("UPDATE `商城用户` SET `登录账号`=?,`登录账号规范值`=?,`密码哈希`=?,`密码盐`=? WHERE `商城用户编号`=?", [names.username, names.normalized, credentials.hash, credentials.salt, admin.id]);
      await tx.query('UPDATE shop_sessions SET revoked_at=CURRENT_TIMESTAMP(3) WHERE user_id=? AND revoked_at IS NULL', [admin.id]);
      await tx.query("INSERT INTO `授权账号绑定` (`授权账号`,`授权账号规范值`,`许可证ID`,`商城用户编号`,`SteamID`,`绑定状态`) VALUES (?,?,?,?,?,'active')", [names.username, names.normalized, licenseId, admin.id, admin.steamId]);
      await tx.query("INSERT INTO bootstrap_states (state_key,created_user_id,completed_at) VALUES ('initial_super_admin',?,CURRENT_TIMESTAMP(3)) ON DUPLICATE KEY UPDATE created_user_id=VALUES(created_user_id),completed_at=VALUES(completed_at)", [admin.id]);
      return { id: admin.id, username: names.username, steamId: admin.steamId, role: 'super_admin' };
    });
  } catch (error) {
    if (error?.code === 'ER_DUP_ENTRY') throw new Error('授权账号、许可证或 SteamID 已存在固定绑定，不能执行旧安装接管');
    throw error;
  }
}

export async function createInitialSuperAdmin(db, input, options = {}) {
  const steamId = input?.steamId == null || input.steamId === '' ? null : String(input.steamId).trim();
  if ((!steamId && !options.allowUnbound) || (steamId && !isSteamId64(steamId))) throw new Error('SteamID 格式无效');
  let names;
  try { names = authInternals.normalizeUsername(input?.username); }
  catch { throw new Error('授权中心用户名不符合商城 3-32 位账号规则，请先在授权中心使用兼容账号'); }
  const authorization = options.authorization || null;
  let licenseId = null;
  if (!options.allowUnbound) {
    if (!authorization?.username || !authorization?.licenseId) throw new Error('授权中心未返回完整的账号和许可证信息');
    let authorizedNames;
    try { authorizedNames = authInternals.normalizeUsername(authorization.username); }
    catch { throw new Error('授权中心账号格式无效'); }
    if (authorizedNames.normalized !== names.normalized) throw new Error('授权账号与商城初始账号不一致');
    licenseId = String(authorization.licenseId).trim();
    if (!licenseId || licenseId.length > 100) throw new Error('许可证标识无效');
  }
  let password = authInternals.validateRegistrationPassword(input?.password);
  const credentials = await hashPassword(password);
  password = null;
  const issued = sessionToken();
  const expiresAt = new Date((options.clock?.() ?? Date.now()) + authInternals.SESSION_MS);
  const actorLabel = String(options.actorLabel || names.username).slice(0, 100);
  const metadata = options.metadata || {};

  try {
    return await db.transaction(async (tx) => {
      if (!options.allowUnbound) {
        const completed = await tx.query("SELECT s.created_user_id AS id,u.`登录账号` AS username,u.`登录账号规范值` AS normalized,u.`SteamID` AS steamId,u.`用户角色` AS role,u.`账户状态` AS status,b.`授权账号规范值` AS bindingNormalized,b.`许可证ID` AS bindingLicenseId,b.`SteamID` AS bindingSteamId,b.`绑定状态` AS bindingStatus FROM bootstrap_states s JOIN `商城用户` u ON u.`商城用户编号`=s.created_user_id LEFT JOIN `授权账号绑定` b ON b.`商城用户编号`=u.`商城用户编号` WHERE s.state_key='initial_super_admin' AND s.completed_at IS NOT NULL FOR UPDATE");
        if (completed.length) {
          if (completed.length !== 1) throw new Error('系统已经完成初始超级管理员初始化，但固定绑定记录不唯一');
          const existing = completed[0];
          const matches = existing.normalized === names.normalized && existing.steamId === steamId && existing.role === 'super_admin' && existing.status === 'active' && existing.bindingNormalized === names.normalized && existing.bindingLicenseId === licenseId && existing.bindingSteamId === steamId && existing.bindingStatus === 'active';
          if (!matches) throw new Error('系统已经完成初始超级管理员初始化，当前授权身份或 SteamID 与固定绑定不一致');
          if (options.createSession !== false) await tx.query('INSERT INTO shop_sessions (user_id,token_hash,expires_at,ip_address,user_agent) VALUES (?,?,?,?,?)', [existing.id, issued.hash, expiresAt, String(metadata.ip || '').slice(0, 64) || null, String(metadata.userAgent || '').slice(0, 255) || null]);
          const result = { id: existing.id, username: existing.username, steamId: existing.steamId, role: existing.role, idempotent: true };
          if (options.createSession !== false) result.session = { token: issued.token, expiresAt };
          return result;
        }
      }
      const reserved = await tx.query("INSERT IGNORE INTO bootstrap_states (state_key) VALUES ('initial_super_admin')");
      if (Number(reserved.affectedRows) !== 1) throw new Error('系统已经完成或开始过初始超级管理员初始化');
      const users = await tx.query('SELECT `商城用户编号` AS id, `用户角色` AS role FROM `商城用户` FOR UPDATE');
      if (users.some(user => ['admin','super_admin'].includes(user.role))) throw new Error('当前已存在 admin 或 super_admin，不能创建初始超级管理员');
      if (!options.allowUnbound) {
        const bindings = await tx.query('SELECT `绑定编号` FROM `授权账号绑定` WHERE `授权账号规范值`=? OR `许可证ID`=? OR `SteamID`=? FOR UPDATE', [names.normalized, licenseId, steamId]);
        if (bindings.length) throw new Error('授权账号、许可证或 SteamID 已存在固定绑定');
      }
      const existing = steamId ? await tx.query('SELECT `商城用户编号` AS id,`登录账号` AS username,`登录账号规范值` AS normalized,`SteamID` AS steamId,`用户角色` AS role,`账户状态` AS status FROM `商城用户` WHERE `SteamID`=? OR `登录账号规范值`=? FOR UPDATE', [steamId, names.normalized]) : [];
      if (new Set(existing.map(user => Number(user.id))).size > 1) throw new Error('授权账号与 SteamID 分属不同商城用户，不能自动合并');
      const matched = existing[0] || null;
      if (matched?.status !== undefined && matched.status !== 'active') throw new Error('待绑定商城用户已被停用');
      if (matched?.normalized && matched.normalized !== names.normalized) throw new Error('SteamID 已绑定其他商城账号');
      if (matched?.steamId && matched.steamId !== steamId) throw new Error('授权账号已绑定其他 SteamID');
      let userId;
      let oldRole = 'user';
      if (matched) {
        userId = matched.id;
        oldRole = matched.role || 'user';
        await tx.query("UPDATE `商城用户` SET `登录账号`=?,`登录账号规范值`=?,`密码哈希`=?,`密码盐`=?,`SteamID`=?,`用户角色`='super_admin',`管理员授权时间`=CURRENT_TIMESTAMP(3),`商城账户创建时间`=COALESCE(`商城账户创建时间`,CURRENT_TIMESTAMP(3)) WHERE `商城用户编号`=?", [names.username, names.normalized, credentials.hash, credentials.salt, steamId, userId]);
        await tx.query('UPDATE shop_sessions SET revoked_at=CURRENT_TIMESTAMP(3) WHERE user_id=? AND revoked_at IS NULL', [userId]);
      } else {
        const inserted = await tx.query("INSERT INTO `商城用户` (`登录账号`,`登录账号规范值`,`密码哈希`,`密码盐`,`SteamID`,`用户角色`,`账户状态`,`管理员授权时间`,`商城币余额`,`商城账户创建时间`) VALUES (?,?,?,?,?,'super_admin','active',CURRENT_TIMESTAMP(3),0,CURRENT_TIMESTAMP(3))", [names.username, names.normalized, credentials.hash, credentials.salt, steamId]);
        userId = inserted.insertId;
      }
      if (oldRole !== 'super_admin') await tx.query("INSERT INTO admin_role_audits (actor_user_id,actor_type,actor_label,actor_username_snapshot,target_user_id,target_username_snapshot,target_steam_id,old_role,new_role,reason) VALUES (NULL,?,?,?, ?,?,?,?,'super_admin',?)", [options.actorType || 'license', actorLabel, actorLabel, userId, names.username, steamId, oldRole, options.reason || '授权中心账号完成本机首装初始化']);
      if (!options.allowUnbound) await tx.query("INSERT INTO `授权账号绑定` (`授权账号`,`授权账号规范值`,`许可证ID`,`商城用户编号`,`SteamID`,`绑定状态`) VALUES (?,?,?,?,?,'active')", [names.username, names.normalized, licenseId, userId, steamId]);
      if (options.createSession !== false) await tx.query('INSERT INTO shop_sessions (user_id,token_hash,expires_at,ip_address,user_agent) VALUES (?,?,?,?,?)', [userId, issued.hash, expiresAt, String(metadata.ip || '').slice(0, 64) || null, String(metadata.userAgent || '').slice(0, 255) || null]);
      await tx.query("UPDATE bootstrap_states SET created_user_id = ?, completed_at = CURRENT_TIMESTAMP(3) WHERE state_key = 'initial_super_admin'", [userId]);
      const result = { id: userId, username: names.username, steamId, role: 'super_admin' };
      if (options.createSession !== false) result.session = { token: issued.token, expiresAt };
      return result;
    });
  } catch (error) {
    if (error?.code === 'ER_DUP_ENTRY') throw new Error('授权账号、许可证或 SteamID 已存在固定绑定，不能重复初始化');
    throw error;
  }
}
