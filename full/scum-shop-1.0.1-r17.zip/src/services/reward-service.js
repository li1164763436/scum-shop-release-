import crypto from 'node:crypto';
import { isSteamId64 } from './command-policy.js';
import { ServiceError } from './commerce-service.js';
import { RewardOrderService } from './reward-order-service.js';

const RULE_TYPES = new Set(['daily_checkin', 'checkin_streak', 'checkin_total', 'online_total']);
const REWARD_TYPES = new Set(['gift', 'product', 'shop_coin', 'combined']);
function duplicate(error) { return error?.code === 'ER_DUP_ENTRY' || error?.errno === 1062; }
function positive(value, name, max = Number.MAX_SAFE_INTEGER) { const number = Number(value); if (!Number.isSafeInteger(number) || number < 1 || number > max) throw new ServiceError(`${name}必须是正整数`); return number; }
function id(value, name = '奖励规则 ID') { return positive(value, name); }
function pageOptions(options = {}) { const page = positive(options.page ?? 1, '页码', 1000000), limit = positive(options.limit ?? 50, '显示条数', 500); return { page, limit, offset: (page - 1) * limit }; }
function shanghaiDay(now) { const value = new Date(now.getTime() + 8 * 3600000); return `${value.getUTCFullYear()}-${String(value.getUTCMonth() + 1).padStart(2, '0')}-${String(value.getUTCDate()).padStart(2, '0')}`; }
function dateKey(value) { return typeof value === 'string' ? value.slice(0, 10) : new Date(value).toISOString().slice(0, 10); }
function previousDay(day) { const date = new Date(`${day}T00:00:00.000Z`); date.setUTCDate(date.getUTCDate() - 1); return date.toISOString().slice(0, 10); }
function parseProductItems(value, fallback = []) { try { const items = Array.isArray(value) ? value : JSON.parse(value || '[]'); return items.map((item) => ({ productId: positive(item.productId, '商品 ID'), quantity: positive(item.quantity, '商品数量', 1000) })).slice(0, 50); } catch { return fallback; } }
function mapRule(row) { const fallback = row.productId == null ? [] : [{ productId: Number(row.productId), quantity: Number(row.productQuantity || 1) }]; return { id: Number(row.id), ruleType: row.ruleType, threshold: Number(row.threshold), rewardType: row.rewardType || (row.giftId ? 'gift' : row.productId ? 'product' : 'shop_coin'), giftId: row.giftId == null ? null : Number(row.giftId), giftName: row.giftName, productId: row.productId == null ? null : Number(row.productId), productName: row.productName, productQuantity: Number(row.productQuantity || 1), productItems: parseProductItems(row.productItemsJson, fallback), coinAmount: row.coinAmount == null ? null : Number(row.coinAmount), legacyGift: row.ruleType !== 'online_total' && row.coinAmount == null, enabled: Boolean(row.enabled), createdByUserId: Number(row.createdByUserId), createdBy: row.createdBy, createdAt: row.createdAt, updatedAt: row.updatedAt }; }
function normalizeRule(input, existing = null) {
  const ruleType = String(input?.ruleType ?? input?.type ?? existing?.ruleType ?? '').trim();
  if (!RULE_TYPES.has(ruleType)) throw new ServiceError('奖励规则类型无效');
  const threshold = ruleType === 'daily_checkin' ? 1 : positive(input?.threshold ?? input?.thresholdValue ?? existing?.threshold, '奖励门槛');
  const online = ruleType === 'online_total';
  const legacyUnchanged = existing?.legacyGift && input?.coinAmount === undefined && ruleType === existing.ruleType;
  const rewardType = online ? String(input?.rewardType ?? existing?.rewardType ?? 'gift') : 'shop_coin';
  if (!REWARD_TYPES.has(rewardType)) throw new ServiceError('奖励类型无效');
  const coinAmount = legacyUnchanged ? null : ['shop_coin', 'combined'].includes(rewardType) ? positive(input?.coinAmount ?? existing?.coinAmount, '奖励商城币') : null;
  const giftId = legacyUnchanged ? existing.giftId : ['gift', 'combined'].includes(rewardType) ? id(input?.giftId ?? existing?.giftId, '礼包 ID') : null;
  const legacyItems = input?.productId ? [{ productId: input.productId, quantity: input.productQuantity ?? 1 }] : existing?.productItems || [];
  const items = ['product', 'combined'].includes(rewardType) ? parseProductItems(input?.productItems, parseProductItems(legacyItems)) : [];
  if (['product', 'combined'].includes(rewardType) && !items.length) throw new ServiceError('至少选择一个奖励商品');
  const productId = items[0]?.productId ?? null;
  const productQuantity = items[0]?.quantity ?? 1;
  return { ruleType, threshold, rewardType, giftId, productId, productQuantity, productItems: items, productItemsJson: items.length ? JSON.stringify(items) : null, coinAmount, createdByUserId: existing?.createdByUserId ?? null, enabled: input?.enabled === undefined ? (existing?.enabled ?? true) : Boolean(input.enabled) };
}

export class RewardService {
  constructor(db, options = {}) {
    if (db && typeof db === 'object' && db.db) { options = db; this.db = db.db; }
    else this.db = db;
    this.clock = options.clock || (() => new Date());
    this.orderService = options.orderService || new RewardOrderService();
  }

  now() { const value = this.clock(); return value instanceof Date ? new Date(value.getTime()) : new Date(value); }
  async list() { return (await this.db.query('SELECT r.id,r.rule_type AS ruleType,r.threshold_value AS threshold,r.reward_type AS rewardType,r.gift_id AS giftId,r.product_id AS productId,r.product_quantity AS productQuantity,r.coin_amount AS coinAmount,g.name AS giftName,p.name AS productName,r.enabled,r.created_by_user_id AS createdByUserId,u.\`登录账号\` AS createdBy,r.created_at AS createdAt,r.updated_at AS updatedAt FROM reward_rules r LEFT JOIN gift_packages g ON g.id=r.gift_id LEFT JOIN products p ON p.id=r.product_id LEFT JOIN \`商城用户\` u ON u.\`商城用户编号\`=r.created_by_user_id ORDER BY r.id DESC')).map(mapRule); }
  async listAdmin() { return this.list(); }
  async get(value, db = this.db, lock = false) {
    const rows = await db.query(`SELECT r.id,r.rule_type AS ruleType,r.threshold_value AS threshold,r.reward_type AS rewardType,r.gift_id AS giftId,r.product_id AS productId,r.product_quantity AS productQuantity,r.coin_amount AS coinAmount,g.name AS giftName,p.name AS productName,r.enabled,r.created_by_user_id AS createdByUserId,u.\`登录账号\` AS createdBy,r.created_at AS createdAt,r.updated_at AS updatedAt FROM reward_rules r LEFT JOIN gift_packages g ON g.id=r.gift_id LEFT JOIN products p ON p.id=r.product_id LEFT JOIN \`商城用户\` u ON u.\`商城用户编号\`=r.created_by_user_id WHERE r.id=?${lock ? ' FOR UPDATE' : ''}`, [id(value)]);
    if (!rows[0]) throw new ServiceError('奖励规则不存在', 404, 'NOT_FOUND');
    const snapshots = await db.query('SELECT product_items_json AS productItemsJson FROM reward_rules WHERE id=?', [id(value)]);
    rows[0].productItemsJson = snapshots[0]?.productItemsJson ?? null;
    return mapRule(rows[0]);
  }
  async save(input, value = null) {
    try {
      return await this.db.transaction(async (tx) => {
        const existing = value === null ? null : await this.get(value, tx, true);
        const rule = normalizeRule(input, existing);
        if (!existing) {
          const suppliedCreator = input?.createdByUserId ?? input?.userId;
          if (suppliedCreator !== undefined && suppliedCreator !== null && suppliedCreator !== '') {
            rule.createdByUserId = id(suppliedCreator, '管理员用户 ID');
            const admins = await tx.query("SELECT \`商城用户编号\` AS id FROM \`商城用户\` WHERE \`商城用户编号\`=? AND \`用户角色\` IN ('admin','super_admin') AND \`账户状态\`='active' FOR UPDATE", [rule.createdByUserId]);
            if (!admins[0]) throw new ServiceError('创建管理员不存在或未启用', 400, 'INVALID_ADMIN');
          } else {
            const admins = await tx.query("SELECT \`商城用户编号\` AS id FROM \`商城用户\` WHERE \`用户角色\` IN ('admin','super_admin') AND \`账户状态\`='active' ORDER BY \`商城用户编号\` LIMIT 1 FOR UPDATE");
            if (!admins[0]) throw new ServiceError('没有可用的管理员账户', 503, 'NOT_READY');
            rule.createdByUserId = Number(admins[0].id);
          }
        }
        if (rule.giftId !== null) {
        const gifts = await tx.query('SELECT id FROM gift_packages WHERE id=? FOR UPDATE', [rule.giftId]);
        if (!gifts[0]) throw new ServiceError('礼包模板不存在', 404, 'GIFT_NOT_FOUND');
        const actions = await tx.query('SELECT action_type AS actionType FROM gift_actions WHERE gift_id=? FOR UPDATE', [rule.giftId]);
        if (!actions.length) throw new ServiceError('礼包模板没有可执行动作', 409, 'GIFT_EMPTY');
        if (actions.some((action) => !['spawn_item', 'shop_coin'].includes(action.actionType))) throw new ServiceError('礼包模板包含不支持的动作', 409, 'GIFT_ACTION_UNSUPPORTED');
        }
        if (rule.productId !== null) {
          const ids = rule.productItems.map((item) => item.productId);
          const products = await tx.query(`SELECT id FROM products WHERE id IN (${ids.map(() => '?').join(',')}) AND enabled=1 FOR UPDATE`, ids);
          if (products.length !== ids.length) throw new ServiceError('奖励商品不存在或已下架', 404, 'PRODUCT_NOT_FOUND');
        }
        let ruleId;
        if (!existing) {
          const inserted = await tx.query('INSERT INTO reward_rules (rule_type,threshold_value,reward_type,gift_id,product_id,product_quantity,coin_amount,enabled,created_by_user_id) VALUES (?,?,?,?,?,?,?,?,?)', [rule.ruleType, rule.threshold, rule.rewardType, rule.giftId, rule.productId, rule.productQuantity, rule.coinAmount, rule.enabled, rule.createdByUserId]);
          ruleId = inserted.insertId;
        } else {
          ruleId = existing.id;
          const claimed = Number((await tx.query('SELECT COUNT(*) AS count FROM reward_claims WHERE rule_id=?', [ruleId]))[0]?.count || 0);
          if (claimed > 0 && (rule.ruleType !== existing.ruleType || rule.threshold !== existing.threshold || rule.rewardType !== existing.rewardType || rule.giftId !== existing.giftId || JSON.stringify(rule.productItems) !== JSON.stringify(existing.productItems))) throw new ServiceError('奖励规则已有领取记录，不允许修改类型、门槛或奖励对象', 409, 'REWARD_RULE_IMMUTABLE');
          await tx.query('UPDATE reward_rules SET rule_type=?,threshold_value=?,reward_type=?,gift_id=?,product_id=?,product_quantity=?,coin_amount=?,enabled=? WHERE id=?', [rule.ruleType, rule.threshold, rule.rewardType, rule.giftId, rule.productId, rule.productQuantity, rule.coinAmount, rule.enabled, ruleId]);
        }
        await tx.query('UPDATE reward_rules SET product_items_json=? WHERE id=?', [rule.productItemsJson, ruleId]);
        return this.get(ruleId, tx);
      });
    } catch (error) { if (duplicate(error)) throw new ServiceError('相同类型和门槛的奖励规则已存在', 409, 'DUPLICATE_RULE'); throw error; }
  }
  async disable(value) { const result = await this.db.query('UPDATE reward_rules SET enabled=0 WHERE id=?', [id(value)]); if (!result.affectedRows) throw new ServiceError('奖励规则不存在', 404, 'NOT_FOUND'); }
  async delete(value) { const { deleteRewardRule } = await import('./deletion-service.js'); return this.db.transaction((tx) => deleteRewardRule(tx, value)); }

  async listClaims(options = {}) {
    const { page, limit, offset } = pageOptions(options);
    const clauses = [], params = [];
    if (options.steamId) { if (!isSteamId64(options.steamId)) throw new ServiceError('SteamID 格式无效'); clauses.push('c.steam_id=?'); params.push(String(options.steamId)); }
    if (options.ruleId) { clauses.push('c.rule_id=?'); params.push(id(options.ruleId)); }
    const where = clauses.length ? ` WHERE ${clauses.join(' AND ')}` : '';
    const total = Number((await this.db.query(`SELECT COUNT(*) AS count FROM reward_claims c${where}`, params))[0]?.count || 0);
    const items = await this.db.query(`SELECT c.id,c.steam_id AS steamId,c.rule_id AS ruleId,r.rule_type AS ruleType,r.threshold_value AS threshold,c.checkin_id AS checkinId,c.sample_id AS sampleId,c.gift_id AS giftId,g.name AS giftName,c.product_id AS productId,p.name AS productName,c.coin_amount AS coinAmount,c.order_id AS orderId,o.order_no AS orderNo,CASE WHEN c.coin_amount IS NOT NULL THEN 'succeeded' ELSE o.status END AS status,c.created_at AS createdAt FROM reward_claims c JOIN reward_rules r ON r.id=c.rule_id LEFT JOIN gift_packages g ON g.id=c.gift_id LEFT JOIN products p ON p.id=c.product_id LEFT JOIN orders o ON o.id=c.order_id${where} ORDER BY c.id DESC LIMIT ${limit} OFFSET ${offset}`, params);
    return { items, page, limit, total };
  }

  async status(steamId) {
    if (!isSteamId64(steamId)) throw new ServiceError('SteamID 格式无效');
    const sid = String(steamId), day = shanghaiDay(this.now());
    const checkins = await this.db.query('SELECT id,checkin_day AS checkinDay,streak_days AS streakDays,total_days AS totalDays,created_at AS createdAt FROM player_checkins WHERE steam_id=? ORDER BY checkin_day DESC LIMIT 1', [sid]);
    const online = await this.db.query('SELECT total_seconds AS totalSeconds,updated_at AS updatedAt FROM player_online_totals WHERE steam_id=?', [sid]);
    const onlineTotalSeconds = Number(online[0]?.totalSeconds || 0);
    const latestCheckin = checkins[0] || null;
    const streakDays = Number(latestCheckin?.streakDays || 0);
    const totalDays = Number(latestCheckin?.totalDays || 0);
    const claimableOnlineRewards = await this.db.query("SELECT r.id AS ruleId,r.threshold_value AS threshold,r.reward_type AS rewardType,r.gift_id AS giftId,g.name AS giftName,r.product_id AS productId,p.name AS productName,r.coin_amount AS coinAmount FROM reward_rules r LEFT JOIN gift_packages g ON g.id=r.gift_id LEFT JOIN products p ON p.id=r.product_id WHERE r.enabled=1 AND r.rule_type='online_total' AND r.threshold_value<=? AND NOT EXISTS (SELECT 1 FROM reward_claims c WHERE c.rule_id=r.id AND c.steam_id=?) ORDER BY r.threshold_value,r.id", [onlineTotalSeconds, sid]);
    const nextRules = await this.db.query("SELECT r.id AS ruleId,r.threshold_value AS threshold,r.reward_type AS rewardType,r.gift_id AS giftId,g.name AS giftName,r.product_id AS productId,p.name AS productName,r.coin_amount AS coinAmount FROM reward_rules r LEFT JOIN gift_packages g ON g.id=r.gift_id LEFT JOIN products p ON p.id=r.product_id WHERE r.enabled=1 AND r.rule_type='online_total' AND r.threshold_value>? ORDER BY r.threshold_value,r.id LIMIT 1", [onlineTotalSeconds]);
    const nextCheckinRules = await this.db.query("SELECT r.id AS ruleId,r.rule_type AS ruleType,r.threshold_value AS threshold,r.coin_amount AS coinAmount FROM reward_rules r WHERE r.enabled=1 AND ((r.rule_type='checkin_streak' AND r.threshold_value>?) OR (r.rule_type='checkin_total' AND r.threshold_value>?)) ORDER BY CASE WHEN r.rule_type='checkin_streak' THEN r.threshold_value-? ELSE r.threshold_value-? END,r.id LIMIT 1", [streakDays, totalDays, streakDays, totalDays]);
    const dailyRules = nextCheckinRules[0] ? [] : await this.db.query("SELECT r.id AS ruleId,r.rule_type AS ruleType,r.threshold_value AS threshold,r.coin_amount AS coinAmount FROM reward_rules r WHERE r.enabled=1 AND r.rule_type='daily_checkin' ORDER BY r.id LIMIT 1");
    const recentClaims = await this.db.query("SELECT c.id,c.rule_id AS ruleId,r.rule_type AS ruleType,r.threshold_value AS threshold,c.gift_id AS giftId,g.name AS giftName,c.product_id AS productId,p.name AS productName,c.coin_amount AS coinAmount,c.order_id AS orderId,o.order_no AS orderNo,CASE WHEN c.coin_amount IS NOT NULL THEN 'succeeded' ELSE o.status END AS status,c.created_at AS createdAt FROM reward_claims c JOIN reward_rules r ON r.id=c.rule_id LEFT JOIN gift_packages g ON g.id=c.gift_id LEFT JOIN products p ON p.id=c.product_id LEFT JOIN orders o ON o.id=c.order_id WHERE c.steam_id=? ORDER BY c.id DESC LIMIT 10", [sid]);
    const nextOnlineReward = nextRules[0] ? { ...nextRules[0], ruleId: Number(nextRules[0].ruleId), threshold: Number(nextRules[0].threshold), giftId: nextRules[0].giftId == null ? null : Number(nextRules[0].giftId), productId: nextRules[0].productId == null ? null : Number(nextRules[0].productId), coinAmount: nextRules[0].coinAmount == null ? null : Number(nextRules[0].coinAmount), remainingSeconds: Math.max(0, Number(nextRules[0].threshold) - onlineTotalSeconds) } : null;
    const checkinRule = nextCheckinRules[0] || dailyRules[0];
    const nextCheckinReward = checkinRule ? { ...checkinRule, ruleId: Number(checkinRule.ruleId), threshold: Number(checkinRule.threshold), coinAmount: Number(checkinRule.coinAmount), remainingDays: checkinRule.ruleType === 'checkin_streak' ? Math.max(1, Number(checkinRule.threshold) - streakDays) : checkinRule.ruleType === 'checkin_total' ? Math.max(1, Number(checkinRule.threshold) - totalDays) : 1 } : null;
    return { steamId: sid, today: day, checkedInToday: latestCheckin ? dateKey(latestCheckin.checkinDay) === day : false, latestCheckin, onlineTotalSeconds, onlineUpdatedAt: online[0]?.updatedAt || null, claimableOnlineRewards: claimableOnlineRewards.map((rule) => ({ ...rule, ruleId: Number(rule.ruleId), threshold: Number(rule.threshold), giftId: rule.giftId == null ? null : Number(rule.giftId), productId: rule.productId == null ? null : Number(rule.productId), coinAmount: rule.coinAmount == null ? null : Number(rule.coinAmount) })), nextOnlineReward, nextCheckinReward, recentClaims };
  }

  async claimOnlineRewards(steamId, requestKey) {
    if (!isSteamId64(steamId)) throw new ServiceError('SteamID 格式无效');
    const sid = String(steamId), key = String(requestKey || '').trim();
    if (!key || key.length > 100) throw new ServiceError('Idempotency-Key 长度必须为 1-100');
    try {
      return await this.db.transaction(async (tx) => {
        await tx.query('INSERT INTO \`商城用户\` (\`SteamID\`,\`商城币余额\`) VALUES (?,0) ON DUPLICATE KEY UPDATE \`SteamID\`=VALUES(\`SteamID\`)', [sid]);
        await tx.query('SELECT \`SteamID\` AS steam_id FROM \`商城用户\` WHERE \`SteamID\`=? FOR UPDATE', [sid]);
        const keyed = await tx.query('SELECT id,steam_id AS steamId,checkin_id AS checkinId FROM reward_requests WHERE request_key=? FOR UPDATE', [key]);
        if (keyed[0] && (keyed[0].steamId !== sid || keyed[0].checkinId != null)) throw new ServiceError('Idempotency-Key 已被其他奖励请求使用', 409, 'IDEMPOTENCY_CONFLICT');
        if (keyed[0]) return this.onlineClaimResult(tx, keyed[0].id, true);
        const online = await tx.query('SELECT total_seconds AS totalSeconds FROM player_online_totals WHERE steam_id=? FOR UPDATE', [sid]);
        const total = Number(online[0]?.totalSeconds || 0);
        const request = await tx.query('INSERT INTO reward_requests (request_key,steam_id) VALUES (?,?)', [key, sid]);
        const rules = await tx.query("SELECT r.id,r.rule_type AS ruleType,r.threshold_value AS threshold,r.reward_type AS rewardType,r.gift_id AS giftId,r.product_id AS productId,r.product_quantity AS productQuantity,r.coin_amount AS coinAmount FROM reward_rules r WHERE r.enabled=1 AND r.rule_type='online_total' AND r.threshold_value<=? AND NOT EXISTS (SELECT 1 FROM reward_claims c WHERE c.rule_id=r.id AND c.steam_id=?) ORDER BY r.id FOR UPDATE", [total, sid]);
        const claims = await this.claimRules(tx, { requestId: request.insertId, steamId: sid, rules });
        return { onlineTotalSeconds: total, claims, idempotent: false };
      });
    } catch (error) {
      if (!duplicate(error)) throw error;
      const keyed = await this.db.query('SELECT id,steam_id AS steamId,checkin_id AS checkinId FROM reward_requests WHERE request_key=?', [key]);
      if (!keyed[0] || keyed[0].steamId !== sid || keyed[0].checkinId != null) throw new ServiceError('Idempotency-Key 冲突', 409, 'IDEMPOTENCY_CONFLICT');
      return this.onlineClaimResult(this.db, keyed[0].id, true);
    }
  }

  async onlineClaimResult(db, requestId, idempotent) {
    const claims = await db.query('SELECT id,rule_id AS ruleId,order_id AS orderId,coin_amount AS coinAmount FROM reward_claims WHERE request_id=? ORDER BY id', [requestId]);
    return { claims, idempotent };
  }

  async claimRules(tx, { requestId, steamId, checkin = null, sampleId = null, rules }) {
    const created = [];
    for (const rule of rules) {
      const claimKey = rule.ruleType === 'daily_checkin' ? `daily_checkin:${rule.id}:${steamId}:${checkin.checkinDay}` : `${rule.ruleType}:${rule.id}:${steamId}`;
      const existing = await tx.query('SELECT id,order_id AS orderId FROM reward_claims WHERE claim_key=?', [claimKey]);
      if (existing[0]) continue;
      if (rule.rewardType === 'combined') {
        const amount = positive(rule.coinAmount, '奖励商城币');
        const snapshots = await tx.query('SELECT product_items_json AS productItemsJson FROM reward_rules WHERE id=? FOR UPDATE', [rule.id]);
        const items = parseProductItems(snapshots[0]?.productItemsJson, [{ productId: rule.productId, quantity: rule.productQuantity || 1 }]);
        const ids = items.map((item) => item.productId);
        const rows = await tx.query(`SELECT id,sku,name,item_id AS itemId,grant_amount AS grantAmount,currency_type AS currencyType,fulfillment_codes AS fulfillmentCodes FROM products WHERE id IN (${ids.map(() => '?').join(',')}) AND enabled=1 FOR UPDATE`, ids);
        if (rows.length !== ids.length) throw new ServiceError('奖励商品不存在或已下架', 404, 'PRODUCT_NOT_FOUND');
        const byId = new Map(rows.map((row) => [Number(row.id), row]));
        const products = items.map((item) => ({ ...byId.get(item.productId), quantity: item.quantity }));
        const actions = await tx.query('SELECT action_index AS actionIndex,action_type AS actionType,product_id AS productId,item_id AS itemId,quantity,options_json AS optionsJson,coin_amount AS coinAmount FROM gift_actions WHERE gift_id=? ORDER BY action_index ASC FOR UPDATE', [rule.giftId]);
        if (!actions.length) throw new ServiceError('奖励礼包没有可执行动作', 409, 'GIFT_EMPTY');
        const accounts = await tx.query('SELECT \`商城币余额\` AS balance FROM \`商城用户\` WHERE \`SteamID\`=? FOR UPDATE', [steamId]);
        const balance = Number(accounts[0].balance) + amount;
        if (!Number.isSafeInteger(balance)) throw new ServiceError('商城币余额超出安全范围', 409, 'BALANCE_OVERFLOW');
        const claim = await tx.query('INSERT INTO reward_claims (request_id,claim_key,steam_id,rule_id,checkin_id,sample_id,gift_id,product_id,coin_amount) VALUES (?,?,?,?,?,?,?,?,?)', [requestId, claimKey, steamId, rule.id, checkin?.id || null, sampleId, rule.giftId, rule.productId, amount]);
        const order = await this.orderService.create({ tx, steamId, giftId: rule.giftId, claimKey, source: checkin ? 'checkin_reward' : 'online_reward', giftActions: actions });
        for (const product of products) await this.orderService.appendProduct({ tx, orderId: order.id, steamId, product, quantity: product.quantity });
        await tx.query('UPDATE \`商城用户\` SET \`商城币余额\`=? WHERE \`SteamID\`=?', [balance, steamId]);
        await tx.query("INSERT INTO coin_ledger (steam_id,amount,balance_after,type,reference_type,reference_id,note) VALUES (?,?,?,?,?,?,?)", [steamId, amount, balance, checkin ? 'checkin_reward' : 'online_reward', 'reward_claim', String(claim.insertId), '组合奖励商城币']);
        await tx.query('UPDATE reward_claims SET order_id=? WHERE id=?', [order.id, claim.insertId]);
        created.push({ id: claim.insertId, ruleId: rule.id, orderId: order.id, coinAmount: amount });
        continue;
      }
      if (rule.coinAmount != null) {
        const amount = positive(rule.coinAmount, '奖励商城币');
        const accounts = await tx.query('SELECT \`商城币余额\` AS balance FROM \`商城用户\` WHERE \`SteamID\`=? FOR UPDATE', [steamId]);
        const balance = Number(accounts[0].balance) + amount;
        if (!Number.isSafeInteger(balance)) throw new ServiceError('商城币余额超出安全范围', 409, 'BALANCE_OVERFLOW');
        const claim = await tx.query('INSERT INTO reward_claims (request_id,claim_key,steam_id,rule_id,checkin_id,sample_id,gift_id,product_id,coin_amount) VALUES (?,?,?,?,?,?,?,?,?)', [requestId, claimKey, steamId, rule.id, checkin?.id || null, sampleId, null, null, amount]);
        await tx.query('UPDATE \`商城用户\` SET \`商城币余额\`=? WHERE \`SteamID\`=?', [balance, steamId]);
        await tx.query("INSERT INTO coin_ledger (steam_id,amount,balance_after,type,reference_type,reference_id,note) VALUES (?,?,?,?,?,?,?)", [steamId, amount, balance, checkin ? 'checkin_reward' : 'online_reward', 'reward_claim', String(claim.insertId), checkin ? '签到商城币奖励' : '在线商城币奖励']);
        created.push({ id: claim.insertId, ruleId: rule.id, orderId: null, coinAmount: amount });
        continue;
      }
      if (rule.productId != null) {
        const snapshots = await tx.query('SELECT product_items_json AS productItemsJson FROM reward_rules WHERE id=? FOR UPDATE', [rule.id]);
        const items = parseProductItems(snapshots[0]?.productItemsJson, [{ productId: rule.productId, quantity: rule.productQuantity || 1 }]);
        const ids = items.map((item) => item.productId);
        const rows = await tx.query(`SELECT id,sku,name,item_id AS itemId,grant_amount AS grantAmount,currency_type AS currencyType,fulfillment_codes AS fulfillmentCodes FROM products WHERE id IN (${ids.map(() => '?').join(',')}) AND enabled=1 FOR UPDATE`, ids);
        if (rows.length !== ids.length) throw new ServiceError('奖励商品不存在或已下架', 404, 'PRODUCT_NOT_FOUND');
        const byId = new Map(rows.map((row) => [Number(row.id), row]));
        const products = items.map((item) => ({ ...byId.get(item.productId), quantity: item.quantity }));
        const claim = await tx.query('INSERT INTO reward_claims (request_id,claim_key,steam_id,rule_id,checkin_id,sample_id,product_id) VALUES (?,?,?,?,?,?,?)', [requestId, claimKey, steamId, rule.id, checkin?.id || null, sampleId, rule.productId]);
        const order = await this.orderService.createProducts({ tx, steamId, products, claimKey, source: checkin ? 'checkin_reward' : 'online_reward' });
        await tx.query('UPDATE reward_claims SET order_id=? WHERE id=?', [order.id, claim.insertId]);
        created.push({ id: claim.insertId, ruleId: rule.id, orderId: order.id, productId: rule.productId });
        continue;
      }
      const actions = await tx.query('SELECT action_index AS actionIndex,action_type AS actionType,product_id AS productId,item_id AS itemId,quantity,options_json AS optionsJson,coin_amount AS coinAmount FROM gift_actions WHERE gift_id=? ORDER BY action_index ASC FOR UPDATE', [rule.giftId]);
      if (!actions.length) throw new ServiceError('奖励礼包没有可执行动作', 409, 'GIFT_EMPTY');
      const claim = await tx.query('INSERT INTO reward_claims (request_id,claim_key,steam_id,rule_id,checkin_id,sample_id,gift_id) VALUES (?,?,?,?,?,?,?)', [requestId, claimKey, steamId, rule.id, checkin?.id || null, sampleId, rule.giftId]);
      const order = await this.orderService.create({ tx, steamId, giftId: rule.giftId, claimKey, source: checkin ? 'checkin_reward' : 'online_reward', giftActions: actions });
      await tx.query('UPDATE reward_claims SET order_id=? WHERE id=?', [order.id, claim.insertId]);
      created.push({ id: claim.insertId, ruleId: rule.id, orderId: order.id });
    }
    return created;
  }

  async checkIn(steamId, requestKey) {
    if (!isSteamId64(steamId)) throw new ServiceError('SteamID 格式无效');
    const sid = String(steamId), key = String(requestKey || '').trim();
    if (!key || key.length > 100) throw new ServiceError('Idempotency-Key 长度必须为 1-100');
    const day = shanghaiDay(this.now());
    try {
      return await this.db.transaction(async (tx) => {
        await tx.query('INSERT INTO \`商城用户\` (\`SteamID\`,\`商城币余额\`) VALUES (?,0) ON DUPLICATE KEY UPDATE \`SteamID\`=VALUES(\`SteamID\`)', [sid]);
        await tx.query('SELECT \`SteamID\` AS steam_id FROM \`商城用户\` WHERE \`SteamID\`=? FOR UPDATE', [sid]);
        const keyed = await tx.query('SELECT id,steam_id AS steamId,checkin_id AS checkinId FROM reward_requests WHERE request_key=? FOR UPDATE', [key]);
        if (keyed[0] && keyed[0].steamId !== sid) throw new ServiceError('Idempotency-Key 已被其他玩家使用', 409, 'IDEMPOTENCY_CONFLICT');
        if (keyed[0]) return this.checkinResult(tx, keyed[0].checkinId, true);
        const latest = await tx.query('SELECT id,checkin_day AS checkinDay,streak_days AS streakDays,total_days AS totalDays FROM player_checkins WHERE steam_id=? ORDER BY checkin_day DESC LIMIT 1 FOR UPDATE', [sid]);
        if (latest[0] && dateKey(latest[0].checkinDay) === day) {
          await tx.query('INSERT INTO reward_requests (request_key,steam_id,checkin_id) VALUES (?,?,?)', [key, sid, latest[0].id]);
          return this.checkinResult(tx, latest[0].id, true);
        }
        const streak = latest[0] && dateKey(latest[0].checkinDay) === previousDay(day) ? Number(latest[0].streakDays) + 1 : 1;
        const total = Number(latest[0]?.totalDays || 0) + 1;
        const inserted = await tx.query('INSERT INTO player_checkins (steam_id,checkin_day,streak_days,total_days) VALUES (?,?,?,?)', [sid, day, streak, total]);
        const request = await tx.query('INSERT INTO reward_requests (request_key,steam_id,checkin_id) VALUES (?,?,?)', [key, sid, inserted.insertId]);
        const rules = await tx.query("SELECT id,rule_type AS ruleType,threshold_value AS threshold,gift_id AS giftId,coin_amount AS coinAmount FROM reward_rules WHERE enabled=1 AND ((rule_type='daily_checkin' AND threshold_value=1) OR (rule_type='checkin_streak' AND threshold_value<=?) OR (rule_type='checkin_total' AND threshold_value<=?)) ORDER BY id FOR UPDATE", [streak, total]);
        const checkin = { id: inserted.insertId, checkinDay: day, streakDays: streak, totalDays: total };
        const claims = await this.claimRules(tx, { requestId: request.insertId, steamId: sid, checkin, rules });
        const member = (await tx.query("SELECT s.checkin_bonus AS bonus FROM \`商城用户\` u JOIN membership_strategies s ON s.level=CASE WHEN u.\`会员等级\`>0 AND (u.\`会员到期时间\` IS NULL OR u.\`会员到期时间\`>CURRENT_TIMESTAMP(3)) THEN u.\`会员等级\` ELSE 0 END WHERE u.\`SteamID\`=? AND s.enabled=1", [sid]))[0];
        const memberBonus = Number(member?.bonus || 0);
        if (memberBonus > 0) {
          const account = (await tx.query('SELECT \`商城币余额\` AS balance FROM \`商城用户\` WHERE \`SteamID\`=? FOR UPDATE', [sid]))[0];
          const balance = Number(account.balance) + memberBonus;
          await tx.query('UPDATE \`商城用户\` SET \`商城币余额\`=? WHERE \`SteamID\`=?', [balance, sid]);
          await tx.query("INSERT INTO coin_ledger (steam_id,amount,balance_after,type,reference_type,reference_id,note) VALUES (?,?,?,'membership_checkin_bonus','player_checkin',?,'会员签到额外赠送')", [sid, memberBonus, balance, String(inserted.insertId)]);
        }
        return { ...checkin, claims, memberBonus, idempotent: false };
      });
    } catch (error) {
      if (!duplicate(error)) throw error;
      const existing = await this.db.query('SELECT steam_id AS steamId,checkin_id AS checkinId FROM reward_requests WHERE request_key=?', [key]);
      if (existing[0]) { if (existing[0].steamId !== sid) throw new ServiceError('Idempotency-Key 已被其他玩家使用', 409, 'IDEMPOTENCY_CONFLICT'); return this.checkinResult(this.db, existing[0].checkinId, true); }
      const sameDay = await this.db.query('SELECT id FROM player_checkins WHERE steam_id=? AND checkin_day=?', [sid, day]);
      if (sameDay[0]) return this.checkinResult(this.db, sameDay[0].id, true);
      throw error;
    }
  }

  async checkinResult(db, checkinId, idempotent) {
    const rows = await db.query('SELECT id,checkin_day AS checkinDay,streak_days AS streakDays,total_days AS totalDays FROM player_checkins WHERE id=?', [checkinId]);
    const claims = await db.query('SELECT id,rule_id AS ruleId,order_id AS orderId,coin_amount AS coinAmount FROM reward_claims WHERE checkin_id=? ORDER BY id', [checkinId]);
    return { ...rows[0], claims, idempotent };
  }

  async accrueOnlineSample({ tx, sampleId, sampledAt, players, previousAdjacentSample, pollIntervalMs }) {
    if (!tx?.query) throw new TypeError('tx 必填');
    if (!previousAdjacentSample || previousAdjacentSample.status !== 'ok' || !Boolean(previousAdjacentSample.playerQueryOk ?? previousAdjacentSample.player_query_ok)) return { creditedPlayers: 0, creditedSeconds: 0, claims: 0 };
    const currentAt = new Date(sampledAt), previousAt = new Date(previousAdjacentSample.sampledAt ?? previousAdjacentSample.sampled_at);
    const elapsedMs = currentAt.getTime() - previousAt.getTime(), interval = Number(pollIntervalMs);
    if (!Number.isFinite(elapsedMs) || !Number.isFinite(interval) || elapsedMs <= 0 || elapsedMs > Math.max(interval * 2, interval + 5000)) return { creditedPlayers: 0, creditedSeconds: 0, claims: 0 };
    const seconds = Math.floor(elapsedMs / 1000);
    if (seconds < 1) return { creditedPlayers: 0, creditedSeconds: 0, claims: 0 };
    const currentIds = [...new Set((players || []).map((player) => String(player?.steamId || player?.steamId64 || '')).filter(isSteamId64))];
    if (!currentIds.length) return { creditedPlayers: 0, creditedSeconds: 0, claims: 0 };
    const placeholders = currentIds.map(() => '?').join(',');
    const previous = await tx.query(`SELECT steam_id AS steamId FROM online_player_snapshots WHERE sample_id=? AND steam_id IN (${placeholders})`, [previousAdjacentSample.id, ...currentIds]);
    let creditedPlayers = 0, creditedTotal = 0, claimCount = 0;
    for (const row of previous) {
      const sid = row.steamId;
      await tx.query('INSERT INTO \`商城用户\` (\`SteamID\`,\`商城币余额\`) VALUES (?,0) ON DUPLICATE KEY UPDATE \`SteamID\`=VALUES(\`SteamID\`)', [sid]);
      const member = (await tx.query("SELECT s.online_bonus AS onlineBonus FROM \`商城用户\` u JOIN membership_strategies s ON s.level=CASE WHEN u.\`会员等级\`>0 AND (u.\`会员到期时间\` IS NULL OR u.\`会员到期时间\`>CURRENT_TIMESTAMP(3)) THEN u.\`会员等级\` ELSE 0 END WHERE u.\`SteamID\`=? AND s.enabled=1", [sid]))[0];
      const creditedSeconds = Math.max(1, Math.floor(seconds * Number(member?.onlineBonus ?? 100) / 100));
      const accrual = await tx.query('INSERT IGNORE INTO player_online_accruals (sample_id,steam_id,previous_sample_id,credited_seconds) VALUES (?,?,?,?)', [sampleId, sid, previousAdjacentSample.id, creditedSeconds]);
      if (!accrual.affectedRows) continue;
      creditedPlayers += 1;
      creditedTotal += creditedSeconds;
      await tx.query('INSERT INTO player_online_totals (steam_id,total_seconds) VALUES (?,?) ON DUPLICATE KEY UPDATE total_seconds=total_seconds+VALUES(total_seconds)', [sid, creditedSeconds]);
      const total = Number((await tx.query('SELECT total_seconds AS totalSeconds FROM player_online_totals WHERE steam_id=? FOR UPDATE', [sid]))[0].totalSeconds);
      const requestKey = `online:${crypto.createHash('sha256').update(`${sampleId}:${sid}`).digest('hex')}`;
      await tx.query('INSERT IGNORE INTO reward_requests (request_key,steam_id) VALUES (?,?)', [requestKey, sid]);
      const request = await tx.query('SELECT id FROM reward_requests WHERE request_key=?', [requestKey]);
      const rules = await tx.query("SELECT id,rule_type AS ruleType,threshold_value AS threshold,reward_type AS rewardType,gift_id AS giftId,product_id AS productId,product_quantity AS productQuantity,coin_amount AS coinAmount FROM reward_rules WHERE enabled=1 AND rule_type='online_total' AND threshold_value<=? ORDER BY id FOR UPDATE", [total]);
      const claims = await this.claimRules(tx, { requestId: request[0].id, steamId: sid, sampleId, rules });
      claimCount += claims.length;
    }
    return { creditedPlayers, creditedSeconds: creditedTotal, claims: claimCount };
  }
}

export { shanghaiDay };
