import { ServiceError } from './commerce-service.js';

function safeId(value, name) {
  const id = Number(value);
  if (!Number.isSafeInteger(id) || id < 1) throw new ServiceError(`${name} 无效`);
  return id;
}
function placeholders(values) { return values.map(() => '?').join(','); }
async function ids(tx, sql, params) { return (await tx.query(sql, params)).map((row) => Number(row.id)); }

async function deleteRewardClaims(tx, claimIds) {
  const unique = [...new Set(claimIds.map(Number).filter((id) => Number.isSafeInteger(id) && id > 0))];
  if (!unique.length) return;
  const ph = placeholders(unique);
  const requestIds = await ids(tx, `SELECT request_id AS id FROM reward_claims WHERE id IN (${ph})`, unique);
  await tx.query(`DELETE FROM coin_ledger WHERE reference_type='reward_claim' AND reference_id IN (${ph})`, unique.map(String));
  await tx.query(`DELETE FROM reward_claims WHERE id IN (${ph})`, unique);
  if (requestIds.length) await tx.query(`DELETE FROM reward_requests WHERE id IN (${placeholders(requestIds)}) AND NOT EXISTS (SELECT 1 FROM reward_claims WHERE reward_claims.request_id=reward_requests.id)`, requestIds);
}

export async function deleteOrders(tx, orderIds) {
  const unique = [...new Set(orderIds.map(Number).filter((id) => Number.isSafeInteger(id) && id > 0))];
  if (!unique.length) return;
  const ph = placeholders(unique);
  const taskIds = await ids(tx, `SELECT id FROM fulfillment_tasks WHERE order_id IN (${ph})`, unique);
  const batchIds = await ids(tx, `SELECT id FROM lottery_batches WHERE order_id IN (${ph})`, unique);
  const giftClaimIds = await ids(tx, `SELECT id FROM gift_claims WHERE order_id IN (${ph})`, unique);
  const redeemClaimIds = await ids(tx, `SELECT id FROM redeem_code_claims WHERE order_id IN (${ph})`, unique);
  const rewardClaimIds = await ids(tx, `SELECT id FROM reward_claims WHERE order_id IN (${ph})`, unique);
  if (taskIds.length) {
    const taskPh = placeholders(taskIds);
    await tx.query(`DELETE FROM lottery_fulfillment_logs WHERE fulfillment_task_id IN (${taskPh}) OR order_id IN (${ph})`, [...taskIds, ...unique]);
    await tx.query(`DELETE FROM fulfillment_attempts WHERE task_id IN (${taskPh})`, taskIds);
    await tx.query(`DELETE FROM coin_ledger WHERE reference_type='fulfillment_task' AND reference_id IN (${taskPh})`, taskIds.map(String));
  }
  if (batchIds.length) {
    const batchPh = placeholders(batchIds);
    await tx.query(`DELETE FROM lottery_fulfillment_logs WHERE lottery_batch_id IN (${batchPh})`, batchIds);
    await tx.query(`DELETE FROM lottery_draws WHERE batch_id IN (${batchPh})`, batchIds);
    await tx.query(`DELETE FROM lottery_batches WHERE id IN (${batchPh})`, batchIds);
    await tx.query(`DELETE FROM coin_ledger WHERE reference_type='lottery_batch' AND reference_id IN (${batchPh})`, batchIds.map(String));
  }
  await tx.query(`DELETE FROM scum_chat_claim_audits WHERE order_id IN (${ph})`, unique);
  await tx.query(`DELETE FROM fulfillment_tasks WHERE order_id IN (${ph})`, unique);
  await deleteRewardClaims(tx, rewardClaimIds);
  await tx.query(`UPDATE gift_claims SET order_id=NULL WHERE order_id IN (${ph})`, unique);
  await tx.query(`UPDATE redeem_code_claims SET order_id=NULL WHERE order_id IN (${ph})`, unique);
  await tx.query(`DELETE FROM order_items WHERE order_id IN (${ph})`, unique);
  await tx.query(`DELETE FROM coin_ledger WHERE reference_type='order' AND reference_id IN (${ph})`, unique.map(String));
  if (giftClaimIds.length) await tx.query(`DELETE FROM coin_ledger WHERE reference_type='gift_claim' AND reference_id IN (${placeholders(giftClaimIds)})`, giftClaimIds.map(String));
  if (redeemClaimIds.length) await tx.query(`DELETE FROM coin_ledger WHERE reference_type='redeem_claim' AND reference_id IN (${placeholders(redeemClaimIds)})`, redeemClaimIds.map(String));
  await tx.query(`DELETE FROM orders WHERE id IN (${ph})`, unique);
}

async function deleteLotteryBatches(tx, batchIds) {
  const unique = [...new Set(batchIds.map(Number).filter((id) => Number.isSafeInteger(id) && id > 0))];
  if (!unique.length) return;
  const ph = placeholders(unique);
  const orderIds = await ids(tx, `SELECT order_id AS id FROM lottery_batches WHERE id IN (${ph}) AND order_id IS NOT NULL`, unique);
  await deleteOrders(tx, orderIds);
  const remaining = await ids(tx, `SELECT id FROM lottery_batches WHERE id IN (${ph})`, unique);
  if (!remaining.length) return;
  const remainingPh = placeholders(remaining);
  await tx.query(`DELETE FROM lottery_fulfillment_logs WHERE lottery_batch_id IN (${remainingPh})`, remaining);
  await tx.query(`DELETE FROM lottery_draws WHERE batch_id IN (${remainingPh})`, remaining);
  await tx.query(`DELETE FROM coin_ledger WHERE reference_type='lottery_batch' AND reference_id IN (${remainingPh})`, remaining.map(String));
  await tx.query(`DELETE FROM lottery_batches WHERE id IN (${remainingPh})`, remaining);
}

export async function deleteGift(tx, value) {
  const giftId = safeId(value, '礼包 ID');
  const giftClaims = await ids(tx, 'SELECT id FROM gift_claims WHERE gift_id=?', [giftId]);
  const rewardClaims = await ids(tx, 'SELECT id FROM reward_claims WHERE gift_id=?', [giftId]);
  const lotteryBatches = await ids(tx, 'SELECT DISTINCT batch_id AS id FROM lottery_draws WHERE gift_id=?', [giftId]);
  const orderIds = await ids(tx, 'SELECT id FROM orders WHERE gift_id=? OR gift_claim_id IN (SELECT id FROM gift_claims WHERE gift_id=?) OR id IN (SELECT order_id FROM reward_claims WHERE gift_id=?)', [giftId, giftId, giftId]);
  if (giftClaims.length) {
    const ph = placeholders(giftClaims);
    await tx.query(`DELETE FROM activity_gift_claims WHERE gift_claim_id IN (${ph})`, giftClaims);
    await tx.query(`DELETE FROM scum_chat_claim_audits WHERE gift_claim_id IN (${ph})`, giftClaims);
  }
  await tx.query('DELETE FROM scum_chat_claim_audits WHERE gift_id=?', [giftId]);
  await deleteLotteryBatches(tx, lotteryBatches);
  await deleteOrders(tx, orderIds);
  await deleteRewardClaims(tx, rewardClaims);
  await tx.query('DELETE FROM activity_gift_claims WHERE gift_id=?', [giftId]);
  await tx.query('DELETE FROM gift_claims WHERE gift_id=?', [giftId]);
  await tx.query('DELETE FROM reward_rules WHERE gift_id=?', [giftId]);
  await tx.query('DELETE FROM lottery_prizes WHERE gift_id=?', [giftId]);
  await tx.query('DELETE FROM gift_actions WHERE gift_id=?', [giftId]);
  await tx.query('DELETE FROM activity_gifts WHERE gift_id=?', [giftId]);
  await tx.query('DELETE FROM gift_packages WHERE id=?', [giftId]);
}

export async function deleteRedeemCode(tx, value) {
  const codeId = safeId(value, '兑换码 ID');
  const claimIds = await ids(tx, 'SELECT id FROM redeem_code_claims WHERE redeem_code_id=?', [codeId]);
  const orderIds = await ids(tx, 'SELECT id FROM orders WHERE redeem_code_id=? OR redeem_claim_id IN (SELECT id FROM redeem_code_claims WHERE redeem_code_id=?)', [codeId, codeId]);
  await deleteOrders(tx, orderIds);
  if (claimIds.length) {
    await tx.query(`DELETE FROM coin_ledger WHERE reference_type='redeem_claim' AND reference_id IN (${placeholders(claimIds)})`, claimIds.map(String));
    await tx.query(`DELETE FROM redeem_code_claims WHERE id IN (${placeholders(claimIds)})`, claimIds);
  }
  await tx.query('DELETE FROM redeem_code_actions WHERE redeem_code_id=?', [codeId]);
  await tx.query('DELETE FROM redeem_codes WHERE id=?', [codeId]);
}

export async function deleteRewardRule(tx, value) {
  const ruleId = safeId(value, '奖励规则 ID');
  const claimIds = await ids(tx, 'SELECT id FROM reward_claims WHERE rule_id=?', [ruleId]);
  const orderIds = await ids(tx, 'SELECT order_id AS id FROM reward_claims WHERE rule_id=? AND order_id IS NOT NULL', [ruleId]);
  await deleteOrders(tx, orderIds);
  await deleteRewardClaims(tx, claimIds);
  await tx.query('DELETE FROM reward_rules WHERE id=?', [ruleId]);
}

export async function deleteActivity(tx, value) {
  const activityId = safeId(value, '活动 ID');
  const claimIds = await ids(tx, 'SELECT gift_claim_id AS id FROM activity_gift_claims WHERE activity_id=?', [activityId]);
  const orderIds = claimIds.length ? await ids(tx, `SELECT id FROM orders WHERE gift_claim_id IN (${placeholders(claimIds)})`, claimIds) : [];
  await deleteOrders(tx, orderIds);
  if (claimIds.length) {
    const ph = placeholders(claimIds);
    await tx.query(`DELETE FROM scum_chat_claim_audits WHERE gift_claim_id IN (${ph})`, claimIds);
    await tx.query(`DELETE FROM activity_gift_claims WHERE gift_claim_id IN (${ph})`, claimIds);
    await tx.query(`DELETE FROM coin_ledger WHERE reference_type='gift_claim' AND reference_id IN (${ph})`, claimIds.map(String));
    await tx.query(`DELETE FROM gift_claims WHERE id IN (${ph})`, claimIds);
  }
  await tx.query('DELETE FROM activity_gifts WHERE activity_id=?', [activityId]);
  await tx.query('DELETE FROM activity_lottery_pools WHERE activity_id=?', [activityId]);
  await tx.query('DELETE FROM activities WHERE id=?', [activityId]);
}

export async function deleteLotteryPool(tx, value) {
  const poolId = safeId(value, '奖池 ID');
  const activityIds = await ids(tx, 'SELECT a.id FROM activities a JOIN activity_lottery_pools ap ON ap.activity_id=a.id WHERE ap.pool_id=?', [poolId]);
  for (const activityId of activityIds) await deleteActivity(tx, activityId);
  const batchIds = await ids(tx, 'SELECT id FROM lottery_batches WHERE pool_id=?', [poolId]);
  await deleteLotteryBatches(tx, batchIds);
  await tx.query('DELETE FROM lottery_player_states WHERE pool_id=?', [poolId]);
  await tx.query('DELETE FROM lottery_fulfillment_logs WHERE pool_id=?', [poolId]);
  await tx.query('UPDATE lottery_pools SET current_version_id=NULL WHERE id=?', [poolId]);
  const versionIds = await ids(tx, 'SELECT id FROM lottery_pool_versions WHERE pool_id=?', [poolId]);
  if (versionIds.length) await tx.query(`DELETE FROM lottery_prizes WHERE version_id IN (${placeholders(versionIds)})`, versionIds);
  await tx.query('DELETE FROM lottery_pool_versions WHERE pool_id=?', [poolId]);
  await tx.query('DELETE FROM activity_lottery_pools WHERE pool_id=?', [poolId]);
  await tx.query('DELETE FROM lottery_pools WHERE id=?', [poolId]);
}

export async function deleteStock(tx, value) {
  const stockId = safeId(value, '股票 ID');
  await tx.query('DELETE FROM stock_watchlists WHERE stock_id=?', [stockId]);
  await tx.query('DELETE FROM stock_volume_bindings WHERE stock_id=?', [stockId]);
  await tx.query('DELETE FROM stock_price_history WHERE stock_id=?', [stockId]);
  const tradeIds = await ids(tx, 'SELECT id FROM stock_trades WHERE stock_id=?', [stockId]);
  await tx.query('DELETE FROM stock_holdings WHERE stock_id=?', [stockId]);
  if (tradeIds.length) await tx.query(`DELETE FROM coin_ledger WHERE reference_type='stock_trade' AND reference_id IN (${placeholders(tradeIds)})`, tradeIds.map(String));
  await tx.query('DELETE FROM stock_trades WHERE stock_id=?', [stockId]);
  await tx.query('DELETE FROM stocks WHERE id=?', [stockId]);
}

export async function deleteMaintenance(tx, value) {
  const id = safeId(value, '维护编号');
  await tx.query('DELETE FROM maintenance_announcement_runs WHERE maintenance_id=?', [id]);
  await tx.query('DELETE FROM maintenance_audit_logs WHERE maintenance_id=?', [id]);
  await tx.query('DELETE FROM maintenance_windows WHERE id=?', [id]);
}

export async function deleteProduct(tx, value) {
  const productId = safeId(value, '商品 ID');
  const rewardClaims = await ids(tx, 'SELECT id FROM reward_claims WHERE product_id=?', [productId]);
  const orderIds = await ids(tx, 'SELECT DISTINCT order_id AS id FROM order_items WHERE product_id=?', [productId]);
  const lotteryBatches = await ids(tx, 'SELECT DISTINCT d.batch_id AS id FROM lottery_draws d JOIN lottery_prizes p ON p.id=d.prize_id WHERE p.product_id=?', [productId]);
  await deleteLotteryBatches(tx, lotteryBatches);
  await deleteOrders(tx, orderIds);
  await deleteRewardClaims(tx, rewardClaims);
  await tx.query('DELETE FROM reward_rules WHERE product_id=?', [productId]);
  await tx.query('DELETE FROM gift_actions WHERE product_id=?', [productId]);
  await tx.query('DELETE FROM lottery_prizes WHERE product_id=?', [productId]);
  await tx.query('DELETE FROM stock_volume_bindings WHERE product_id=?', [productId]);
  await tx.query('DELETE FROM order_items WHERE product_id=?', [productId]);
  await tx.query('DELETE FROM products WHERE id=?', [productId]);
}
