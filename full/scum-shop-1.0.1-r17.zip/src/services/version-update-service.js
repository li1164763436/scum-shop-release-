import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { createReadStream, createWriteStream } from 'node:fs';
import { Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { ServiceError } from './commerce-service.js';
import {
  downloadVerifiedFile,
  fetchFromMirrors,
  fetchJsonFromMirrors,
  requireUpdateUrl,
  splitUrlList,
  updateTransportOptions,
  verifyReleaseManifestSignature
} from './update-transport.js';

const MAX_PACKAGE_BYTES = 1024 * 1024 * 1024;
const DEFAULT_MANIFEST_URLS = [
  'https://update.scum0.cn/release-v1/version.json',
  'https://raw.githubusercontent.com/li1164763436/scum-shop-release-/main/version.json'
];

function requireHttpUrl(value, name = '地址') {
  let url;
  try { url = new URL(String(value || '').trim()); } catch { throw new ServiceError(`${name}无效`, 400, 'INVALID_UPDATE_URL'); }
  if (!['http:', 'https:'].includes(url.protocol)) throw new ServiceError(`${name}仅支持 HTTP/HTTPS`, 400, 'INVALID_UPDATE_URL');
  return url;
}

function requireSha256(value) {
  const sha256 = String(value || '').trim().toLowerCase();
  if (!/^[a-f0-9]{64}$/.test(sha256)) throw new ServiceError('SHA256 校验值无效', 400, 'INVALID_UPDATE_HASH');
  return sha256;
}

function requireVersion(value) {
  const version = String(value || '').trim();
  if (!/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/.test(version)) throw new ServiceError('version.json 版本号无效', 400, 'INVALID_VERSION_MANIFEST');
  return version;
}

function requireReleaseRevision(value, { allowMissing = true } = {}) {
  if ((value === undefined || value === null || value === '') && allowMissing) return 0;
  const revision = Number(value);
  if (!Number.isSafeInteger(revision) || revision < 0) throw new ServiceError('version.json 发布修订号无效', 400, 'INVALID_VERSION_MANIFEST');
  return revision;
}

function compareVersions(left, right) {
  const parse = value => {
    const [core, ...suffix] = value.split('-');
    return { core: core.split('.').map(Number), prerelease: suffix.length ? suffix.join('-').split('.') : null };
  };
  const a = parse(left);
  const b = parse(right);
  for (let index = 0; index < 3; index += 1) if (a.core[index] !== b.core[index]) return a.core[index] > b.core[index] ? 1 : -1;
  if (!a.prerelease || !b.prerelease) return a.prerelease ? -1 : b.prerelease ? 1 : 0;
  const length = Math.max(a.prerelease.length, b.prerelease.length);
  for (let index = 0; index < length; index += 1) {
    const leftId = a.prerelease[index];
    const rightId = b.prerelease[index];
    if (leftId === undefined || rightId === undefined) return leftId === undefined ? -1 : 1;
    if (leftId === rightId) continue;
    const leftNumeric = /^\d+$/.test(leftId);
    const rightNumeric = /^\d+$/.test(rightId);
    if (leftNumeric && rightNumeric) return BigInt(leftId) > BigInt(rightId) ? 1 : -1;
    if (leftNumeric !== rightNumeric) return leftNumeric ? -1 : 1;
    return leftId > rightId ? 1 : -1;
  }
  return 0;
}

export function compareReleaseIdentity(left, right) {
  const versionOrder = compareVersions(left.version, right.version);
  if (versionOrder !== 0) return versionOrder;
  return Math.sign(left.releaseRevision - right.releaseRevision);
}
function checksumEntries(entries) {
  const hash = createHash('sha256');
  for (const entry of entries) hash.update(`${entry.path}\0${entry.sha256 || ''}\0${entry.size || 0}\n`);
  return hash.digest('hex');
}
async function fileDigest(filePath) {
  const stat = await fs.stat(filePath);
  if (!stat.isFile()) throw new Error('更新路径不是文件');
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(filePath)) hash.update(chunk);
  return { localSha256: hash.digest('hex'), localSize: stat.size };
}

async function fileMatches(filePath, expectedSize, expectedSha256) {
  try {
    const stat = await fs.stat(filePath);
    if (!stat.isFile() || stat.size !== expectedSize) return false;
    const hash = createHash('sha256');
    for await (const chunk of createReadStream(filePath)) hash.update(chunk);
    return hash.digest('hex') === expectedSha256;
  } catch { return false; }
}

export function normalizeManifest(raw) {
  if (raw?.files !== undefined) {
    if (!Array.isArray(raw.files) || raw.files.length === 0) throw new ServiceError('更新文件清单为空', 400, 'INVALID_VERSION_MANIFEST');
    const seen = new Set();
    const files = raw.files.map(file => {
      const name = String(file?.path || '');
      const allowed = ['src', 'public', 'scripts', 'resources', 'node_modules'].includes(name.split('/')[0]) || ['package.json', 'package-lock.json', 'ScumShopLauncher.exe', 'SCUM商城控制台.bat', '.scum-release-manifest.json', 'data/teleport-map-calibration.json'].includes(name) || name.startsWith('data/release-catalog-1.0.0/');
      if (!name || /[\\:\0-\x1f]/.test(name) || name.split('/').some(part => !part || part === '.' || part === '..' || /[. ]$/.test(part)) || !allowed || name.toLowerCase().startsWith('public/uploads/') || seen.has(name.toLowerCase())) throw new ServiceError('更新文件路径无效或重复', 400, 'INVALID_VERSION_MANIFEST');
      seen.add(name.toLowerCase());
      const size = Number(file.size);
      if (!Number.isSafeInteger(size) || size < 0 || size > MAX_PACKAGE_BYTES) throw new ServiceError('更新文件大小无效', 400, 'INVALID_VERSION_MANIFEST');
      const urls = splitUrlList([file.url, ...(Array.isArray(file.urls) ? file.urls : [])]).map(item => requireHttpUrl(item).href);
      if (!urls.length) throw new ServiceError('更新文件缺少下载地址', 400, 'INVALID_VERSION_MANIFEST');
      return { path: name, url: urls[0], urls, sha256: requireSha256(file.sha256), size };
    });
    const size = files.reduce((sum, file) => sum + file.size, 0);
    if (size > MAX_PACKAGE_BYTES) throw new ServiceError('更新文件总大小超出限制', 400, 'INVALID_VERSION_MANIFEST');
    return { version: requireVersion(raw.version), releaseRevision: requireReleaseRevision(raw.releaseRevision), notes: Array.isArray(raw.notes) ? raw.notes.map(String).slice(0, 20) : [], files, size };
  }
  const urls = splitUrlList([raw?.url || raw?.downloadUrl, ...(Array.isArray(raw?.urls) ? raw.urls : [])]).map(item => requireHttpUrl(item, '更新包地址').href);
  if (!urls.length) throw new ServiceError('更新包缺少下载地址', 400, 'INVALID_VERSION_MANIFEST');
  const url = urls[0];
  const sha256 = requireSha256(raw?.sha256);
  const version = requireVersion(raw?.version);
  const notes = Array.isArray(raw?.notes) ? raw.notes.map(item => String(item).trim()).filter(Boolean).slice(0, 20) : [];
  const size = raw?.size == null ? null : Number(raw.size);
  if (size !== null && (!Number.isSafeInteger(size) || size <= 0 || size > MAX_PACKAGE_BYTES)) throw new ServiceError('version.json 更新包大小无效', 400, 'INVALID_VERSION_MANIFEST');
  return { version, releaseRevision: requireReleaseRevision(raw?.releaseRevision), notes, url, urls, sha256, size };
}

export class VersionUpdateService {
  constructor({ root, logger, manifestUrl, manifestUrls, spawnProcess = spawn, transportOptions } = {}) {
    this.root = root;
    this.logger = logger;
    this.spawnProcess = spawnProcess;
    const configured = manifestUrls || process.env.VERSION_UPDATE_MANIFEST_URLS || manifestUrl || process.env.VERSION_UPDATE_MANIFEST_URL || DEFAULT_MANIFEST_URLS;
    this.manifestUrls = splitUrlList(configured);
    this.manifestUrl = this.manifestUrls[0] || '';
    this.transport = { ...updateTransportOptions(), ...transportOptions };
    this.validateUpdateUrl = value => requireUpdateUrl(value, {
      allowHttp: this.transport.allowHttp,
      allowedHosts: this.transport.allowedHosts,
      name: '版本更新地址'
    });
    this.statusFile = path.join(root, 'data', 'version-update-status.json');
    this.packageDir = path.join(root, 'data', 'updates');
    this.repositoryRoot = path.join(this.packageDir, 'repository', 'objects');
    this.updaterExecutable = path.join(root, 'ScumShopUpdater.exe');
    this.packageFile = path.join(root, 'package.json');
    this.lockFile = path.join(this.packageDir, 'version-update.lock');
    this.statusWriteQueue = Promise.resolve();
  }

  async currentRelease() {
    const data = JSON.parse((await fs.readFile(this.packageFile, 'utf8')).replace(/^\uFEFF/, ''));
    return { version: requireVersion(data.version), releaseRevision: requireReleaseRevision(data.releaseRevision) };
  }

  async currentVersion() {
    return (await this.currentRelease()).version;
  }

  async status() {
    try { return JSON.parse((await fs.readFile(this.statusFile, 'utf8')).replace(/^\uFEFF/, '')); }
    catch (error) {
      if (error?.code === 'ENOENT') return { status: 'idle', message: '暂无更新任务', updatedAt: null };
      this.logger?.error?.('version update status read failed', { component: 'version-update', error: error?.message });
      return { status: 'failed', message: '更新状态文件读取失败', updatedAt: null };
    }
  }

  writeStatus(data) {
    const operation = async () => {
      await fs.mkdir(path.dirname(this.statusFile), { recursive: true });
      const temporary = `${this.statusFile}.${process.pid}.${randomUUID()}.tmp`;
      await fs.writeFile(temporary, JSON.stringify({ ...data, updatedAt: new Date().toISOString() }, null, 2));
      try {
        await fs.rename(temporary, this.statusFile);
      } finally {
        await fs.rm(temporary, { force: true }).catch(() => {});
      }
      const now = new Date();
      await fs.utimes(this.lockFile, now, now).catch(() => {});
    };
    const pending = this.statusWriteQueue.then(operation, operation);
    this.statusWriteQueue = pending.catch(() => {});
    return pending;
  }

  async loadManifest() {
    if (!this.manifestUrls.length) throw new ServiceError('请填写版本更新清单地址', 400, 'VERSION_UPDATE_NOT_CONFIGURED');
    try {
      const { value, url } = await fetchJsonFromMirrors(splitUrlList([this.manifestUrl, ...this.manifestUrls]), {
        label: '版本更新清单读取',
        retries: this.transport.retries,
        retryDelayMs: this.transport.retryDelayMs,
        timeoutMs: Math.min(this.transport.requestTimeoutMs, 30000),
        validateUrl: this.validateUpdateUrl
      });
      return { ...normalizeManifest(value), manifestSource: url };
    } catch (error) {
      throw new ServiceError(error.message || '版本更新清单读取失败', 502, 'VERSION_MANIFEST_FAILED');
    }
  }

  async manifest() {
    const [manifest, currentRelease] = await Promise.all([this.loadManifest(), this.currentRelease()]);
    const currentVersion = currentRelease.version;
    const files = [];
    for (const file of manifest.files || []) {
      const { localSha256, localSize } = await fileDigest(path.join(this.root, file.path))
        .catch(() => ({ localSha256: '', localSize: 0 }));
      files.push({ ...file, localSha256, localSize, matches: localSha256 === file.sha256 && localSize === file.size });
    }
    return {
      currentVersion,
      currentReleaseRevision: currentRelease.releaseRevision,
      latestVersion: manifest.version,
      latestReleaseRevision: manifest.releaseRevision,
      version: manifest.version,
      releaseRevision: manifest.releaseRevision,
      notes: manifest.notes,
      updateAvailable: compareReleaseIdentity(manifest, currentRelease) > 0,
      fileCount: files.length,
      changedFileCount: files.filter(file => !file.matches).length,
      currentChecksum: checksumEntries(files.map(file => ({ path: file.path, sha256: file.localSha256, size: file.localSize }))),
      remoteChecksum: checksumEntries(files),
      files
    };
  }

  async acquireLock() {
    await fs.mkdir(this.packageDir, { recursive: true });
    try {
      const handle = await fs.open(this.lockFile, 'wx');
      await handle.writeFile(JSON.stringify({ pid: process.pid, createdAt: new Date().toISOString() }));
      await handle.close();
    } catch (error) {
      if (error?.code !== 'EEXIST') throw error;
      const [stat, lock] = await Promise.all([
        fs.stat(this.lockFile).catch(() => null),
        fs.readFile(this.lockFile, 'utf8').then(JSON.parse).catch(() => null)
      ]);
      let ownerAlive = false;
      if (Number.isSafeInteger(lock?.pid) && lock.pid > 0) {
        try { process.kill(lock.pid, 0); ownerAlive = true; }
        catch (probeError) { ownerAlive = probeError?.code === 'EPERM'; }
      }
      if (stat && Date.now() - stat.mtimeMs > 15 * 60 * 1000 && !ownerAlive) {
        await fs.rm(this.lockFile, { force: true });
        return this.acquireLock();
      }
      throw new ServiceError('已有版本更新任务正在执行', 409, 'UPDATE_IN_PROGRESS');
    }
  }

  async start() {
    await this.acquireLock();
    const taskId = `${Date.now()}-${process.pid}`;
    const target = path.join(this.packageDir, `update-${taskId}`);
    await this.writeStatus({ taskId, status: 'preparing', message: '正在读取版本信息', progress: 2 });
    this.runUpdate({ taskId, target }).catch(error => this.logger?.error?.('version update failed', { component: 'version-update', taskId, error: error?.message }));
    return { taskId, status: 'preparing', message: '更新任务已启动' };
  }

  async download() {
    await this.acquireLock();
    const taskId = `${Date.now()}-${process.pid}`;
    const target = path.join(this.packageDir, `update-${taskId}`);
    await this.writeStatus({ taskId, status: 'preparing', message: '正在读取版本信息', progress: 2 });
    this.runUpdate({ taskId, target, downloadOnly: true }).catch(error => this.logger?.error?.('version download failed', { component: 'version-update', taskId, error: error?.message }));
    return { taskId, status: 'preparing', message: '下载任务已启动' };
  }

  async install() {
    const ready = await this.status();
    if (ready.status !== 'ready' || !ready.packagePath || !ready.targetVersion) throw new ServiceError('请先下载并校验更新文件', 409, 'UPDATE_NOT_READY');
    await this.acquireLock();
    const taskId = `${Date.now()}-${process.pid}`;
    try {
      await this.scheduleInstall({ taskId, target: ready.packagePath, targetVersion: ready.targetVersion, targetReleaseRevision: ready.targetReleaseRevision || 0, totalBytes: ready.totalBytes || 0 });
      return { taskId, status: 'applying', message: '安装任务已启动' };
    } catch (error) {
      await fs.rm(this.lockFile, { force: true }).catch(() => {});
      await this.writeStatus({ taskId, status: 'failed', message: `安装任务启动失败：${error?.message || '未知错误'}`, progress: 100, targetVersion: ready.targetVersion, code: error?.code || 'INSTALL_START_FAILED' }).catch(() => {});
      throw error;
    }
  }

  async scheduleInstall({ taskId, target, targetVersion, targetReleaseRevision = 0, totalBytes = 0, sha256 }) {
    await this.writeStatus({ taskId, status: 'applying', message: '更新文件校验通过，准备启动固定客户端更新器', progress: 75, downloadedBytes: totalBytes, totalBytes, targetVersion, targetReleaseRevision, packagePath: target, lockPath: this.lockFile, statusPath: this.statusFile, sha256 });
    await fs.access(this.updaterExecutable);
    const args = [
      '--schedule',
      '--PackagePath', target,
      '--AppRoot', this.root,
      '--TargetVersion', targetVersion,
      '--TargetRevision', String(targetReleaseRevision),
      '--LockPath', this.lockFile,
      '--StatusPath', this.statusFile,
      '--TaskId', taskId,
      '--TaskName', `ScumRconUpdate-${taskId}`,
      '--RequireSignature', '1'
    ];
    await new Promise((resolve, reject) => {
      const child = this.spawnProcess(this.updaterExecutable, args, { cwd: this.root, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
      let output = '';
      child.stdout?.on('data', chunk => { output += chunk; });
      child.stderr?.on('data', chunk => { output += chunk; });
      child.once('error', reject);
      child.once('close', code => code === 0 ? resolve() : reject(new Error(`固定客户端更新器启动失败：${output.trim() || `退出码 ${code}`}`)));
    });
  }

  async runUpdate({ taskId, target, downloadOnly = false }) {
    try {
      const manifest = await this.loadManifest();
      const currentRelease = await this.currentRelease();
      const currentVersion = currentRelease.version;
      if (compareReleaseIdentity(manifest, currentRelease) <= 0) throw new ServiceError('当前已是最新版本', 409, 'UPDATE_NOT_AVAILABLE');
      if (manifest.files && !manifest.files.some(file => file.path === '.scum-release-manifest.json')) throw new ServiceError('更新清单缺少完整性契约', 400, 'UPDATE_CONTRACT_MISSING');
      await this.writeStatus({ taskId, status: 'downloading', message: manifest.files ? '正在逐个下载更新文件' : '正在下载更新包', progress: 5, downloadedBytes: 0, totalBytes: manifest.size, currentVersion, currentReleaseRevision: currentRelease.releaseRevision, targetVersion: manifest.version, targetReleaseRevision: manifest.releaseRevision });
      let actualSha256;
      let bytes = 0;
      let networkBytes = 0;
      let reusedFiles = 0;
      let downloadedFiles = 0;
      const totalBytes = manifest.size;
      if (manifest.files) {
        await fs.mkdir(target, { recursive: true });
        await fs.mkdir(this.repositoryRoot, { recursive: true });
        const filesByHash = new Map();
        for (const file of manifest.files) {
          const group = filesByHash.get(file.sha256) || [];
          group.push(file);
          filesByHash.set(file.sha256, group);
        }
        const blobPromises = new Map();
        const cachePath = file => path.join(this.repositoryRoot, file.sha256.slice(0, 2), file.sha256);
        const publishCacheFile = async (temporary, cached, file) => {
          await fs.mkdir(path.dirname(cached), { recursive: true });
          try { await fs.rename(temporary, cached); }
          catch (error) {
            if (!(await fileMatches(cached, file.size, file.sha256))) throw error;
            await fs.rm(temporary, { force: true });
          }
        };
        const ensureBlob = file => {
          if (blobPromises.has(file.sha256)) return blobPromises.get(file.sha256);
          const promise = (async () => {
            const cached = cachePath(file);
            if (await fileMatches(cached, file.size, file.sha256)) return { cached, source: 'cache', networkBytes: 0 };
            for (const candidate of filesByHash.get(file.sha256) || [file]) {
              const installed = path.join(this.root, candidate.path);
              if (!(await fileMatches(installed, file.size, file.sha256))) continue;
              const temporary = `${cached}.${taskId}.${process.pid}.tmp`;
              await fs.mkdir(path.dirname(cached), { recursive: true });
              await fs.copyFile(installed, temporary);
              await publishCacheFile(temporary, cached, file);
              return { cached, source: 'installed', networkBytes: 0 };
            }
            const urls = splitUrlList((filesByHash.get(file.sha256) || [file]).flatMap(candidate => candidate.urls || [candidate.url]));
            try {
              const result = await downloadVerifiedFile({
                urls,
                destination: cached,
                expectedSize: file.size,
                expectedSha256: file.sha256,
                label: `更新文件 ${file.path}`,
                retries: this.transport.retries,
                retryDelayMs: this.transport.retryDelayMs,
                timeoutMs: this.transport.requestTimeoutMs,
                validateUrl: this.validateUpdateUrl
              });
              return { cached, source: 'download', networkBytes: result.bytes };
            } catch (error) {
              throw new ServiceError(error.message || `文件下载失败：${file.path}`, 502, 'DOWNLOAD_FAILED');
            }
          })();
          blobPromises.set(file.sha256, promise);
          return promise;
        };
        let nextFile = 0;
        let lastReportedAt = 0;
        const reportFile = async (file, message) => {
          const now = Date.now();
          if (now - lastReportedAt >= 300 || bytes === totalBytes) {
            lastReportedAt = now;
            await this.writeStatus({ taskId, status: 'downloading', message: `${message}：${file.path}`, progress: 5 + Math.floor(bytes / Math.max(totalBytes, 1) * 65), downloadedBytes: networkBytes, processedBytes: bytes, totalBytes, reusedFiles, downloadedFiles, currentVersion, currentReleaseRevision: currentRelease.releaseRevision, targetVersion: manifest.version, targetReleaseRevision: manifest.releaseRevision });
          }
        };
        const downloadFile = async file => {
          const output = path.join(target, file.path);
          await fs.mkdir(path.dirname(output), { recursive: true });
          const blob = await ensureBlob(file);
          await fs.copyFile(blob.cached, output);
          bytes += file.size;
          if (blob.source === 'download') {
            if (blob.networkBytes) {
              networkBytes += blob.networkBytes;
              downloadedFiles += 1;
              blob.networkBytes = 0;
            } else {
              reusedFiles += 1;
            }
            await reportFile(file, '已下载并校验');
          } else {
            reusedFiles += 1;
            await reportFile(file, blob.source === 'installed' ? '已复用运行文件' : '已复用哈希仓库');
          }
        };
        const workers = Array.from({ length: Math.min(this.transport.concurrency, manifest.files.length) }, async () => {
          while (true) {
            const index = nextFile++;
            if (index >= manifest.files.length) return;
            await downloadFile(manifest.files[index]);
          }
        });
        const results = await Promise.allSettled(workers);
        const failed = results.find(result => result.status === 'rejected');
        if (failed) throw failed.reason;
        const [stagedPackage, stagedContract] = await Promise.all([
          fs.readFile(path.join(target, 'package.json'), 'utf8').then(JSON.parse),
          fs.readFile(path.join(target, '.scum-release-manifest.json'), 'utf8').then(JSON.parse)
        ]);
        for (const [name, identity] of [['package.json', stagedPackage], ['.scum-release-manifest.json', stagedContract]]) {
          if (requireVersion(identity.version) !== manifest.version || requireReleaseRevision(identity.releaseRevision) !== manifest.releaseRevision) {
            throw new ServiceError(`${name} 的发布身份与 version.json 不一致`, 400, 'UPDATE_RELEASE_IDENTITY_MISMATCH');
          }
        }
        try {
          verifyReleaseManifestSignature(stagedContract, {
            publicKeys: this.transport.publicKeys,
            requireSignature: this.transport.requireSignature
          });
        } catch (error) {
          throw new ServiceError(error.message, 400, 'UPDATE_SIGNATURE_INVALID');
        }
      } else {
      if (manifest.size) {
        try {
          const result = await downloadVerifiedFile({
            urls: manifest.urls,
            destination: target,
            expectedSize: manifest.size,
            expectedSha256: manifest.sha256,
            label: '更新包',
            retries: this.transport.retries,
            retryDelayMs: this.transport.retryDelayMs,
            timeoutMs: Math.max(this.transport.requestTimeoutMs, 10 * 60 * 1000),
            validateUrl: this.validateUpdateUrl
          });
          bytes = manifest.size;
          networkBytes = result.bytes;
          actualSha256 = manifest.sha256;
        } catch (error) {
          throw new ServiceError(error.message || '更新包下载失败', 502, 'DOWNLOAD_FAILED');
        }
      } else {
        const { response } = await fetchFromMirrors(manifest.urls, {
          label: '更新包下载',
          retries: this.transport.retries,
          retryDelayMs: this.transport.retryDelayMs,
          timeoutMs: Math.max(this.transport.requestTimeoutMs, 10 * 60 * 1000),
          validateUrl: this.validateUpdateUrl
        });
        if (!response.body) throw new ServiceError('更新包下载响应为空', 502, 'DOWNLOAD_FAILED');
        const hash = createHash('sha256');
        const meter = new Transform({ transform: (chunk, encoding, callback) => {
          bytes += chunk.length;
          if (bytes > MAX_PACKAGE_BYTES) return callback(new ServiceError('更新包超过允许大小', 400, 'UPDATE_PACKAGE_TOO_LARGE'));
          hash.update(chunk);
          callback(null, chunk);
        } });
        await pipeline(response.body, meter, createWriteStream(target));
        actualSha256 = hash.digest('hex');
        if (actualSha256 !== manifest.sha256) throw new ServiceError('更新包 SHA256 校验失败', 400, 'UPDATE_HASH_MISMATCH');
      }
      }
      if (downloadOnly) {
        await fs.rm(this.lockFile, { force: true });
        await this.writeStatus({ taskId, status: 'ready', message: `更新文件准备完成，复用 ${reusedFiles} 个，下载 ${downloadedFiles} 个`, progress: 75, downloadedBytes: networkBytes, processedBytes: bytes, totalBytes, reusedFiles, downloadedFiles, currentVersion, currentReleaseRevision: currentRelease.releaseRevision, targetVersion: manifest.version, targetReleaseRevision: manifest.releaseRevision, packagePath: target, sha256: actualSha256 });
        return;
      }
      await this.scheduleInstall({ taskId, target, targetVersion: manifest.version, targetReleaseRevision: manifest.releaseRevision, totalBytes, sha256: actualSha256 });
      this.logger?.info?.('version update started', { taskId, targetVersion: manifest.version, targetReleaseRevision: manifest.releaseRevision, sha256: actualSha256, mode: 'fixed-client-updater' });
      return;
    } catch (error) {
      await fs.rm(target, { force: true, recursive: true }).catch(() => {});
      await fs.rm(this.lockFile, { force: true }).catch(() => {});
      await this.writeStatus({ taskId, status: 'failed', message: error?.message || '版本更新失败', progress: 100, code: error?.code || 'UPDATE_FAILED' }).catch(() => {});
      throw error;
    }
  }
}
