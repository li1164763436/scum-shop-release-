import { redact } from '../utils/redactor.js';
import os from 'node:os';

function rowsOf(result) {
  return Array.isArray(result) && Array.isArray(result[0]) ? result[0] : result;
}

function cleanError(error) {
  const code = String(error?.code || error?.name || 'MONITOR_QUERY_FAILED').replace(/[^A-Za-z0-9_.-]/g, '_').slice(0, 64);
  const redacted = redact(error?.message || '玩家查询失败');
  const serialized = typeof redacted === 'string' ? redacted : JSON.stringify(redacted);
  const message = String(serialized || '玩家查询失败')
    .replace(/\r?\n[\s\S]*/g, '')
    .replace(/\b(?:token|password|secret|api[-_]?key)\s*[=:]\s*[^\s,;]+/gi, 'credential=***')
    .replace(/[\u0000-\u001f\u007f]/g, ' ')
    .trim()
    .slice(0, 500);
  return { code, message: message || '玩家查询失败' };
}

function normalizePlayer(player) {
  return {
    steamId: String(player?.steamId || player?.steamId64 || '').trim(),
    characterName: String(player?.characterName || player?.name || '').trim().slice(0, 255) || null,
    steamName: String(player?.steamName || '').trim().slice(0, 255) || null,
    isAdmin: player?.isAdmin === true || player?.isAdmin === 1 || player?.isAdmin === '1',
    money: player?.money !== null && player?.money !== undefined && Number.isFinite(Number(player.money)) ? Number(player.money) : null,
    gold: player?.gold !== null && player?.gold !== undefined && Number.isFinite(Number(player.gold)) ? Number(player.gold) : null
  };
}

function diffPresence(previous, current) {
  const before = new Map(previous.map((player) => [player.steamId, player]));
  const after = new Map(current.map((player) => [player.steamId, player]));
  return {
    online: current.filter((player) => !before.has(player.steamId)),
    offline: previous.filter((player) => !after.has(player.steamId))
  };
}

export class ServerMonitorWorker {
  constructor({ db, store, clients, logger, rewardService = null, fulfillmentWorkerStatus = () => ({ running: false }), activityGate = null, economyPollIntervalMs = 60000, idleEconomyPollIntervalMs = 900000, clock = () => Date.now(), setTimeout: setTimer = globalThis.setTimeout, clearTimeout: clearTimer = globalThis.clearTimeout }) {
    this.db = db;
    this.store = store;
    this.clients = clients;
    this.logger = logger;
    this.rewardService = rewardService;
    this.fulfillmentWorkerStatus = fulfillmentWorkerStatus;
    this.activityGate = activityGate;
    this.clock = clock;
    this.setTimer = setTimer;
    this.clearTimer = clearTimer;
    this.timer = null;
    this.activeTick = null;
    this.enabled = false;
    this.running = false;
    this.stopped = true;
    this.pollIntervalMs = null;
    this.lastOnlineCount = null;
    this.retentionDays = 7;
    this.economyPollIntervalMs = Math.max(60000, Number(economyPollIntervalMs) || 60000);
    this.idleEconomyPollIntervalMs = Math.max(this.economyPollIntervalMs, Number(idleEconomyPollIntervalMs) || 900000);
    this.lastEconomyAt = null;
    this.lastStartedAt = null;
    this.lastCompletedAt = null;
    this.lastSuccessAt = null;
    this.lastDurationMs = null;
    this.lastError = null;
    this.consecutiveFailures = 0;
    this.lastCleanupDay = null;
    this.lastCpuUsage = process.cpuUsage();
    this.lastCpuMeasuredAt = process.hrtime.bigint();
  }

  status() {
    return {
      enabled: this.enabled,
      running: this.running,
      polling: Boolean(this.timer),
      pollIntervalMs: this.pollIntervalMs,
      effectivePollIntervalMs: this.lastOnlineCount === 0 ? Math.max(this.pollIntervalMs || 0, 15000) : this.pollIntervalMs,
      emptyServerMode: this.lastOnlineCount === 0,
      economyPollIntervalMs: this.economyPollIntervalMs,
      idleEconomyPollIntervalMs: this.idleEconomyPollIntervalMs,
      storefrontActive: this.activityGate ? this.activityGate.isActive(this.clock()) : true,
      lastEconomyAt: this.lastEconomyAt,
      lastStartedAt: this.lastStartedAt,
      lastCompletedAt: this.lastCompletedAt,
      lastSuccessAt: this.lastSuccessAt,
      lastDurationMs: this.lastDurationMs,
      lastError: this.lastError,
      consecutiveFailures: this.consecutiveFailures
    };
  }

  async start() {
    this.stopped = false;
    return this.reconfigure();
  }

  async reconfigure() {
    const config = await this.store.read();
    const monitoring = { enabled: true, pollIntervalMs: 10000, retentionDays: 7, ...config.monitoring };
    this.enabled = Boolean(monitoring.enabled);
    this.pollIntervalMs = monitoring.pollIntervalMs;
    this.retentionDays = monitoring.retentionDays;
    this.clearSchedule();
    if (!this.enabled) {
      this.stopped = true;
      await this.drain();
      return this.status();
    }
    this.stopped = false;
    void this.tick();
    return this.status();
  }

  clearSchedule() {
    if (this.timer) this.clearTimer(this.timer);
    this.timer = null;
  }

  schedule() {
    if (!this.enabled || this.stopped || this.timer) return;
    const delay = this.lastOnlineCount === 0 ? Math.max(this.pollIntervalMs, 15000) : this.pollIntervalMs;
    this.timer = this.setTimer(() => {
      this.timer = null;
      void this.tick();
    }, delay);
    this.timer?.unref?.();
  }

  stop() {
    this.stopped = true;
    this.clearSchedule();
  }

  async drain() {
    await this.activeTick;
  }

  async stopAndDrain() {
    this.stop();
    await this.drain();
  }

  log(level, message, metadata = {}) {
    this.logger[level]?.(message, { component: 'server-monitor', ...metadata });
  }

  async tick() {
    if (this.running || !this.enabled || this.stopped) return false;
    this.activeTick = this.performTick();
    try { return await this.activeTick; }
    finally {
      this.activeTick = null;
      this.schedule();
    }
  }

  async performTick() {
    this.running = true;
    const startedMs = this.clock();
    const sampledAt = new Date(startedMs);
    this.lastStartedAt = sampledAt.toISOString();
    let querySucceeded = false;
    try {
      const { ggcon } = await this.clients();
      const queryStarted = this.clock();
      const storefrontActive = this.activityGate ? this.activityGate.isActive(startedMs) : true;
      const economyIntervalMs = storefrontActive ? this.economyPollIntervalMs : this.idleEconomyPollIntervalMs;
      const includeEconomy = this.lastEconomyAt === null || startedMs - this.lastEconomyAt >= economyIntervalMs;
      const result = await ggcon.players({ includeEconomy });
      querySucceeded = true;
      const latency = Math.max(0, Math.round(this.clock() - queryStarted));
      const players = (Array.isArray(result) ? result : []).map(normalizePlayer).filter((player) => /^\d{17}$/.test(player.steamId));
      const unique = [...new Map(players.map((player) => [player.steamId, player])).values()];
      this.lastOnlineCount = unique.length;
      if (this.stopped) return false;
      await this.saveSuccess(sampledAt, latency, unique);
      if (includeEconomy) this.lastEconomyAt = startedMs;
      const wasFailing = this.consecutiveFailures > 0;
      this.lastSuccessAt = sampledAt.toISOString();
      this.lastError = null;
      this.consecutiveFailures = 0;
      this.log(wasFailing ? 'info' : 'debug', wasFailing ? '服务器监控采集已恢复' : '服务器监控采集成功', { sampledAt: this.lastSuccessAt, onlineCount: unique.length, rconLatencyMs: latency });
      try { await this.cleanupIfDue(sampledAt); }
      catch (error) { this.log('warn', '服务器监控保留清理失败', cleanError(error)); }
      return true;
    } catch (error) {
      const safe = cleanError(error);
      if (this.stopped) return false;
      if (querySucceeded) {
        this.lastError = safe;
        this.consecutiveFailures += 1;
        this.log('error', '服务器监控成功采样写入失败', { errorCode: safe.code, errorMessage: safe.message });
        return false;
      }
      try { await this.saveFailure(sampledAt, safe); }
      catch (databaseError) {
        this.lastError = cleanError(databaseError);
        this.consecutiveFailures += 1;
        this.log('error', '服务器监控失败采样写入失败', { errorCode: this.lastError.code, errorMessage: this.lastError.message, queryErrorCode: safe.code });
        return false;
      }
      this.lastError = safe;
      this.consecutiveFailures += 1;
      this.log('warn', '服务器监控采集失败', { sampledAt: sampledAt.toISOString(), errorCode: safe.code, errorMessage: safe.message, consecutiveFailures: this.consecutiveFailures });
      return true;
    } finally {
      const completedMs = this.clock();
      this.lastCompletedAt = new Date(completedMs).toISOString();
      this.lastDurationMs = Math.max(0, Math.round(completedMs - startedMs));
      this.running = false;
    }
  }

  processMetrics() {
    const memory = process.memoryUsage();
    const cpuUsage = process.cpuUsage();
    const measuredAt = process.hrtime.bigint();
    const elapsedMicros = Number(measuredAt - this.lastCpuMeasuredAt) / 1000;
    const usedMicros = Math.max(0, cpuUsage.user - this.lastCpuUsage.user) + Math.max(0, cpuUsage.system - this.lastCpuUsage.system);
    const cpuCount = Math.max(1, os.cpus()?.length || 1);
    const cpuPercent = elapsedMicros > 0 ? Math.min(100, usedMicros / elapsedMicros / cpuCount * 100) : 0;
    this.lastCpuUsage = cpuUsage;
    this.lastCpuMeasuredAt = measuredAt;
    return { uptime: Math.max(0, Math.floor(process.uptime())), rss: memory.rss, heapUsed: memory.heapUsed, cpuPercent: Number(cpuPercent.toFixed(2)) };
  }

  fulfillmentRunning() {
    try { return Boolean(this.fulfillmentWorkerStatus()?.running); }
    catch { return false; }
  }

  async saveSuccess(sampledAt, latency, players) {
    const metrics = this.processMetrics();
    await this.db.transaction(async (tx) => {
      const previousSuccess = rowsOf(await tx.query("SELECT id FROM server_monitor_samples WHERE status='ok' AND player_query_ok=1 AND sampled_at<? ORDER BY sampled_at DESC,id DESC LIMIT 1", [sampledAt]));
      const inserted = rowsOf(await tx.query("INSERT INTO server_monitor_samples (sampled_at,status,rcon_ok,player_query_ok,online_count,rcon_latency_ms,process_uptime_sec,process_rss_bytes,process_heap_used_bytes,process_cpu_percent,worker_running,error_code,error_message) VALUES (?,'ok',1,1,?,?,?,?,?,?,?,NULL,NULL)", [sampledAt, players.length, latency, metrics.uptime, metrics.rss, metrics.heapUsed, metrics.cpuPercent, this.fulfillmentRunning()]));
      const sampleId = inserted.insertId;
      if (players.length) {
        const placeholders = players.map(() => '(?,?,?,?,?,?,?,?)').join(',');
        const values = players.flatMap((player) => [sampleId, player.steamId, player.characterName, player.steamName, player.isAdmin, player.money, player.gold, sampledAt]);
        await tx.query(`INSERT INTO online_player_snapshots (sample_id,steam_id,character_name,steam_name,is_admin,money,gold,observed_at) VALUES ${placeholders}`, values);
        for (const player of players) await tx.query('INSERT INTO \`商城用户\` (\`SteamID\`,\`游戏名称\`,\`游戏币\`,\`游戏金条\`,\`最后游戏在线时间\`) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE \`游戏名称\`=VALUES(\`游戏名称\`),\`游戏币\`=COALESCE(VALUES(\`游戏币\`),\`游戏币\`),\`游戏金条\`=COALESCE(VALUES(\`游戏金条\`),\`游戏金条\`),\`最后游戏在线时间\`=VALUES(\`最后游戏在线时间\`)', [player.steamId, player.characterName, player.money, player.gold, sampledAt]);
      }
      const adjacent = rowsOf(await tx.query('SELECT id,sampled_at AS sampledAt,status,player_query_ok AS playerQueryOk FROM server_monitor_samples WHERE id<>? AND (sampled_at<? OR (sampled_at=? AND id<?)) ORDER BY sampled_at DESC,id DESC LIMIT 1', [sampleId, sampledAt, sampledAt, sampleId]));
      if (this.rewardService?.accrueOnlineSample) await this.rewardService.accrueOnlineSample({ tx, sampleId, sampledAt, players, previousAdjacentSample: adjacent[0] || null, pollIntervalMs: this.pollIntervalMs });
      if (!previousSuccess[0]) return;
      const previousRows = rowsOf(await tx.query('SELECT steam_id AS steamId, character_name AS characterName, steam_name AS steamName, is_admin AS isAdmin FROM online_player_snapshots WHERE sample_id=?', [previousSuccess[0].id]));
      const previousPlayers = previousRows.map((player) => ({ ...player, isAdmin: Boolean(player.isAdmin) }));
      const changes = diffPresence(previousPlayers, players);
      for (const player of changes.online) await this.insertEvent(tx, sampleId, sampledAt, 'online', player);
      for (const player of changes.offline) await this.insertEvent(tx, sampleId, sampledAt, 'offline', player);
    });
  }

  async insertEvent(tx, sampleId, sampledAt, type, player) {
    await tx.query('INSERT INTO player_presence_events (steam_id,event_type,character_name,steam_name,is_admin,observed_at,sample_id) VALUES (?,?,?,?,?,?,?)', [player.steamId, type, player.characterName || null, player.steamName || null, Boolean(player.isAdmin), sampledAt, sampleId]);
  }

  async saveFailure(sampledAt, safe) {
    const metrics = this.processMetrics();
    await this.db.query("INSERT INTO server_monitor_samples (sampled_at,status,rcon_ok,player_query_ok,online_count,rcon_latency_ms,process_uptime_sec,process_rss_bytes,process_heap_used_bytes,process_cpu_percent,worker_running,error_code,error_message) VALUES (?,'error',0,0,NULL,NULL,?,?,?,?,?,?,?)", [sampledAt, metrics.uptime, metrics.rss, metrics.heapUsed, metrics.cpuPercent, this.fulfillmentRunning(), safe.code, safe.message]);
  }

  async cleanupIfDue(sampledAt) {
    const day = sampledAt.toISOString().slice(0, 10);
    if (this.lastCleanupDay === day) return false;
    const microseconds = this.retentionDays * 86400 * 1000000;
    await this.db.transaction(async (tx) => {
      await tx.query('DELETE FROM player_presence_events WHERE observed_at < DATE_SUB(UTC_TIMESTAMP(3), INTERVAL ? MICROSECOND)', [microseconds]);
      await tx.query('DELETE a FROM player_online_accruals a JOIN server_monitor_samples s ON s.id=a.sample_id OR s.id=a.previous_sample_id WHERE s.sampled_at < DATE_SUB(UTC_TIMESTAMP(3), INTERVAL ? MICROSECOND)', [microseconds]);
      await tx.query('DELETE FROM server_monitor_samples WHERE sampled_at < DATE_SUB(UTC_TIMESTAMP(3), INTERVAL ? MICROSECOND)', [microseconds]);
    });
    this.lastCleanupDay = day;
    return true;
  }
}

export { cleanError, normalizePlayer, diffPresence, rowsOf };
