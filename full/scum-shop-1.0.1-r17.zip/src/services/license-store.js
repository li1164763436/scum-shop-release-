import fs from 'node:fs/promises';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import Joi from 'joi';

const execFileAsync = promisify(execFile);

const licenseSchema = Joi.object({
  baseUrl: Joi.string().uri({ scheme: ['http', 'https'] }).max(2048).required(),
  licenseId: Joi.string().guid({ version: ['uuidv4'] }).required(),
  licenseToken: Joi.string().min(1).max(8192).required(),
  username: Joi.string().trim().min(1).max(255).required(),
  expiresAt: Joi.string().isoDate().required(),
  lastVerifiedAt: Joi.string().isoDate().required()
}).required().unknown(false);

export class LicenseStoreError extends Error {
  constructor(message, code = 'LICENSE_STORE_ERROR', options) {
    super(message, options);
    this.name = 'LicenseStoreError';
    this.code = code;
  }
}

export class LicenseStore {
  constructor(filePath = process.env.LICENSE_FILE || path.resolve('runtime', 'secrets', 'license.json')) {
    this.filePath = path.resolve(filePath);
  }

  validate(input) {
    const { value, error } = licenseSchema.validate(input, { abortEarly: true, convert: false });
    if (error) throw new LicenseStoreError('授权文件格式无效', 'LICENSE_FILE_INVALID', { cause: error });
    return value;
  }

  async read() {
    let text;
    try {
      text = await fs.readFile(this.filePath, 'utf8');
    } catch (error) {
      if (error?.code === 'ENOENT') {
        throw new LicenseStoreError('未找到授权，请运行 npm run license:activate', 'LICENSE_NOT_ACTIVATED', { cause: error });
      }
      throw new LicenseStoreError('无法读取授权文件', 'LICENSE_FILE_READ_FAILED', { cause: error });
    }
    try {
      return this.validate(JSON.parse(text));
    } catch (error) {
      if (error instanceof LicenseStoreError) throw error;
      throw new LicenseStoreError('授权文件格式无效', 'LICENSE_FILE_INVALID', { cause: error });
    }
  }

  async save(input) {
    const value = this.validate(input);
    const directory = path.dirname(this.filePath);
    const temporary = path.join(directory, `.${path.basename(this.filePath)}.${process.pid}.${Date.now()}.tmp`);
    try {
      await fs.mkdir(directory, { recursive: true });
      await fs.chmod(directory, 0o700).catch(() => {});
      await fs.writeFile(temporary, `${JSON.stringify(value, null, 2)}\n`, { encoding: 'utf8', mode: 0o600 });
      await fs.rename(temporary, this.filePath);
      await fs.chmod(this.filePath, 0o600).catch(() => {});
      if (process.platform === 'win32') {
        await execFileAsync('icacls.exe', [this.filePath, '/inheritance:r', '/grant:r', '*S-1-5-18:(F)', '*S-1-5-32-544:(F)'], { windowsHide: true }).catch(() => {});
      }
      return value;
    } catch (error) {
      await fs.rm(temporary, { force: true }).catch(() => {});
      if (error instanceof LicenseStoreError) throw error;
      throw new LicenseStoreError('无法保存授权文件', 'LICENSE_FILE_WRITE_FAILED', { cause: error });
    }
  }

  sanitize(value) {
    return {
      baseUrl: value.baseUrl,
      licenseId: value.licenseId,
      username: value.username,
      expiresAt: value.expiresAt,
      lastVerifiedAt: value.lastVerifiedAt,
      hasLicenseToken: Boolean(value.licenseToken),
      hasLicenseId: Boolean(value.licenseId)
    };
  }
}
