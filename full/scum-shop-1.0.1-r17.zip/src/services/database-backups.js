import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { createReadStream } from 'node:fs';
import mysql from 'mysql2/promise';

const HOUR = 3600000;
export async function fileHash(file) {
  const hash = crypto.createHash('sha256');
  for await (const chunk of createReadStream(file)) hash.update(chunk);
  return hash.digest('hex');
}
export function runMysqlTool(executable, args, { password, input, log, timeout = 15 * 60000 } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(executable, args, { windowsHide: true, env: { ...process.env, MYSQL_PWD: password || '' }, stdio: [input ? 'pipe' : 'ignore', 'ignore', 'pipe'] });
    let detail = '', stream;
    const timer = setTimeout(() => { child.kill(); }, timeout);
    child.stderr.on('data', chunk => { detail = (detail + chunk.toString()).slice(-4000); });
    child.once('error', error => { clearTimeout(timer); reject(error); });
    if (input) {
      stream = createReadStream(input);
      stream.on('error', error => { child.kill(); reject(error); });
      child.stdin.on('error', () => {});
      stream.pipe(child.stdin);
    }
    child.once('close', async code => {
      clearTimeout(timer); stream?.destroy();
      if (log) await fs.writeFile(log, detail, { mode: 0o600 }).catch(() => {});
      if (code !== 0) { const error = new Error('数据库工具执行失败，请查看恢复日志'); error.code = 'MYSQL_TOOL_FAILED'; reject(error); }
      else resolve();
    });
  });
}

export class DatabaseBackups {
  constructor({ root, store, logger, intervalMs = HOUR, mysqlBin = null }) {
    this.root = path.resolve(root); this.store = store; this.logger = logger;
    this.directory = path.join(this.root, 'backups', 'database');
    this.intervalMs = intervalMs; this.timer = null; this.running = false;
    this.latestAt = null; this.error = null; this.restoring = false; this.mysqlBin = mysqlBin; this.available = [];
  }
  status() { return { running: this.running, latestAt: this.latestAt, error: this.error, items: this.available }; }
  remember(backups) {
    this.available = backups.map(({ manifest, createdAt, database, size }) => ({ manifest, createdAt, database, size }));
    this.latestAt = this.available[0]?.createdAt || null;
  }
  async managedMysql() {
    if (this.mysqlBin) return this.mysqlBin;
    const candidates = [this.root];
    for (const root of candidates) {
      const bin = path.join(root, 'runtime', 'mysql', 'bin');
      try { await fs.access(path.join(bin, 'mysqldump.exe')); return bin; } catch {}
    }
    throw new Error('未找到内置MySQL工具');
  }
  async connection(config, overrides = {}) {
    return mysql.createConnection({ host: config.host, port: config.port, user: config.user, password: config.password, database: config.database, charset: 'utf8mb4', timezone: 'Z', connectTimeout: 5000, ...overrides });
  }
  async counts(connection, database) {
    const [tables] = await connection.execute("SELECT TABLE_NAME AS name FROM information_schema.tables WHERE table_schema=? AND table_type='BASE TABLE' ORDER BY TABLE_NAME", [database]);
    const counts = {};
    for (const { name } of tables) {
      const [rows] = await connection.query('SELECT COUNT(*) AS count FROM ' + mysql.escapeId(database) + '.' + mysql.escapeId(name));
      counts[name] = String(rows[0].count);
    }
    return counts;
  }
  async validBackups() {
    await fs.mkdir(this.directory, { recursive: true });
    const result = [];
    for (const name of await fs.readdir(this.directory)) {
      if (!/^backup-[0-9T-]+\.json$/.test(name)) continue;
      try {
        const entry = JSON.parse(await fs.readFile(path.join(this.directory, name), 'utf8'));
        if (entry.complete !== true || !/^backup-[0-9T-]+\.sql$/.test(entry.file) || !Number.isFinite(Date.parse(entry.createdAt))) continue;
        const file = path.join(this.directory, entry.file), stat = await fs.stat(file);
        if (stat.size !== entry.size || await fileHash(file) !== entry.sha256) continue;
        result.push({ ...entry, manifest: name });
      } catch {}
    }
    return result.sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt));
  }
  start() {
    if (this.timer) return;
    const tick = async () => {
      try {
        const backups = await this.validBackups(), latest = backups[0];
        this.remember(backups);
        if (!latest || Date.now() - Date.parse(latest.createdAt) >= this.intervalMs) await this.backup();
      } catch { this.error = '数据库备份失败，将在下次周期重试'; }
    };
    this.timer = setInterval(() => { void tick(); }, this.intervalMs);
    this.timer.unref?.(); void tick();
  }
  stop() { clearInterval(this.timer); this.timer = null; }
  async stopAndDrain() { this.stop(); while (this.running) await new Promise(resolve => setTimeout(resolve, 200)); }
  async backup() {
    if (this.running) throw new Error('备份或恢复正在执行');
    this.running = true;
    let connection, pending;
    try {
      const config = (await this.store.read()).mysql, bin = await this.managedMysql();
      connection = await this.connection(config);
      const [required] = await connection.execute("SELECT TABLE_NAME AS name FROM information_schema.tables WHERE table_schema=? AND TABLE_NAME IN ('商城用户','orders','products') AND TABLE_TYPE='BASE TABLE'", [config.database]);
      if (required.length !== 3) throw new Error('商城数据库尚未初始化完整，未生成备份');
      const stamp = new Date().toISOString().replace(/[:.Z]/g, '-'), file = 'backup-' + stamp + '.sql';
      await fs.mkdir(this.directory, { recursive: true });
      pending = path.join(this.directory, file + '.partial');
      await runMysqlTool(path.join(bin, 'mysqldump.exe'), ['--host=' + config.host, '--port=' + config.port, '--user=' + config.user, '--default-character-set=utf8mb4', '--single-transaction', '--routines', '--events', '--triggers', '--hex-blob', '--quick', '--no-tablespaces', '--skip-add-locks', '--set-gtid-purged=OFF', '--result-file=' + pending, config.database], { password: config.password });
      const handle = await fs.open(pending, 'r');
      let stat, tail;
      try { stat = await handle.stat(); const bytes = Buffer.alloc(Math.min(stat.size, 4096)); await handle.read(bytes, 0, bytes.length, stat.size - bytes.length); tail = bytes.toString('utf8'); } finally { await handle.close(); }
      if (!/-- Dump completed on/.test(tail) || stat.size < 100) throw new Error('备份不完整');
      const entry = { complete: true, createdAt: new Date().toISOString(), database: config.database, file, size: stat.size, sha256: await fileHash(pending) };
      await fs.rename(pending, path.join(this.directory, file));
      await fs.writeFile(path.join(this.directory, file.replace(/\.sql$/, '.json')), JSON.stringify(entry, null, 2), { mode: 0o600, flag: 'wx' });
      this.latestAt = entry.createdAt; this.error = null;
      await this.prune(); this.remember(await this.validBackups()); return entry;
    } catch (error) {
      if (pending) await fs.unlink(pending).catch(() => {});
      this.error = '备份失败，已有有效备份保留';
      this.logger?.error('数据库备份失败', { code: error.code || 'BACKUP_FAILED' });
      throw error;
    }
    finally { await connection?.end().catch(() => {}); this.running = false; }
  }
  async prune() {
    const backups = await this.validBackups(), days = new Set();
    for (const entry of backups) {
      const age = Date.now() - Date.parse(entry.createdAt), day = entry.createdAt.slice(0, 10);
      const keep = age < 48 * HOUR || (age < 7 * 24 * HOUR && !days.has(day));
      if (keep) { days.add(day); continue; }
      await fs.unlink(path.join(this.directory, entry.manifest));
      await fs.unlink(path.join(this.directory, entry.file));
    }
  }
  async restoreLatest(rootPassword = '') {
    const entry = (await this.validBackups())[0];
    if (!entry) throw new Error('没有有效数据库备份');
    return this.restoreBackup(entry.manifest, rootPassword);
  }
  async restoreBackup(manifest, suppliedRootPassword = '') {
    if (!/^backup-[0-9T-]+\.json$/.test(String(manifest || ''))) throw new Error('请选择有效数据库备份');
    if (this.running) throw new Error('备份或恢复正在执行');
    this.running = true; this.restoring = true;
    try {
      const config = (await this.store.read()).mysql;
      if (!['localhost','127.0.0.1'].includes(config.host)) throw new Error('仅支持恢复本机内置数据库');
      const backups = await this.validBackups();
      this.remember(backups);
      const entry = backups.find(item => item.database === config.database && item.manifest === manifest);
      if (!entry) throw new Error('选定备份不存在或完整性校验失败');
      let rootPassword = suppliedRootPassword;
      if (!rootPassword) try { rootPassword = (await fs.readFile(path.join(this.root, 'runtime/secrets/mysql-root.secret'), 'utf8')).trim(); } catch {}
      const bin = await this.managedMysql();
      const iniCandidates = [path.join(this.root, 'runtime/mysql-start.ini')];
      let ini, content;
      for (const candidate of iniCandidates) { try { content = await fs.readFile(candidate, 'utf8'); ini = candidate; break; } catch {} }
      if (!ini) throw new Error('未找到内置数据库配置');
      const dataValue = content.match(/^datadir\s*=\s*(.+)$/mi)?.[1]?.trim().replace(/^"|"$/g, '');
      const data = path.resolve(dataValue || ''), runtime = path.dirname(ini);
      if (data !== path.join(runtime, 'mysql-data') || /innodb[-_]force[-_]recovery\s*=/i.test(content)) throw new Error('数据库恢复路径或运行模式不安全');
      let admin;
      try { admin = await this.connection(config, { user: 'root', password: rootPassword, database: undefined }); }
      catch (error) { if (!['ECONNREFUSED','ETIMEDOUT'].includes(error.code)) throw error; }
      if (admin) {
        try {
          const [rows] = await admin.query('SELECT @@datadir AS directory');
          if (path.resolve(rows[0].directory) !== data) throw new Error('当前数据库不属于此商城目录');
        } finally { await admin.end(); }
        await runMysqlTool(path.join(bin, 'mysqladmin.exe'), ['--host=' + config.host, '--port=' + config.port, '--user=root', 'shutdown'], { password: rootPassword });
      }
      const suffix = Date.now();
      let moved = false;
      for (let n = 0; n < 30; n++) {
        try { await fs.rename(data, data + '-before-restore-' + suffix); moved = true; break; }
        catch (error) { if (!['EBUSY','EPERM','EACCES'].includes(error.code)) throw error; await new Promise(resolve => setTimeout(resolve, 500)); }
      }
      if (!moved) throw new Error('数据库文件尚未释放，未修改原数据目录');
      await fs.mkdir(data);
      await runMysqlTool(path.join(bin, 'mysqld.exe'), ['--defaults-file=' + ini, '--initialize-insecure'], { log: path.join(runtime, 'restore-initialize-' + suffix + '.log') });
      const child = spawn(path.join(bin, 'mysqld.exe'), ['--defaults-file=' + ini], { windowsHide: true, detached: true, stdio: 'ignore' });
      child.on('error', () => {}); child.unref();
      let connection;
      for (let n = 0; n < 30; n++) {
        try { connection = await this.connection(config, { user: 'root', password: '', database: undefined }); break; } catch { await new Promise(resolve => setTimeout(resolve, 1000)); }
      }
      if (!connection) throw new Error('重建数据库启动失败，旧目录已保留');
      try {
        const rootSecret = rootPassword || crypto.randomBytes(32).toString('hex');
        await connection.query("ALTER USER 'root'@'localhost' IDENTIFIED BY ?", [rootSecret]);
        await fs.mkdir(path.join(this.root, 'runtime/secrets'), { recursive: true });
        await fs.writeFile(path.join(this.root, 'runtime/secrets/mysql-root.secret'), rootSecret, { mode: 0o600 });
        await connection.query('CREATE DATABASE ' + mysql.escapeId(config.database) + ' CHARACTER SET utf8mb4');
        for (const host of ['localhost','127.0.0.1']) {
          await connection.query('CREATE USER ?@? IDENTIFIED BY ?', [config.user, host, config.password]);
          await connection.query('GRANT ALL PRIVILEGES ON ' + mysql.escapeId(config.database) + '.* TO ?@?', [config.user, host]);
        }
        await runMysqlTool(path.join(bin, 'mysql.exe'), ['--host=' + config.host, '--port=' + config.port, '--user=root', '--default-character-set=utf8mb4', '--binary-mode', config.database], { password: rootSecret, input: path.join(this.directory, entry.file), log: path.join(runtime, 'restore-import-' + suffix + '.log') });
        const counts = await this.counts(connection, config.database);
        if (!Object.hasOwn(counts, '商城用户') || !Object.hasOwn(counts, 'orders') || !Object.hasOwn(counts, 'products')) throw new Error('恢复后缺少关键业务表');
        const [checks] = await connection.query('CHECK TABLE ' + Object.keys(counts).map(name => mysql.escapeId(config.database) + '.' + mysql.escapeId(name)).join(','));
        if (checks.some(row => row.Msg_type === 'error')) throw new Error('恢复后的数据库检查失败');
      } finally { await connection.end(); }
      this.error = null;
    } catch (error) { this.error = '恢复失败，旧数据目录及备份保留'; throw error; }
    finally { this.running = false; this.restoring = false; }
  }
}
