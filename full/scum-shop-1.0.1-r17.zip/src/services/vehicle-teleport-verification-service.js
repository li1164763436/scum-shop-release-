import { randomUUID } from 'node:crypto';
import { parseVehicleLocation } from './scum-locked-vehicle-reader.js';

const LEGACY_PENDING_STATUS = 'success_pending_persistence';
const COMPLETED_STATUS = 'completed';
const AUDITABLE_STATUSES = new Set([LEGACY_PENDING_STATUS, COMPLETED_STATUS]);
const LEASE_TIMEOUT_MINUTES = 5;
const SECOND_ATTEMPT_DELAY_SECONDS = 60;
const MAX_INCONCLUSIVE_ATTEMPTS = 5;
const MAX_RESPONSE_LENGTH = 65535;
const POSITION_TOLERANCE_WORLD_UNITS = 10_000;

function rows(value) { return Array.isArray(value) ? value : []; }

function finiteCoordinate(value, name) {
  const coordinate = Number(value);
  if (!Number.isFinite(coordinate) || Math.abs(coordinate) > 10_000_000) {
    throw Object.assign(new Error(`载具复核${name}无效`), { code: 'VEHICLE_TELEPORT_VERIFICATION_INVALID' });
  }
  return coordinate;
}

function entityId(value) {
  const id = Number(value);
  if (!Number.isSafeInteger(id) || id < 1) {
    throw Object.assign(new Error('载具复核实体编号无效'), { code: 'VEHICLE_TELEPORT_VERIFICATION_INVALID' });
  }
  return id;
}

function safeText(value, fallback = '载具位置复核失败') {
  return String(value || fallback)
    .replace(/[A-Za-z]:\\[^\r\n]*/g, '[路径已隐藏]')
    .replace(/\b(?:password|token|secret|api[-_]?key)\s*[=:]\s*[^\s,;]+/gi, 'credential=***')
    .replace(/[\u0000-\u001f\u007f]/g, ' ')
    .trim()
    .slice(0, MAX_RESPONSE_LENGTH) || fallback;
}

function rawResponse(result) {
  return String(result?.response ?? result ?? '').replace(/\r\n?/g, '\n').slice(0, MAX_RESPONSE_LENGTH);
}

export function vehicleTeleportDistance(expected, actual) {
  const dx = finiteCoordinate(actual.worldX, '实际X坐标') - finiteCoordinate(expected.worldX, '目标X坐标');
  const dy = finiteCoordinate(actual.worldY, '实际Y坐标') - finiteCoordinate(expected.worldY, '目标Y坐标');
  const vertical = Math.abs(finiteCoordinate(actual.worldZ, '实际Z坐标') - finiteCoordinate(expected.worldZ, '目标Z坐标'));
  return { horizontal: Math.hypot(dx, dy), vertical };
}

export class VehicleTeleportVerificationService {
  constructor({ db, clients, logger, leaseToken = () => `${Date.now()}-${randomUUID()}` } = {}) {
    this.db = db;
    this.clients = clients;
    this.logger = logger;
    this.leaseToken = leaseToken;
  }

  async claimDue() {
    return this.db.transaction(async (tx) => {
      const due = rows(await tx.query(
        "SELECT `记录编号` AS id,`执行状态` AS status,`游戏目标编号` AS vehicleEntityId,`载具目标X` AS expectedX,`载具目标Y` AS expectedY,`载具目标Z` AS expectedZ,`载具复核次数` AS attempts FROM `传送执行记录` WHERE `执行状态` IN (?,?) AND `载具下次复核时间`<=CURRENT_TIMESTAMP(3) AND (`载具复核租约时间` IS NULL OR `载具复核租约时间`<DATE_SUB(CURRENT_TIMESTAMP(3),INTERVAL 5 MINUTE)) ORDER BY `载具下次复核时间`,`记录编号` LIMIT 1 FOR UPDATE SKIP LOCKED",
        [LEGACY_PENDING_STATUS, COMPLETED_STATUS]
      ))[0];
      if (!due) return null;
      const status = String(due.status || '');
      if (!AUDITABLE_STATUSES.has(status)) return null;
      const lease = this.leaseToken();
      const claimed = await tx.query(
        "UPDATE `传送执行记录` SET `载具复核租约时间`=CURRENT_TIMESTAMP(3),`载具复核响应`=? WHERE `记录编号`=? AND `执行状态`=? AND (`载具复核租约时间` IS NULL OR `载具复核租约时间`<DATE_SUB(CURRENT_TIMESTAMP(3),INTERVAL 5 MINUTE))",
        [`lease:${lease}`, due.id, status]
      );
      if (Number(claimed?.affectedRows) !== 1) return null;
      return {
        id: Number(due.id),
        status,
        vehicleEntityId: due.vehicleEntityId,
        expected: { worldX: due.expectedX, worldY: due.expectedY, worldZ: due.expectedZ },
        attempts: Math.max(0, Number(due.attempts || 0)),
        lease
      };
    });
  }

  async finish(task, { outcome, response }) {
    const nextAttempt = task.attempts + 1;
    const verified = outcome === 'matched';
    const auditResponse = `audit_status=${outcome}\n${response}`.slice(0, MAX_RESPONSE_LENGTH);
    let sql;
    if (verified && task.status === LEGACY_PENDING_STATUS) {
      sql = "UPDATE `传送执行记录` SET `执行状态`='verified',`载具复核次数`=?,`载具下次复核时间`=NULL,`载具复核响应`=?,`载具复核租约时间`=NULL WHERE `记录编号`=? AND `执行状态`=? AND `载具复核响应`=?";
    } else if (verified) {
      sql = "UPDATE `传送执行记录` SET `载具复核次数`=?,`载具下次复核时间`=NULL,`载具复核响应`=?,`载具复核租约时间`=NULL WHERE `记录编号`=? AND `执行状态`=? AND `载具复核响应`=?";
    } else if ((outcome === 'query_error' || outcome === 'live_inconclusive') && nextAttempt < MAX_INCONCLUSIVE_ATTEMPTS) {
      sql = "UPDATE `传送执行记录` SET `载具复核次数`=?,`载具下次复核时间`=DATE_ADD(CURRENT_TIMESTAMP(3),INTERVAL 60 SECOND),`载具复核响应`=?,`载具复核租约时间`=NULL WHERE `记录编号`=? AND `执行状态`=? AND `载具复核响应`=?";
    } else if (nextAttempt < 2) {
      sql = "UPDATE `传送执行记录` SET `载具复核次数`=?,`载具下次复核时间`=DATE_ADD(CURRENT_TIMESTAMP(3),INTERVAL 60 SECOND),`载具复核响应`=?,`载具复核租约时间`=NULL WHERE `记录编号`=? AND `执行状态`=? AND `载具复核响应`=?";
    } else if (task.status === LEGACY_PENDING_STATUS) {
      sql = "UPDATE `传送执行记录` SET `执行状态`='manual_review',`载具复核次数`=?,`载具下次复核时间`=NULL,`载具复核响应`=?,`载具复核租约时间`=NULL,`错误代码`='VEHICLE_PERSISTENCE_AUDIT_REVIEW_REQUIRED',`错误信息`='两次复核未能确认载具保存坐标，请人工核查；不得自动再次传送' WHERE `记录编号`=? AND `执行状态`=? AND `载具复核响应`=?";
    } else {
      sql = "UPDATE `传送执行记录` SET `载具复核次数`=?,`载具下次复核时间`=NULL,`载具复核响应`=?,`载具复核租约时间`=NULL WHERE `记录编号`=? AND `执行状态`=? AND `载具复核响应`=?";
    }
    const result = await this.db.query(sql, [nextAttempt, auditResponse, task.id, task.status, `lease:${task.lease}`]);
    return Number(result?.affectedRows) === 1;
  }

  async verify(task) {
    let outcome = 'query_error';
    let response;
    let distance = null;
    try {
      const id = entityId(task.vehicleEntityId);
      const expected = {
        worldX: finiteCoordinate(task.expected.worldX, '目标X坐标'),
        worldY: finiteCoordinate(task.expected.worldY, '目标Y坐标'),
        worldZ: finiteCoordinate(task.expected.worldZ, '目标Z坐标')
      };
      const { ggcon } = await this.clients();
      if (!ggcon || typeof ggcon.command !== 'function') throw Object.assign(new Error('RCON载具位置查询能力不可用'), { code: 'RCON_COMMAND_UNAVAILABLE' });
      const result = await ggcon.command(`QueryVehicleLocation ${id}`, { retry: false, priority: 'high', skipHealth: true });
      response = rawResponse(result);
      const actual = parseVehicleLocation(result, id);
      distance = vehicleTeleportDistance(expected, actual);
      if (distance.horizontal <= POSITION_TOLERANCE_WORLD_UNITS && distance.vertical <= POSITION_TOLERANCE_WORLD_UNITS) outcome = 'matched';
      else outcome = actual.realtime ? 'live_inconclusive' : 'saved_mismatch';
    } catch (error) {
      response = `ERROR: ${safeText(error?.code || error?.name || 'VEHICLE_LOCATION_QUERY_FAILED')} ${safeText(error?.message)}`.slice(0, MAX_RESPONSE_LENGTH);
      this.logger?.warn?.('载具传送持久化复核失败', { component: 'vehicle-teleport-verification', operationId: task.id, errorCode: error?.code || error?.name || 'VEHICLE_LOCATION_QUERY_FAILED' });
    }
    const verified = outcome === 'matched';
    const committed = await this.finish(task, { outcome, response });
    return { id: task.id, attempt: task.attempts + 1, outcome, verified, committed, distance };
  }

  async processOne() {
    const task = await this.claimDue();
    return task ? this.verify(task) : null;
  }

  async processDue({ limit = 20 } = {}) {
    const maximum = Math.max(1, Math.min(100, Number(limit) || 20));
    const results = [];
    while (results.length < maximum) {
      const result = await this.processOne();
      if (!result) break;
      results.push(result);
    }
    return { processed: results.length, verified: results.filter((item) => item.verified && item.committed).length, results };
  }
}

export const vehicleTeleportVerificationConstants = Object.freeze({
  pendingStatus: LEGACY_PENDING_STATUS,
  completedStatus: COMPLETED_STATUS,
  leaseTimeoutMinutes: LEASE_TIMEOUT_MINUTES,
  secondAttemptDelaySeconds: SECOND_ATTEMPT_DELAY_SECONDS,
  maxInconclusiveAttempts: MAX_INCONCLUSIVE_ATTEMPTS,
  positionToleranceWorldUnits: POSITION_TOLERANCE_WORLD_UNITS
});
