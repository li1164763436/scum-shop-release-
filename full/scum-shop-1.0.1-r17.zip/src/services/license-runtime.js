import { assertStartupAllowed } from './license-client.js';

const DEFINITIVE_FAILURES = new Set(['LICENSE_INVALID', 'LICENSE_EXPIRED', 'LICENSE_DISABLED', 'ACCOUNT_DISABLED', 'LICENSE_SIGNATURE_INVALID', 'LICENSE_RESPONSE_REPLAYED', 'LICENSE_RESPONSE_INVALID']);

export class LicenseRuntime {
  constructor({ store, clientFactory, intervalMs = Number(process.env.LICENSE_VERIFY_INTERVAL_MS) || 30000, onInvalid } = {}) {
    this.store = store;
    this.clientFactory = clientFactory;
    this.intervalMs = intervalMs;
    this.onInvalid = onInvalid;
    this.timer = null;
    this.checking = false;
    this.invalid = false;
  }

  async checkNow() {
    if (this.checking || this.invalid) return false;
    this.checking = true;
    try {
      await assertStartupAllowed({ store: this.store, clientFactory: this.clientFactory });
      return true;
    } catch (error) {
      if (!DEFINITIVE_FAILURES.has(error?.code)) return true;
      this.invalid = true;
      await this.onInvalid?.(error);
      return false;
    } finally {
      this.checking = false;
    }
  }

  start() {
    if (this.timer) return;
    this.timer = setInterval(() => { void this.checkNow(); }, this.intervalMs);
    this.timer.unref?.();
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }
}
