import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { randomBytes } from 'node:crypto';
export function createRuntimeHost({ host = '0.0.0.0', port = 3090, root = null, appVersion = null, releaseRevision = 0 } = {}) {
  let businessPort = null, licensePort = null, failure = null, degraded = [];
  const readErrorFile = (relative, fallback = '') => {
    try { return root ? fs.readFileSync(path.join(root, relative)) : Buffer.from(fallback, 'utf8'); }
    catch { return Buffer.from(fallback, 'utf8'); }
  };
  const servicePage = readErrorFile(path.join('public', 'shop', 'pages', 'errors', 'service-unavailable', 'index.html'), '<!doctype html><meta charset="utf-8"><title>商城暂时离线</title><h1>商城业务暂时不可用</h1><p>系统正在自动重试，请稍后刷新。</p>');
  const errorAssets = new Map([
    ['/shop/css/errors.css', { type: 'text/css; charset=utf-8', body: readErrorFile(path.join('public', 'shop', 'css', 'errors.css')) }],
    ['/shop/js/errors.js', { type: 'text/javascript; charset=utf-8', body: readErrorFile(path.join('public', 'shop', 'js', 'errors.js')) }]
  ]);
  const token = randomBytes(32).toString('hex');
  const local = req => {
    try { return ['127.0.0.1','::1','::ffff:127.0.0.1'].includes(req.socket.remoteAddress) && ['127.0.0.1','localhost','[::1]'].includes(new URL('http://' + req.headers.host).hostname); }
    catch { return false; }
  };
  const json = (res, code, data) => { res.writeHead(code, {'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify(data)); };
  const proxy = (req,res,target,license=false) => {
    const headers={...req.headers};
    if(license){if(!local(req))return json(res,403,{success:false});if(req.method!=='GET'&&req.headers.origin!=='http://'+req.headers.host)return json(res,403,{success:false});headers.host='127.0.0.1:'+target;if(headers.origin)headers.origin='http://127.0.0.1:'+target;}
    const upstream=http.request({hostname:'127.0.0.1',port:target,path:req.url,method:req.method,headers},response=>{res.writeHead(response.statusCode,response.headers);response.pipe(res);});
    upstream.on('error',()=>{if(!res.headersSent)json(res,503,{success:false,message:'商城业务暂不可用，主体仍在运行'});else res.destroy();});req.on('aborted',()=>upstream.destroy());req.pipe(upstream);
  };
  const api={retry:async()=>{},backups:null,publicAccess:()=>({url:null,kind:null}),get ready(){return businessPort!==null;},attach(value,issues=[]){businessPort=value;failure=null;degraded=Array.isArray(issues)?issues:[];},detach(){businessPort=null;degraded=[];},attachLicense(value){licensePort=value;},detachLicense(){licensePort=null;},fail(error){businessPort=null;degraded=[];failure={code:String(error?.code||'BUSINESS_START_FAILED')};},listen:()=>new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,host,resolve);}),close:()=>new Promise(resolve=>server.close(resolve)),server:null};
  const server=http.createServer(async(req,res)=>{
    const pathname=new URL(req.url,'http://localhost').pathname;
    try{
      if(pathname==='/api/runtime/status'){if(!local(req))return json(res,403,{success:false});return json(res,200,{success:true,data:{subject:'running',business:api.ready?(degraded.length?'degraded':'ready'):'unavailable',degraded,failure,backup:api.backups?.status()||null}});}
      if(pathname==='/api/runtime/public-access'){if(!local(req))return json(res,403,{success:false});return json(res,200,{success:true,data:await api.publicAccess()});}
      if(pathname==='/runtime'&&req.method==='GET'){if(!local(req))return json(res,403,{success:false});res.writeHead(200,{'content-type':'text/html; charset=utf-8','cache-control':'no-store','x-frame-options':'DENY'});return res.end(runtimePage(token));}
      if(pathname.startsWith('/api/runtime/')){
        if(!local(req)||req.method!=='POST'||req.headers.origin!=='http://'+req.headers.host||req.headers['x-runtime-token']!==token)return json(res,403,{success:false,message:'本机操作校验失败'});
        let body='';for await(const chunk of req){body+=chunk;if(body.length>4096)return json(res,413,{success:false});}const input=body?JSON.parse(body):{};
        if(pathname==='/api/runtime/retry'){if(api.backups?.restoring)return json(res,409,{success:false,message:'数据库恢复中'});await api.retry();}
        else if(pathname==='/api/runtime/backup')await api.backups.backup();
        else if(pathname==='/api/runtime/shutdown')api.shutdown();
        else if(pathname==='/api/runtime/restore'){if(api.ready||input.confirm!=='恢复选定备份')return json(res,409,{success:false,message:'请先停止商城业务并确认恢复'});if(!/^backup-[0-9T-]+\.json$/.test(String(input.backupManifest||'')))return json(res,400,{success:false,message:'请选择有效数据库备份'});await api.backups.restoreBackup(String(input.backupManifest));}
        else return json(res,404,{success:false});return json(res,200,{success:true});
      }
      if(businessPort)return proxy(req,res,businessPort);
      if(pathname==='/api/health')return json(res,200,{success:true,data:{subject:'running',business:'unavailable',...(appVersion&&failure?.code==='ECONNREFUSED'?{version:appVersion,releaseRevision}: {})}});
      if(licensePort)return proxy(req,res,licensePort,true);
      if(pathname.startsWith('/api/'))return json(res,503,{success:false,code:'BUSINESS_UNAVAILABLE',message:'数据库或商城业务未就绪，主体保持运行'});
      const asset=errorAssets.get(pathname);
      if(asset&&['GET','HEAD'].includes(req.method)){res.writeHead(200,{'content-type':asset.type,'cache-control':'no-store'});return res.end(req.method==='HEAD'?undefined:asset.body);}
      res.writeHead(503,{'content-type':'text/html; charset=utf-8','cache-control':'no-store','retry-after':'5'});res.end(req.method==='HEAD'?undefined:servicePage);
    }catch{if(!res.headersSent)json(res,500,{success:false,message:'操作失败，原数据和备份保留，请检查运行日志'});else res.destroy();}
  });api.server=server;return api;
}
function runtimePage(token){
 return '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>商城运行主体</title><style>body{font:15px system-ui;background:#f3f6fb;color:#26334a;max-width:860px;margin:40px auto;padding:20px}section{background:white;border:1px solid #dbe3ee;padding:24px;border-radius:12px}button,input{padding:10px;margin:6px;border:1px solid #c5d2e4;border-radius:6px}pre{white-space:pre-wrap}</style><section><h2>商城运行主体</h2><p>软件授权、数据库备份恢复独立于商城业务。仅本机可操作。</p><pre id="status">正在读取状态</pre><button data-action="retry">重试商城业务</button><button data-action="stop-business">停止商城业务</button><button data-action="backup">立即备份</button><h3>数据库恢复</h3><p>请在 Windows 启动器的“备份 / 恢复”窗口中选择具体备份时间。</p><p id="message"></p></section><script>const token='+JSON.stringify(token)+',status=document.querySelector("#status"),message=document.querySelector("#message");async function refresh(){const r=await fetch("/api/runtime/status",{cache:"no-store"}),b=await r.json();const d=b.data;status.textContent="主体：运行中\n商城业务："+(d.business==="ready"?"正常":d.business==="degraded"?"降级":"未就绪")+"\n故障代码："+(d.failure?.code||"无")+"\n最近有效备份："+(d.backup?.latestAt||"暂无")+"\n备份状态："+(d.backup?.running?"执行中":d.backup?.error||"空闲")}document.addEventListener("click",async e=>{const button=e.target.closest("[data-action]");if(!button)return;const action=button.dataset.action;button.disabled=true;message.textContent="正在执行，请勿关闭程序";try{const input={};const r=await fetch("/api/runtime/"+action,{method:"POST",headers:{"content-type":"application/json","x-runtime-token":token},body:JSON.stringify(input)});const b=await r.json();if(!r.ok||!b.success)throw Error(b.message||"操作失败");message.textContent="操作完成";await refresh()}catch(error){message.textContent=error.message}finally{button.disabled=false}});refresh();setInterval(refresh,5000)</script></html>';
}
