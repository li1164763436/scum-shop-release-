import { randomBytes } from 'node:crypto';
import { ServiceError } from './commerce-service.js';

function positiveId(value, name) {
  const id = Number(value);
  if (!Number.isSafeInteger(id) || id < 1) throw new ServiceError(`${name}无效`, 400, 'INVALID_INPUT');
  return id;
}

function requestKeyOf(value, action = '购买') {
  const key = String(value || '').trim();
  if (!key || key.length > 100) throw new ServiceError(`${action}请求编号无效`, 400, 'INVALID_REQUEST_KEY');
  return key;
}

function duplicate(error) { return error?.code === 'ER_DUP_ENTRY' || error?.errno === 1062; }

function uniqueNumber(prefix) {
  const timestamp = new Date().toISOString().replace(/\D/g, '').slice(0, 17);
  return `${prefix}-${timestamp}-${randomBytes(4).toString('hex').toUpperCase()}`;
}

function policyNumber() { return uniqueNumber('VI'); }
function claimNumber() { return uniqueNumber('VIC'); }
function beijingDayRange(now = Date.now()) {
  const day = new Date(now + 8 * 60 * 60 * 1000).toISOString().slice(0, 10);
  const start = new Date(`${day}T00:00:00+08:00`);
  return { start, end: new Date(start.getTime() + 24 * 60 * 60 * 1000) };
}

function numeric(row) {
  if (!row) return row;
  const result = { ...row };
  for (const key of ['id', 'vehicleId', 'strategyId', 'productId', 'purchaseId', 'orderId', 'fulfillmentTaskId', 'sourceVehicleId', 'sourceLockSlots', 'worldX', 'worldY', 'worldZ', 'totalClaimLimit', 'dailyClaimLimit', 'totalClaimsUsed', 'dailyClaimsUsed', 'durationDays', 'price', 'balanceAfter']) {
    if (result[key] !== undefined && result[key] !== null) result[key] = Number(result[key]);
  }
  return result;
}

function normalizedVehicleValue(value) {
  return String(value || '').trim().toLowerCase().replace(/^#spawnvehicle\s+/, '').replace(/^vehicle:/, '');
}
function strategyMatchesVehicle(strategy, vehicle) {
  const expected = [strategy.vehicleCode, strategy.vehicleType].map(normalizedVehicleValue).filter(Boolean);
  const actual = [vehicle.sourceAssetId, vehicle.sourceVehicleAlias, vehicle.vehicleType, vehicle.modelName].map(normalizedVehicleValue).filter(Boolean);
  return expected.some((value) => actual.includes(value));
}

export class VehicleInsuranceShopService {
  constructor({ db, isPlayerOnline = null }) {
    this.db = db;
    this.isPlayerOnline = isPlayerOnline;
  }

  async findPurchase(requestKey, query = this.db) {
    const rows = await query.query('SELECT id,steam_id AS steamId,vehicle_id AS vehicleId,strategy_id AS strategyId,policy_number AS policyNumber,price,balance_after AS balanceAfter,starts_at AS startsAt,expires_at AS expiresAt FROM vehicle_insurance_purchases WHERE request_key=? LIMIT 1', [requestKey]);
    return numeric(rows[0]);
  }

  async findClaim(requestKey, query = this.db) {
    const rows = await query.query('SELECT id,request_key AS requestKey,claim_number AS claimNumber,steam_id AS steamId,purchase_id AS purchaseId,vehicle_id AS vehicleId,old_source_vehicle_id AS sourceVehicleId,strategy_id AS strategyId,vehicle_code AS vehicleCode,total_claim_limit AS totalClaimLimit,daily_claim_limit AS dailyClaimLimit,order_id AS orderId,fulfillment_task_id AS fulfillmentTaskId,created_at AS createdAt FROM vehicle_insurance_claims WHERE request_key=? LIMIT 1', [requestKey]);
    return numeric(rows[0]);
  }

  replay(receipt, owner, strategyId) {
    if (String(receipt.steamId) !== owner || receipt.strategyId !== strategyId) throw new ServiceError('Idempotency-Key 已被其他保险购买请求使用', 409, 'IDEMPOTENCY_CONFLICT');
    return { ...receipt, idempotent: true };
  }

  replayClaim(receipt, owner, vehicleId) {
    if (String(receipt.steamId) !== owner || receipt.vehicleId !== vehicleId) throw new ServiceError('Idempotency-Key 已被其他载具索赔请求使用', 409, 'IDEMPOTENCY_CONFLICT');
    return { ...receipt, idempotent: true };
  }

  async overview(steamId) {
    const owner = String(steamId);
    const [strategies, policies, vehicles, claims, vehicleProducts] = await Promise.all([
      this.db.query("SELECT id,name,total_claim_limit AS totalClaimLimit,daily_claim_limit AS dailyClaimLimit,duration_days AS durationDays,purchase_condition AS purchaseCondition,product_id AS productId,vehicle_type AS vehicleType,vehicle_code AS vehicleCode,price FROM vehicle_insurance_strategies WHERE enabled=1 AND deleted_at IS NULL ORDER BY price ASC,id DESC"),
      this.db.query("SELECT p.id,p.policy_number AS policyNumber,p.strategy_name_snapshot AS strategyName,p.product_id_snapshot AS productId,p.vehicle_type_snapshot AS vehicleType,p.vehicle_code_snapshot AS vehicleCode,p.total_claim_limit_snapshot AS totalClaimLimit,p.daily_claim_limit_snapshot AS dailyClaimLimit,p.purchase_condition_snapshot AS purchaseCondition,p.duration_days_snapshot AS durationDays,p.price,p.starts_at AS startsAt,p.expires_at AS expiresAt,(SELECT COUNT(*) FROM vehicle_insurance_claims c LEFT JOIN fulfillment_tasks t ON t.id=c.fulfillment_task_id WHERE c.purchase_id=p.id AND (t.id IS NULL OR t.status NOT IN ('failed','cancelled'))) AS totalClaimsUsed,(SELECT COUNT(*) FROM vehicle_insurance_claims c LEFT JOIN fulfillment_tasks t ON t.id=c.fulfillment_task_id WHERE c.purchase_id=p.id AND c.created_at>=CURRENT_DATE() AND c.created_at<DATE_ADD(CURRENT_DATE(),INTERVAL 1 DAY) AND (t.id IS NULL OR t.status NOT IN ('failed','cancelled'))) AS dailyClaimsUsed,CASE WHEN p.expires_at<=CURRENT_TIMESTAMP(3) THEN 'expired' ELSE 'active' END AS insuranceStatus FROM vehicle_insurance_purchases p WHERE p.steam_id=? AND p.cancelled_at IS NULL ORDER BY p.created_at DESC,p.id DESC", [owner]),
      this.db.query("SELECT `载具档案编号` AS vehicleId,`载具档案编码` AS vehicleCode,`载具类型` AS vehicleType,`型号名称` AS modelName,`显示名称` AS displayName,`来源载具编号` AS sourceVehicleId,`来源资产标识` AS sourceAssetId,`来源载具别名` AS sourceVehicleAlias,`来源锁槽数量` AS sourceLockSlots,`地图格编号` AS gridCode,`世界X坐标` AS worldX,`世界Y坐标` AS worldY,`世界Z坐标` AS worldZ,`位置来源` AS locationSource,`最后观测时间` AS lastSeenAt,`来源同步时间` AS sourceSynchronizedAt FROM `载具档案` WHERE `车主SteamID`=? AND `来源类型`='scum_locked_vehicle' AND `来源同步状态`='present' AND `来源锁槽数量`>0 AND `档案状态` NOT IN ('destroyed','retired') ORDER BY `来源同步时间` DESC,`载具档案编号` DESC", [owner]),
      this.db.query("SELECT c.id,c.claim_number AS claimNumber,c.purchase_id AS purchaseId,c.vehicle_id AS vehicleId,c.old_source_vehicle_id AS sourceVehicleId,c.vehicle_code AS vehicleCode,c.created_at AS createdAt,t.status AS fulfillmentStatus,t.last_error AS lastError FROM vehicle_insurance_claims c LEFT JOIN fulfillment_tasks t ON t.id=c.fulfillment_task_id WHERE c.steam_id=? ORDER BY c.created_at DESC,c.id DESC", [owner]),
      this.db.query("SELECT id AS productId,name,item_id AS itemId,fulfillment_codes AS fulfillmentCodes,image_path AS imagePath FROM products WHERE parent_category='载具交通' AND category_name='载具' ORDER BY enabled DESC,id DESC")
    ]);
    return { strategies: strategies.map(numeric), policies: policies.map(numeric), vehicles: vehicles.map(numeric), claims: claims.map(numeric), vehicleProducts };
  }

  async purchase(steamId, input = {}, headerKey = '') {
    const owner = String(steamId);
    const strategyId = positiveId(input.strategyId, '保险策略');
    const requestKey = requestKeyOf(headerKey || input.requestKey);
    const prior = await this.findPurchase(requestKey);
    if (prior) return { receipt: this.replay(prior, owner, strategyId), ...(await this.overview(owner)) };
    let receipt;
    try {
      receipt = await this.db.transaction(async (tx) => {
        const repeated = await this.findPurchase(requestKey, tx);
        if (repeated) return this.replay(repeated, owner, strategyId);
        const strategies = await tx.query('SELECT id,name,total_claim_limit AS totalClaimLimit,daily_claim_limit AS dailyClaimLimit,duration_days AS durationDays,purchase_condition AS purchaseCondition,product_id AS productId,vehicle_type AS vehicleType,vehicle_code AS vehicleCode,price FROM vehicle_insurance_strategies WHERE id=? AND enabled=1 AND deleted_at IS NULL FOR UPDATE', [strategyId]);
        const strategy = numeric(strategies[0]);
        if (!strategy) throw new ServiceError('保险销售策略不存在或已停止销售', 404, 'INSURANCE_STRATEGY_UNAVAILABLE');
        const activePolicies = await tx.query('SELECT id,expires_at AS expiresAt FROM vehicle_insurance_purchases WHERE steam_id=? AND vehicle_code_snapshot=? AND cancelled_at IS NULL AND expires_at>CURRENT_TIMESTAMP(3) ORDER BY expires_at DESC,id DESC LIMIT 1 FOR UPDATE', [owner, strategy.vehicleCode]);
        if (activePolicies[0]) throw new ServiceError('当前保险尚未到期，暂不能续保', 409, 'INSURANCE_ALREADY_ACTIVE');
        const accounts = await tx.query('SELECT \`商城币余额\` AS balance FROM \`商城用户\` WHERE \`SteamID\`=? FOR UPDATE', [owner]);
        if (!accounts[0]) throw new ServiceError('商城账户不存在', 404, 'ACCOUNT_NOT_FOUND');
        const balance = Number(accounts[0].balance || 0);
        if (balance < strategy.price) throw new ServiceError('商城币余额不足', 409, 'INSUFFICIENT_BALANCE');
        const balanceAfter = balance - strategy.price;
        const number = policyNumber();
        await tx.query('UPDATE \`商城用户\` SET \`商城币余额\`=? WHERE \`SteamID\`=?', [balanceAfter, owner]);
        const inserted = await tx.query('INSERT INTO vehicle_insurance_purchases (request_key,steam_id,vehicle_id,strategy_id,strategy_name_snapshot,product_id_snapshot,vehicle_type_snapshot,vehicle_code_snapshot,total_claim_limit_snapshot,daily_claim_limit_snapshot,purchase_condition_snapshot,duration_days_snapshot,policy_number,price,balance_after,starts_at,expires_at) VALUES (?,?,NULL,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP(3),DATE_ADD(CURRENT_TIMESTAMP(3),INTERVAL ? DAY))', [requestKey, owner, strategyId, strategy.name, strategy.productId || null, strategy.vehicleType, strategy.vehicleCode, strategy.totalClaimLimit, strategy.dailyClaimLimit, strategy.purchaseCondition || '', strategy.durationDays, number, strategy.price, balanceAfter, strategy.durationDays]);
        await tx.query("INSERT INTO coin_ledger (steam_id,amount,balance_after,type,reference_type,reference_id,note) VALUES (?,?,?,'vehicle_insurance_purchase','vehicle_insurance_purchase',?,?)", [owner, -strategy.price, balanceAfter, String(inserted.insertId), `购买载具保险：${strategy.name}`]);
        const rows = await tx.query('SELECT id,steam_id AS steamId,vehicle_id AS vehicleId,strategy_id AS strategyId,policy_number AS policyNumber,price,balance_after AS balanceAfter,starts_at AS startsAt,expires_at AS expiresAt FROM vehicle_insurance_purchases WHERE id=?', [inserted.insertId]);
        return { ...numeric(rows[0]), idempotent: false };
      });
    } catch (error) {
      if (!duplicate(error)) throw error;
      const repeated = await this.findPurchase(requestKey);
      if (!repeated) throw error;
      receipt = this.replay(repeated, owner, strategyId);
    }
    return { receipt, ...(await this.overview(owner)) };
  }

  async claim(steamId, input = {}, headerKey = '') {
    const owner = String(steamId);
    const vehicleId = positiveId(input.vehicleId, '索赔载具');
    const requestKey = requestKeyOf(headerKey || input.requestKey, '索赔');
    const prior = await this.findClaim(requestKey);
    if (prior) return { claim: this.replayClaim(prior, owner, vehicleId), ...(await this.overview(owner)) };
    if (this.isPlayerOnline && !(await this.isPlayerOnline(owner))) throw new ServiceError('索赔失败：玩家当前不在线，请进入游戏后重试', 409, 'PLAYER_OFFLINE');
    let claim;
    try {
      claim = await this.db.transaction(async (tx) => {
        const repeated = await this.findClaim(requestKey, tx);
        if (repeated) return this.replayClaim(repeated, owner, vehicleId);
        const vehicleRows = await tx.query("SELECT `载具档案编号` AS vehicleId,`载具类型` AS vehicleType,`型号名称` AS modelName,`来源载具编号` AS sourceVehicleId,`来源资产标识` AS sourceAssetId,`来源载具别名` AS sourceVehicleAlias,`来源锁槽数量` AS sourceLockSlots FROM `载具档案` WHERE `载具档案编号`=? AND `车主SteamID`=? AND `来源类型`='scum_locked_vehicle' AND `来源同步状态`='present' AND `来源锁槽数量`>0 AND `档案状态` NOT IN ('destroyed','retired') FOR UPDATE", [vehicleId, owner]);
        const vehicle = numeric(vehicleRows[0]);
        if (!vehicle) throw new ServiceError('载具不存在、未上锁或不属于当前玩家', 404, 'INSURANCE_CLAIM_VEHICLE_UNAVAILABLE');
        const existingClaims = await tx.query("SELECT c.id,t.status AS fulfillmentStatus FROM vehicle_insurance_claims c LEFT JOIN fulfillment_tasks t ON t.id=c.fulfillment_task_id WHERE c.vehicle_id=? AND (t.id IS NULL OR t.status NOT IN ('failed','cancelled')) LIMIT 1", [vehicleId]);
        if (existingClaims[0]) throw new ServiceError('该载具已经提交过索赔，请等待赔付完成', 409, 'INSURANCE_CLAIM_ALREADY_EXISTS');
        const policies = (await tx.query("SELECT p.id AS purchaseId,p.strategy_id AS strategyId,p.policy_number AS policyNumber,p.starts_at AS startsAt,p.expires_at AS expiresAt,p.product_id_snapshot AS productId,p.strategy_name_snapshot AS strategyName,p.vehicle_type_snapshot AS vehicleType,p.vehicle_code_snapshot AS vehicleCode,p.total_claim_limit_snapshot AS totalClaimLimit,p.daily_claim_limit_snapshot AS dailyClaimLimit FROM vehicle_insurance_purchases p WHERE p.steam_id=? AND p.cancelled_at IS NULL AND p.starts_at<=CURRENT_TIMESTAMP(3) AND p.expires_at>CURRENT_TIMESTAMP(3) ORDER BY p.expires_at ASC,p.id ASC FOR UPDATE", [owner])).map(numeric);
        const matching = policies.filter((policy) => strategyMatchesVehicle(policy, vehicle));
        if (!matching.length) throw new ServiceError('没有适用于该载具的有效保险保单', 409, 'INSURANCE_CLAIM_NO_POLICY');
        let selected = null;
        const day = beijingDayRange();
        for (const policy of matching) {
          const usageRows = await tx.query("SELECT COUNT(*) AS totalClaimsUsed,COALESCE(SUM(CASE WHEN c.created_at>=? AND c.created_at<? THEN 1 ELSE 0 END),0) AS dailyClaimsUsed FROM vehicle_insurance_claims c LEFT JOIN fulfillment_tasks t ON t.id=c.fulfillment_task_id WHERE c.purchase_id=? AND (t.id IS NULL OR t.status NOT IN ('failed','cancelled'))", [day.start, day.end, policy.purchaseId]);
          const usage = numeric(usageRows[0] || { totalClaimsUsed: 0, dailyClaimsUsed: 0 });
          if (usage.totalClaimsUsed < policy.totalClaimLimit && usage.dailyClaimsUsed < policy.dailyClaimLimit) { selected = { ...policy, ...usage }; break; }
        }
        if (!selected) throw new ServiceError('该载具保险的今日或累计索赔次数已用完', 409, 'INSURANCE_CLAIM_LIMIT_REACHED');
        const number = claimNumber();
        const orderNo = uniqueNumber('VIC-ORDER');
        const order = await tx.query("INSERT INTO orders (order_no,source,external_order_id,steam_id,total_amount,status) VALUES (?,'vehicle_insurance_claim',?,?,0,'pending')", [orderNo, requestKey, owner]);
        const item = await tx.query("INSERT INTO order_items (order_id,product_id,sku,name,unit_price,quantity,item_id,grant_amount,parent_category,category_name,currency_type,min_member_level,fulfillment_codes_snapshot) VALUES (?,?,?,?,0,1,?,1,'载具交通','载具','gift',0,?)", [order.insertId, selected.productId || null, number, `保险索赔：${selected.strategyName}`, selected.vehicleCode, JSON.stringify([{ actionType: 'vehicle_insurance_claim', itemId: selected.vehicleCode, quantity: 1, oldVehicleId: vehicle.sourceVehicleId, vehicleId: vehicle.vehicleId }])]);
        const payload = { actionType: 'vehicle_insurance_claim', itemId: selected.vehicleCode, quantity: 1, oldVehicleId: vehicle.sourceVehicleId, vehicleId: vehicle.vehicleId };
        const task = await tx.query("INSERT INTO fulfillment_tasks (order_id,order_item_id,code_index,generation,request_key,steam_id,task_type,payload_json,item_id,amount,status,next_attempt_at) VALUES (?,?,0,0,?,?,?, ?,?,1,'pending',CURRENT_TIMESTAMP(3))", [order.insertId, item.insertId, `VIC-${number}`, owner, 'vehicle_insurance_claim', JSON.stringify(payload), selected.vehicleCode]);
        const inserted = await tx.query('INSERT INTO vehicle_insurance_claims (request_key,claim_number,steam_id,purchase_id,vehicle_id,old_source_vehicle_id,strategy_id,vehicle_code,total_claim_limit,daily_claim_limit,order_id,fulfillment_task_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', [requestKey, number, owner, selected.purchaseId, vehicleId, vehicle.sourceVehicleId, selected.strategyId, selected.vehicleCode, selected.totalClaimLimit, selected.dailyClaimLimit, order.insertId, task.insertId]);
        const rows = await tx.query('SELECT id,request_key AS requestKey,claim_number AS claimNumber,steam_id AS steamId,purchase_id AS purchaseId,vehicle_id AS vehicleId,old_source_vehicle_id AS sourceVehicleId,strategy_id AS strategyId,vehicle_code AS vehicleCode,total_claim_limit AS totalClaimLimit,daily_claim_limit AS dailyClaimLimit,order_id AS orderId,fulfillment_task_id AS fulfillmentTaskId,created_at AS createdAt FROM vehicle_insurance_claims WHERE id=?', [inserted.insertId]);
        return { ...numeric(rows[0]), idempotent: false, fulfillmentStatus: 'pending' };
      });
    } catch (error) {
      if (!duplicate(error)) throw error;
      const repeated = await this.findClaim(requestKey);
      if (!repeated) throw error;
      claim = this.replayClaim(repeated, owner, vehicleId);
    }
    return { claim, ...(await this.overview(owner)) };
  }
}
