import { joinUrl, requestWithPolicy } from './http.js';
import { isScumInstance, normalizeScumInstance } from './scum.js';

export class Gsm3Client {
  constructor(config, reconnect) {
    this.config = config;
    this.reconnect = reconnect;
  }

  headers() {
    return { 'X-API-Key': this.config.apiKey, Accept: 'application/json' };
  }

  async get(path) {
    const response = await requestWithPolicy({ method: 'get', url: joinUrl(this.config.baseUrl, path), headers: this.headers(), timeout: this.config.timeoutMs }, this.reconnect);
    return response.data;
  }

  async health() {
    try {
      return await this.get('/health');
    } catch (error) {
      if (error?.response?.status !== 404) throw error;
      return this.get('/system/status');
    }
  }

  async instanceStatus(instanceId) {
    const result = await this.get(`/instances/${encodeURIComponent(instanceId)}/status`);
    const data = result?.data && typeof result.data === 'object' ? result.data : result;
    return String(data?.status ?? data?.state ?? 'unknown').toLowerCase();
  }

  async instances() {
    const result = await this.get('/instances');
    const instances = Array.isArray(result) ? result : (result.data || result.instances || []);
    const scum = instances.filter(isScumInstance);
    return Promise.all(scum.map(async (instance) => {
      const id = instance.id ?? instance.instanceId ?? instance.uuid;
      let status = {};
      if (id !== undefined) status = await this.get(`/instances/${encodeURIComponent(id)}/status`);
      return normalizeScumInstance(instance, status);
    }));
  }
}
