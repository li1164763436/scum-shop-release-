import fs from 'node:fs';
import path from 'node:path';
import { DEFAULT_TELEPORT_MAP_PROFILE, evaluateTeleportAffineCalibration, solveTeleportAffineCalibration } from '../src/services/teleport-map-service.js';

function fail(message) {
  console.error(message);
  process.exitCode = 1;
}

const inputFile = process.argv[2];
const outputFile = process.argv[3] || path.join(import.meta.dirname, '..', 'data', 'teleport-map-calibration.json');
if (!inputFile) {
  fail('用法：node scripts/calibrate-teleport-map.js <实测点.json> [输出.json]');
} else {
  try {
    const input = JSON.parse(fs.readFileSync(path.resolve(inputFile), 'utf8').replace(/^\uFEFF/, ''));
    const calibrationPoints = input.calibrationPoints || input.points;
    if (!Array.isArray(calibrationPoints) || calibrationPoints.length < 5) throw new Error('正式校准至少需要5个分散实测点');
    let solved;
    if (input.affine && typeof input.affine === 'object') {
      const affine = {};
      for (const key of ['a', 'b', 'c', 'd', 'e', 'f']) {
        affine[key] = Number(input.affine[key]);
        if (!Number.isFinite(affine[key])) throw new Error(`预设仿射参数 ${key} 无效`);
      }
      solved = { affine, ...evaluateTeleportAffineCalibration(affine, calibrationPoints) };
    } else {
      solved = solveTeleportAffineCalibration(calibrationPoints);
    }
    const validationPoints = Array.isArray(input.validationPoints) ? input.validationPoints : [];
    const validation = validationPoints.length ? evaluateTeleportAffineCalibration(solved.affine, validationPoints) : null;
    const verified = Boolean(validation && validation.pointCount >= 10 && validation.averageMeterError <= 20 && validation.maximumMeterError <= 50);
    const profile = {
      ...DEFAULT_TELEPORT_MAP_PROFILE,
      id: String(input.id || 'scum-map-ultra-affine-v1'),
      mapVersion: String(input.mapVersion || DEFAULT_TELEPORT_MAP_PROFILE.mapVersion),
      calibrationMethod: 'affine',
      calibratedAt: new Date().toISOString(),
      verified,
      affine: solved.affine,
      pointCount: solved.pointCount,
      averagePixelError: solved.averagePixelError,
      maximumPixelError: solved.maximumPixelError,
      validation
    };
    fs.mkdirSync(path.dirname(path.resolve(outputFile)), { recursive: true });
    fs.writeFileSync(path.resolve(outputFile), `${JSON.stringify(profile, null, 2)}\n`, 'utf8');
    console.log(JSON.stringify({ outputFile: path.resolve(outputFile), verified, calibration: solved, validation }, null, 2));
    if (!verified) console.warn('校准文件已生成但仍未验证：需要至少10个独立验证点，平均误差≤20米且最大误差≤50米。');
  } catch (error) {
    fail(`传送地图校准失败：${error.message}`);
  }
}
