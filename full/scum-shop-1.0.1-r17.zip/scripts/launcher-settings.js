import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { ConfigStore } from '../src/services/config-store.js';
import { createDatabase } from '../src/services/database.js';
import { ensureSchema } from '../src/services/schema.js';
import { assertStartupAllowed, authenticateLicenseAccount } from '../src/services/license-client.js';
import { LicenseStore } from '../src/services/license-store.js';
import { SourceRconClient } from '../src/services/source-rcon-client.js';
import { discoverScumServer } from '../src/services/scum-server-discovery.js';
import { RconPluginService } from '../src/services/rcon-plugin-service.js';
import { createInitialSuperAdmin } from './promote-super-admin.js';
import { assertInitialSuperAdminBinding, hasInitialSuperAdmin, recoverLegacySuperAdmin } from '../src/services/initial-super-admin-service.js';
import mysql from 'mysql2/promise';

function startPluginSyncWorker(root) {
  const child = spawn(process.execPath, [path.join(root, 'scripts', 'rcon-plugin-sync-worker.js')], { cwd: root, detached: true, windowsHide: true, stdio: 'ignore' });
  child.unref();
}

export async function applyLauncherSettings(input, { store, openDatabase, verifyLicense, authenticateLicense, initializeDatabase = ensureSchema, discoverServer = discoverScumServer, pluginService, launchPluginWorker } = {}) {
  if (input.operation === 'read') {
    const config = await store.read();
    const db = await openDatabase(config.mysql);
    try {
      await initializeDatabase(db);
      const admins = await db.query("SELECT `商城用户编号` AS id FROM `商城用户` WHERE `用户角色` = 'super_admin' AND `账户状态` = 'active' LIMIT 2");
      const bindings = await db.query("SELECT b.`绑定编号` AS id,b.`绑定状态` AS bindingStatus,u.`用户角色` AS role,u.`账户状态` AS userStatus FROM `授权账号绑定` b LEFT JOIN `商城用户` u ON u.`商城用户编号`=b.`商城用户编号` LIMIT 2");
      const configured = bindings.length === 1 && bindings[0].bindingStatus === 'active' && bindings[0].role === 'super_admin' && bindings[0].userStatus === 'active';
      const initialAdminRequired = bindings.length === 0 && admins.length === 0;
      const legacyRecoveryRequired = bindings.length === 0 && admins.length === 1;
      const publicRcon = store.sanitize(config).ggcon;
      const pluginSync = pluginService ? await pluginService.status() : { status: 'idle' };
      return { ...publicRcon, pluginSyncRecommended: !Boolean(publicRcon.hasServerDirectory || publicRcon.gameDirectory), pluginSync, initialAdminConfigured: configured, initialAdminRequired, legacyRecoveryRequired, bindingConfigurationInvalid: !configured && !initialAdminRequired && !legacyRecoveryRequired };
    } finally { await db.close(); }
  }
  if (input.operation === 'discover-scum-server') {
    const found = await discoverServer({ configuredDirectory: String(input.serverDirectory || '').trim() });
    return { ...found, message: `已找到 SCUM 服务器启动器：${found.executable}` };
  }
  if (['save-rcon', 'test-rcon'].includes(input.operation)) {
    const host = String(input.host || '').trim();
    const port = Number(input.port);
    const serverDirectory = String(input.serverDirectory || '').trim();
    if (!host || host.length > 255 || /[\s/\\]/.test(host)) throw new Error('RCON 地址无效');
    if (port !== 28015) throw new Error('RCON 端口必须固定为 28015');
    const config = await store.read();
    const password = String(input.password || '') || (config.ggcon.mode === 'source-tcp' ? config.ggcon.password : '');
    if (!password || password.length > 500) throw new Error('请填写 RCON 密码');
    if (input.operation === 'save-rcon' && !serverDirectory) throw new Error('请选择 SCUM 服务器根目录，或使用自动搜索');
    if (typeof verifyLicense !== 'function' || typeof openDatabase !== 'function') throw new Error('无法验证首装授权绑定状态');
    const identity = await verifyLicense();
    const db = await openDatabase(config.mysql);
    try {
      await initializeDatabase(db);
      if (!(await hasInitialSuperAdmin(db))) throw new Error('请先完成授权账号、许可证、商城超级管理员和 SteamID 的固定绑定');
      await assertInitialSuperAdminBinding(db, identity, { allowLegacy: false });
    } finally { await db.close(); }
    let resolvedServerDirectory = serverDirectory;
    if (input.operation === 'save-rcon') resolvedServerDirectory = (await discoverServer({ configuredDirectory: serverDirectory, configuredOnly: true })).serverDirectory;
    const ggcon = { mode: 'source-tcp', discoveryMode: 'manual', host, port, password, serverDirectory: resolvedServerDirectory, configPath: '', clearServerConfig: !resolvedServerDirectory, noPasswordAuth: false };
    if (input.operation === 'save-rcon') {
      await store.save({ ggcon }, { allowLocalRconPassword: true, readGameRconConfig: false, ensureGameRconConfig: true });
      if (input.syncPlugins === true) {
        if (!pluginService) throw new Error('RCON 设置已保存，但插件同步服务未就绪');
        const plugins = await pluginService.prepareSync(resolvedServerDirectory);
        if (plugins.sync.status === 'pending') launchPluginWorker?.();
        const message = plugins.sync.status === 'completed'
          ? 'RCON 设置已保存，三份签名插件已备份、替换并校验。'
          : `RCON 设置已保存；${plugins.sync.message}。`;
        return { message, pluginSync: plugins.sync };
      }
      return { message: 'RCON 设置已保存，并已生成或更新原生 SCUMRCON\\config.ini；重启 SCUM 服务器和商城服务后生效。', pluginSync: { status: 'skipped' } };
    }
    const client = new SourceRconClient({ ...ggcon, connectTimeoutMs: 5000, authTimeoutMs: 5000, commandTimeoutMs: 5000, maxPacketSize: 1048576 }, { maxAttempts: 0 });
    try { await client.command('#ListPlayers', { retry: false }); return { message: 'RCON 认证及只读 ListPlayers 测试成功。' }; }
    finally { client.close(); }
  }
  if (input.operation === 'create-admin') {
    if (!input.steamId) throw new Error('请填写 SteamID');
    if (typeof authenticateLicense !== 'function') throw new Error('无法重新认证授权账号');
    const identity = await authenticateLicense(input.password);
    if (!identity?.username) throw new Error('授权中心未返回有效账号');
    const config = await store.read();
    const db = await openDatabase(config.mysql);
    try {
      const admin = await createInitialSuperAdmin(db, { ...input, username: identity.username }, { allowUnbound: false, authorization: identity, actorType: 'license', actorLabel: identity.username, reason: '授权中心账号完成本机首装初始化' });
      return { message: admin.idempotent ? '首次超级管理员已完成绑定，可以继续启动商城。' : '首次超级管理员已创建并绑定 SteamID，请使用该账号登录后台。' };
    } finally { await db.close(); }
  }
  if (input.operation === 'recover-legacy-admin') {
    if (typeof authenticateLicense !== 'function') throw new Error('无法重新认证授权账号');
    const identity = await authenticateLicense(input.password);
    if (!identity?.username) throw new Error('授权中心未返回有效账号');
    const config = await store.read();
    const db = await openDatabase(config.mysql);
    try {
      const user = await recoverLegacySuperAdmin(db, input, identity);
      return { message: '旧商城超级管理员已由当前授权账号接管，固定绑定已建立。', userId: user.id, username: user.username };
    } finally { await db.close(); }
  }
  if (input.operation === 'change-mysql-password') {
    const rootPassword = String(input.rootPassword || '');
    const newPassword = String(input.newPassword || '');
    if (!rootPassword) throw new Error('请填写 MySQL root 密码');
    if (newPassword.length < 8 || newPassword.length > 128) throw new Error('MySQL 新密码须为 8-128 位');
    const current = await store.read();
    const mysqlConfig = current.mysql;
    if (!/^[A-Za-z0-9_$-]{1,64}$/.test(String(mysqlConfig.database || ''))) throw new Error('数据库名称无效');
    const admin = await mysql.createConnection({ host: mysqlConfig.host, port: mysqlConfig.port, user: 'root', password: rootPassword, charset: 'utf8mb4' });
    try {
      await admin.query("CREATE USER IF NOT EXISTS 'scum_shop'@'localhost' IDENTIFIED BY ?", [newPassword]);
      await admin.query("ALTER USER 'scum_shop'@'localhost' IDENTIFIED BY ?", [newPassword]);
      await admin.query("CREATE USER IF NOT EXISTS 'scum_shop'@'127.0.0.1' IDENTIFIED BY ?", [newPassword]);
      await admin.query("ALTER USER 'scum_shop'@'127.0.0.1' IDENTIFIED BY ?", [newPassword]);
      const grantPrefix = 'GRANT ALL PRIVILEGES ON ' + String.fromCharCode(96) + mysqlConfig.database + String.fromCharCode(96) + '.* TO ';
      await admin.query(grantPrefix + "'scum_shop'@'localhost'");
      await admin.query(grantPrefix + "'scum_shop'@'127.0.0.1'");
      await admin.query('FLUSH PRIVILEGES');
    } finally { await admin.end(); }
    await store.save({ mysql: { ...mysqlConfig, password: newPassword } });
    return { message: 'MySQL 密码已修改，商城配置已同步。请重启商城服务。' };
  }
  throw new Error('未知窗口设置操作');
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    let text = '';
    for await (const chunk of process.stdin) { text += chunk; if (text.length > 16384) throw new Error('输入过长'); }
    const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
    const licenseStore = new LicenseStore(path.join(root, 'runtime', 'secrets', 'license.json'));
    const store = new ConfigStore(path.join(root, 'data', 'config.json'));
    const result = await applyLauncherSettings(JSON.parse(text), {
      store,
      openDatabase: createDatabase,
      verifyLicense: () => assertStartupAllowed({ store: licenseStore }),
      authenticateLicense: password => authenticateLicenseAccount({ store: licenseStore, password }),
      pluginService: new RconPluginService({ root, store }),
      launchPluginWorker: () => startPluginSyncWorker(root)
    });
    console.log(JSON.stringify(result));
  } catch (error) {
    console.error(JSON.stringify({ message: `设置失败：${error.message}` }));
    process.exitCode = 1;
  }
}
