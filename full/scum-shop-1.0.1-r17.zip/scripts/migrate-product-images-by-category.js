import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import mysql from 'mysql2/promise';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const config = JSON.parse((await fs.readFile(path.join(root, 'data', 'config.json'), 'utf8')).replace(/^\uFEFF/, '')).mysql;
const imageRoot = path.join(root, 'public', 'uploads', 'products');
const segment = (value, fallback) => {
  const text = String(value || '').trim();
  return text && text !== '.' && text !== '..' && /^[\p{L}\p{N}_ ()&-]{1,100}$/u.test(text) ? text : fallback;
};
const db = await mysql.createConnection({ ...config, charset: 'utf8mb4', timezone: 'Z', decimalNumbers: true });
const moved = [];
let locked = false;
try {
  const [lock] = await db.query('SELECT GET_LOCK(?, 10) AS acquired', ['shop-migrate-product-images']);
  if (Number(lock[0].acquired) !== 1) throw new Error('已有图片迁移正在执行');
  locked = true;
  const [products] = await db.query("SELECT id,image_path,parent_category,category_name FROM products WHERE image_path LIKE '/uploads/products/%'");
  const candidates = products.filter((product) => !product.image_path.split('/').slice(3, -1).length);
  if (!candidates.length) { console.log(JSON.stringify({ migrated: 0, message: '没有需要迁移的平铺图片' }, null, 2)); process.exitCode = 0; }
  else {
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backup = path.join(root, 'backups', `before-image-category-migration-${stamp}.sql`);
    await fs.mkdir(path.dirname(backup), { recursive: true });
    const dump = path.join(root, 'runtime', 'mysql', 'bin', 'mysqldump.exe');
    await new Promise((resolve, reject) => {
      const child = spawn(dump, [`--host=${config.host}`, `--port=${config.port}`, `--user=${config.user}`, '--single-transaction', '--no-tablespaces', '--default-character-set=utf8mb4', `--result-file=${backup}`, config.database, 'products'], { windowsHide: true, env: { ...process.env, MYSQL_PWD: config.password }, stdio: ['ignore', 'ignore', 'pipe'] });
      let detail = ''; child.stderr.on('data', (chunk) => { detail += chunk.toString(); }); child.on('error', reject); child.on('close', (code) => code === 0 ? resolve() : reject(new Error(`数据库备份失败：${detail}`)));
    });
    await db.beginTransaction();
    for (const product of candidates) {
      const filename = path.basename(product.image_path);
      if (!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,199}$/.test(filename)) throw new Error(`图片文件名无效：${filename}`);
      const parent = segment(product.parent_category, '未分类');
      const category = segment(product.category_name, '未分类');
      const relative = path.join('products', parent, category, filename);
      const source = path.join(imageRoot, filename);
      const target = path.join(root, 'public', 'uploads', relative);
      await fs.mkdir(path.dirname(target), { recursive: true });
      try { await fs.access(source); } catch { throw new Error(`找不到图片：${source}`); }
      try { await fs.access(target); throw new Error(`目标图片已存在：${target}`); } catch (error) { if (error.code !== 'ENOENT') throw error; }
      await fs.rename(source, target);
      moved.push({ source, target, id: product.id, imagePath: `/uploads/${relative.replaceAll('\\', '/')}` });
      await db.execute('UPDATE products SET image_path=? WHERE id=?', [moved.at(-1).imagePath, product.id]);
    }
    await db.commit();
    const report = { migrated: moved.length, backup, products: moved.map(({ id, imagePath }) => ({ id, imagePath })) };
    const reportPath = path.join(root, 'data', `image-category-migration-${stamp}.json`);
    await fs.writeFile(reportPath, JSON.stringify(report, null, 2));
    console.log(JSON.stringify({ migrated: moved.length, backup, report: reportPath }, null, 2));
  }
} catch (error) {
  await db.rollback();
  for (const item of moved.reverse()) await fs.rename(item.target, item.source).catch(() => {});
  throw error;
} finally {
  if (locked) await db.query('SELECT RELEASE_LOCK(?)', ['shop-migrate-product-images']);
  await db.end();
}
