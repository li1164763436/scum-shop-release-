import { buildMessageCommand } from './command-policy.js';
import { buildAnnouncementCommand } from './command-policy.js';
import { formatGameMessage } from './game-message.js';

function message(error) {
  return String(error?.message || '公告发送失败').slice(0, 500);
}

function slotFor(now, item) {
  if (typeof item === 'number') { const intervalMs=item*60000;return new Date(Math.floor(Number(now)/intervalMs)*intervalMs); }
  item = { executionTime: '00:00', weekdays: [1,2,3,4,5,6,7], intervalMinutes: 0, ...item };
  const shifted = new Date(Number(now) + 8 * 3600000);
  const weekday = shifted.getUTCDay() || 7;
  if (!item.weekdays.includes(weekday)) return null;
  const [hour, minute] = item.executionTime.split(':').map(Number);
  const currentMinute = shifted.getUTCHours() * 60 + shifted.getUTCMinutes();
  const scheduledMinute = hour * 60 + minute;
  if (currentMinute < scheduledMinute) return null;
  const interval = Number(item.intervalMinutes || 0);
  const slotMinute = interval > 0 ? scheduledMinute + Math.floor((currentMinute - scheduledMinute) / interval) * interval : scheduledMinute;
  const localSlot = Date.UTC(shifted.getUTCFullYear(), shifted.getUTCMonth(), shifted.getUTCDate(), Math.floor(slotMinute / 60), slotMinute % 60);
  return new Date(localSlot - 8 * 3600000);
}

export async function sendMessageToOnlinePlayers({ clients, config, logger, message: text, context = {} }) {
  const { ggcon } = await clients();
  const players = await ggcon.players();
  const total = players.length;
  try {
    const command = buildMessageCommand({ global: true, message: formatGameMessage(config, text) }, config.commandPolicy);
    await ggcon.command(command, { retry: false });
    return { sent: total, failed: 0, total, lastError: null };
  } catch (error) {
    const lastError = message(error);
    logger.warn('公告向全球频道发送失败', { ...context, error: lastError });
    return { sent: 0, failed: total, total, lastError };
  }
}

export class AnnouncementWorker {
  constructor({ db, store, clients, logger, clock = () => Date.now(), setTimeout: setTimer = globalThis.setTimeout, clearTimeout: clearTimer = globalThis.clearTimeout }) {
    this.db = db;
    this.store = store;
    this.clients = clients;
    this.logger = logger;
    this.clock = clock;
    this.setTimer = setTimer;
    this.clearTimer = clearTimer;
    this.timer = null;
    this.activeTick = null;
    this.running = false;
    this.stopped = true;
    this.enabled = false;
    this.pollIntervalMs = null;
  }

  status() {
    return { enabled: this.enabled, running: this.running, polling: Boolean(this.timer), pollIntervalMs: this.pollIntervalMs };
  }

  async start() {
    this.stopped = false;
    const status = await this.configure();
    if (this.enabled) void this.tick().catch((error) => this.logger.error('公告 Worker 执行失败', { component: 'announcement', error: message(error) }));
    return status;
  }

  async reconfigure() {
    const status = await this.configure();
    if (this.enabled) await this.tick();
    return status;
  }

  async configure() {
    const config = await this.store.read();
    this.enabled = Boolean(config.announcements.enabled);
    this.clearSchedule();
    if (!this.enabled) {
      this.stop();
      await this.drain();
      return this.status();
    }
    this.pollIntervalMs = config.announcements.pollIntervalMs;
    this.stopped = false;
    return this.status();
  }

  clearSchedule() {
    if (this.timer) this.clearTimer(this.timer);
    this.timer = null;
  }

  schedule() {
    if (!this.enabled || this.stopped || this.timer) return;
    this.timer = this.setTimer(() => {
      this.timer = null;
      void this.tick().catch((error) => this.logger.error('公告 Worker 执行失败', { component: 'announcement', error: message(error) }));
    }, this.pollIntervalMs);
    this.timer?.unref?.();
  }

  stop() {
    this.stopped = true;
    this.clearSchedule();
    this.pollIntervalMs = null;
  }

  async drain() {
    await this.activeTick;
  }

  async stopAndDrain() {
    this.stop();
    await this.drain();
  }

  async claimSlot(item, scheduledFor) {
    try {
      const result = await this.db.query("INSERT INTO scheduled_announcement_runs (announcement_id, scheduled_for, status) VALUES (?, ?, 'sending')", [item.id, scheduledFor]);
      return result.insertId;
    } catch (error) {
      if (error?.code === 'ER_DUP_ENTRY' || error?.errno === 1062) return null;
      throw error;
    }
  }

  async send(item, config) {
    const lines = item.message.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
    let sent = 0, failed = 0, total = 0, lastError = null;
    for (const line of lines) {
      try {
        if (line.startsWith('#')) { const { ggcon } = await this.clients(); await ggcon.command(buildAnnouncementCommand({ command: line }), { retry: false, priority: 'normal' }); sent += 1; total += 1; }
        else { const stats = await sendMessageToOnlinePlayers({ clients: this.clients, config, logger: this.logger, message: line, context: { announcementId: item.id } }); sent += stats.sent; failed += stats.failed; total += stats.total; lastError = stats.lastError || lastError; }
      } catch (error) { failed += 1; total += 1; lastError = message(error); this.logger.warn('公告单行执行失败', { announcementId: item.id, line, error: lastError }); }
    }
    return { sent, failed, total, lastError };
  }

  async tick() {
    if (this.running || !this.enabled || this.stopped) return false;
    this.activeTick = this.performTick();
    try {
      return await this.activeTick;
    } finally {
      this.activeTick = null;
      this.schedule();
    }
  }

  async performTick() {
    this.running = true;
    try {
      const config = await this.store.read();
      if (!config.announcements.enabled) return false;
      for (const item of config.announcements.items.filter((candidate) => candidate.enabled)) {
        if (this.stopped) break;
        const scheduledFor = slotFor(this.clock(), item);
        if (!scheduledFor) continue;
        const runId = await this.claimSlot(item, scheduledFor);
        if (!runId) continue;
        try {
          const stats = await this.send(item, config);
          await this.db.query("UPDATE scheduled_announcement_runs SET status = ?, sent_count = ?, failed_count = ?, last_error = ?, completed_at = CURRENT_TIMESTAMP(3) WHERE id = ?", [stats.failed ? 'completed_with_errors' : 'completed', stats.sent, stats.failed, stats.lastError, runId]);
        } catch (error) {
          await this.db.query("UPDATE scheduled_announcement_runs SET status = 'failed', last_error = ?, completed_at = CURRENT_TIMESTAMP(3) WHERE id = ?", [message(error), runId]);
          this.logger.error('公告发送失败', { announcementId: item.id, error: message(error) });
        }
      }
      return true;
    } finally {
      this.running = false;
    }
  }

  async sendNow(id) {
    const config = await this.store.read();
    const item = config.announcements.items.find((candidate) => candidate.id === String(id));
    if (!item) throw new Error('公告不存在');
    return this.send(item, config);
  }
}

export { slotFor };
