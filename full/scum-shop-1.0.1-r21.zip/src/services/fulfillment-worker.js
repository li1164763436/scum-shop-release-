import crypto from 'node:crypto';
import { buildItemCommand } from './command-policy.js';
import { renderGiftRconCommand } from './gift-code-policy.js';
import { recomputeOrderStatus } from './commerce-service.js';
import { sendDeliveryNotification } from './delivery-notification.js';

const MAX_ITEMS_PER_SPAWN = 10;

function message(error) {
  return String(error?.message || '发货失败').slice(0, 500);
}

async function syncLotteryLog(tx, task, status, errorSummary = null) {
  if (!Boolean(task.isLottery)) return;
  await tx.query('UPDATE lottery_fulfillment_logs SET status = ?, error_summary = ? WHERE fulfillment_task_id = ?', [status, errorSummary, task.id]);
}

function commandSucceeded(result) {
  if (!result || typeof result !== 'object' || result.success === false || result.data?.success === false) return false;
  const status = String(result.status || result.data?.status || '').toLowerCase();
  return result.success === true || result.data?.success === true || status === 'ok' || status === 'success';
}

export class FulfillmentWorker {
  constructor({ db, store, clients, logger, maintenanceService = null, setTimeout: setTimer = globalThis.setTimeout, clearTimeout: clearTimer = globalThis.clearTimeout }) {
    this.db = db;
    this.store = store;
    this.clients = clients;
    this.logger = logger;
    this.maintenanceService = maintenanceService;
    this.setTimer = setTimer;
    this.clearTimer = clearTimer;
    this.timer = null;
    this.activeTick = null;
    this.running = false;
    this.stopped = true;
    this.enabled = false;
    this.pollIntervalMs = null;
    this.paused = false;
    this.pauseReason = null;
    this.activeMaintenanceId = null;
  }

  status() {
    return { enabled: this.enabled, running: this.running, polling: Boolean(this.timer), pollIntervalMs: this.pollIntervalMs, paused: this.paused, maintenanceId: this.activeMaintenanceId, pauseReason: this.pauseReason, pausedReason: this.pauseReason, currentMaintenanceId: this.activeMaintenanceId };
  }

  async start() {
    this.stopped = false;
    const status = await this.configure();
    if (this.enabled) void this.tick().catch((error) => this.logger.error('发货 Worker 执行失败', { component: 'fulfillment', error: message(error) }));
    return status;
  }

  async reconfigure() {
    const status = await this.configure();
    if (this.enabled) await this.tick();
    return status;
  }

  async configure() {
    const config = await this.store.read();
    this.enabled = Boolean(config.fulfillment.workerEnabled);
    this.clearSchedule();
    if (!this.enabled) {
      this.stop();
      await this.drain();
      return this.status();
    }
    this.pollIntervalMs = config.fulfillment.pollIntervalMs;
    this.stopped = false;
    return this.status();
  }

  clearSchedule() {
    if (this.timer) this.clearTimer(this.timer);
    this.timer = null;
  }

  schedule() {
    if (!this.enabled || this.stopped || this.timer) return;
    this.timer = this.setTimer(() => {
      this.timer = null;
      void this.tick().catch((error) => this.logger.error('发货 Worker 执行失败', { component: 'fulfillment', error: message(error) }));
    }, this.pollIntervalMs);
    this.timer?.unref?.();
  }

  stop() {
    this.stopped = true;
    this.clearSchedule();
    this.pollIntervalMs = null;
  }

  async drain() {
    await this.activeTick;
  }

  async stopAndDrain() {
    this.stop();
    await this.drain();
  }

  async quarantineStaleTask(tx) {
    const rows = await tx.query("SELECT id, order_id AS orderId, attempts, (SELECT COUNT(*) > 0 FROM lottery_fulfillment_logs l WHERE l.fulfillment_task_id = fulfillment_tasks.id) AS isLottery FROM fulfillment_tasks WHERE status IN ('processing','dispatching') AND locked_at < DATE_SUB(CURRENT_TIMESTAMP(3), INTERVAL 5 MINUTE) ORDER BY id LIMIT 1 FOR UPDATE SKIP LOCKED");
    if (!rows[0]) return false;
    const reason = '任务处理状态超时，发货结果不确定，需人工核查';
    await tx.query("UPDATE fulfillment_tasks SET status = 'manual_review', last_error = ?, locked_at = NULL, delivery_token = NULL WHERE id = ?", [reason, rows[0].id]);
    await syncLotteryLog(tx, rows[0], 'manual_review', reason);
    await tx.query("INSERT INTO fulfillment_attempts (task_id, attempt_no, status, message) VALUES (?, ?, 'manual_review', ?)", [rows[0].id, rows[0].attempts, reason]);
    await recomputeOrderStatus(tx, rows[0].orderId);
    return true;
  }

  async readPauseState(query = this.db) {
    if (!this.maintenanceService) {
      this.paused = false;
      this.activeMaintenanceId = null;
      this.pauseReason = null;
      return false;
    }
    const state = await this.maintenanceService.isFulfillmentPaused(query);
    this.paused = Boolean(state.paused);
    this.activeMaintenanceId = state.maintenanceId || null;
    this.pauseReason = state.reason || null;
    return this.paused;
  }

  async claimTask({ warehouseOnly = false } = {}) {
    return this.db.transaction(async (tx) => {
      while (await this.quarantineStaleTask(tx)) {}
      if (await this.readPauseState(tx)) return null;
      const warehouseFilter = warehouseOnly ? " AND task_type='spawn_item' AND JSON_UNQUOTE(JSON_EXTRACT(payload_json,'$.preferWarehouse'))='true'" : '';
      const rows = await tx.query("SELECT id, order_id AS orderId, status AS previousStatus, last_error AS previousError FROM fulfillment_tasks WHERE status IN ('pending','waiting_instance','waiting_offline','retry') AND next_attempt_at <= CURRENT_TIMESTAMP(3)" + warehouseFilter + " ORDER BY id LIMIT 1 FOR UPDATE SKIP LOCKED");
      if (!rows[0]) return null;
      const claimToken = crypto.randomUUID();
      await tx.query("UPDATE fulfillment_tasks SET status = 'processing', locked_at = CURRENT_TIMESTAMP(3), delivery_token = ? WHERE id = ?", [claimToken, rows[0].id]);
      await recomputeOrderStatus(tx, rows[0].orderId);
      const tasks = await tx.query('SELECT id, order_id AS orderId, steam_id AS steamId, task_type AS taskType, payload_json AS payloadJson, coin_amount AS coinAmount, item_id AS itemId, amount, attempts, delivery_token AS deliveryToken, (SELECT COUNT(*) > 0 FROM lottery_fulfillment_logs l WHERE l.fulfillment_task_id = fulfillment_tasks.id) AS isLottery FROM fulfillment_tasks WHERE id = ?', [rows[0].id]);
      return { ...tasks[0], previousStatus: rows[0].previousStatus, previousError: rows[0].previousError };
    });
  }

  async tick() {
    if (this.running || !this.enabled || this.stopped) return false;
    this.activeTick = this.performTick();
    try {
      return await this.activeTick;
    } finally {
      this.activeTick = null;
      this.schedule();
    }
  }

  async performTick() {
    this.running = true;
    try {
      let task;
      while (!this.stopped) {
        task = await this.claimTask({ warehouseOnly: true });
        if (task) {
          await this.process(task);
          continue;
        }
        task = await this.claimTask();
        if (!task) break;
        await this.process(task);
      }
      return true;
    } finally {
      this.running = false;
    }
  }

  async process(task) {
    const attemptNo = Number(task.attempts) + 1;
    try {
      return await this.processClaimed(task);
    } catch (error) {
      let config;
      try {
        config = await this.store.read();
      } catch {
        config = { fulfillment: { maxAttempts: 1, pollIntervalMs: 30000 } };
      }
      await this.retryBusinessError(task, attemptNo, error, config);
    }
  }

  async processClaimed(task) {
    const config = await this.store.read();
    const attemptNo = Number(task.attempts) + 1;
    const taskType = task.taskType || 'spawn_item';
    if (taskType === 'shop_coin') {
      await this.processCoin(task, attemptNo);
      return;
    }
    if (!['spawn_item', 'vehicle_insurance_claim'].includes(taskType)) {
      await this.manualReview(task, attemptNo, '不支持的履约任务类型');
      return;
    }
    const warehousePayload = typeof task.payloadJson === 'string' ? JSON.parse(task.payloadJson) : task.payloadJson;
    if (warehousePayload?.preferWarehouse) {
      await this.processWarehouse(task, warehousePayload, attemptNo);
      return;
    }
    const { gsm3, ggcon } = await this.clients();
    let dispatching = false;
    let completed = false;
    let deliveryToken;
    try {
      if (config.fulfillment.instanceId) {
        const instanceStatus = await gsm3.instanceStatus(config.fulfillment.instanceId);
        if (instanceStatus !== 'running') {
          await this.defer(task, 'waiting_instance', `SCUM 实例状态为 ${instanceStatus}`, config.fulfillment.pollIntervalMs);
          return;
        }
      }
      const players = await ggcon.players({ priority: 'high' });
      if (!players.some((player) => player.steamId === task.steamId)) {
        await this.defer(task, 'waiting_offline', '玩家当前离线', config.fulfillment.pollIntervalMs);
        return;
      }
      const payload = typeof task.payloadJson === 'string' ? JSON.parse(task.payloadJson) : task.payloadJson;
      const insuranceClaim = payload?.actionType === 'vehicle_insurance_claim';
      const vehicle = payload?.actionType === 'spawn_vehicle';
      const animal = payload?.actionType === 'spawn_animal';
      const zombie = payload?.actionType === 'spawn_zombie';
      const armedNpc = payload?.actionType === 'spawn_armed_npc';
      if (vehicle && (!/^[A-Za-z0-9_]{1,80}$/.test(payload.itemId) || payload.quantity !== 1 || !/^7656119\d{10}$/.test(task.steamId))) throw new Error('车辆发货参数无效');
      if (insuranceClaim && (!/^[A-Za-z0-9_]{1,80}$/.test(payload.itemId) || payload.quantity !== 1 || !Number.isSafeInteger(Number(payload.oldVehicleId)) || Number(payload.oldVehicleId) < 1 || !Number.isSafeInteger(Number(payload.vehicleId)) || Number(payload.vehicleId) < 1 || !/^7656119\d{10}$/.test(task.steamId))) throw new Error('载具保险索赔参数无效');
      if (armedNpc && (!/^[A-Za-z0-9_]{1,80}$/.test(payload.itemId) || payload.quantity !== 1 || !/^7656119\d{10}$/.test(task.steamId))) throw new Error('武装 NPC 发货参数无效');
      if (zombie && (!/^[A-Za-z0-9_]{1,80}$/.test(payload.itemId) || !Number.isSafeInteger(payload.quantity) || payload.quantity < 1 || payload.quantity > 100 || !/^7656119\d{10}$/.test(task.steamId))) throw new Error('木偶发货参数无效');
      if (animal && (!/^[A-Za-z0-9_]{1,80}$/.test(payload.itemId) || !Number.isSafeInteger(payload.quantity) || payload.quantity < 1 || payload.quantity > 100 || !/^7656119\d{10}$/.test(task.steamId))) throw new Error('动物发货参数无效');
      const totalAmount = Number(payload?.quantity || task.amount || 0);
      const commands = insuranceClaim
        ? [`#DestroyVehicle ${payload.oldVehicleId}`, `#SpawnVehicle ${payload.itemId} 1 Location ${task.steamId}`]
        : armedNpc
        ? [`#SpawnArmedNPC ${payload.itemId} ${payload.quantity} Location ${task.steamId}`]
        : zombie
          ? [`SpawnZombieForPlayer ${task.steamId} ${payload.itemId} ${payload.quantity} CONFIRM`]
          : animal
            ? [`SpawnAnimalForPlayer ${task.steamId} ${payload.itemId} ${payload.quantity} CONFIRM`]
            : vehicle
              ? [`#SpawnVehicle ${payload.itemId} ${payload.quantity} Location ${task.steamId}`]
              : Array.from({ length: Math.ceil(totalAmount / MAX_ITEMS_PER_SPAWN) }, (_, index) => {
        const amount = Math.min(MAX_ITEMS_PER_SPAWN, totalAmount - index * MAX_ITEMS_PER_SPAWN);
        if (task.payloadJson) return renderGiftRconCommand({ taskType: 'spawn_item', payload: { ...payload, quantity: amount } }, task.steamId);
        buildItemCommand({ steamId: task.steamId, itemId: task.itemId, amount }, {
          allowedMessageLength: config.commandPolicy.allowedMessageLength,
          allowedItems: [{ id: task.itemId, name: task.itemId, maxAmount: 10 }]
        });
        return `SpawnItemForPlayer ${task.steamId} ${task.itemId} ${amount} CONFIRM`;
              });
      deliveryToken = task.deliveryToken;
      if (!deliveryToken) throw new Error('发货任务缺少有效租约');
      await this.db.transaction(async (tx) => {
        const updated = await tx.query("UPDATE fulfillment_tasks SET status = 'dispatching', attempts = ?, locked_at = CURRENT_TIMESTAMP(3) WHERE id = ? AND status = 'processing' AND delivery_token = ?", [attemptNo, task.id, deliveryToken]);
        if (!updated.affectedRows) throw new Error('发货任务租约已失效');
        await syncLotteryLog(tx, task, 'dispatching');
        await recomputeOrderStatus(tx, task.orderId);
      });
      dispatching = true;
      const marker = vehicle ? 'spawn_vehicle_for_player=executed'
        : armedNpc ? 'spawn_armed_npc_for_player=executed'
          : zombie ? 'spawn_zombie_for_player=executed'
            : animal ? 'spawn_animal_for_player=executed'
              : 'spawn_item_for_player=executed';
      const label = insuranceClaim ? '载具保险索赔' : vehicle ? '车辆' : armedNpc ? '武装 NPC' : zombie ? '木偶' : animal ? '动物' : '物品';
      const commandIntervalMs = Math.min(Math.max(Number(config.fulfillment.commandIntervalMs) || 0, 0), 5000);
      for (let index = 0; index < commands.length; index += 1) {
        const lease = await this.db.transaction((tx) => tx.query("UPDATE fulfillment_tasks SET locked_at = CURRENT_TIMESTAMP(3) WHERE id = ? AND status = 'dispatching' AND delivery_token = ?", [task.id, deliveryToken]));
        if (!lease.affectedRows) throw new Error(`发货任务租约已失效；已确认完成 ${index}/${commands.length} 段`);
        const result = await ggcon.command(commands[index], { retry: false, deliveryToken: `${deliveryToken}:${index}`, priority: 'high' });
        const lines = String(result?.response || '').split(/\r?\n/);
        const expectedMarker = insuranceClaim ? (index === 0 ? 'admin_command=executed' : 'spawn_vehicle_for_player=executed') : marker;
        if (!commandSucceeded(result) || !lines.includes(expectedMarker)) {
          const error = new Error(`${label}未返回明确成功结果；已确认完成 ${index}/${commands.length} 段`);
          error.uncertainDelivery = true;
          throw error;
        }
        if (insuranceClaim && index === 0) {
          const removed = await this.db.transaction((tx) => tx.query("UPDATE `载具档案` SET `来源失联前状态`=CASE WHEN `档案状态`<>'lost' THEN `档案状态` ELSE `来源失联前状态` END,`档案状态`='lost',`来源同步状态`='missing',`来源缺失时间`=COALESCE(`来源缺失时间`,CURRENT_TIMESTAMP(3)),`最后观测时间`=CURRENT_TIMESTAMP(3) WHERE `载具档案编号`=? AND `车主SteamID`=? AND `来源类型`='scum_locked_vehicle' AND `来源载具编号`=?", [Number(payload.vehicleId), task.steamId, Number(payload.oldVehicleId)]));
          if (!removed.affectedRows) {
            const error = new Error('旧载具已在游戏内移除，但同步档案清理失败；禁止自动重试');
            error.uncertainDelivery = true;
            throw error;
          }
        }
        if (commandIntervalMs > 0 && index < commands.length - 1) await new Promise((resolve) => setTimeout(resolve, commandIntervalMs));
      }
      const completion = await this.db.transaction(async (tx) => {
        const before = await tx.query('SELECT status, order_no AS orderNo FROM orders WHERE id = ? FOR UPDATE', [task.orderId]);
        const updated = await tx.query("UPDATE fulfillment_tasks SET status = 'completed', last_error = NULL, locked_at = NULL, delivery_token = NULL WHERE id = ? AND status = 'dispatching' AND delivery_token = ?", [task.id, deliveryToken]);
        if (!updated.affectedRows) throw new Error('发货成功但任务完成状态落库失败');
        await syncLotteryLog(tx, task, 'completed');
        await tx.query("INSERT INTO fulfillment_attempts (task_id, attempt_no, status, message) VALUES (?, ?, 'success', '发货成功')", [task.id, attemptNo]);
        const status = await recomputeOrderStatus(tx, task.orderId);
        return { notify: before[0]?.status !== 'completed' && status === 'completed', orderNo: before[0]?.orderNo };
      });
      completed = true;
      this.logger.info('自动发货成功', { taskId: task.id, orderId: task.orderId, steamId: task.steamId, itemId: task.itemId, amount: task.amount, deliveryToken });
      if (completion.notify && config.fulfillment.notifyOnSuccess) {
        try {
          await sendDeliveryNotification({ db: { query: (sql, params) => this.db.transaction((tx) => tx.query(sql, params)) }, config, ggcon, steamId: task.steamId, orderId: task.orderId, action: '发货成功' });
        } catch (error) {
          this.logger.warn('订单完成通知发送失败', { taskId: task.id, orderId: task.orderId, error: message(error) });
        }
      }
    } catch (error) {
      if (completed) {
        this.logger.warn('发货完成后的非关键处理失败', { taskId: task.id, orderId: task.orderId, error: message(error) });
        return;
      }
      if (dispatching) {
        await this.manualReview(task, attemptNo, `进入发货阶段后发生异常，禁止自动重发：${message(error)}`);
        return;
      }
      await this.retryBusinessError(task, attemptNo, error, config);
    }
  }

  async processWarehouse(task, payload, attemptNo) {
    const itemId = String(payload.itemId || task.itemId || '');
    const quantity = Number(payload.quantity || task.amount || 0);
    if (!/^[A-Za-z0-9_-]{1,80}$/.test(itemId) || !Number.isSafeInteger(quantity) || quantity < 1) throw new Error('云储奖励参数无效');
    const actionType = payload.actionType || null;
    if (['spawn_animal','spawn_zombie','spawn_armed_npc'].includes(actionType)) throw new Error('动物、僵尸或武装NPC奖品不支持存入云储仓库');
    if (actionType && actionType !== 'spawn_vehicle') throw new Error('云储奖励类型无效');
    if (actionType === 'spawn_vehicle' && quantity !== 1) throw new Error('载具云储奖励数量必须为1');
    const result = await this.db.transaction(async (tx) => {
      const updated = await tx.query("UPDATE fulfillment_tasks SET status='completed',attempts=?,last_error=NULL,locked_at=NULL,delivery_token=NULL WHERE id=? AND status='processing' AND delivery_token=?", [attemptNo, task.id, task.deliveryToken]);
      if (updated.affectedRows === 0) return null;
      await tx.query('INSERT INTO \`商城用户\` (\`SteamID\`,\`商城币余额\`) VALUES (?,0) ON DUPLICATE KEY UPDATE \`SteamID\`=VALUES(\`SteamID\`)', [task.steamId]);
      for (let index = 0; index < quantity; index += 1) {
        await tx.query("INSERT INTO cloud_inventory_batches (steam_id,source_item_id,item_code,item_name,quantity,item_snapshot_json,status) VALUES (?,NULL,?,?,?,?, 'active')", [task.steamId, itemId, itemId, 1, actionType ? JSON.stringify({ actionType }) : null]);
      }
      await tx.query("INSERT INTO fulfillment_attempts (task_id,attempt_no,status,message) VALUES (?,?,'success','奖励已优先存入云储仓库')", [task.id, attemptNo]);
      await syncLotteryLog(tx, task, 'completed');
      return recomputeOrderStatus(tx, task.orderId);
    });
    if (result === null) return;
    this.logger.info('奖励已存入云储仓库', { taskId: task.id, orderId: task.orderId, steamId: task.steamId, itemId, quantity, orderStatus: result });
  }

  async processCoin(task, attemptNo) {
    try {
      let processed = false;
      const ledgerType = task.isLottery ? 'lottery_reward' : 'gift_reward';
      const ledgerNote = task.isLottery ? '抽奖商城币奖励' : '礼包商城币奖励';
      await this.db.transaction(async (tx) => {
        const current = await tx.query('SELECT status, delivery_token AS deliveryToken FROM fulfillment_tasks WHERE id = ? FOR UPDATE', [task.id]);
        if (current[0]?.status !== 'processing' || current[0]?.deliveryToken !== task.deliveryToken) return;
        await tx.query('INSERT INTO \`商城用户\` (\`SteamID\`,\`商城币余额\`) VALUES (?,0) ON DUPLICATE KEY UPDATE \`SteamID\`=VALUES(\`SteamID\`)', [task.steamId]);
        const account = await tx.query('SELECT \`商城币余额\` AS balance FROM \`商城用户\` WHERE \`SteamID\`=? FOR UPDATE', [task.steamId]);
        const existing = await tx.query("SELECT steam_id AS steamId, amount FROM coin_ledger WHERE reference_type='fulfillment_task' AND reference_id=? FOR UPDATE", [String(task.id)]);
        if (existing[0]) {
          if (existing[0].steamId !== task.steamId || Number(existing[0].amount) !== Number(task.coinAmount)) throw new Error('商城币幂等流水与当前任务不一致');
        } else {
          const balance = Number(account[0].balance) + Number(task.coinAmount);
          await tx.query("INSERT INTO coin_ledger (steam_id,amount,balance_after,type,reference_type,reference_id,note) VALUES (?,?,?,?,'fulfillment_task',?,?)", [task.steamId, Number(task.coinAmount), balance, ledgerType, String(task.id), ledgerNote]);
          await tx.query('UPDATE \`商城用户\` SET \`商城币余额\`=? WHERE \`SteamID\`=?', [balance, task.steamId]);
        }
        await tx.query("UPDATE fulfillment_tasks SET status='completed',attempts=?,last_error=NULL,locked_at=NULL,delivery_token=NULL WHERE id=? AND status='processing' AND delivery_token=?", [attemptNo, task.id, task.deliveryToken]);
        await syncLotteryLog(tx, task, 'completed');
        await tx.query("INSERT INTO fulfillment_attempts (task_id,attempt_no,status,message) VALUES (?,?,'success','商城币已到账')", [task.id, attemptNo]);
        await recomputeOrderStatus(tx, task.orderId);
        processed = true;
      });
      if (!processed) return;
      this.logger.info('礼包商城币发放成功', { taskId: task.id, orderId: task.orderId, steamId: task.steamId, amount: task.coinAmount });
    } catch (error) {
      await this.retryBusinessError(task, attemptNo, error, await this.store.read());
    }
  }

  async manualReview(task, attemptNo, reason) {
    const changed = await this.db.transaction(async (tx) => {
      const updated = await tx.query("UPDATE fulfillment_tasks SET status = 'manual_review', attempts = ?, last_error = ?, locked_at = NULL, delivery_token = NULL WHERE id = ? AND status IN ('processing','dispatching') AND delivery_token = ?", [attemptNo, reason, task.id, task.deliveryToken]);
      if (!updated.affectedRows) return false;
      await syncLotteryLog(tx, task, 'manual_review', reason);
      await tx.query("INSERT INTO fulfillment_attempts (task_id, attempt_no, status, message) VALUES (?, ?, 'manual_review', ?)", [task.id, attemptNo, reason]);
      await recomputeOrderStatus(tx, task.orderId);
      return true;
    });
    if (changed) this.logger.warn('发货结果不确定，已转人工核查', { taskId: task.id, orderId: task.orderId, attemptNo, error: reason });
  }

  async retryBusinessError(task, attemptNo, error, config) {
    const terminal = attemptNo >= config.fulfillment.maxAttempts;
    const delay = Math.min(config.fulfillment.pollIntervalMs * (2 ** Math.max(0, attemptNo - 1)), 3600000);
    const changed = await this.db.transaction(async (tx) => {
      const updated = await tx.query("UPDATE fulfillment_tasks SET status = ?, attempts = ?, next_attempt_at = DATE_ADD(CURRENT_TIMESTAMP(3), INTERVAL ? MICROSECOND), last_error = ?, locked_at = NULL, delivery_token = NULL WHERE id = ? AND status = 'processing' AND delivery_token = ?", [terminal ? 'failed' : 'retry', attemptNo, delay * 1000, message(error), task.id, task.deliveryToken]);
      if (updated.affectedRows === 0) return false;
      await syncLotteryLog(tx, task, terminal ? 'failed' : 'retry', message(error));
      await tx.query('INSERT INTO fulfillment_attempts (task_id, attempt_no, status, message) VALUES (?, ?, ?, ?)', [task.id, attemptNo, terminal ? 'failed' : 'retry', message(error)]);
      await recomputeOrderStatus(tx, task.orderId);
      return true;
    });
    if (changed) this.logger.warn('自动发货前置检查失败', { taskId: task.id, orderId: task.orderId, attemptNo, error: message(error) });
  }

  async defer(task, status, reason, delay) {
    const safeDelay = Math.max(30000, delay);
    const unchanged = task.previousStatus === status && task.previousError === reason;
    await this.db.transaction(async (tx) => {
      const updated = await tx.query("UPDATE fulfillment_tasks SET status = ?, next_attempt_at = DATE_ADD(CURRENT_TIMESTAMP(3), INTERVAL ? MICROSECOND), last_error = ?, locked_at = NULL, delivery_token = NULL WHERE id = ? AND status = 'processing' AND delivery_token = ?", [status, safeDelay * 1000, reason, task.id, task.deliveryToken]);
      if (updated.affectedRows === 0) return;
      await syncLotteryLog(tx, task, status, reason);
      if (!unchanged) await tx.query('INSERT INTO fulfillment_attempts (task_id, attempt_no, status, message) VALUES (?, ?, ?, ?)', [task.id, task.attempts, status, reason]);
      await recomputeOrderStatus(tx, task.orderId);
    });
  }
}

export { commandSucceeded };
