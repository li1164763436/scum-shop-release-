import express from 'express';
import fsSync from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { ConfigStore } from './services/config-store.js';
import { Gsm3Client } from './services/gsm3-client.js';
import { GgconClient } from './services/ggcon-client.js';
import { buildItemCommand, buildMessageCommand, buildRawCommand } from './services/command-policy.js';
import { formatGameMessage } from './services/game-message.js';
import { createLogger } from './services/logger.js';
import { CommerceService, ServiceError, verifyCallback } from './services/commerce-service.js';
import { AuthService, authInternals } from './services/auth-service.js';
import { GiftService } from './services/gift-service.js';
import { RedeemCodeService } from './services/redeem-code-service.js';
import { RewardService } from './services/reward-service.js';
import { ActivityService } from './services/activity-service.js';
import { LotteryService } from './services/lottery-service.js';
import { StockMarketService } from './services/stock-market-service.js';
import { CloudWarehouseService } from './services/cloud-warehouse-service.js';
import { PlayerAdminCapabilityService } from './services/player-admin-capability-service.js';
import { PlayerAdminService } from './services/player-admin-service.js';
import { KillRankingService } from './services/kill-ranking-service.js';
import { ChatGiftClaimService } from './services/chat-gift-claim-service.js';
import { ChatAutoReplyService } from './services/chat-auto-reply-service.js';
import { CharacterGrowthService } from './services/character-growth-service.js';
import { LogBrowserService } from './services/log-browser-service.js';
import { VersionUpdateService } from './services/version-update-service.js';
import { deleteProduct, deleteGift, deleteRedeemCode, deleteRewardRule, deleteActivity, deleteLotteryPool, deleteStock, deleteMaintenance } from './services/deletion-service.js';
import { redact, safeMessage } from './utils/redactor.js';
import { spawn } from 'node:child_process';
import { StringDecoder } from 'node:string_decoder';
import { RconPluginService } from './services/rcon-plugin-service.js';
import { IMAGE_MIME_TYPES, saveUploadedImage } from './services/image-storage.js';
import { readGameAdminUsers } from './services/game-admin-users.js';
import { VehicleManagementService } from './services/vehicle-management-service.js';
import { VehicleLimitService } from './services/vehicle-limit-service.js';
import { VehicleInsuranceShopService } from './services/vehicle-insurance-shop-service.js';
import { TeleportMapService } from './services/teleport-map-service.js';
import { TeleportService } from './services/teleport-service.js';
import { DomainAccessError, DomainAccessService } from './services/domain-access-service.js';

function modifyScumPlayer(payload) { return new Promise((resolve, reject) => { const script = path.join(import.meta.dirname, '..', 'scripts', 'modify-scum-player.py'); const bundledPython = path.join(import.meta.dirname, '..', 'scripts', 'python', 'python.exe'); const executable = fsSync.existsSync(bundledPython) ? bundledPython : (process.platform === 'win32' ? 'python.exe' : 'python3'); const child = spawn(executable, ['-X', 'utf8', script], { env: { ...process.env, PYTHONIOENCODING: 'utf-8' }, windowsHide: true }); const stdout = new StringDecoder('utf8'); const stderr = new StringDecoder('utf8'); let out = '', err = ''; const readonly = payload?.action === 'read'; const timer = setTimeout(() => { child.kill(); reject(new ServiceError(readonly ? 'SCUM玩家档案读取超时' : 'SCUM玩家属性操作超时', 504, readonly ? 'SCUM_PROFILE_TIMEOUT' : 'SCUM_MODIFY_TIMEOUT')); }, 15000); child.stdout.on('data', (d) => { out += stdout.write(d); }); child.stderr.on('data', (d) => { err += stderr.write(d); }); child.on('error', (e) => { clearTimeout(timer); reject(new ServiceError(`无法启动SCUM属性脚本：${e.message}`, 503, 'SCUM_MODIFY_START_FAILED')); }); child.on('close', (code) => { clearTimeout(timer); out += stdout.end(); err += stderr.end(); clearTimeout(timer); try { const result = JSON.parse(out.trim()); if (result.error) return reject(new ServiceError(result.error, readonly ? 404 : 409, readonly ? 'SCUM_PROFILE_UNAVAILABLE' : 'SCUM_MODIFY_FAILED')); if (code) return reject(new ServiceError(result.error || err.trim() || (readonly ? '读取SCUM玩家档案失败' : '修改SCUM玩家失败'), readonly ? 404 : 409, readonly ? 'SCUM_PROFILE_UNAVAILABLE' : 'SCUM_MODIFY_FAILED')); resolve(result); } catch { reject(new ServiceError(err.trim() || 'SCUM属性脚本返回无效数据', code ? (readonly ? 404 : 409) : 502, readonly ? 'SCUM_PROFILE_INVALID_RESPONSE' : 'SCUM_MODIFY_INVALID_RESPONSE')); } }); child.stdin.end(JSON.stringify(payload)); }); }

const COOKIE_OPTIONS = 'Path=/; HttpOnly; SameSite=Lax; Max-Age=604800';
function runProcess(file, args) { return new Promise((resolve, reject) => { const child = spawn(file, args, { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] }); let output = ''; child.stdout.on('data', (chunk) => { output += chunk; }); child.stderr.on('data', (chunk) => { output += chunk; }); child.once('error', reject); child.once('close', (code) => code === 0 ? resolve(output) : reject(new Error(output.trim() || `进程退出码 ${code}`))); }); }
async function scheduleStoreRestart(root) {
  if (process.platform !== 'win32') throw new Error('当前系统不支持商城服务重启');
  const script = path.join(root, 'scripts', 'restart-store.ps1');
  if (!fsSync.existsSync(script)) throw new Error('缺少商城服务控制脚本');
  const systemRoot = process.env.SystemRoot || 'C:\\Windows';
  const powershell = path.join(systemRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  const schtasks = path.join(systemRoot, 'System32', 'schtasks.exe');
  const taskName = 'ScumRconManualRestart';
  const quote = (value) => `"${String(value).replaceAll('\"', '\"\"')}"`;
  const command = [quote(powershell), '-NoLogo', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', quote(script), '-AppRoot', quote(root)].join(' ');
  await runProcess(schtasks, ['/Create', '/TN', taskName, '/TR', command, '/SC', 'ONCE', '/ST', '00:00', '/RU', 'SYSTEM', '/RL', 'HIGHEST', '/F']);
  await runProcess(schtasks, ['/Run', '/TN', taskName]);
}

// #region debug-point A:log-api-runtime
function debugRuntimeLogs(hypothesisId, msg, data) { fetch('http://127.0.0.1:7777/event', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sessionId: 'runtime-logs-empty', runId: 'pre-fix', hypothesisId, location: 'src/app.js', msg: `[DEBUG] ${msg}`, data, ts: Date.now() }) }).catch(() => {}); }
// #endregion

// #region debug-point C:admin-list-runtime
function debugAdminList(hypothesisId, msg, data) { fetch('http://127.0.0.1:7777/event', { method: 'POST', body: JSON.stringify({ sessionId: 'delete-hidden-admin-visible', runId: 'pre-fix', hypothesisId, location: 'src/app.js', msg: `[DEBUG] ${msg}`, data, ts: Date.now() }) }).catch(() => {}); }
// #endregion

function cookies(req) {
  return Object.fromEntries(String(req.headers.cookie || '').split(';').map((part) => part.trim().split('=').map(decodeURIComponent)).filter((part) => part.length === 2));
}

function metadata(req) {
  return { ip: req.ip, userAgent: req.get('user-agent') };
}

function limiter({ windowMs, max }) {
  const entries = new Map();
  return (req, res, next) => {
    const key = `${req.ip}:${req.path}:${String(req.body?.username || req.body?.steamId || '').toLowerCase()}`;
    const now = Date.now();
    const item = entries.get(key);
    if (!item || item.until <= now) entries.set(key, { count: 1, until: now + windowMs });
    else if (++item.count > max) return res.status(429).json({ success: false, message: '请求过于频繁，请稍后再试', code: 'RATE_LIMITED' });
    if (entries.size > 5000) for (const [entryKey, value] of entries) if (value.until <= now) entries.delete(entryKey);
    next();
  };
}

export function adminPermissionFor(url) {
  if (/^\/api\/(?:dashboard|monitor)(?:\/|\?|$)/.test(url)) return 'overview';
  if (/^\/api\/(?:products|product-|website|gifts|gift-|redeem|reward|activities|lottery|stock|cloud)/.test(url)) return 'commerce';
  if (/^\/api\/(?:accounts|memberships|vehicles|players|player-admin|teleport-management|admin\/users|admin\/players|character-growth-purchases|account-exchanges|player-checkins)(?:\/|\?|$)/.test(url)) return 'players';
  if (/^\/api\/(?:orders|order-logs|tasks|fulfillment|game-claims|announcements)(?:\/|\?|$)/.test(url)) return 'fulfillment';
  if (/^\/api\/(?:logs|scum-logs|chat-logs|maintenance|gateway|commands|ggcon|store-settings)(?:\/|\?|$)/.test(url)) return 'operations';
  if (/^\/api\/(?:config|connections|instances|bridge|rcon|license|gsm3|admin\/version-update|admin\/system)(?:\/|\?|$)/.test(url)) return 'system';
  if (/^\/api\/(?:admin\/auth|health|shop|callback)(?:\/|\?|$)/.test(url)) return null;
  return 'system';
}

export function createApp(options = {}) {
  const root = options.root || path.resolve(import.meta.dirname, '..');
  const appVersion = options.appVersion || 'unknown';
  const releaseRevision = Number.isSafeInteger(options.releaseRevision) && options.releaseRevision >= 0 ? options.releaseRevision : 0;
  const store = options.store || new ConfigStore(path.join(root, 'data', 'config.json'));
  const logger = options.logger || createLogger(path.join(root, 'logs'));
  const logBrowser = options.logBrowser || new LogBrowserService({ root, store });
  const versionUpdate = options.versionUpdate || new VersionUpdateService({ root, logger, manifestUrl: options.versionUpdateManifestUrl });
  const rconPlugins = options.rconPlugins || new RconPluginService({ root, store, sourceRoot: options.rconPluginSourceRoot, cacheRoot: options.rconPluginCacheRoot });
  let rconPluginRecovery = null;
  const resumeRconPluginSync = () => {
    if (rconPluginRecovery || typeof rconPlugins.resumePending !== 'function') return rconPluginRecovery;
    const operation = rconPlugins.resumePending({ wait: true, signal: options.rconPluginSyncSignal })
      .catch(error => logger.error('RCON 插件待同步任务恢复失败', { component: 'rcon-plugin-sync', errorCode: error?.code || error?.name || 'PLUGIN_SYNC_FAILED' }))
      .finally(() => { if (rconPluginRecovery === operation) rconPluginRecovery = null; });
    rconPluginRecovery = operation;
    return operation;
  };
  if (options.rconPluginAutoResume === true) resumeRconPluginSync();
  const commerce = options.commerce || (options.db ? new CommerceService(options.db) : null);
  const gifts = options.gifts || (options.db ? new GiftService(options.db) : null);
  const redeemCodes = options.redeemCodes || (options.db ? new RedeemCodeService(options.db) : null);
  const rewards = options.rewards || (options.db ? new RewardService(options.db) : null);
  const activities = options.activities || (options.db ? new ActivityService(options.db, gifts) : null);
  const lottery = options.lottery || (options.db ? new LotteryService(options.db) : null);
  const stockMarket = options.stockMarket || (options.db ? new StockMarketService(options.db, { store }) : null);
  const vehicleManagement = options.vehicleManagement || (options.db ? new VehicleManagementService({ db: options.db }) : null);
  const vehicleLimit = options.vehicleLimit || (options.db ? new VehicleLimitService({ db: options.db }) : null);
  const vehicleSyncStatus = typeof options.vehicleSyncStatus === 'function' ? options.vehicleSyncStatus : () => null;
  const vehicleLimitStatus = typeof options.vehicleLimitStatus === 'function' ? options.vehicleLimitStatus : () => null;
  let vehicleInsuranceShop = options.vehicleInsuranceShop || null;
  const teleportMap = options.teleportMap || (options.db ? new TeleportMapService({ db: options.db, profile: options.teleportMapProfile, snapshotStore: options.teleportSnapshotStore }) : null);
  let teleport = options.teleport || null;
  let cloudWarehouse = options.cloudWarehouse || null;
  const killRanking = options.killRanking || (options.db ? new KillRankingService({ db: options.db }) : null);
  let chatGiftClaims = options.chatGiftClaims || null;
  let chatAutoReplies = options.chatAutoReplies || null;
  const auth = options.auth || (options.db ? new AuthService(options.db, { challengeSecret: options.challengeSecret || process.env.AUTH_CHALLENGE_SECRET }) : null);
  let playerAdminCapabilities = options.playerAdminCapabilities || null;
  let playerAdmin = options.playerAdmin || null;
  const legacyAdmin = options.allowUnauthenticatedAdmin === true;
  const app = express();
  const startedAt = Date.now();
  const status = { gsm3: { ok: false, checkedAt: null }, ggcon: { ok: false, checkedAt: null } };
  let latestBridgeStatus = null;
  let bridgeStatusPending = null;
  const workerStatus = options.workerStatus || (() => ({ enabled: false, running: false, polling: false, pollIntervalMs: null }));
  const teleportInitialWaitMs = Number.isFinite(Number(options.teleportInitialWaitMs)) ? Math.max(0, Number(options.teleportInitialWaitMs)) : 5_000;
  const monitorStatus = options.monitorStatus || (() => ({ enabled: false, running: false, polling: false, pollIntervalMs: null }));
  const maintenanceStatus = options.maintenanceStatus || (() => ({ enabled: false, running: false, polling: false, pollIntervalMs: null }));
  const stockMarketStatus = options.stockMarketStatus || (() => ({ enabled: false, running: false, polling: false, pollIntervalMs: null }));
  const temporaryBanStatus = options.temporaryBanStatus || (() => ({ enabled: false, running: false, polling: false, pollIntervalMs: null }));
  const scumLogStatus = options.scumLogStatus || (() => ({ enabled: false, running: false, polling: false, directoryConfigured: false, pollIntervalMs: null }));
  const chatLogStatus = options.chatLogStatus || (() => ({ enabled: false, running: false, polling: false, directoryConfigured: false, pollIntervalMs: null }));
  const licenseStore = options.licenseStore || null;
  const domainAccess = options.domainAccess || new DomainAccessService({ licenseStore, fetchImpl: options.domainAccessFetch, env: options.domainAccessEnv || process.env });
  const domainAccessStatus = options.domainAccessStatus || (async () => ({ connectionState: 'unavailable', tunnelStatus: 'unavailable', managedDomain: null, customDomain: null, updatedAt: new Date().toISOString() }));
  const monitorService = options.monitorService || null;
  const maintenanceService = options.maintenanceService || null;
  const maintenanceWorker = options.maintenanceWorker || null;
  const announcementWorker = options.announcementWorker || null;
  const readCharacterGrowth = async (fallback = { attributePointPrice: 0, skillLevelPrice: 0 }) => {
    if (!options.db) return fallback;
    const rows = await options.db.query('SELECT attribute_point_price AS attributePointPrice,skill_level_price AS skillLevelPrice FROM `系统配置` WHERE setting_key=?', ['default']);
    if (!rows[0]) return fallback;
    return { attributePointPrice: Number(rows[0].attributePointPrice), skillLevelPrice: Number(rows[0].skillLevelPrice) };
  };
  const characterGrowth = options.db ? new CharacterGrowthService({
    db: options.db,
    readSettings: () => readCharacterGrowth(),
    players: async () => (await options.clients()).ggcon.players(),
    modifyPlayer: async (payload) => {
      const config = await store.read();
      return modifyScumPlayer({ ...payload, serverDirectory: config.ggcon?.serverDirectory });
    }
  }) : null;

  app.disable('x-powered-by');
  const publicRoot = path.join(root, 'public');
  const shopRoot = path.join(publicRoot, 'shop');
  const notFoundPage = path.join(shopRoot, 'pages', 'errors', 'not-found', 'index.html');
  const setStaticAssetCache = (res) => {
    const versioned = /(?:\?|&)v=\d{8,}(?:&|$)/.test(res.req.originalUrl || '');
    res.setHeader('Cache-Control', versioned
      ? 'public, max-age=31536000, immutable'
      : 'public, max-age=0, must-revalidate');
  };
  const jsonParser = express.json({ limit: '64kb', verify: (req, res, buffer) => { req.rawBody = Buffer.from(buffer); } });
  const rawImagePaths = new Set(['/api/website/background', '/api/products/image', '/api/lottery/pools/image', '/api/gifts/image']);
  app.use((req, res, next) => {
    if (req.method === 'GET' && (req.path === '/' || req.path === '/shop' || req.path === '/shop/')) options.storefrontActivity?.mark?.();
    next();
  });
  app.use((req, res, next) => rawImagePaths.has(req.path) ? next() : jsonParser(req, res, next));
  const sendStorefrontShell = (req, res) => {
    res.set('Cache-Control', 'no-store');
    res.sendFile(path.join(shopRoot, 'index.html'));
  };
  app.get(/^\/$/, sendStorefrontShell);
  app.get(/^\/shop$/, (req, res) => res.redirect(301, '/shop/'));
  app.get(/^\/shop\/$/, sendStorefrontShell);
  app.get(/^\/admin$/, (req, res) => res.redirect(301, '/admin/'));
  app.get(/^\/admin\/$/, (req, res) => { res.set('Cache-Control', 'no-store'); res.sendFile(path.join(publicRoot, 'index.html')); });
  app.use('/admin', express.static(publicRoot, { index: false, setHeaders: setStaticAssetCache }));
  app.use('/shop', express.static(shopRoot, { index: false, setHeaders: setStaticAssetCache }));
  app.use(express.static(publicRoot, { index: false, setHeaders: setStaticAssetCache }));
  app.use((req, res, next) => {
    if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) || req.path === '/api/callback/orders') return next();
    const origin = req.get('origin');
    if (!origin) return next();
    try {
      if (new URL(origin).host !== req.get('host')) return res.status(403).json({ success: false, message: 'Origin 校验失败', code: 'INVALID_ORIGIN' });
    } catch { return res.status(403).json({ success: false, message: 'Origin 校验失败', code: 'INVALID_ORIGIN' }); }
    next();
  });

  let cachedClients = null;
  let cachedSignature = '';
  const clients = options.clients || (async () => {
    const config = await store.read();
    const signature = JSON.stringify({ gsm3: config.gsm3, ggcon: config.ggcon, serverDirectory: config.ggcon?.serverDirectory, reconnect: config.reconnect, instanceId: config.fulfillment.instanceId });
    if (cachedClients && cachedSignature === signature) return { config, ...cachedClients };
    cachedClients?.ggcon.close();
    const gsm3 = new Gsm3Client(config.gsm3, config.reconnect);
    cachedClients = { gsm3, ggcon: new GgconClient(config.ggcon, config.reconnect, { gsm3, instanceId: config.fulfillment.instanceId, logger }) };
    cachedSignature = signature;
    return { config, ...cachedClients };
  });
  if (!vehicleInsuranceShop && options.db) vehicleInsuranceShop = new VehicleInsuranceShopService({
    db: options.db,
    isPlayerOnline: async (steamId) => {
      const { ggcon } = await clients();
      const players = await ggcon.players({ priority: 'high' });
      return players.some((player) => String(player.steamId) === String(steamId));
    }
  });
  if (!teleport && options.db && commerce) teleport = new TeleportService({ db: options.db, clients, snapshotStore: options.teleportSnapshotStore, membershipEntitlements: (steamId) => commerce.membershipEntitlements(steamId) });
  if (!chatAutoReplies && options.db) chatAutoReplies = new ChatAutoReplyService({ db: options.db, store, clients, logger });
  if (!cloudWarehouse && options.db) cloudWarehouse = new CloudWarehouseService(options.db, { clients, logger });
  if (!chatGiftClaims && options.db) chatGiftClaims = new ChatGiftClaimService({ db: options.db, gifts, cloudWarehouse });
  if (!playerAdminCapabilities && options.db) playerAdminCapabilities = new PlayerAdminCapabilityService({ db: options.db, clients });
  if (!playerAdmin && options.db && playerAdminCapabilities) playerAdmin = new PlayerAdminService({ db: options.db, clients, capabilityService: playerAdminCapabilities });
  const publicBridgeValue = (value) => {
    if (Array.isArray(value)) return value.map(publicBridgeValue);
    if (!value || typeof value !== 'object') return value;
    return Object.fromEntries(Object.entries(value)
      .filter(([key]) => !/(?:key|secret|password|token|authorization|pipe|endpoint|path)/i.test(key))
      .map(([key, item]) => [key, publicBridgeValue(item)]));
  };
  const fulfillmentCapabilities = (capabilities = {}) => ({
    players: capabilities.players === true,
    command: capabilities.command === true,
    giveItem: capabilities.giveItem === true || capabilities.item === true || capabilities.items === true
  });
  const hasFulfillmentCapabilities = (capabilities) => {
    const required = fulfillmentCapabilities(capabilities);
    return required.players && (required.command || required.giveItem);
  };
  const degradedReason = (connected, capabilities = {}) => {
    if (!connected) return 'SCUM 商城桥接未连接';
    const required = fulfillmentCapabilities(capabilities);
    const missing = [];
    if (!required.players) missing.push('玩家查询');
    if (!required.command && !required.giveItem) missing.push('物品发放');
    return missing.length ? `桥接在线，但${missing.join('、')}能力未接入` : null;
  };
  const readBridgeStatus = async () => {
    const checkedAt = Date.parse(latestBridgeStatus?.checkedAt || '');
    if (Number.isFinite(checkedAt) && Date.now() - checkedAt < 2000) return latestBridgeStatus;
    if (bridgeStatusPending) return bridgeStatusPending;
    bridgeStatusPending = (async () => {
    let mode = 'unknown';
    try {
      const { config, ggcon } = await clients();
      mode = config?.ggcon?.mode || ggcon?.config?.mode || 'unknown';
      const health = publicBridgeValue(redact(await ggcon.health()));
      const capabilities = publicBridgeValue(redact(await ggcon.capabilities()));
      const connected = true;
      const readyForFulfillment = connected && hasFulfillmentCapabilities(capabilities);
      latestBridgeStatus = { mode, connected, health, capabilities, readyForFulfillment, degradedReason: degradedReason(connected, capabilities), checkedAt: new Date().toISOString() };
    } catch (error) {
      latestBridgeStatus = { mode, connected: false, health: null, capabilities: {}, readyForFulfillment: false, degradedReason: safeMessage(error, 'SCUM 商城桥接未连接'), checkedAt: new Date().toISOString() };
    }
    return latestBridgeStatus;
    })().finally(() => { bridgeStatusPending = null; });
    return bridgeStatusPending;
  };
  const sendError = (req, res, error, fallback, code = 502) => {
    const statusCode = error instanceof ServiceError || error instanceof DomainAccessError ? error.status : (error?.response?.status && error.response.status < 500 ? error.response.status : code);
    const details = redact({ component: 'http', event: 'request_failed', method: req?.method, path: req?.path, error: error?.message, code: error?.code, statusCode, upstreamStatus: error?.response?.status });
    if (statusCode >= 500 && !(error instanceof ServiceError)) logger.error?.(fallback, details);
    else if (statusCode >= 500 || [409, 423, 429].includes(statusCode)) logger.warn?.(fallback, details);
    else logger.debug?.(fallback, details);
    res.status(statusCode).json({ success: false, message: safeMessage(error, fallback), code: error?.code });
  };
  const service = (handler) => async (req, res) => {
    try { await handler(req, res); } catch (error) { sendError(req, res, error, '商城服务请求失败', 500); }
  };
  const requireAuth = () => {
    if (!auth) throw new ServiceError('商城数据库服务未就绪', 503, 'NOT_READY');
    return auth;
  };
  const requireCommerce = () => {
    if (!commerce) throw new ServiceError('商城数据库服务未就绪', 503, 'NOT_READY');
    return commerce;
  };
  const requireGifts = () => {
    if (!gifts) throw new ServiceError('礼包数据库服务未就绪', 503, 'NOT_READY');
    return gifts;
  };
  const requireRedeemCodes = () => {
    if (!redeemCodes) throw new ServiceError('兑换码数据库服务未就绪', 503, 'NOT_READY');
    return redeemCodes;
  };
  const requireRewards = () => {
    if (!rewards) throw new ServiceError('奖励数据库服务未就绪', 503, 'NOT_READY');
    return rewards;
  };
  const requireActivities = () => { if (!activities) throw new ServiceError('活动服务未就绪', 503, 'NOT_READY'); return activities; };
  const requireLottery = () => { if (!lottery) throw new ServiceError('抽奖服务未就绪', 503, 'NOT_READY'); return lottery; };
  const requireStockMarket = () => { if (!stockMarket) throw new ServiceError('股市服务未就绪', 503, 'NOT_READY'); return stockMarket; };
  const requireCloudWarehouse = () => { if (!cloudWarehouse) throw new ServiceError('云储仓库服务未就绪', 503, 'NOT_READY'); return cloudWarehouse; };
  const requireVehicleManagement = () => { if (!vehicleManagement) throw new ServiceError('保险管理服务未就绪', 503, 'NOT_READY'); return vehicleManagement; };
  const requireVehicleInsuranceShop = () => { if (!vehicleInsuranceShop) throw new ServiceError('载具保险服务未就绪', 503, 'NOT_READY'); return vehicleInsuranceShop; };
  const requireVehicleLimit = () => { if (!vehicleLimit) throw new ServiceError('载具数量治理服务未就绪', 503, 'NOT_READY'); return vehicleLimit; };
  const requireTeleportMap = () => { if (!teleportMap) throw new ServiceError('传送地图服务未就绪', 503, 'NOT_READY'); return teleportMap; };
  const requireTeleport = () => { if (!teleport) throw new ServiceError('商城传送服务未就绪', 503, 'NOT_READY'); return teleport; };
  const requirePlayerAdmin = () => { if (!playerAdmin || !playerAdminCapabilities) throw new ServiceError('玩家管理服务未就绪', 503, 'NOT_READY'); return playerAdmin; };
  const requireKillRanking = () => { if (!killRanking) throw new ServiceError('SCUM 日志排行服务未就绪', 503, 'NOT_READY'); return killRanking; };
  const requireChatGiftClaims = () => { if (!chatGiftClaims) throw new ServiceError('SCUM 聊天日志服务未就绪', 503, 'NOT_READY'); return chatGiftClaims; };
  const shop = (handler) => service(async (req, res) => {
    const user = await requireAuth().authenticate(cookies(req).shop_session);
    if (!user || !authInternals.SHOP_ROLES.includes(user.role) || !/^\d{17}$/.test(String(user.steamId || ''))) throw new ServiceError('请先登录', 401, 'UNAUTHORIZED');
    req.user = user;
    await handler(req, res);
  });

  const admin = (handler) => service(async (req, res) => {
    if (legacyAdmin) return handler(req, res);
    if (!auth) throw new ServiceError('管理员认证服务未就绪', 503, 'NOT_READY');
    const user = await auth.authenticate(cookies(req).admin_session, authInternals.ADMIN_ROLES);
    if (!user) throw new ServiceError('管理员未登录', 401, 'UNAUTHORIZED');
    const permission = adminPermissionFor(req.originalUrl || req.url);
    if (user.role !== 'super_admin' && permission && !user.adminPermissions?.includes(permission)) throw new ServiceError('当前管理员没有该功能权限', 403, 'ADMIN_PERMISSION_REQUIRED');
    req.user = user;
    await handler(req, res);
  });
  const setSession = (res, name, session) => res.setHeader('Set-Cookie', `${name}=${encodeURIComponent(session.token)}; ${COOKIE_OPTIONS}${options.secureCookies ? '; Secure' : ''}`);
  const clearSession = (res, name) => res.setHeader('Set-Cookie', `${name}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${options.secureCookies ? '; Secure' : ''}`);
  const authLimit = limiter({ windowMs: 15 * 60 * 1000, max: 10 });
  const challengeLimit = limiter({ windowMs: 10 * 60 * 1000, max: 5 });
  const redeemClaimLimit = limiter({ windowMs: 10 * 60 * 1000, max: 20 });
  const checkinLimit = limiter({ windowMs: 10 * 60 * 1000, max: 20 });
  const lotteryLimit = limiter({ windowMs: 10 * 60 * 1000, max: 30 });
  const stockTradeLimit = limiter({ windowMs: 10 * 60 * 1000, max: 60 });
  const cloudTradeLimit = limiter({ windowMs: 10 * 60 * 1000, max: 60 });
  const teleportReadLimit = limiter({ windowMs: 10 * 60 * 1000, max: 120 });
  const teleportActionLimit = limiter({ windowMs: 10 * 60 * 1000, max: 30 });
  const playerAdminActionLimit = limiter({ windowMs: 10 * 60 * 1000, max: 20 });
  const playerAdminProbeLimit = limiter({ windowMs: 5 * 60 * 1000, max: 10 });
  const playerAdminVerifyLimit = limiter({ windowMs: 10 * 60 * 1000, max: 30 });
  const domainAccessLimit = limiter({ windowMs: 60 * 1000, max: 5 });
  const domainAccessStatusLimit = limiter({ windowMs: 60 * 1000, max: 30 });
  const requireStrictSameOrigin = (req, res, next) => {
    const origin = req.get('origin');
    try {
      if (!origin || new URL(origin).host !== req.get('host')) return res.status(403).json({ success: false, message: 'Origin 校验失败', code: 'INVALID_ORIGIN' });
    } catch { return res.status(403).json({ success: false, message: 'Origin 校验失败', code: 'INVALID_ORIGIN' }); }
    next();
  };

  app.get('/api/domain-access/status', domainAccessStatusLimit, admin(async (req, res) => {
    if (req.user?.role !== 'super_admin') throw new ServiceError('仅超级管理员可以查看域名状态', 403, 'SUPER_ADMIN_REQUIRED');
    try { res.json({ success: true, data: await domainAccessStatus() }); }
    catch (error) { throw new ServiceError('暂时无法读取域名状态', 502, 'DOMAIN_ACCESS_STATUS_UNAVAILABLE', { cause: error }); }
  }));

  app.post('/api/domain-access/handoff', requireStrictSameOrigin, domainAccessLimit, admin(async (req, res) => {
    if (req.user?.role !== 'super_admin') throw new ServiceError('仅超级管理员可以进入域名接入中心', 403, 'SUPER_ADMIN_REQUIRED');
    if (!req.body || Array.isArray(req.body) || Object.keys(req.body).length !== 0) throw new ServiceError('该接口不接受客户端参数', 400, 'DOMAIN_ACCESS_BODY_NOT_ALLOWED');
    res.json({ success: true, data: await domainAccess.handoff(req.user.username) });
  }));

  app.get('/api/health', async (req, res) => {
    res.set('X-SCUM-Upstream-Bound', '1');
    const pending = readBridgeStatus();
    const bridge = await Promise.race([pending, new Promise((resolve) => setTimeout(() => resolve(latestBridgeStatus), 750))]);
    let maintenance = { worker: maintenanceStatus(), fulfillmentPaused: false, current: null };
    if (maintenanceService) {
      try {
        const current = await maintenanceService.current();
        maintenance = { worker: maintenanceStatus(), fulfillmentPaused: current.fulfillmentPaused, current: current.active ? { id: current.active.id, state: current.active.state, scheduledAt: current.active.scheduledAt } : null };
      } catch { maintenance = { ...maintenance, worker: maintenanceStatus(), unavailable: true }; }
    }
    let playerAdminHealth = { capabilities: null, temporaryBan: temporaryBanStatus() };
    if (playerAdminCapabilities) { try { playerAdminHealth.capabilities = await playerAdminCapabilities.latest(); } catch { playerAdminHealth.unavailable = true; } }
    res.json({ success: true, data: { status: 'ok', uptime: Math.floor((Date.now() - startedAt) / 1000), version: appVersion, releaseRevision, connections: { ...status, bridge }, worker: workerStatus(), monitor: monitorStatus(), maintenance, stockMarket: stockMarketStatus(), scumLogs: scumLogStatus(), chatLogs: chatLogStatus(), playerAdmin: playerAdminHealth } });
  });

  app.post('/api/shop/auth/challenge', challengeLimit, service(async (req, res) => {
    const authService = requireAuth();
    const steamId = String(req.body?.steamId || '');
    const { config, ggcon } = await clients();
    const players = await ggcon.players();
    if (!players.some((player) => player.steamId === steamId)) throw new ServiceError('玩家当前不在线', 409, 'PLAYER_OFFLINE');
    const code = await authService.createChallenge(steamId);
    const command = buildMessageCommand({ steamId, message: formatGameMessage(config, `商城注册验证码 ${code}，10分钟内有效，请勿泄露`) }, config.commandPolicy);
    await ggcon.command(command);
    res.json({ success: true, message: '验证码已发送至游戏内' });
  }));
  app.post('/api/shop/auth/register', authLimit, service(async (req, res) => {
    const result = await requireAuth().register(req.body || {}, metadata(req));
    setSession(res, 'shop_session', result.session);
    res.status(201).json({ success: true, data: result.user });
  }));
  app.post('/api/shop/auth/password-challenge', challengeLimit, service(async (req, res) => {
    const steamId = String(req.body?.steamId || '');
    const { config, ggcon } = await clients();
    const players = await ggcon.players();
    if (!players.some((player) => player.steamId === steamId)) throw new ServiceError('玩家当前不在线', 409, 'PLAYER_OFFLINE');
    const code = await requireAuth().createChallenge(steamId, 'password-reset');
    await ggcon.command(buildMessageCommand({ steamId, message: formatGameMessage(config, `商城密码重置验证码 ${code}，10分钟内有效，请勿泄露`) }, config.commandPolicy));
    res.json({ success: true, message: '验证码已发送至游戏内' });
  }));
  app.post('/api/shop/auth/reset-password', authLimit, service(async (req, res) => {
    await requireAuth().resetPassword(req.body || {});
    clearSession(res, 'shop_session');
    res.json({ success: true });
  }));
  app.post('/api/shop/auth/change-password', authLimit, shop(async (req, res) => {
    await requireAuth().changePassword(req.user.id, req.body || {});
    clearSession(res, 'shop_session');
    res.json({ success: true });
  }));
  app.post('/api/shop/auth/login', authLimit, service(async (req, res) => {
    const result = await requireAuth().login(req.body || {}, metadata(req), { roles: authInternals.SHOP_ROLES, requireSteamId: true });
    setSession(res, 'shop_session', result.session);
    res.json({ success: true, data: result.user });
  }));
  app.get('/api/shop/auth/me', shop(async (req, res) => {
    const authService = requireAuth();
    if (typeof authService.touchShopVisit === 'function') await authService.touchShopVisit(req.user.id);
    res.json({ success: true, data: req.user });
  }));
  app.post('/api/shop/activity', shop(async (req, res) => {
    options.storefrontActivity?.mark?.();
    res.json({ success: true });
  }));
  app.post('/api/shop/auth/logout', service(async (req, res) => { await requireAuth().logout(cookies(req).shop_session); clearSession(res, 'shop_session'); res.json({ success: true }); }));
  app.get('/api/shop/config', service(async (req, res) => {
    const config = await store.read();
    const fallback = config.website?.backgroundImage || '';
    const rows = options.db ? await options.db.query('SELECT background_image FROM `系统配置` WHERE setting_key = ?', ['default']) : [];
    res.json({ success: true, data: { website: { backgroundImage: rows[0]?.background_image || fallback }, characterGrowth: await readCharacterGrowth(config.characterGrowth) } });
  }));
  app.get('/api/shop/products', service(async (req, res) => res.json({ success: true, data: await requireCommerce().listProducts({ includeDisabled: false, publicView: true }) })));
  app.get('/api/shop/membership/strategies', service(async (req, res) => res.json({ success: true, data: await requireCommerce().listMembershipStrategies({ publicView: true }) })));
  app.get('/api/shop/membership/policy', service(async (req, res) => res.json({ success: true, data: await requireCommerce().membershipPolicy() })));
  app.get('/api/shop/membership/entitlements', shop(async (req, res) => res.json({ success: true, data: await requireCommerce().membershipEntitlements(req.user.steamId) })));
  app.post('/api/shop/membership/purchase/:level', shop(async (req, res) => { const key=String(req.get('Idempotency-Key')||'').trim();if(!key)throw new ServiceError('Idempotency-Key 必填');const data=await requireCommerce().purchaseMembership(req.user.steamId,req.params.level,key);res.status(data.idempotent?200:201).json({success:true,data}); }));
  app.get('/api/shop/gifts', shop(async (req, res) => res.json({ success: true, data: await requireGifts().listVisible(req.user.steamId, req.user.memberLevel) })));
  app.get('/api/shop/vehicle-insurance', shop(async (req, res) => res.json({ success: true, data: await requireVehicleInsuranceShop().overview(req.user.steamId) })));
  app.get('/api/shop/teleport/map', teleportReadLimit, shop(async (req, res) => res.json({ success: true, data: await requireTeleportMap().overview(req.user.steamId) })));
  app.get('/api/shop/teleport', teleportReadLimit, shop(async (req, res) => res.json({ success: true, data: await requireTeleport().overview(req.user.steamId) })));
  app.post('/api/shop/teleport/quote', teleportReadLimit, shop(async (req, res) => {
    const payload = req.body || {};
    if (Object.keys(payload).some((key) => !['targetType', 'targetId', 'destinationId'].includes(key))) throw new ServiceError('报价请求仅允许目标类型、目标引用与不透明目的地引用', 400, 'UNSAFE_TELEPORT_INPUT');
    res.json({ success: true, data: await requireTeleport().quote(req.user.steamId, payload) });
  }));
  app.post('/api/shop/teleport', teleportActionLimit, shop(async (req, res) => {
    const payload = req.body || {};
    if (Object.keys(payload).some((key) => !['targetType', 'targetId', 'destinationId', 'quoteToken'].includes(key))) throw new ServiceError('请求仅允许目标、目的地与报价令牌', 400, 'UNSAFE_TELEPORT_INPUT');
    const quoteToken = String(payload.quoteToken || '').trim();
    if (!quoteToken) throw new ServiceError('请先计算传送距离和费用', 409, 'TELEPORT_QUOTE_REQUIRED');
    const target = { targetType: payload.targetType, targetId: payload.targetId };
    if (Object.hasOwn(payload, 'destinationId')) target.destinationId = payload.destinationId;
    const execution = requireTeleport().execute(req.user.steamId, target, req.get('Idempotency-Key'), quoteToken);
    const pending = Symbol('teleport-pending');
    let timer;
    const data = await Promise.race([
      execution,
      new Promise((resolve) => { timer = setTimeout(() => resolve(pending), teleportInitialWaitMs); })
    ]).finally(() => clearTimeout(timer));
    if (data === pending) return res.status(202).json({ success: true, data: { status: 'processing' } });
    if (data.status === 'failed') return res.status(502).json({ success: false, code: data.errorCode || 'TELEPORT_FAILED', message: data.errorMessage || '传送失败，余额预留已释放', data });
    const accepted = ['prepared', 'success_pending_persistence', 'command_result_unknown', 'manual_review'].includes(data.status);
    res.status(accepted ? 202 : data.idempotent ? 200 : 201).json({ success: true, data: data.status === 'prepared' ? { ...data, status: 'processing' } : data });
  }));
  app.post('/api/shop/vehicle-insurance/purchase', cloudTradeLimit, shop(async (req, res) => { const data = await requireVehicleInsuranceShop().purchase(req.user.steamId, req.body || {}, req.get('Idempotency-Key')); res.status(data.receipt?.idempotent ? 200 : 201).json({ success: true, data }); }));
  app.post('/api/shop/vehicle-insurance/claim', cloudTradeLimit, shop(async (req, res) => { const data = await requireVehicleInsuranceShop().claim(req.user.steamId, req.body || {}, req.get('Idempotency-Key')); res.status(data.claim?.idempotent ? 200 : 201).json({ success: true, data }); }));
  app.get('/api/shop/rewards/status', shop(async (req, res) => res.json({ success: true, data: await requireRewards().status(req.user.steamId) })));
  app.get('/api/shop/activities/current', service(async (req, res) => res.json({ success: true, data: await requireActivities().current() })));
  app.get('/api/shop/lottery/pools/:id/public', service(async (req,res)=>res.json({success:true,data:await requireLottery().publicPool(req.params.id,null,req.query.activityId)})));
  app.get('/api/shop/lottery/pools/:id', shop(async (req,res)=>res.json({success:true,data:await requireLottery().publicPool(req.params.id,req.user.steamId,req.query.activityId)})));
  app.post('/api/shop/lottery/pools/:id/draw', lotteryLimit, shop(async(req,res)=>{const key=String(req.get('Idempotency-Key')||'').trim();if(!key)throw new ServiceError('Idempotency-Key 必填');const data=await requireLottery().draw(req.params.id,req.user.steamId,req.body?.count,key,req.body?.activityId ?? req.query.activityId);res.status(data.idempotent?200:201).json({success:true,data});}));
  app.get('/api/shop/lottery/history', shop(async(req,res)=>res.json({success:true,data:await requireLottery().history(req.user.steamId,{limit:req.query.limit})})));
  app.get('/api/shop/market/quotes', service(async(req,res)=>res.json({success:true,data:await requireStockMarket().quotes()})));
  app.get('/api/shop/market/public-overview', service(async(req,res)=>res.json({success:true,data:await requireStockMarket().overview()})));
  app.get('/api/shop/market/overview', shop(async(req,res)=>res.json({success:true,data:await requireStockMarket().overview(req.user.steamId)})));
  app.get('/api/shop/market/stocks/:id/history', service(async(req,res)=>res.json({success:true,data:await requireStockMarket().history(req.params.id,{limit:req.query.limit===undefined?100:req.query.limit,enabledOnly:true})})));
  app.get('/api/shop/market/stocks/:id/candles', service(async(req,res)=>res.json({success:true,data:await requireStockMarket().candles(req.params.id,{period:req.query.period,limit:req.query.limit,enabledOnly:true})})));
  app.get('/api/shop/market/watchlist', shop(async(req,res)=>res.json({success:true,data:await requireStockMarket().watchlist(req.user.steamId)})));
  app.put('/api/shop/market/watchlist/:id', shop(async(req,res)=>res.json({success:true,data:await requireStockMarket().setWatch(req.user.steamId,req.params.id,true)})));
  app.delete('/api/shop/market/watchlist/:id', shop(async(req,res)=>res.json({success:true,data:await requireStockMarket().setWatch(req.user.steamId,req.params.id,false)})));
  app.get('/api/shop/market/announcements', shop(async(req,res)=>res.json({success:true,data:await requireStockMarket().announcements(true)})));
  app.get('/api/shop/market/portfolio', shop(async(req,res)=>res.json({success:true,data:await requireStockMarket().portfolio(req.user.steamId)})));
  app.get('/api/shop/market/trades', shop(async(req,res)=>res.json({success:true,data:await requireStockMarket().trades(req.user.steamId,{limit:req.query.limit})})));
  for(const direction of ['buy','sell']) app.post(`/api/shop/market/stocks/:id/${direction}`, stockTradeLimit, shop(async(req,res)=>{const key=String(req.get('Idempotency-Key')||'').trim();if(!key)throw new ServiceError('Idempotency-Key 必填');const data=await requireStockMarket().trade(req.params.id,req.user.steamId,direction,req.body?.quantity,key);res.status(data.idempotent?200:201).json({success:true,data});}));
  app.get('/api/shop/cloud-warehouse', shop(async(req,res)=>res.json({success:true,data:{settings:await requireCloudWarehouse().settings(),quota:await requireCloudWarehouse().quota(req.user.steamId),passPlans:await requireCloudWarehouse().passPlans(),passes:await requireCloudWarehouse().passes(req.user.steamId),inventory:await requireCloudWarehouse().inventory(req.user.steamId),trades:await requireCloudWarehouse().trades(req.user.steamId,50)}})));
  app.post('/api/shop/cloud-passes/:type/buy', cloudTradeLimit, shop(async(req,res)=>res.json({success:true,data:await requireCloudWarehouse().buyPass(req.user.steamId,req.params.type,req.get('Idempotency-Key'))})));
  app.post('/api/shop/cloud-warehouse/recycle', cloudTradeLimit, shop(async(req,res)=>res.status(201).json({success:true,data:await requireCloudWarehouse().recycle(req.user.steamId,req.body?.itemId)})));
  app.post('/api/shop/cloud-warehouse/recycle/inspect', shop(async(req,res)=>res.json({success:true,data:await requireCloudWarehouse().inspect(req.user.steamId,req.body?.itemId)})));
  app.get('/api/shop/cloud-market', shop(async(req,res)=>res.json({success:true,data:await requireCloudWarehouse().market(req.query)})));
  app.post('/api/shop/cloud-inventory/bulk-withdraw-preview', shop(async(req,res)=>res.json({success:true,data:await requireCloudWarehouse().withdrawManyPreview(req.user.steamId,req.body||{})})));
  app.post('/api/shop/cloud-inventory/bulk-withdraw', cloudTradeLimit, shop(async(req,res)=>res.json({success:true,data:await requireCloudWarehouse().withdrawMany(req.user.steamId,req.body||{})})));
  app.post('/api/shop/cloud-inventory/bulk-destroy-preview', shop(async(req,res)=>res.json({success:true,data:await requireCloudWarehouse().destroyManyPreview(req.user.steamId,req.body||{})})));
  app.post('/api/shop/cloud-inventory/bulk-destroy', cloudTradeLimit, shop(async(req,res)=>res.status(201).json({success:true,data:await requireCloudWarehouse().destroyMany(req.user.steamId,req.body||{})})));
  app.post('/api/shop/cloud-inventory/:id/list', shop(async(req,res)=>res.status(201).json({success:true,data:await requireCloudWarehouse().list(req.user.steamId,req.params.id,req.body||{})})));
  app.post('/api/shop/cloud-inventory/:id/withdraw', cloudTradeLimit, shop(async(req,res)=>res.json({success:true,data:await requireCloudWarehouse().withdraw(req.user.steamId,req.params.id,req.body||{})})));
  app.get('/api/shop/cloud-inventory/:id/destroy-preview', shop(async(req,res)=>res.json({success:true,data:await requireCloudWarehouse().destroyPreview(req.user.steamId,req.params.id)})));
  app.post('/api/shop/cloud-inventory/:id/destroy', cloudTradeLimit, shop(async(req,res)=>{const data=await requireCloudWarehouse().destroy(req.user.steamId,req.params.id);res.status(data.idempotent?200:201).json({success:true,data});}));
  app.post('/api/shop/cloud-listings/:id/cancel', shop(async(req,res)=>res.json({success:true,data:await requireCloudWarehouse().cancel(req.user.steamId,req.params.id)})));
  app.post('/api/shop/cloud-listings/:id/buy', cloudTradeLimit, shop(async(req,res)=>{const key=String(req.get('Idempotency-Key')||'').trim();if(!key)throw new ServiceError('Idempotency-Key 必填');const data=await requireCloudWarehouse().buy(req.user.steamId,req.params.id,req.body||{},key);res.status(data.idempotent?200:201).json({success:true,data});}));
  app.post('/api/shop/checkins', checkinLimit, shop(async (req, res) => {
    const requestKey = String(req.get('Idempotency-Key') || '').trim();
    if (!requestKey) throw new ServiceError('Idempotency-Key 必填');
    const data = await requireRewards().checkIn(req.user.steamId, requestKey);
    res.status(data.idempotent ? 200 : 201).json({ success: true, data });
  }));
  app.post('/api/shop/rewards/online/claim', checkinLimit, shop(async (req, res) => {
    const requestKey = String(req.get('Idempotency-Key') || '').trim();
    if (!requestKey) throw new ServiceError('Idempotency-Key 必填');
    const data = await requireRewards().claimOnlineRewards(req.user.steamId, requestKey);
    res.status(data.idempotent ? 200 : 201).json({ success: true, data });
  }));
  app.post('/api/shop/gifts/:id/claim', shop(async (req, res) => {
    const requestKey = String(req.get('Idempotency-Key') || '').trim();
    if (!requestKey) throw new ServiceError('Idempotency-Key 必填');
    const data = await requireGifts().claim(req.params.id, req.user.steamId, req.user.memberLevel, requestKey);
    res.status(data.idempotent ? 200 : 201).json({ success: true, data });
  }));
  app.post('/api/shop/redeem-codes/claim', redeemClaimLimit, shop(async (req, res) => {
    const requestKey = String(req.get('Idempotency-Key') || '').trim();
    if (!requestKey) throw new ServiceError('Idempotency-Key 必填');
    const data = await requireRedeemCodes().claim(req.body?.code, req.user.steamId, req.user.memberLevel, requestKey);
    res.status(data.idempotent ? 200 : 201).json({ success: true, data });
  }));
  app.get('/api/shop/starter-gift', shop(async (req, res) => {
    const rows = (await requireGifts().listVisible(req.user.steamId, req.user.memberLevel)).filter((gift) => gift.name === '新手礼包');
    if (!rows[0]) throw new ServiceError('新手礼包不存在或不可用', 404, 'NOT_FOUND');
    res.json({ success: true, data: rows[0] });
  }));
  app.post('/api/shop/starter-gift/claim', shop(async (req, res) => {
    const rows = (await requireGifts().listVisible(req.user.steamId, req.user.memberLevel)).filter((gift) => gift.name === '新手礼包');
    if (!rows[0]) throw new ServiceError('新手礼包不存在或不可用', 404, 'NOT_FOUND');
    const requestKey = String(req.get('Idempotency-Key') || crypto.randomUUID()).trim();
    const data = await requireGifts().claim(rows[0].id, req.user.steamId, req.user.memberLevel, requestKey);
    res.status(data.idempotent ? 200 : 201).json({ success: true, data });
  }));
  app.get('/api/shop/account', shop(async (req, res) => {
    const config = await store.read();
    const account = await requireCommerce().getAccount(req.user.steamId);
    let gameProfile = null;
    try { gameProfile = await modifyScumPlayer({ action: 'read', serverDirectory: config.ggcon?.serverDirectory, steamId: req.user.steamId }); }
    catch (error) { logger.warn('玩家角色档案读取失败，账户余额继续返回', { steamId: req.user.steamId, code: error?.code || error?.name || 'PROFILE_READ_FAILED' }); }
    res.json({ success: true, data: { ...account, gameProfile } });
  }));
  app.get('/api/shop/account/exchange-config', shop(async (req, res) => {
    const config = await store.read();
    res.json({ success: true, data: config.exchange });
  }));
  app.post('/api/shop/account/exchange', shop(async (req, res) => {
    const requestKey = String(req.get('Idempotency-Key') || '').trim();
    if (!requestKey) throw new ServiceError('Idempotency-Key 必填', 400, 'INVALID_IDEMPOTENCY_KEY');
    const clientSet = await clients();
    const config = clientSet.config || await store.read();
    const data = await commerce.exchangeCurrency(
      req.user.steamId,
      { direction: req.body?.direction, amount: req.body?.amount, requestKey },
      clientSet.ggcon,
      config.exchange
    );
    const status = data.idempotent ? 200 : (data.status === 'uncertain' ? 202 : 201);
    res.status(status).json({ success: true, data });
  }));
  const purchaseCharacterGrowth = shop(async (req, res) => {
    if (!characterGrowth) throw new ServiceError('角色属性技能购买服务未就绪', 503, 'NOT_READY');
    const requestKey = String(req.get('Idempotency-Key') || '').trim();
    const data = await characterGrowth.purchase(req.user.steamId, req.body || {}, requestKey);
    res.status(data.idempotent ? 200 : 201).json({ success: true, data });
  });
  app.post('/api/shop/account/character-growth/purchase', purchaseCharacterGrowth);
  app.post('/api/shop/character-growth/purchase', purchaseCharacterGrowth);
  app.get('/api/shop/orders', shop(async (req, res) => res.json({ success: true, data: await commerce.listOrders(req.query.limit || 100, req.user.steamId) })));
  app.get('/api/shop/orders/:id', shop(async (req, res) => res.json({ success: true, data: await commerce.getOrder(req.params.id, req.user.steamId) })));
  app.post('/api/shop/orders', shop(async (req, res) => {
    const requestId = String(req.get('Idempotency-Key') || req.body?.requestId || '').trim();
    if (!requestId) throw new ServiceError('Idempotency-Key 或 requestId 必填');
    const data = await commerce.createOrder({ steamId: req.user.steamId, items: req.body?.items, source: 'shop', externalOrderId: requestId });
    res.status(data.idempotent ? 200 : 201).json({ success: true, data });
  }));

  app.post('/api/admin/bootstrap', authLimit, service(async () => {
    throw new ServiceError('管理员自动初始化已禁用；请先注册并绑定 SteamID，再通过服务器命令行任命超级管理员', 410, 'ADMIN_BOOTSTRAP_DISABLED');
  }));
  app.post('/api/admin/auth/login', authLimit, service(async (req, res) => {
    const binding = await options.verifyAdminAccess?.();
    const requirement = binding ? { roles: ['super_admin'], requiredUserId: binding.userId } : authInternals.ADMIN_ROLES;
    const result = await requireAuth().login(req.body || {}, metadata(req), requirement);
    setSession(res, 'admin_session', result.session);
    res.json({ success: true, data: result.user });
  }));
  app.post('/api/admin/auth/exchange', service(async (req, res) => {
    const authService = requireAuth();
    clearSession(res, 'admin_session');
    const binding = await options.verifyAdminAccess?.();
    const requirement = binding ? { roles: ['super_admin'], requiredUserId: binding.userId } : authInternals.ADMIN_ROLES;
    const user = await authService.authenticate(cookies(req).shop_session, requirement);
    if (!user || (binding && Number(user.id) !== Number(binding.userId))) throw new ServiceError('管理员未登录', 401, 'UNAUTHORIZED');
    const session = await authService.createSession(user.id, metadata(req));
    setSession(res, 'admin_session', session);
    res.json({ success: true, data: user });
  }));
  app.get('/api/admin/auth/me', admin(async (req, res) => res.json({ success: true, data: req.user })));
  app.get('/api/admin/version-update/manifest', admin(async (req, res) => res.json({ success: true, data: await versionUpdate.manifest() })));
  app.get('/api/admin/version-update/status', admin(async (req, res) => res.json({ success: true, data: await versionUpdate.status() })));
  app.post('/api/admin/version-update/start', admin(async (req, res) => res.json({ success: true, data: await versionUpdate.start() })));
  app.post('/api/admin/version-update/download', admin(async (req, res) => res.json({ success: true, data: await versionUpdate.download() })));
  app.post('/api/admin/version-update/install', admin(async (req, res) => res.json({ success: true, data: await versionUpdate.install() })));
  app.post('/api/admin/system/restart', admin(async (req, res) => {
    if (process.platform !== 'win32') throw new ServiceError('当前系统不支持商城服务重启', 409, 'RESTART_UNSUPPORTED');
    if (!fsSync.existsSync(path.join(root, 'scripts', 'restart-store.ps1'))) throw new ServiceError('缺少商城重启脚本', 500, 'RESTART_SCRIPT_MISSING');
    res.json({ success: true, message: '商城重启任务已启动' });
    setTimeout(() => scheduleStoreRestart(root).catch((error) => logger.error('商城服务重启失败', { component: 'application', error: error?.message })), 800);
  }));
  app.post('/api/admin/auth/logout', service(async (req, res) => { await requireAuth().logout(cookies(req).admin_session); clearSession(res, 'admin_session'); res.json({ success: true }); }));
  app.post('/api/admin/users/:id/promote', admin(async (req, res) => {
    const data = await requireAuth().promoteUser(req.params.id, req.body || {}, req.user);
    res.json({ success: true, data, message: data.alreadyAdmin ? '该玩家已是后台管理员' : '玩家已提升为后台管理员，现有会话已撤销' });
  }));
  app.post('/api/admin/users/authorize', admin(async (req, res) => {
    const data = await requireAuth().promoteUserBySteamId(req.body || {}, req.user);
    res.json({ success: true, data, message: data.alreadyAdmin ? '该商城用户已是后台管理员' : '商城用户已授权为后台管理员，现有会话已撤销' });
  }));
  app.get('/api/admin/users/authorized', admin(async (req, res) => res.json({ success: true, data: await requireAuth().listAdminUsers(req.user) })));
  app.put('/api/admin/users/:id/permissions', admin(async (req, res) => res.json({ success: true, data: await requireAuth().updateAdminPermissions(req.params.id, req.body || {}, req.user) })));
  app.post('/api/admin/users/:id/demote', admin(async (req, res) => {
    const data = await requireAuth().demoteUser(req.params.id, req.body || {}, req.user);
    res.json({ success: true, data, message: data.alreadyUser ? '该玩家已是普通商城用户' : '后台管理员授权已取消，现有会话已撤销' });
  }));

  const storeSettingsView = (config) => {
    const publicConfig = store.sanitize(config);
    return {
      fulfillment: {
        instanceId: publicConfig.fulfillment.instanceId,
        workerEnabled: publicConfig.fulfillment.workerEnabled,
        pollIntervalMs: publicConfig.fulfillment.pollIntervalMs,
        commandIntervalMs: publicConfig.fulfillment.commandIntervalMs,
        maxAttempts: publicConfig.fulfillment.maxAttempts,
        hasSharedSecret: publicConfig.fulfillment.hasSharedSecret
      },
      monitoring: publicConfig.monitoring
    };
  };
  const assertStoreSettingFields = (value, allowed, scope) => {
    if (value === undefined) return;
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new ServiceError(`${scope} 配置格式无效`, 400, 'INVALID_INPUT');
    const unexpected = Object.keys(value).filter((key) => !allowed.includes(key));
    if (unexpected.length) throw new ServiceError(`${scope} 包含不允许修改的字段：${unexpected.join('、')}`, 400, 'INVALID_INPUT');
  };
  app.get('/api/store-settings', admin(async (req, res) => {
    res.json({ success: true, data: storeSettingsView(await store.read()) });
  }));
  app.get('/api/store-settings/instances', admin(async (req, res) => {
    const { gsm3 } = await clients();
    const instances = await gsm3.instances();
    res.json({ success: true, data: instances.map((instance) => ({ id: String(instance.id || instance.instanceId || ''), name: String(instance.name || '未命名实例') })) });
  }));
  app.put('/api/store-settings', admin(async (req, res) => {
    const body = req.body || {};
    assertStoreSettingFields(body, ['fulfillment', 'monitoring'], '商城设置');
    assertStoreSettingFields(body.fulfillment, ['instanceId', 'sharedSecret', 'workerEnabled', 'pollIntervalMs', 'commandIntervalMs', 'maxAttempts'], '发货服务');
    assertStoreSettingFields(body.monitoring, ['enabled', 'pollIntervalMs', 'retentionDays'], '服务器监控');
    const changesSharedSecret = Boolean(String(body.fulfillment?.sharedSecret || '').trim());
    const canManageSharedSecret = req.user?.role === 'super_admin' || req.user?.adminPermissions?.includes('system');
    if (changesSharedSecret && !canManageSharedSecret) throw new ServiceError('更换订单回调共享密钥需要系统配置权限', 403, 'ADMIN_PERMISSION_REQUIRED');
    const previous = await store.read();
    if (body.fulfillment?.workerEnabled === true && previous.fulfillment.workerEnabled !== true) {
      const { ggcon } = await clients();
      let capabilities;
      try { capabilities = await ggcon.capabilities(); }
      catch (error) { throw new ServiceError(`无法启用 Worker：${safeMessage(error, '桥接能力检查失败')}`, 409, 'BRIDGE_NOT_READY'); }
      if (!hasFulfillmentCapabilities(capabilities)) throw new ServiceError(`无法启用 Worker：${degradedReason(true, capabilities)}`, 409, 'BRIDGE_NOT_READY');
    }
    const saved = await store.save({ ...(body.fulfillment ? { fulfillment: body.fulfillment } : {}), ...(body.monitoring ? { monitoring: body.monitoring } : {}) });
    try { await options.onConfigSaved?.(saved); }
    catch (error) {
      logger.error('商城设置已保存，但运行时应用失败', redact({ component: 'application', error: error?.message, code: error?.code }));
      return res.status(500).json({ success: false, message: `商城设置已保存，但运行时应用失败：${safeMessage(error, '请检查 Worker 配置或重启服务')}`, code: error?.code });
    }
    logger.info('商城设置已保存');
    res.json({ success: true, message: '商城设置已保存', data: storeSettingsView(saved) });
  }));

  app.get('/api/config', admin(async (req, res) => {
    const data = await store.publicConfig();
    const rows = options.db ? await options.db.query('SELECT background_image FROM `系统配置` WHERE setting_key = ?', ['default']) : [];
    data.website = { ...data.website, backgroundImage: rows[0]?.background_image || data.website?.backgroundImage || '' };
    data.characterGrowth = await readCharacterGrowth(data.characterGrowth);
    res.json({ success: true, data });
  }));
  const requireMaintenance = () => {
    if (!maintenanceService) throw new ServiceError('维护服务未就绪', 503, 'NOT_READY');
    return maintenanceService;
  };
  const adminActor = (req) => String(req.user?.username || req.user?.id || 'admin').slice(0, 100);
  const redeemCodeInput = (req, includeCode = false) => {
    const { code, createdBy, ...input } = req.body || {};
    return { ...input, ...(includeCode ? { code } : {}), createdBy: adminActor(req) };
  };
  const rewardRuleInput = (req) => {
    const { createdByUserId, userId, ...input } = req.body || {};
    return { ...input, createdByUserId: req.user?.id ?? null };
  };
  const maintenanceLimit = (value) => {
    if (value !== undefined && (!/^\d+$/.test(String(value)) || Number(value) < 1 || Number(value) > 100)) throw new ServiceError('limit 必须是 1-100 的整数', 400, 'INVALID_LIMIT');
    return value === undefined ? 50 : Number(value);
  };
  app.get('/api/maintenance/windows', admin(async (req, res) => res.json({ success: true, data: await requireMaintenance().list({ limit: maintenanceLimit(req.query.limit) }) })));
  app.get('/api/maintenance/current', admin(async (req, res) => {
    const data = await requireMaintenance().current();
    res.json({ success: true, data: { ...data, worker: maintenanceStatus(), history: await requireMaintenance().list({ limit: 20 }) } });
  }));
  app.get('/api/maintenance/windows/:id', admin(async (req, res) => {
    const service = requireMaintenance();
    const window = await service.get(req.params.id);
    res.json({ success: true, data: { ...window, runs: await service.runs(window.id) } });
  }));
  const createMaintenance = admin(async (req, res) => {
    const keys = Object.keys(req.body || {});
    if (keys.some((key) => /command|script|shell|powershell|startcommand|message|process/i.test(key))) throw new ServiceError('维护窗口不接受命令、消息或进程参数', 400, 'INVALID_INPUT');
    res.status(201).json({ success: true, data: await requireMaintenance().create(req.body || {}, adminActor(req)) });
  });
  app.post('/api/maintenance', createMaintenance);
  app.post('/api/maintenance/windows', createMaintenance);
  app.post('/api/maintenance/windows/:id/cancel', admin(async (req, res) => res.json({ success: true, data: await requireMaintenance().delete(req.params.id, adminActor(req)) })));
  app.post('/api/maintenance/windows/:id/begin', admin(async (req, res) => {
    const data = await requireMaintenance().beginMaintenance(req.params.id, adminActor(req));
    if (maintenanceWorker) await maintenanceWorker.sendRun(data.id, 0, new Date(data.scheduledAt), (await store.read()).maintenance.maintenanceMessage);
    res.json({ success: true, data });
  }));
  app.post('/api/maintenance/windows/:id/await-recovery', admin(async (req, res) => res.json({ success: true, data: await requireMaintenance().markAwaitingRecovery(req.params.id, adminActor(req)) })));
  app.post('/api/maintenance/windows/:id/confirm-recovered', admin(async (req, res) => {
    const data = await requireMaintenance().confirmRecovered(req.params.id, adminActor(req));
    res.json({ success: true, data });
  }));
  app.get('/api/monitor/overview', admin(async (req, res) => {
    if (!monitorService) throw new ServiceError('服务器监控服务未就绪', 503, 'NOT_READY');
    res.json({ success: true, data: await monitorService.overview(monitorStatus) });
  }));
  app.get('/api/monitor/players', admin(async (req, res) => {
    if (!monitorService) throw new ServiceError('服务器监控服务未就绪', 503, 'NOT_READY');
    res.json({ success: true, data: await monitorService.players() });
  }));
  app.get('/api/monitor/events', admin(async (req, res) => {
    if (!monitorService) throw new ServiceError('服务器监控服务未就绪', 503, 'NOT_READY');
    const rawLimit = req.query.limit;
    if (rawLimit !== undefined && (!/^\d+$/.test(String(rawLimit)) || Number(rawLimit) < 1)) throw new ServiceError('limit 必须是正整数', 400, 'INVALID_LIMIT');
    res.json({ success: true, data: await monitorService.events(rawLimit === undefined ? 50 : Math.min(Number(rawLimit), 200)) });
  }));
  app.get('/api/scum-logs/overview', admin(async (req, res) => res.json({ success: true, data: await requireKillRanking().overview(scumLogStatus) })));
  app.get('/api/scum-logs/rankings', admin(async (req, res) => res.json({ success: true, data: await requireKillRanking().rankings({ period: req.query.period, limit: req.query.limit }) })));
  app.get('/api/scum-logs/events', admin(async (req, res) => res.json({ success: true, data: await requireKillRanking().events({ limit: req.query.limit, steamId: req.query.steamId }) })));
  app.get('/api/chat-logs/overview', admin(async (req, res) => res.json({ success: true, data: await requireChatGiftClaims().overview(chatLogStatus) })));
  app.get('/api/chat-logs/events', admin(async (req, res) => res.json({ success: true, data: await requireChatGiftClaims().events({ page: req.query.page, limit: req.query.limit }) })));
  app.get('/api/chat-logs/settings', admin(async (req, res) => { const config=await store.read();res.json({success:true,data:{claimPrefix:config.chatLogs?.claimPrefix||'@',recycleCommand:config.chatLogs?.recycleCommand||'回收',autoReplyEnabled:config.chatLogs?.autoReplyEnabled===true,scumLogs:{enabled:config.scumLogs.enabled,pollIntervalMs:config.scumLogs.pollIntervalMs,retentionDays:config.scumLogs.retentionDays},chatLogs:{enabled:config.chatLogs.enabled,pollIntervalMs:config.chatLogs.pollIntervalMs,retentionDays:config.chatLogs.retentionDays}}}); }));
  app.put('/api/chat-logs/settings', admin(async (req, res) => { const current=await store.read();const chatLogs={claimPrefix:req.body?.claimPrefix===undefined?current.chatLogs.claimPrefix:String(req.body.claimPrefix).trim(),recycleCommand:req.body?.recycleCommand===undefined?current.chatLogs.recycleCommand:String(req.body.recycleCommand).trim(),enabled:req.body?.chatLogs?.enabled===undefined?current.chatLogs.enabled:Boolean(req.body.chatLogs.enabled),pollIntervalMs:req.body?.chatLogs?.pollIntervalMs===undefined?current.chatLogs.pollIntervalMs:Number(req.body.chatLogs.pollIntervalMs),retentionDays:req.body?.chatLogs?.retentionDays===undefined?current.chatLogs.retentionDays:Number(req.body.chatLogs.retentionDays),autoReplyEnabled:req.body?.autoReplyEnabled===undefined?current.chatLogs.autoReplyEnabled:Boolean(req.body.autoReplyEnabled)};const scumLogs={enabled:req.body?.scumLogs?.enabled===undefined?current.scumLogs.enabled:Boolean(req.body.scumLogs.enabled),pollIntervalMs:req.body?.scumLogs?.pollIntervalMs===undefined?current.scumLogs.pollIntervalMs:Number(req.body.scumLogs.pollIntervalMs),retentionDays:req.body?.scumLogs?.retentionDays===undefined?current.scumLogs.retentionDays:Number(req.body.scumLogs.retentionDays)};const saved=await store.save({chatLogs,scumLogs});await options.onConfigSaved?.(saved);res.json({success:true,data:{claimPrefix:saved.chatLogs.claimPrefix,recycleCommand:saved.chatLogs.recycleCommand,autoReplyEnabled:saved.chatLogs.autoReplyEnabled,scumLogs:{enabled:saved.scumLogs.enabled,pollIntervalMs:saved.scumLogs.pollIntervalMs,retentionDays:saved.scumLogs.retentionDays},chatLogs:{enabled:saved.chatLogs.enabled,pollIntervalMs:saved.chatLogs.pollIntervalMs,retentionDays:saved.chatLogs.retentionDays}}}); }));
  app.get('/api/chat-logs/auto-replies', admin(async (req,res)=>{if(!chatAutoReplies)throw new ServiceError('自动回复服务未就绪',503,'NOT_READY');res.json({success:true,data:await chatAutoReplies.list()});}));
  app.post('/api/chat-logs/auto-replies', admin(async (req,res)=>{if(!chatAutoReplies)throw new ServiceError('自动回复服务未就绪',503,'NOT_READY');res.status(201).json({success:true,data:await chatAutoReplies.save(req.body||{})});}));
  app.put('/api/chat-logs/auto-replies/:id', admin(async (req,res)=>{if(!chatAutoReplies)throw new ServiceError('自动回复服务未就绪',503,'NOT_READY');res.json({success:true,data:await chatAutoReplies.save(req.body||{},req.params.id)});}));
  app.delete('/api/chat-logs/auto-replies/:id', admin(async (req,res)=>{if(!chatAutoReplies)throw new ServiceError('自动回复服务未就绪',503,'NOT_READY');await chatAutoReplies.delete(req.params.id);res.json({success:true});}));
  app.get('/api/bridge/status', admin(async (req, res) => res.json({ success: true, data: await readBridgeStatus() })));
  app.get('/api/rcon/plugins', admin(async (req, res) => { const data = await rconPlugins.inspect(req.query.directory); res.json({ success: true, data: { ...data, sync: await rconPlugins.status() } }); }));
  app.post('/api/rcon/plugins/download', admin(async (req, res) => res.json({ success: true, data: await rconPlugins.download(req.body?.directory) })));
  app.post('/api/rcon/plugins/replace', admin(async (req, res) => {
    const data = await rconPlugins.replace(req.body?.directory);
    if (data.sync?.status === 'pending') resumeRconPluginSync();
    res.json({ success: true, data });
  }));
  app.get('/api/player-admin/capabilities', admin(async (req, res) => res.json({ success: true, data: await requirePlayerAdmin().capabilities() })));
  app.post('/api/player-admin/capabilities/probe', playerAdminProbeLimit, admin(async (req, res) => res.json({ success: true, data: await requirePlayerAdmin().probeCapabilities(), message: '只读能力探测已完成' })));
  app.get('/api/player-admin/actions', admin(async (req, res) => res.json({ success: true, data: await requirePlayerAdmin().list({ page: req.query.page, limit: req.query.limit, steamId: req.query.steamId, action: req.query.action, status: req.query.status }) })));
  app.get('/api/player-admin/actions/:id', admin(async (req, res) => res.json({ success: true, data: await requirePlayerAdmin().get(req.params.id) })));
  app.post('/api/player-admin/actions', playerAdminActionLimit, admin(async (req, res) => { const key = String(req.get('Idempotency-Key') || '').trim(); if (!key) throw new ServiceError('Idempotency-Key 必填', 400, 'INVALID_INPUT'); const { adminId, adminUserId, actor, role, ...input } = req.body || {}; const data = await requirePlayerAdmin().create(input, key, req.user); res.status(data.idempotent ? 200 : 201).json({ success: true, data, message: data.idempotent ? '返回已有操作结果' : '玩家管理操作已创建并单次投递' }); }));
  app.post('/api/player-admin/actions/:id/verify', playerAdminVerifyLimit, admin(async (req, res) => { const key = String(req.get('Idempotency-Key') || '').trim(); if (!key) throw new ServiceError('Idempotency-Key 必填', 400, 'INVALID_INPUT'); const data = await requirePlayerAdmin().verify(req.params.id, req.body || {}, key, req.user); res.status(data.idempotent ? 200 : 201).json({ success: true, data, message: '人工核查已记录，不会重新发送命令' }); }));
  const saveConfig = admin(async (req, res) => {
    try {
      const previous = await store.read();
      const enablingWorker = req.body?.fulfillment?.workerEnabled === true && previous.fulfillment.workerEnabled !== true;
      if (enablingWorker) {
        const { ggcon } = await clients();
        let capabilities;
        try { capabilities = await ggcon.capabilities(); }
        catch (error) { throw new ServiceError(`无法启用 Worker：${safeMessage(error, '桥接能力检查失败')}`, 409, 'BRIDGE_NOT_READY'); }
        if (!hasFulfillmentCapabilities(capabilities)) throw new ServiceError(`无法启用 Worker：${degradedReason(true, capabilities)}`, 409, 'BRIDGE_NOT_READY');
      }
      const input = req.body || {};
      const merged = { ...previous, website: { backgroundImage: '', ...(previous.website || {}) }, ...input };
      for (const key of Object.keys(input)) {
        if (input[key] && typeof input[key] === 'object' && !Array.isArray(input[key])) merged[key] = { ...(previous[key] || {}), ...input[key] };
      }
      const saved = await store.save(merged);
      if (options.db && input.website?.backgroundImage !== undefined) await options.db.query('INSERT INTO `系统配置` (setting_key, background_image) VALUES (?, ?) ON DUPLICATE KEY UPDATE background_image = VALUES(background_image)', ['default', saved.website.backgroundImage]);
      if (options.db && input.characterGrowth !== undefined) await options.db.query('INSERT INTO `系统配置` (setting_key,attribute_point_price,skill_level_price) VALUES (?,?,?) ON DUPLICATE KEY UPDATE attribute_point_price=VALUES(attribute_point_price),skill_level_price=VALUES(skill_level_price)', ['default', saved.characterGrowth.attributePointPrice, saved.characterGrowth.skillLevelPrice]);
      const restartRequired = JSON.stringify(previous.mysql) !== JSON.stringify(saved.mysql);
      try { await options.onConfigSaved?.(saved); }
      catch (error) {
        logger.error('配置已保存，但运行时应用失败', redact({ component: 'application', error: error?.message, code: error?.code }));
        return res.status(500).json({ success: false, message: `配置已保存，但运行时应用失败：${safeMessage(error, '请检查 Worker 配置或重启服务')}`, code: error?.code, restartRequired });
      }
      logger.info('配置已保存', { restartRequired });
      res.json({ success: true, message: '配置已保存', data: { ...store.sanitize(saved), restartRequired }, restartRequired });
    } catch (error) { sendError(req, res, error, '保存配置失败', 400); }
  });
  app.put('/api/config', saveConfig);
  app.post('/api/config', saveConfig);
  app.post('/api/connections/test', admin(async (req, res) => {
    const target = req.body?.target || 'all';
    if (!['all', 'gsm3', 'ggcon'].includes(target)) return res.status(400).json({ success: false, message: '连接测试目标无效' });
    const { gsm3, ggcon } = await clients();
    const result = {};
    for (const [name, client] of Object.entries({ gsm3, ggcon })) {
      if (target !== 'all' && target !== name) continue;
      try {
        await client.health();
        if (name === 'ggcon') {
          const capabilities = await client.capabilities();
          const readyForFulfillment = hasFulfillmentCapabilities(capabilities);
          status[name] = { ok: readyForFulfillment, connected: true, degraded: !readyForFulfillment, checkedAt: new Date().toISOString() };
          result[name] = { ok: readyForFulfillment, connected: true, degraded: !readyForFulfillment, readyForFulfillment, message: readyForFulfillment ? 'SCUM 商城桥接与游戏能力正常' : '桥接在线，游戏能力未接入' };
        } else {
          status[name] = { ok: true, checkedAt: new Date().toISOString() };
          result[name] = { ok: true, message: '连接正常' };
        }
      } catch (error) { status[name] = { ok: false, checkedAt: new Date().toISOString() }; result[name] = { ok: false, connected: false, message: safeMessage(error) }; }
    }
    const allOk = Object.values(result).every((item) => item.ok);
    const degraded = Object.values(result).some((item) => item.degraded);
    res.status(allOk || degraded ? 200 : 502).json({ success: allOk || degraded, data: result, degraded, message: degraded ? '连接测试已完成，桥接处于降级状态' : '连接测试已完成' });
  }));
  app.get('/api/gsm3/instances', admin(async (req, res) => { const { gsm3 } = await clients(); res.json({ success: true, data: await gsm3.instances() }); }));
  app.get('/api/ggcon/players', admin(async (req, res) => { const { ggcon } = await clients(); res.json({ success: true, data: await ggcon.players() }); }));
  app.post('/api/commands/message', admin(async (req, res) => { const { config, ggcon } = await clients(); let command; try { command = buildMessageCommand({ ...(req.body || {}), message: formatGameMessage(config, req.body?.message) }, config.commandPolicy); } catch (error) { throw new ServiceError(error.message); } const data = await ggcon.command(command); res.json({ success: true, data: redact(data) }); }));
  app.post('/api/commands/raw', admin(async (req, res) => { const { ggcon } = await clients(); let command; try { command = buildRawCommand(req.body || {}); } catch (error) { throw new ServiceError(error.message); } const data = await ggcon.command(command); res.json({ success: true, data: redact(data) }); }));
  app.post('/api/commands/item', admin(async (req, res) => { const { config, ggcon } = await clients(); let command; try { command = buildItemCommand(req.body || {}, config.commandPolicy); } catch (error) { throw new ServiceError(error.message); } const data = await ggcon.command(command); res.json({ success: true, data: redact(data) }); }));
  const playerAttributes = async (req, res, action) => { const { config } = await clients(); const steamId = String(req.params.steamId || ''); if (!/^\d{17}$/.test(steamId)) throw new ServiceError('SteamID格式不正确', 400, 'INVALID_STEAM_ID'); const data = await modifyScumPlayer({ action, steamId, serverDirectory: config.ggcon?.serverDirectory, attributes: req.body?.attributes || {}, skills: req.body?.skills || [] }); res.json({ success: true, data }); };
  app.get('/api/admin/players/:steamId/attributes', admin(async (req, res) => { const { config } = await clients(); const steamId = String(req.params.steamId || ''); if (!/^\d{17}$/.test(steamId)) throw new ServiceError('SteamID格式不正确', 400, 'INVALID_STEAM_ID'); res.json({ success: true, data: await modifyScumPlayer({ action: 'read', steamId, serverDirectory: config.ggcon?.serverDirectory }) }); }));
  app.post('/api/admin/players/:steamId/attributes', admin(async (req, res) => { await playerAttributes(req, res, 'write'); }));
  app.post('/api/admin/players/:steamId/gold', admin(async (req, res) => { const { ggcon } = await clients(); const amount = Number(req.body?.amount); if (!Number.isSafeInteger(amount) || amount === 0 || Math.abs(amount) > 1000000000) throw new ServiceError('金条数量必须是非零整数'); const data = await commerce.adjustGameGold(req.params.steamId, amount, ggcon); res.json({ success: true, data: redact(data) }); }));
  app.get('/api/logs', admin(async (req, res) => {
    res.json({ success: true, data: await logBrowser.list(req.query) });
  }));
  app.get('/api/dashboard', admin(async (req, res) => {
    const data = await commerce.dashboard();
    const license = licenseStore ? licenseStore.sanitize(await licenseStore.read()) : null;
    res.json({ success: true, data: { ...data, license } });
  }));
  app.get('/api/license/status', admin(async (req, res) => {
    if (!licenseStore) return res.json({ success: true, data: { activated: false } });
    try {
      const license = licenseStore.sanitize(await licenseStore.read());
      res.json({ success: true, data: { activated: true, ...license } });
    } catch (error) {
      if (error?.code === 'LICENSE_NOT_ACTIVATED') return res.json({ success: true, data: { activated: false } });
      throw error;
    }
  }));
  app.get('/api/products', admin(async (req, res) => { const data = await commerce.listProducts({ includeDisabled: req.query.enabled !== 'true' }); debugAdminList('C', 'admin products listed', { count: data.length, ids: data.map((item) => Number(item.id)) }); res.json({ success: true, data }); }));
  app.get('/api/product-categories', admin(async (req, res) => res.json({ success: true, data: await commerce.listProductCategories() })));
  app.get('/api/product-parent-categories', admin(async (req, res) => res.json({ success: true, data: await commerce.listProductParentCategories() })));
  app.post('/api/product-parent-categories', admin(async (req, res) => res.status(201).json({ success: true, data: await commerce.saveProductParentCategory(req.body || {}) })));
  app.put('/api/product-parent-categories/order', admin(async (req, res) => { await commerce.reorderProductParentCategories(req.body || {}); res.json({ success: true }); }));
  app.put('/api/product-categories/order', admin(async (req, res) => { await commerce.reorderProductCategories(req.body || {}); res.json({ success: true }); }));
  app.put('/api/product-parent-categories/:id/name', admin(async (req, res) => res.json({ success: true, data: await commerce.renameProductParentCategory(req.params.id, req.body || {}) })));
  app.delete('/api/product-parent-categories/:id', admin(async (req, res) => { await commerce.deleteProductParentCategory(req.params.id); res.json({ success: true }); }));
  app.post('/api/product-categories', admin(async (req, res) => res.status(201).json({ success: true, data: await commerce.saveProductCategory(req.body || {}) })));
  app.put('/api/product-categories/:id', admin(async (req, res) => res.json({ success: true, data: await commerce.renameProductCategory(req.params.id, req.body || {}) })));
  app.delete('/api/product-categories/:id', admin(async (req, res) => { await commerce.deleteProductCategory(req.params.id); res.json({ success: true }); }));
  app.post('/api/website/background', express.raw({ type: IMAGE_MIME_TYPES, limit: '8mb' }), admin(async (req, res) => { const mime = String(req.get('content-type') || '').split(';')[0].toLowerCase(); const imagePath = await saveUploadedImage(root, mime, req.body, 'website');
    if (options.db) await options.db.query('INSERT INTO `系统配置` (setting_key, background_image) VALUES (?, ?) ON DUPLICATE KEY UPDATE background_image = VALUES(background_image)', ['default', imagePath]);
    res.status(201).json({ success: true, data: { imagePath } }); }));
  app.post('/api/products/image', express.raw({ type: IMAGE_MIME_TYPES, limit: '2mb' }), admin(async (req, res) => {
    const mime = String(req.get('content-type') || '').split(';')[0].toLowerCase();
    const parentCategory = String(req.query.parentCategory || '').trim();
    const category = String(req.query.category || '').trim();
    if (!parentCategory || !category) throw new ServiceError('请先选择主分类和副分类');
    if (options.db) {
      const rows = await options.db.query('SELECT id FROM product_categories WHERE parent_name=? AND name=? LIMIT 1', [parentCategory, category]);
      if (!rows.length) throw new ServiceError('商品分类不存在', 404, 'NOT_FOUND');
    }
    const imagePath = await saveUploadedImage(root, mime, req.body, 'products', [parentCategory, category]);
    res.status(201).json({ success: true, data: { imagePath } });
  }));
  app.post('/api/lottery/pools/image', express.raw({ type: IMAGE_MIME_TYPES, limit: '2mb' }), admin(async (req, res) => {
    const mime = String(req.get('content-type') || '').split(';')[0].toLowerCase();
    const imagePath = await saveUploadedImage(root, mime, req.body, 'lottery');
    res.status(201).json({ success: true, data: { imagePath } });
  }));
  app.post('/api/gifts/image', express.raw({ type: IMAGE_MIME_TYPES, limit: '2mb' }), admin(async (req, res) => {
    const mime = String(req.get('content-type') || '').split(';')[0].toLowerCase();
    if (mime !== 'image/png') throw new ServiceError('礼包图片仅支持 PNG 格式');
    const giftName = String(req.query.giftName || '').trim();
    const giftType = String(req.query.giftType || '').trim();
    if (!giftName || giftName.length > 100) throw new ServiceError('请先填写礼包名称');
    const typeFolders = { normal: '普通', private: '私人', title: '称号', squad: '小队', monthly: '月度', weekly: '周度', quarterly: '季度' };
    if (!typeFolders[giftType]) throw new ServiceError('请先选择礼包类型');
    const imagePath = await saveUploadedImage(root, mime, req.body, 'gifts', [typeFolders[giftType]], giftName);
    res.status(201).json({ success: true, data: { imagePath } });
  }));
  app.post('/api/products', admin(async (req, res) => res.status(201).json({ success: true, data: await commerce.saveProduct(req.body || {}) })));
  app.put('/api/products/:id', admin(async (req, res) => res.json({ success: true, data: await commerce.saveProduct(req.body || {}, req.params.id) })));
  app.delete('/api/products/:id', admin(async (req, res) => { await commerce.deleteProduct(req.params.id); res.json({ success: true }); }));
  app.patch('/api/products/:id/status', admin(async (req, res) => { await commerce.setProductEnabled(req.params.id, req.body?.enabled); res.json({ success: true }); }));
  app.patch('/api/products/status', admin(async (req, res) => res.json({ success: true, data: await commerce.setAllProductsEnabled(req.body?.enabled) })));
  app.get('/api/gifts', admin(async (req, res) => { const data = await requireGifts().listAdmin(); debugAdminList('C', 'admin gifts listed', { count: data.length, ids: data.map((item) => Number(item.id)) }); res.json({ success: true, data }); }));
  app.get('/api/gift-types', admin(async (req, res) => res.json({ success: true, data: await requireGifts().listTypes() })));
  app.post('/api/gift-types', admin(async (req, res) => res.status(201).json({ success: true, data: await requireGifts().addType(req.body || {}) })));
  app.put('/api/gift-types/:code', admin(async (req, res) => res.json({ success: true, data: await requireGifts().updateType(req.params.code, req.body || {}) })));
  app.patch('/api/gift-types/:code/move', admin(async (req, res) => { await requireGifts().moveType(req.params.code, req.body?.direction); res.json({ success: true }); }));
  app.delete('/api/gift-types/:code', admin(async (req, res) => { await requireGifts().deleteType(req.params.code); res.json({ success: true }); }));
  app.get('/api/gift-claims', admin(async (req, res) => res.json({ success: true, data: await requireCommerce().listGiftClaims(req.query.limit || 300) })));
  app.get('/api/gift-claim-logs', admin(async (req, res) => res.json({ success: true, data: await requireCommerce().listGiftClaimLogs(req.query.limit || 300) })));
  app.get('/api/gifts/:id', admin(async (req, res) => res.json({ success: true, data: await requireGifts().get(req.params.id) })));
  app.post('/api/gifts', admin(async (req, res) => res.status(201).json({ success: true, data: await requireGifts().save(req.body || {}) })));
  app.put('/api/gifts/:id', admin(async (req, res) => res.json({ success: true, data: await requireGifts().save(req.body || {}, req.params.id) })));
  app.patch('/api/gifts/:id/status', admin(async (req, res) => { await requireGifts().setEnabled(req.params.id, req.body?.enabled); res.json({ success: true }); }));
  app.delete('/api/gifts/:id', admin(async (req, res) => { await requireGifts().delete(req.params.id); res.json({ success: true }); }));
  app.get('/api/account-exchanges', admin(async (req, res) => res.json({ success: true, data: await requireCommerce().listAccountExchanges() })));
  app.get('/api/character-growth-purchases', admin(async (req, res) => res.json({ success: true, data: await requireCommerce().listCharacterGrowthPurchases(req.query.limit || 300) })));
  app.get('/api/redeem-code-claims', admin(async (req, res) => res.json({ success: true, data: await requireCommerce().listRedeemCodeClaims(req.query.limit || 300) })));
  app.get('/api/stock-price-history', admin(async (req, res) => res.json({ success: true, data: await requireCommerce().listStockPriceHistory(req.query.limit || 300) })));
  app.get('/api/player-checkins', admin(async (req, res) => res.json({ success: true, data: await requireCommerce().listPlayerCheckins(req.query.limit || 300) })));
  app.get('/api/redeem-codes', admin(async (req, res) => res.json({ success: true, data: await requireRedeemCodes().listAdmin() })));
  app.get('/api/redeem-codes/:id', admin(async (req, res) => res.json({ success: true, data: await requireRedeemCodes().get(req.params.id) })));
  app.post('/api/redeem-codes', admin(async (req, res) => res.status(201).json({ success: true, data: await requireRedeemCodes().save(redeemCodeInput(req, true)) })));
  app.put('/api/redeem-codes/:id', admin(async (req, res) => res.json({ success: true, data: await requireRedeemCodes().save(redeemCodeInput(req), req.params.id) })));
  app.delete('/api/redeem-codes/:id', admin(async (req, res) => { await requireRedeemCodes().delete(req.params.id); res.json({ success: true }); }));
  app.get('/api/redeem-codes/:id/claims', admin(async (req, res) => res.json({ success: true, data: await requireRedeemCodes().listClaims(req.params.id, { limit: req.query.limit, page: req.query.page }) })));
  app.get('/api/reward-rules', admin(async (req, res) => res.json({ success: true, data: await requireRewards().listAdmin() })));
  app.get('/api/reward-rules/:id', admin(async (req, res) => res.json({ success: true, data: await requireRewards().get(req.params.id) })));
  app.post('/api/reward-rules', admin(async (req, res) => res.status(201).json({ success: true, data: await requireRewards().save(rewardRuleInput(req)) })));
  app.put('/api/reward-rules/:id', admin(async (req, res) => res.json({ success: true, data: await requireRewards().save(rewardRuleInput(req), req.params.id) })));
  app.delete('/api/reward-rules/:id', admin(async (req, res) => { await requireRewards().delete(req.params.id); res.json({ success: true }); }));
  app.get('/api/reward-claims', admin(async (req, res) => res.json({ success: true, data: await requireRewards().listClaims({ page: req.query.page, limit: req.query.limit, steamId: req.query.steamId, ruleId: req.query.ruleId }) })));
  app.get('/api/activities', admin(async(req,res)=>res.json({success:true,data:await requireActivities().listAdmin()})));
  app.get('/api/activities/:id', admin(async(req,res)=>res.json({success:true,data:await requireActivities().get(req.params.id)})));
  app.post('/api/activities', admin(async(req,res)=>res.status(201).json({success:true,data:await requireActivities().save(req.body||{},null,req.user?.id)})));
  app.put('/api/activities/:id', admin(async(req,res)=>res.json({success:true,data:await requireActivities().save(req.body||{},req.params.id,req.user?.id)})));
  app.delete('/api/activities/:id', admin(async(req,res)=>{await requireActivities().delete(req.params.id);res.json({success:true});}));
  app.put('/api/activities/:id/relations', admin(async(req,res)=>res.json({success:true,data:await requireActivities().replaceRelations(req.params.id,req.body||{})})));
  app.get('/api/lottery/pools', admin(async(req,res)=>res.json({success:true,data:await requireLottery().listAdmin()})));
  app.get('/api/lottery/products', admin(async(req,res)=>res.json({success:true,data:await requireLottery().listProducts()})));
  app.post('/api/lottery/pools', admin(async(req,res)=>res.status(201).json({success:true,data:await requireLottery().savePool(req.body||{},null,req.user?.id)})));
  app.put('/api/lottery/pools/:id', admin(async(req,res)=>res.json({success:true,data:await requireLottery().savePool(req.body||{},req.params.id,req.user?.id)})));
  app.delete('/api/lottery/pools/:id', admin(async(req,res)=>{await requireLottery().delete(req.params.id);res.json({success:true});}));
  app.get('/api/lottery/pools/:id/versions', admin(async(req,res)=>res.json({success:true,data:await requireLottery().versions(req.params.id)})));
  app.post('/api/lottery/pools/:id/versions', admin(async(req,res)=>res.status(201).json({success:true,data:await requireLottery().createVersion(req.params.id,req.body||{},req.user?.id)})));
  app.get('/api/lottery/versions/:id', admin(async(req,res)=>res.json({success:true,data:await requireLottery().version(req.params.id)})));
  app.get('/api/lottery/records', admin(async(req,res)=>res.json({success:true,data:await requireLottery().adminRecords({limit:req.query.limit})})));
  app.get('/api/stocks', admin(async(req,res)=>res.json({success:true,data:await requireStockMarket().listAdmin()})));
  app.get('/api/stocks/market-status', admin(async(req,res)=>res.json({success:true,data:await requireStockMarket().marketStatus()})));
  app.post('/api/stocks', admin(async(req,res)=>res.status(201).json({success:true,data:await requireStockMarket().save(req.body||{},null,req.user?.id)})));
  app.put('/api/stocks/:id', admin(async(req,res)=>res.json({success:true,data:await requireStockMarket().save(req.body||{},req.params.id,req.user?.id)})));
  app.delete('/api/stocks/:id', admin(async(req,res)=>{await requireStockMarket().delete(req.params.id);res.json({success:true});}));
  app.patch('/api/stocks/:id/status', admin(async(req,res)=>res.json({success:true,data:await requireStockMarket().setStatus(req.params.id,req.body||{})})));
  app.post('/api/stocks/:id/manual-price', admin(async(req,res)=>{const key=String(req.get('Idempotency-Key')||'').trim();if(!key)throw new ServiceError('Idempotency-Key 必填');const data=await requireStockMarket().manualPrice(req.params.id,req.body||{},key,req.user);res.status(data.idempotent?200:201).json({success:true,data});}));
  app.get('/api/stocks/:id/bindings', admin(async(req,res)=>res.json({success:true,data:await requireStockMarket().bindings(req.params.id)})));
  app.post('/api/stocks/:id/bindings', admin(async(req,res)=>res.status(201).json({success:true,data:await requireStockMarket().saveBinding(req.params.id,req.body||{})})));
  app.put('/api/stocks/:id/bindings/:bindingId', admin(async(req,res)=>res.json({success:true,data:await requireStockMarket().saveBinding(req.params.id,req.body||{},req.params.bindingId)})));
  app.delete('/api/stocks/:id/bindings/:bindingId', admin(async(req,res)=>{await requireStockMarket().deleteBinding(req.params.id,req.params.bindingId);res.json({success:true});}));
  app.get('/api/stocks/:id/prices', admin(async(req,res)=>res.json({success:true,data:await requireStockMarket().history(req.params.id,{limit:req.query.limit})})));
  app.get('/api/stock-market-announcements', admin(async(req,res)=>res.json({success:true,data:await requireStockMarket().announcements(false)})));
  app.post('/api/stock-market-announcements', admin(async(req,res)=>res.status(201).json({success:true,data:await requireStockMarket().saveAnnouncement(req.body||{},null,req.user?.id)})));
  app.put('/api/stock-market-announcements/:id', admin(async(req,res)=>res.json({success:true,data:await requireStockMarket().saveAnnouncement(req.body||{},req.params.id,req.user?.id)})));
  app.patch('/api/stock-market-announcements/:id/status', admin(async(req,res)=>{await requireStockMarket().setAnnouncementStatus(req.params.id,req.body?.enabled,req.user?.id);res.json({success:true});}));
  app.delete('/api/stock-market-announcements/:id', admin(async(req,res)=>{await requireStockMarket().deleteAnnouncement(req.params.id);res.json({success:true});}));
  app.get('/api/stock-trades', admin(async(req,res)=>res.json({success:true,data:await requireStockMarket().trades(null,{limit:req.query.limit})})));
  app.get('/api/cloud-warehouse', admin(async(req,res)=>res.json({success:true,data:await requireCloudWarehouse().adminOverview(req.query)})));
  app.put('/api/cloud-warehouse/settings', admin(async(req,res)=>res.json({success:true,data:await requireCloudWarehouse().saveSettings(req.body||{},req.user?.id)})));
  app.get('/api/cloud-warehouse/pass-plans', admin(async(req,res)=>res.json({success:true,data:await requireCloudWarehouse().passPlans()})));
  app.put('/api/cloud-warehouse/pass-plans', admin(async(req,res)=>res.json({success:true,data:await requireCloudWarehouse().savePassPlans(req.body)})));
  app.get('/api/cloud-warehouse/recycle-restrictions', admin(async(req,res)=>res.json({success:true,data:await requireCloudWarehouse().recycleRestrictions()})));
  app.get('/api/cloud-warehouse/recycle-restrictions/settings', admin(async(req,res)=>res.json({success:true,data:await requireCloudWarehouse().recycleControlSettings()})));
  app.put('/api/cloud-warehouse/recycle-restrictions/settings', admin(async(req,res)=>res.json({success:true,data:await requireCloudWarehouse().setRecycleControlEnabled(req.body?.enabled,req.user?.id)})));
  app.post('/api/cloud-warehouse/recycle-restrictions', admin(async(req,res)=>res.status(201).json({success:true,data:await requireCloudWarehouse().saveRecycleRestriction(req.body||{},req.user?.id)})));
  app.put('/api/cloud-warehouse/recycle-restrictions/:itemCode', admin(async(req,res)=>res.json({success:true,data:await requireCloudWarehouse().setRecycleRestrictionEnabled(req.params.itemCode,req.body?.enabled)})));
  app.delete('/api/cloud-warehouse/recycle-restrictions/:itemCode', admin(async(req,res)=>res.json({success:true,data:await requireCloudWarehouse().deleteRecycleRestriction(req.params.itemCode)})));
  app.post('/api/cloud-warehouse/inventory', admin(async(req,res)=>res.status(201).json({success:true,data:await requireCloudWarehouse().addInventory(req.body||{},req.user?.id)})));
  app.post('/api/cloud-warehouse/listings/:id/cancel', admin(async(req,res)=>res.json({success:true,data:await requireCloudWarehouse().cancel(null,req.params.id,true)})));
  app.put('/api/players/:steamId/titles/:title', admin(async (req, res) => { await requireGifts().setTitle(req.params.steamId, req.params.title, req.body?.expiresAt); res.json({ success: true }); }));
  app.delete('/api/players/:steamId/titles/:title', admin(async (req, res) => { await requireGifts().deleteTitle(req.params.steamId, req.params.title); res.json({ success: true }); }));
  app.put('/api/players/:steamId/squad', admin(async (req, res) => { await requireGifts().setSquad(req.params.steamId, req.body || {}); res.json({ success: true }); }));
  app.delete('/api/players/:steamId/squad', admin(async (req, res) => { await requireGifts().deleteSquad(req.params.steamId); res.json({ success: true }); }));
  app.get('/api/vehicles/summary', admin(async (req, res) => res.json({ success: true, data: await requireVehicleManagement().summary() })));
  app.get('/api/vehicles/sync-status', admin(async (req, res) => res.json({ success: true, data: vehicleSyncStatus() })));
  app.get('/api/vehicles/limit-governance', admin(async (req, res) => res.json({ success: true, data: { ...await requireVehicleLimit().overview(), worker: vehicleLimitStatus() } })));
  app.put('/api/vehicles/limit-governance/settings', admin(async (req, res) => res.json({ success: true, data: await requireVehicleLimit().saveSettings(req.body || {}, req.user || {}) })));
  app.get('/api/vehicles', admin(async (req, res) => res.json({ success: true, data: await requireVehicleManagement().list(req.query) })));
  app.get('/api/vehicles/insurance-products', admin(async (req, res) => res.json({ success: true, data: await requireVehicleManagement().listInsuranceProducts() })));
  app.get('/api/vehicles/insurance-purchases', admin(async (req, res) => res.json({ success: true, data: await requireVehicleManagement().listInsurancePurchases(req.query) })));
  app.delete('/api/vehicles/insurance-purchases/:id', admin(async (req, res) => res.json({ success: true, data: await requireVehicleManagement().removeInsurancePurchase(req.params.id) })));
  app.get('/api/vehicles/insurance-strategies', admin(async (req, res) => res.json({ success: true, data: await requireVehicleManagement().listInsuranceStrategies() })));
  app.post('/api/vehicles/insurance-strategies', admin(async (req, res) => res.status(201).json({ success: true, data: await requireVehicleManagement().saveInsuranceStrategy(req.body || {}, adminActor(req)) })));
  app.put('/api/vehicles/insurance-strategies/:id', admin(async (req, res) => res.json({ success: true, data: await requireVehicleManagement().saveInsuranceStrategy(req.body || {}, adminActor(req), req.params.id) })));
  app.delete('/api/vehicles/insurance-strategies/:id', admin(async (req, res) => res.json({ success: true, data: await requireVehicleManagement().removeInsuranceStrategy(req.params.id) })));
  app.get('/api/vehicles/:id', admin(async (req, res) => res.json({ success: true, data: await requireVehicleManagement().detail(req.params.id) })));
  app.post('/api/vehicles', admin(async (req, res) => res.status(201).json({ success: true, data: await requireVehicleManagement().create(req.body || {}, adminActor(req)) })));
  app.put('/api/vehicles/:id', admin(async (req, res) => res.json({ success: true, data: await requireVehicleManagement().update(req.params.id, req.body || {}, adminActor(req)) })));
  app.put('/api/vehicles/:id/insurance', admin(async (req, res) => res.json({ success: true, data: await requireVehicleManagement().setInsurance(req.params.id, req.body || {}, adminActor(req)) })));
  app.delete('/api/vehicles/:id', admin(async (req, res) => res.json({ success: true, data: await requireVehicleManagement().remove(req.params.id, adminActor(req)) })));
  app.get('/api/memberships/strategies', admin(async (req, res) => res.json({ success: true, data: await requireCommerce().listMembershipStrategies() })));
  app.get('/api/teleport-management', admin(async (req, res) => res.json({ success: true, data: await requireTeleport().adminOverview() })));
  app.put('/api/teleport-management/settings', admin(async (req, res) => res.json({ success: true, data: await requireTeleport().saveSettings(req.body || {}, req.user?.id) })));
  app.post('/api/teleport-management/fixed-locations', admin(async (req, res) => res.status(201).json({ success: true, data: await requireTeleport().createFixedLocation(req.body || {}, req.user?.id) })));
  app.put('/api/teleport-management/fixed-locations/:id', admin(async (req, res) => res.json({ success: true, data: await requireTeleport().updateFixedLocation(req.params.id, req.body || {}, req.user?.id) })));
  app.delete('/api/teleport-management/fixed-locations/:id', admin(async (req, res) => { await requireTeleport().removeFixedLocation(req.params.id); res.json({ success: true }); }));
  app.get('/api/memberships/policy', admin(async (req, res) => res.json({ success: true, data: await requireCommerce().membershipPolicy() })));
  app.put('/api/memberships/policy', admin(async (req, res) => res.json({ success: true, data: await requireCommerce().saveMembershipPolicy(req.body || {}) })));
  app.post('/api/memberships/strategies', admin(async (req, res) => res.status(201).json({ success: true, data: await requireCommerce().saveMembershipStrategy(req.body || {}) })));
  app.put('/api/memberships/strategies/:level', admin(async (req, res) => res.json({ success: true, data: await requireCommerce().saveMembershipStrategy(req.body || {}, req.params.level) })));
  app.delete('/api/memberships/strategies/:level', admin(async (req, res) => { await requireCommerce().deleteMembershipStrategy(req.params.level); res.json({ success: true }); }));
  app.get('/api/memberships', admin(async (req, res) => res.json({ success: true, data: await requireCommerce().listMemberships(req.query) })));
  app.get('/api/memberships/stats', admin(async (req, res) => res.json({ success: true, data: await requireCommerce().membershipStats() })));
  app.get('/api/memberships/consumption/:steamId', admin(async (req, res) => res.json({ success: true, data: await requireCommerce().membershipConsumption(req.params.steamId) })));
  app.get('/api/memberships/logs', admin(async (req, res) => res.json({ success: true, data: await requireCommerce().membershipLogs(req.query) })));
  app.put('/api/memberships/:steamId', admin(async (req, res) => res.json({ success: true, data: await requireCommerce().setMembership(req.params.steamId, req.body || {}, adminActor(req)) })));
  app.delete('/api/memberships/:steamId', admin(async (req, res) => res.json({ success: true, data: await requireCommerce().setMembership(req.params.steamId, req.body || {}, adminActor(req), true) })));
  const accountGameAdmins = async () => readGameAdminUsers((await store.read()).ggcon?.serverDirectory);
  app.get('/api/accounts', admin(async (req, res) => {
    const [accounts, admins] = await Promise.all([commerce.listAccounts(req.query.limit || 100, req.query.search), accountGameAdmins()]);
    res.json({ success: true, data: accounts.map(account => ({ ...account, isAdmin: admins.has(String(account.steamId)) })) });
  }));
  app.get('/api/accounts/:steamId', admin(async (req, res) => {
    const [account, admins] = await Promise.all([commerce.getAccount(req.params.steamId), accountGameAdmins()]);
    res.json({ success: true, data: { ...account, isAdmin: admins.has(String(req.params.steamId)) } });
  }));
  app.post('/api/accounts/:steamId/adjust', admin(async (req, res) => res.json({ success: true, data: await commerce.adjustBalance(req.params.steamId, req.body?.amount, req.body?.note) })));
  app.post('/api/orders', admin(async (req, res) => res.status(201).json({ success: true, data: await commerce.createOrder({ ...(req.body || {}), source: 'manual' }) })));
  app.post('/api/fulfillment/manual', admin(async (req, res) => res.status(201).json({ success: true, data: await commerce.createManualFulfillment(req.body || {}, req.user?.id) })));
  app.get('/api/orders', admin(async (req, res) => res.json({ success: true, data: await commerce.listOrders(req.query.limit || 100) })));
  app.get('/api/order-logs', admin(async (req, res) => res.json({ success: true, data: await commerce.listShopOrderLogs(req.query.limit || 300) })));
  app.get('/api/orders/:id', admin(async (req, res) => res.json({ success: true, data: await commerce.getOrder(req.params.id) })));
  app.get('/api/fulfillment/tasks', admin(async (req, res) => res.json({ success: true, data: await commerce.listTasks(req.query.limit || 100) })));
  app.get('/api/fulfillment/lottery-logs', admin(async (req, res) => {
    const page = req.query.page === undefined ? 1 : req.query.page;
    const limit = req.query.limit === undefined ? 50 : req.query.limit;
    res.json({ success: true, data: await commerce.listLotteryFulfillmentLogs({ page, limit }) });
  }));
  app.post('/api/fulfillment/tasks/:id/replacements', admin(async (req, res) => {
    const requestKey = String(req.get('Idempotency-Key') || '').trim();
    if (!requestKey) throw new ServiceError('Idempotency-Key 必填');
    const data = await commerce.createReplacementTask(req.params.id, { requestKey, userId: req.user?.id, reason: req.body?.reason, confirmUnknownDeliveryRisk: req.body?.confirmUnknownDeliveryRisk });
    res.status(data.idempotent ? 200 : 201).json({ success: true, data });
  }));
  app.post('/api/fulfillment/tasks/:id/retry', admin(async (req, res) => { await commerce.retryTask(req.params.id); res.json({ success: true }); }));
  app.get('/api/announcements/config', admin(async (req, res) => {
    const config = await store.read();
    res.json({ success: true, data: config.announcements });
  }));
  app.put('/api/announcements/config', admin(async (req, res) => {
    const saved = await store.save({ announcements: req.body || {} });
    await announcementWorker?.reconfigure();
    res.json({ success: true, data: saved.announcements });
  }));
  app.post('/api/announcements/:id/send-now', admin(async (req, res) => {
    if (!announcementWorker) throw new ServiceError('公告服务未就绪', 503, 'NOT_READY');
    try { res.json({ success: true, data: await announcementWorker.sendNow(req.params.id) }); }
    catch (error) { throw new ServiceError(error.message, /不存在/.test(error.message) ? 404 : 502, /不存在/.test(error.message) ? 'NOT_FOUND' : 'ANNOUNCEMENT_FAILED'); }
  }));
  app.get('/api/fulfillment/attempts', admin(async (req, res) => res.json({ success: true, data: await commerce.listAttempts(req.query.limit || 100) })));
  app.post('/api/callback/orders', service(async (req, res) => {
    const config = await store.read();
    verifyCallback({ rawBody: req.rawBody, timestamp: req.get('X-Timestamp'), signature: req.get('X-Signature'), sharedSecret: config.fulfillment.sharedSecret });
    const orderId = String(req.body?.orderId || '').trim();
    if (!orderId) throw new ServiceError('orderId 不能为空');
    const data = await commerce.createOrder({ steamId: req.body?.steamId, items: req.body?.items, source: 'hmac', externalOrderId: orderId });
    res.status(data.idempotent ? 200 : 201).json({ success: true, data });
  }));
  app.use('/api', (req, res) => res.status(404).json({ success: false, message: '接口不存在', code: 'NOT_FOUND' }));
  app.use((req, res, next) => {
    const acceptsHtml = String(req.get('accept') || '').includes('text/html');
    if (['GET', 'HEAD'].includes(req.method) && acceptsHtml) {
      res.set('Cache-Control', 'no-store');
      return res.status(404).sendFile(notFoundPage);
    }
    next();
  });
  app.use((error, req, res, next) => {
    if (error?.type === 'entity.too.large') return res.status(413).json({ success: false, message: '请求内容过大', code: 'PAYLOAD_TOO_LARGE' });
    logger.error('服务内部错误', redact({ component: 'http', event: 'unhandled_request_error', error: error.message }));
    res.status(500).json({ success: false, message: '服务内部错误' });
  });
  app.closeClients = () => cachedClients?.ggcon.close();
  return app;
}
