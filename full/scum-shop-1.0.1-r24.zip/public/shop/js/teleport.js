const teleportGridRows = ['D', 'C', 'B', 'A', 'Z'];
const teleportGridColumns = ['4', '3', '2', '1', '0'];
let teleportMapData = null;
let teleportMapLoading = null;
let teleportMapRefreshTimer = null;
let teleportActionData = null;
let teleportActionLoading = null;
let teleportMapScale = 1;
let teleportMapResizeObserver = null;
let teleportExecutionPending = false;
let teleportQuoteDraft = null;
let teleportMode = 'character';
const teleportResultPollMs = 1000;
const teleportResultPollAttempts = 120;
let teleportMapRefreshMs = 15000;

function configureTeleportMapRefresh() {
  const root = teleportPage();
  if (!root) return;
  const configuredSeconds = Number(teleportActionData?.quota?.character?.intervalSeconds || 0);
  teleportMapRefreshMs = configuredSeconds > 0 ? configuredSeconds * 1000 : 15000;
  if (teleportMapRefreshTimer) window.clearInterval(teleportMapRefreshTimer);
  teleportMapRefreshTimer = window.setInterval(() => {
    if (!root.hidden && state.user && document.visibilityState === 'visible') Promise.allSettled([loadTeleportActionData({ force: true }), loadTeleportMapData({ force: true })]);
  }, teleportMapRefreshMs);
}

function teleportPage() { return document.getElementById('page-teleport'); }
function teleportElement(selector) { return teleportPage()?.querySelector(selector) || null; }

function teleportRequestKey() {
  return window.crypto?.randomUUID?.() || `teleport-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function teleportTargetsFor(type) {
  if (['vehicle_to_territory_flag', 'vehicle_to_player', 'vehicle_to_fixed_location'].includes(type)) return teleportActionData?.targets?.realtimeVehicles || [];
  if (type === 'owned_vehicle') return teleportActionData?.targets?.vehicles || [];
  if (type === 'territory_flag') return teleportActionData?.targets?.territoryFlags || [];
  if (type === 'fixed_location') return teleportActionData?.targets?.fixedLocations || [];
  if (type === 'player') return teleportActionData?.targets?.players || [];
  return [];
}

function teleportTargetTypeForMarker(type) {
  if (teleportMode === 'vehicle') return type === 'vehicle' ? 'vehicle_source' : '';
  return type === 'teammate' ? 'player' : type === 'vehicle' ? 'owned_vehicle' : type === 'flag' ? 'territory_flag' : type === 'fixed' ? 'fixed_location' : '';
}

function teleportAuthorizedTarget(targetType, targetId) {
  return teleportTargetsFor(targetType).find((item) => item.id === targetId) || null;
}

function teleportMapMarker(targetId) {
  return [teleportMapData?.player, ...(teleportMapData?.teammates || []), ...(teleportMapData?.vehicles || []), ...(teleportMapData?.flags || []), ...(teleportMapData?.fixedLocations || [])]
    .find((item) => item?.id === targetId) || null;
}

function clearTeleportDestination() {
  const destination = teleportElement('#teleportDestinationId');
  const type = teleportElement('#teleportTargetType');
  if (destination) destination.value = '';
  if (teleportMode === 'vehicle' && type) type.value = '';
}

function clearTeleportTarget() {
  teleportQuoteDraft = null;
  const type = teleportElement('#teleportTargetType');
  const target = teleportElement('#teleportTargetId');
  if (type) type.value = '';
  if (target) target.value = '';
  clearTeleportDestination();
}

function selectTeleportMapTarget(marker, markerType) {
  if (teleportMode === 'vehicle') {
    if (markerType !== 'vehicle') return false;
    const authorized = (teleportActionData?.targets?.realtimeVehicles || []).find((item) => item.id === marker.id);
    if (!authorized) return false;
    teleportElement('#teleportTargetId').value = authorized.id;
    clearTeleportDestination();
    renderTeleportActions();
    renderTeleportMarkers();
    return true;
  }
  const targetType = teleportTargetTypeForMarker(markerType);
  const authorized = teleportAuthorizedTarget(targetType, marker.id);
  if (!authorized) return false;
  teleportElement('#teleportTargetType').value = targetType;
  teleportElement('#teleportTargetId').value = authorized.id;
  renderTeleportActions();
  renderTeleportMarkers();
  return true;
}

function selectTeleportMapDestination(marker, markerType) {
  if (teleportMode !== 'vehicle' || !teleportElement('#teleportTargetId')?.value) return false;
  let targetType = '';
  let destinationId = '';
  if (markerType === 'flag' && (teleportActionData?.targets?.territoryFlags || []).some((item) => item.id === marker.id)) {
    targetType = 'vehicle_to_territory_flag';
    destinationId = marker.id;
  } else if (markerType === 'player') {
    targetType = 'vehicle_to_player';
    destinationId = 'player:self';
  } else if (markerType === 'teammate' && marker.online === true && (teleportActionData?.targets?.onlinePlayers || []).some((item) => item.id === marker.id)) {
    targetType = 'vehicle_to_player';
    destinationId = marker.id;
  } else if (markerType === 'fixed' && (teleportActionData?.targets?.fixedLocations || []).some((item) => item.id === marker.id)) {
    targetType = 'vehicle_to_fixed_location';
    destinationId = marker.id;
  }
  if (!targetType) return false;
  teleportElement('#teleportTargetType').value = targetType;
  teleportElement('#teleportDestinationId').value = destinationId;
  renderTeleportActions();
  renderTeleportMarkers();
  return true;
}

function renderTeleportActions(error = null) {
  const status = teleportElement('#teleportActionStatus');
  const quota = teleportElement('#teleportActionQuota');
  const price = teleportElement('#teleportActionPrice');
  const type = teleportElement('#teleportTargetType');
  const target = teleportElement('#teleportTargetId');
  const destinationId = teleportElement('#teleportDestinationId');
  const execute = teleportElement('#teleportExecute');
  const note = teleportElement('#teleportActionNote');
  const selected = teleportElement('#teleportSelectedTarget');
  const selectedName = teleportElement('#teleportSelectedTargetName');
  const selectedMeta = teleportElement('#teleportSelectedTargetMeta');
  const clear = teleportElement('#teleportClearTarget');
  const destinationPanel = teleportElement('#teleportSelectedDestination');
  const destinationName = teleportElement('#teleportSelectedDestinationName');
  const destinationMeta = teleportElement('#teleportSelectedDestinationMeta');
  const clearDestination = teleportElement('#teleportClearDestination');
  if (![status, quota, price, type, target, destinationId, execute, note, selected, selectedName, selectedMeta, clear, destinationPanel, destinationName, destinationMeta, clearDestination].every(Boolean)) return;

  const source = teleportMode === 'vehicle'
    ? (teleportActionData?.targets?.realtimeVehicles || []).find((item) => item.id === target.value)
    : teleportAuthorizedTarget(type.value, target.value);
  if (target.value && !source) clearTeleportTarget();
  const destinationMarker = destinationId.value === 'player:self' ? teleportMapData?.player : teleportMapMarker(destinationId.value);
  const destination = type.value === 'vehicle_to_territory_flag'
    ? (teleportActionData?.targets?.territoryFlags || []).find((item) => item.id === destinationId.value)
    : type.value === 'vehicle_to_fixed_location'
      ? (teleportActionData?.targets?.fixedLocations || []).find((item) => item.id === destinationId.value)
      : destinationId.value === 'player:self'
        ? { id:'player:self', name:'本人当前位置' }
        : (teleportActionData?.targets?.onlinePlayers || []).find((item) => item.id === destinationId.value);
  if (teleportMode === 'vehicle' && destinationId.value && !destination) clearTeleportDestination();
  destinationPanel.hidden = teleportMode !== 'vehicle';

  note.classList.toggle('error', Boolean(error));
  if (error) {
    clearTeleportTarget();
    status.textContent = '传送服务暂不可用';
    quota.textContent = '今日可用次数：—';
    price.textContent = '本次价格：—';
    note.textContent = error;
    execute.disabled = true;
  } else if (!state.user) {
    clearTeleportTarget();
    status.textContent = '登录后读取传送额度';
    quota.textContent = '今日可用次数：—';
    price.textContent = '本次价格：—';
    note.textContent = '登录后可读取安全传送目标。';
    execute.disabled = true;
  } else if (!teleportActionData) {
    status.textContent = '正在读取安全传送配置…';
    execute.disabled = true;
  } else {
    const category = teleportMode === 'vehicle' ? 'vehicle' : 'character';
    const q = teleportActionData.quota?.[category] || {};
    const pricing = teleportActionData.pricing?.[category] || {};
    const characterCapabilities = ['player', 'ownedVehicle', 'territoryFlag', 'fixedLocation'].some((name) => teleportActionData.capabilities?.[name] === true);
    const selectedVehicleCapability = type.value === 'vehicle_to_territory_flag' ? 'vehicleToTerritoryFlag' : type.value === 'vehicle_to_player' ? 'vehicleToPlayer' : type.value === 'vehicle_to_fixed_location' ? 'vehicleToFixedLocation' : null;
    const anyVehicleCapability = teleportActionData.capabilities?.vehicleToTerritoryFlag === true || teleportActionData.capabilities?.vehicleToPlayer === true || teleportActionData.capabilities?.vehicleToFixedLocation === true;
    const modeAvailable = teleportMode === 'vehicle' ? (selectedVehicleCapability ? teleportActionData.capabilities?.[selectedVehicleCapability] === true : anyVehicleCapability) : characterCapabilities;
    quota.textContent = `今日可用次数：${q.remaining ?? 0} / ${q.total ?? 0}`;
    price.textContent = pricing.mode === 'distance' ? `距离计价：${number(pricing.perKilometerPrice || 0)} 商城币/公里` : `本次价格：${number(pricing.price || 0)} 商城币`;
    const modeName = teleportMode === 'vehicle' ? '载具传送' : '角色传送';
    status.textContent = teleportExecutionPending ? '传送已提交，游戏处理中' : !modeAvailable ? `${modeName}能力不可用` : q.intervalRemainingSeconds > 0 ? `载具传送间隔中：${q.intervalRemainingSeconds} 秒` : teleportMode === 'vehicle' && !source ? '请在地图选择实时载具' : teleportMode === 'vehicle' && !destination ? '请在地图选择目的地' : `${modeName}已就绪`;
    note.textContent = !modeAvailable ? `当前选择的${modeName}能力不可用。` : teleportMode === 'vehicle' ? '先选择实时载具，再直接点击固定位置、领地旗、本人或在线队友作为目的地。' : teleportActionData.playerDisabledReason || '仅地图上通过安全校验的目标可以被选择。';
    execute.disabled = teleportExecutionPending || !modeAvailable || Number(q.remaining || 0) < 1 || Number(q.intervalRemainingSeconds || 0) > 0 || !source || (teleportMode === 'vehicle' && !destination);
  }

  const sourceMarker = source ? teleportMapMarker(source.id) : null;
  selected.classList.toggle('has-target', Boolean(source));
  selectedName.textContent = source ? `${source.name}${source.plateNumber ? ` · ${source.plateNumber}` : ''}` : teleportMode === 'vehicle' ? '请在地图选择实时载具' : '未选择传送目标';
  selectedMeta.textContent = source ? `${teleportMode === 'vehicle' ? '源载具' : type.value === 'player' ? '小队成员' : type.value === 'territory_flag' ? '领地旗' : type.value === 'fixed_location' ? '固定位置' : '上锁载具'} · ${sourceMarker?.gridCode || '位置已授权'}${source.lastKnown || sourceMarker?.stale ? ' · 离线最后位置' : ' · 实时位置'}` : '—';
  clear.hidden = !source;

  destinationPanel.classList.toggle('has-target', Boolean(destination));
  destinationName.textContent = destination?.name || '请选择固定位置、领地旗、本人或在线队友';
  destinationMeta.textContent = destination ? `${type.value === 'vehicle_to_fixed_location' ? '固定位置' : type.value === 'vehicle_to_territory_flag' ? '授权领地旗' : destinationId.value === 'player:self' ? '本人角色' : '在线队友'} · ${destinationMarker?.gridCode || '位置已授权'} · ${type.value === 'vehicle_to_fixed_location' ? '固定位置' : '实时位置'}` : '—';
  clearDestination.hidden = !destination;
}

async function loadTeleportActionData({ force = false } = {}) {
  if (!state.user) { teleportActionData = null; renderTeleportActions(); return null; }
  if (teleportActionLoading) return teleportActionLoading;
  renderTeleportActions();
  teleportActionLoading = api('/api/shop/teleport').then((data) => { teleportActionData = data; configureTeleportMapRefresh(); renderTeleportActions(); renderTeleportMarkers(); return data; })
    .catch((error) => { if (error.status !== 401) renderTeleportActions(chineseErrorMessage(error.message, '传送配置读取失败，请稍后重试')); throw error; })
    .finally(() => { teleportActionLoading = null; });
  return teleportActionLoading;
}

function teleportObservedLabel(value) {
  if (!value) return '更新时间未知';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '更新时间未知' : `更新于 ${date.toLocaleString('zh-CN', { hour12: false })}`;
}

function teleportMarkerTitle(marker) {
  const stateLabel = marker.online === true ? '在线实时位置' : '离线最后位置';
  const ownership = marker.type === 'vehicle' ? (marker.ownership === 'teammate' ? ' · 队友载具' : ' · 本人载具') : '';
  return `${marker.name}${ownership} · ${stateLabel} · ${marker.gridCode || '网格未知'} · ${teleportObservedLabel(marker.observedAt)}`;
}

function syncTeleportLayerAvailability() {
  const capabilities = teleportMapData?.capabilities || {};
  const layers = teleportMapData?.layers || {};
  for (const [id, available] of [
    ['teleportLayerPlayer', capabilities.playerLocation === true || layers.player === true],
    ['teleportLayerTeammates', capabilities.teammateLocation === true || layers.teammates === true],
    ['teleportLayerFlags', capabilities.flagLocation === true || layers.flags === true],
    ['teleportLayerFixedLocations', capabilities.fixedLocation === true || layers.fixedLocations === true]
  ]) {
    const input = teleportElement(`#${id}`);
    if (!input) continue;
    input.disabled = !available;
    input.closest('label')?.classList.toggle('unavailable', !available);
  }
}

const teleportMarkerIcons = Object.freeze({
  vehicle: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m21 8-2 2-1.5-3.7A2 2 0 0 0 15.65 5h-7.3A2 2 0 0 0 6.5 6.3L5 10 3 8"/><path d="M7 14h.01M17 14h.01"/><rect width="18" height="8" x="3" y="10" rx="2"/><path d="M5 18v2M19 18v2"/></svg>',
  player: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="5"/><path d="M20 21a8 8 0 0 0-16 0"/></svg>',
  teammate: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
  flag: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1zM4 22v-7"/></svg>',
  fixed: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0z"/><circle cx="12" cy="10" r="2"/></svg>',
  target: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/></svg>'
});

function createTeleportMarkerIcon(type, className = 'teleport-marker-icon') {
  const icon = document.createElement('span');
  icon.className = `${className} ${className}-${type}`;
  icon.innerHTML = teleportMarkerIcons[type] || '';
  return icon;
}

function visibleTeleportMarkers() {
  if (!teleportMapData) return [];
  const visible = [];
  if (teleportElement('#teleportLayerVehicles')?.checked !== false) {
    (teleportMapData.vehicles || []).forEach((marker) => visible.push({ marker, type:'vehicle' }));
  }
  if (teleportElement('#teleportLayerPlayer')?.checked === true && teleportMapData.player) {
    visible.push({ marker:teleportMapData.player, type:'player' });
  }
  if (teleportElement('#teleportLayerTeammates')?.checked === true) {
    (teleportMapData.teammates || []).forEach((marker) => visible.push({ marker, type:'teammate' }));
  }
  if (teleportElement('#teleportLayerFlags')?.checked === true) {
    (teleportMapData.flags || []).forEach((marker) => visible.push({ marker, type:'flag' }));
  }
  if (teleportElement('#teleportLayerFixedLocations')?.checked === true) {
    (teleportMapData.fixedLocations || []).forEach((marker) => visible.push({ marker, type:'fixed' }));
  }
  return visible.filter(({ marker }) => Number.isFinite(Number(marker.xPercent)) && Number.isFinite(Number(marker.yPercent)));
}

function teleportMarkerScreenSize(scale) {
  return Math.round(Math.min(46, 26 + Math.max(0, scale - 1) * 3));
}

function layoutTeleportMarkers(items, mapSize, scale) {
  const collisionDistance = teleportMarkerScreenSize(scale) + 14;
  const canvasSize = mapSize * scale;
  const records = items.map((item, index) => ({
    ...item,
    index,
    baseX:Number(item.marker.xPercent) * canvasSize / 100,
    baseY:Number(item.marker.yPercent) * canvasSize / 100
  }));
  const groups = [];
  const assigned = new Set();
  records.forEach((record, start) => {
    if (assigned.has(start)) return;
    const indexes = [start];
    assigned.add(start);
    for (let cursor = 0; cursor < indexes.length; cursor += 1) {
      records.forEach((candidate, index) => {
        if (!assigned.has(index) && Math.hypot(records[indexes[cursor]].baseX - candidate.baseX, records[indexes[cursor]].baseY - candidate.baseY) < collisionDistance) {
          assigned.add(index);
          indexes.push(index);
        }
      });
    }
    groups.push(indexes.map((index) => records[index]));
  });

  const placed = [];
  const result = new Array(items.length);
  const commit = (record, x, y) => {
    placed.push({ x, y });
    const offsetX = (x - record.baseX) / scale;
    const offsetY = (y - record.baseY) / scale;
    result[record.index] = { marker:record.marker, type:record.type, offset:{
      x:offsetX,
      y:offsetY,
      distance:Math.hypot(offsetX, offsetY),
      angle:Math.atan2(offsetY, offsetX) * 180 / Math.PI
    } };
  };
  const available = (x, y) => x >= collisionDistance / 2 && y >= collisionDistance / 2
    && x <= canvasSize - collisionDistance / 2 && y <= canvasSize - collisionDistance / 2
    && placed.every((position) => Math.hypot(position.x - x, position.y - y) >= collisionDistance);

  groups.filter((group) => group.length === 1).forEach(([record]) => commit(record, record.baseX, record.baseY));
  groups.filter((group) => group.length > 1).sort((left, right) => right.length - left.length).forEach((group) => {
    const centerX = group.reduce((sum, record) => sum + record.baseX, 0) / group.length;
    const centerY = group.reduce((sum, record) => sum + record.baseY, 0) / group.length;
    const ordered = group.map((record) => ({
      record,
      sourceAngle:Math.atan2(record.baseY - centerY, record.baseX - centerX),
      sourceDistance:Math.hypot(record.baseX - centerX, record.baseY - centerY)
    })).sort((left, right) => left.sourceDistance - right.sourceDistance || left.sourceAngle - right.sourceAngle || String(left.record.marker.id).localeCompare(String(right.record.marker.id)));
    ordered.forEach((entry, index) => {
      if (available(entry.record.baseX, entry.record.baseY)) {
        commit(entry.record, entry.record.baseX, entry.record.baseY);
        return;
      }
      const preferredAngle = entry.sourceDistance > 1
        ? entry.sourceAngle
        : -Math.PI / 2 + Math.PI * 2 * index / ordered.length;
      const angleSteps = [0, -1, 1, -2, 2, -3, 3, 4];
      let selected = null;
      for (let ring = 1; ring <= 8 && !selected; ring += 1) {
        const radius = collisionDistance * (.55 + ring * .45);
        for (const step of angleSteps) {
          const angle = preferredAngle + step * Math.PI / 12;
          const x = entry.record.baseX + Math.cos(angle) * radius;
          const y = entry.record.baseY + Math.sin(angle) * radius;
          if (available(x, y)) {
            selected = { x, y };
            break;
          }
        }
      }
      if (!selected) {
        for (let ring = 2; ring <= 12 && !selected; ring += 1) {
          const radius = collisionDistance * ring;
          for (let step = 0; step < 24; step += 1) {
            const angle = preferredAngle + step * Math.PI / 12;
            const x = entry.record.baseX + Math.cos(angle) * radius;
            const y = entry.record.baseY + Math.sin(angle) * radius;
            if (available(x, y)) {
              selected = { x, y };
              break;
            }
          }
        }
      }
      commit(entry.record, selected?.x ?? entry.record.baseX, selected?.y ?? entry.record.baseY);
    });
  });
  return result;
}

function teleportVehicleMapDestination(marker, type) {
  if (teleportMode !== 'vehicle' || !teleportElement('#teleportTargetId')?.value) return null;
  if (type === 'player') return { id:'player:self', name:'本人当前位置', targetType:'vehicle_to_player' };
  if (type === 'teammate' && marker.online === true) {
    const player = (teleportActionData?.targets?.onlinePlayers || []).find((item) => item.id === marker.id);
    return player ? { ...player, targetType:'vehicle_to_player' } : null;
  }
  if (type === 'flag') {
    const flag = (teleportActionData?.targets?.territoryFlags || []).find((item) => item.id === marker.id);
    return flag ? { ...flag, targetType:'vehicle_to_territory_flag' } : null;
  }
  if (type === 'fixed') {
    const location = (teleportActionData?.targets?.fixedLocations || []).find((item) => item.id === marker.id);
    return location ? { ...location, targetType:'vehicle_to_fixed_location' } : null;
  }
  return null;
}

function appendTeleportMarker(container, marker, type, offset) {
  const element = document.createElement('button');
  element.type = 'button';
  const edgeClass = Number(marker.xPercent) < 8 ? ' edge-left' : Number(marker.xPercent) > 92 ? ' edge-right' : '';
  const targetType = teleportTargetTypeForMarker(type);
  const destination = teleportVehicleMapDestination(marker, type);
  const source = teleportMode === 'vehicle' && type === 'vehicle'
    ? (teleportActionData?.targets?.realtimeVehicles || []).find((item) => item.id === marker.id)
    : null;
  const authorized = destination || source || teleportAuthorizedTarget(targetType, marker.id);
  const selected = destination
    ? teleportElement('#teleportDestinationId')?.value === destination.id
    : authorized && teleportElement('#teleportTargetId')?.value === authorized.id;
  element.className = `teleport-marker teleport-marker-${type}${marker.stale ? ' stale' : ''}${offset.distance ? ' displaced' : ''}${authorized ? ' selectable' : ' unavailable-target'}${selected ? ' selected' : ''}${edgeClass}`;
  element.style.setProperty('--marker-x', `${marker.xPercent}%`);
  element.style.setProperty('--marker-y', `${marker.yPercent}%`);
  element.style.setProperty('--marker-offset-x', `${offset.x}px`);
  element.style.setProperty('--marker-offset-y', `${offset.y}px`);
  const screenSize = teleportMarkerScreenSize(teleportMapScale);
  element.style.setProperty('--marker-label-offset-y', `${(screenSize / 2 + 12) / teleportMapScale}px`);
  element.style.setProperty('--marker-leader-length', `${offset.distance}px`);
  element.style.setProperty('--marker-leader-angle', `${offset.angle}deg`);
  element.style.setProperty('--marker-line-width', `${2 / teleportMapScale}px`);
  element.style.setProperty('--marker-visual-scale', String(screenSize / 42 / teleportMapScale));
  element.style.setProperty('--marker-label-scale', String(1 / teleportMapScale));
  element.setAttribute('aria-label', teleportMarkerTitle(marker));
  element.title = teleportMarkerTitle(marker);
  element.dataset.teleportMarker = marker.id;
  element.setAttribute('aria-expanded', 'false');
  element.addEventListener('click', () => {
    const show = !element.classList.contains('show-label');
    teleportPage()?.querySelectorAll('.teleport-marker.show-label').forEach((item) => {
      item.classList.remove('show-label');
      item.setAttribute('aria-expanded', 'false');
    });
    teleportPage()?.querySelectorAll('.teleport-marker-anchor.highlighted').forEach((item) => item.classList.remove('highlighted'));
    element.classList.toggle('show-label', show);
    element.setAttribute('aria-expanded', String(show));
    if (show) [...(teleportPage()?.querySelectorAll('.teleport-marker-anchor') || [])]
      .find((item) => item.dataset.markerId === String(marker.id))?.classList.add('highlighted');
    if (destination) selectTeleportMapDestination(marker, type);
    else if (authorized) selectTeleportMapTarget(marker, type);
  });
  const icon = createTeleportMarkerIcon(type);
  const label = document.createElement('small');
  label.className = 'teleport-marker-name';
  label.textContent = marker.name || marker.gridCode || '未命名目标';
  element.append(icon, label);
  container.append(element);
}

function appendTeleportMarkerAnchor(container, marker, type, displaced) {
  const anchor = document.createElement('span');
  anchor.className = `teleport-marker-anchor teleport-marker-anchor-${type}${marker.stale ? ' stale' : ''}${displaced ? ' displaced' : ''}`;
  anchor.style.setProperty('--marker-x', `${marker.xPercent}%`);
  anchor.style.setProperty('--marker-y', `${marker.yPercent}%`);
  anchor.style.setProperty('--marker-anchor-scale', String(1 / teleportMapScale));
  anchor.dataset.markerId = String(marker.id);
  anchor.setAttribute('aria-hidden', 'true');
  container.append(anchor);
}

function renderTeleportMarkers() {
  const markers = teleportElement('#teleportMapMarkers');
  if (!markers) return;
  markers.replaceChildren();
  syncTeleportLayerAvailability();
  const mapSize = teleportElement('#teleportMapFrame')?.clientWidth || 800;
  const layout = layoutTeleportMarkers(visibleTeleportMarkers(), mapSize, teleportMapScale);
  layout.forEach(({ marker, type, offset }) => appendTeleportMarker(markers, marker, type, offset));
  layout.forEach(({ marker, type, offset }) => appendTeleportMarkerAnchor(markers, marker, type, offset.distance > 0));
}

function renderTeleportMapStatus(error = null) {
  const status = teleportElement('#teleportMapStatus');
  const warning = teleportElement('#teleportMapWarning');
  if (!status || !warning) return;
  status.classList.toggle('error', Boolean(error));
  if (error) {
    status.textContent = error;
    warning.hidden = true;
    return;
  }
  if (!state.user) {
    status.textContent = '登录后读取本人、小队与载具位置';
    warning.hidden = true;
    return;
  }
  if (!teleportMapData) {
    status.textContent = '正在读取本人位置数据…';
    warning.hidden = true;
    return;
  }
  const vehicles = teleportMapData.vehicles || [];
  const flags = teleportMapData.flags || [];
  const fixedLocations = teleportMapData.fixedLocations || [];
  const teammates = teleportMapData.teammates || [];
  const onlineTeammates = teammates.filter((item) => item.online === true).length;
  const onlineVehicles = vehicles.filter((item) => item.online === true).length;
  const teammateVehicles = vehicles.filter((item) => item.ownership === 'teammate').length;
  const capabilities = teleportMapData.capabilities || {};
  const playerState = teleportMapData.player
    ? `本人${teleportMapData.player.online === true ? '在线' : '离线'}位置`
    : '本人暂无位置';
  const teammateState = capabilities.teammateLocation === true
    ? `队友位置 ${teammates.length} 个（在线 ${onlineTeammates}）`
    : `队友位置采集离线 · 保留上次位置 ${teammates.length} 个`;
  const flagState = capabilities.flagLocation === true ? `领地旗 ${flags.length} 面` : `领地旗采集离线 · 保留 ${flags.length} 面`;
  const generated = teleportObservedLabel(teleportMapData.generatedAt).replace('更新于 ', '数据生成于 ');
  status.textContent = `${playerState} · ${teammateState} · 载具 ${vehicles.length} 台（在线 ${onlineVehicles}，队友 ${teammateVehicles}） · ${flagState} · 固定位置 ${fixedLocations.length} 个 · ${generated}`;
  warning.textContent = teleportMapData.calibration?.warning || '';
  warning.hidden = !warning.textContent;
}

async function loadTeleportMapData({ force = false } = {}) {
  if (!state.user) {
    teleportMapData = null;
    renderTeleportMarkers();
    renderTeleportMapStatus();
    return null;
  }
  if (!teleportActionData) loadTeleportActionData().catch(() => {});
  if (teleportMapLoading) return teleportMapLoading;
  renderTeleportMapStatus();
  teleportMapLoading = api('/api/shop/teleport/map')
    .then((data) => {
      teleportMapData = data;
      renderTeleportMarkers();
      renderTeleportMapStatus();
      return data;
    })
    .catch((error) => {
      if (teleportMapData) {
        const offlineMarker = (marker) => ({ ...marker, online:false, stale:true });
        teleportMapData = {
          ...teleportMapData,
          player:teleportMapData.player ? offlineMarker(teleportMapData.player) : null,
          teammates:(teleportMapData.teammates || []).map(offlineMarker),
          vehicles:(teleportMapData.vehicles || []).map(offlineMarker),
          flags:(teleportMapData.flags || []).map(offlineMarker),
          fixedLocations:teleportMapData.fixedLocations || [],
          capabilities:{ playerLocation:false, teammateLocation:false, vehicleLocation:false, flagLocation:false }
        };
        renderTeleportMarkers();
      }
      if (error.status !== 401) renderTeleportMapStatus(`${chineseErrorMessage(error.message, '位置数据读取失败，请稍后重试')} · 已保留最后位置`);
      throw error;
    })
    .finally(() => { teleportMapLoading = null; });
  return teleportMapLoading;
}

function loadTeleportPage() {
  const root = teleportPage();
  if (!root || root.dataset.teleportReady) return;
  const frame = root.querySelector('#teleportMapFrame');
  const canvas = root.querySelector('#teleportMapCanvas');
  const grid = root.querySelector('#teleportMapGrid');
  const markers = root.querySelector('#teleportMapMarkers');
  const image = root.querySelector('#teleportMapImage');
  const range = root.querySelector('#teleportZoomRange');
  const zoomValue = root.querySelector('#teleportZoomValue');
  const zoomOut = root.querySelector('#teleportZoomOut');
  const zoomIn = root.querySelector('#teleportZoomIn');
  const zoomReset = root.querySelector('#teleportZoomReset');
  const refresh = root.querySelector('#teleportMapRefresh');
  const vehicleLayer = root.querySelector('#teleportLayerVehicles');
  const playerLayer = root.querySelector('#teleportLayerPlayer');
  const teammateLayer = root.querySelector('#teleportLayerTeammates');
  const flagLayer = root.querySelector('#teleportLayerFlags');
  const fixedLayer = root.querySelector('#teleportLayerFixedLocations');
  const gridLayer = root.querySelector('#teleportLayerGrid');
  const actionForm = root.querySelector('#teleportActionForm');
  const actionType = root.querySelector('#teleportTargetType');
  const actionTarget = root.querySelector('#teleportTargetId');
  const actionExecute = root.querySelector('#teleportExecute');
  const actionRefresh = root.querySelector('#teleportActionRefresh');
  const actionClear = root.querySelector('#teleportClearTarget');
  const destinationClear = root.querySelector('#teleportClearDestination');
  const modeButtons = [...root.querySelectorAll('[data-teleport-mode]')];
  const destinationId = root.querySelector('#teleportDestinationId');
  const receiptModal = document.querySelector('#teleportReceiptModal');
  const receiptTitle = document.querySelector('#teleportReceiptTitle');
  const receiptStatus = document.querySelector('#teleportReceiptStatus');
  const receiptDetails = document.querySelector('#teleportReceiptDetails');
  const receiptWarning = document.querySelector('#teleportReceiptWarning');
  const receiptConfirm = document.querySelector('#teleportReceiptConfirm');
  const receiptCancel = document.querySelector('#teleportReceiptCancel');
  const receiptDone = document.querySelector('#teleportReceiptDone');
  if (![frame, canvas, grid, markers, image, range, zoomValue, zoomOut, zoomIn, zoomReset, refresh, vehicleLayer, playerLayer, teammateLayer, flagLayer, fixedLayer, gridLayer, actionForm, actionType, actionTarget, actionExecute, actionRefresh, actionClear, destinationClear, destinationId, receiptModal, receiptTitle, receiptStatus, receiptDetails, receiptWarning, receiptConfirm, receiptCancel, receiptDone].every(Boolean) || modeButtons.length !== 2) return;

  root.querySelectorAll('[data-teleport-icon]').forEach((slot) => {
    slot.replaceChildren(createTeleportMarkerIcon(slot.dataset.teleportIcon, 'teleport-layer-icon'));
  });

  grid.innerHTML = teleportGridRows.flatMap((row, rowIndex) =>
    teleportGridColumns.map((column, columnIndex) =>
      `<span class="teleport-grid-label" style="--grid-row:${rowIndex};--grid-column:${columnIndex}">${row}${column}</span>`
    )
  ).join('');

  let scale = 1;
  let panX = 0;
  let panY = 0;
  let dragState = null;

  const clampPan = () => {
    if (scale <= 1) {
      panX = 0;
      panY = 0;
      return;
    }
    const maxX = frame.clientWidth * (scale - 1) / 2;
    const maxY = frame.clientHeight * (scale - 1) / 2;
    panX = Math.min(maxX, Math.max(-maxX, panX));
    panY = Math.min(maxY, Math.max(-maxY, panY));
  };
  const applyTransform = () => {
    clampPan();
    canvas.style.transform = `translate(${panX}px,${panY}px) scale(${scale})`;
    range.value = String(scale * 100);
    zoomValue.textContent = `${Math.round(scale * 100)}%`;
    zoomOut.disabled = scale <= 1;
    zoomIn.disabled = scale >= 8;
    frame.classList.toggle('zoomed', scale > 1);
  };
  const setScale = (nextScale, pointer) => {
    const previousScale = scale;
    const next = Math.min(8, Math.max(1, Math.round(nextScale * 4) / 4));
    if (pointer && next !== previousScale) {
      const bounds = frame.getBoundingClientRect();
      const offsetX = pointer.x - bounds.left - bounds.width / 2;
      const offsetY = pointer.y - bounds.top - bounds.height / 2;
      const ratio = next / previousScale;
      panX = offsetX - (offsetX - panX) * ratio;
      panY = offsetY - (offsetY - panY) * ratio;
    }
    scale = next;
    teleportMapScale = scale;
    applyTransform();
    if (next !== previousScale) renderTeleportMarkers();
  };
  const resetScale = () => {
    const changed = scale !== 1;
    scale = 1;
    teleportMapScale = 1;
    panX = 0;
    panY = 0;
    applyTransform();
    if (changed) renderTeleportMarkers();
  };
  const stopDragging = (event) => {
    if (!dragState) return;
    dragState = null;
    canvas.classList.remove('dragging');
    frame.classList.remove('dragging');
    if (event?.pointerId !== undefined && frame.hasPointerCapture(event.pointerId)) frame.releasePointerCapture(event.pointerId);
  };

  const receiptRows = (result) => {
    const discount = Number(result.discountPercent ?? 100);
    const details = [
      ['传送位置', result.targetName || '已授权位置'],
      ['计价方式', result.pricingMode === 'distance' ? '按距离计价' : '固定价格']
    ];
    if (result.pricingMode === 'distance') details.push(['传送距离', `${number(result.kilometers)} 公里`]);
    details.push(
      ['基础费用', `${number(result.basePrice)} 商城币`],
      ['会员折扣', discount >= 100 ? '无折扣' : `${discount}%`],
      ['实际花费', `${number(result.chargedAmount)} 商城币`],
      ['当前余额', `${number(result.balance)} 商城币`],
      ['扣款后余额', `${number(result.balanceAfter)} 商城币`]
    );
    return details;
  };
  const renderTeleportReceipt = (result, phase = 'quote') => {
    receiptDetails.replaceChildren(...receiptRows(result).map(([label, value]) => {
      const row = document.createElement('div');
      const term = document.createElement('dt');
      const detail = document.createElement('dd');
      term.textContent = label;
      detail.textContent = value;
      if (label === '实际花费') row.className = 'teleport-receipt-cost';
      row.append(term, detail);
      return row;
    }));
    const isQuote = phase === 'quote';
    receiptTitle.textContent = isQuote ? '确认传送' : '传送结果';
    receiptStatus.textContent = isQuote ? '请核对本次传送距离与费用' : phase === 'pending' ? '传送申请已提交，正在等待游戏确认' : '传送已完成';
    receiptWarning.hidden = !isQuote;
    receiptConfirm.hidden = !isQuote;
    receiptCancel.hidden = !isQuote;
    receiptDone.hidden = isQuote;
    openModal(receiptModal);
  };
  const showTeleportResult = (result) => {
    const receipt = { ...(teleportQuoteDraft?.quote || {}), ...result };
    if (['manual_review', 'command_result_unknown'].includes(result.status)) {
      closeModal(receiptModal);
      toast(chineseErrorMessage(result.errorMessage, '传送结果暂时无法确认，已转人工核查', { code: result.errorCode }), 'error', '需要人工核查');
    } else if (['failed', 'refunded'].includes(result.status)) {
      closeModal(receiptModal);
      toast(chineseErrorMessage(result.errorMessage, '传送失败，费用已退回', { code: result.errorCode }), 'error');
    } else if (result.status === 'success_pending_persistence') renderTeleportReceipt(receipt, 'pending');
    else renderTeleportReceipt(receipt, 'success');
  };
  const pollTeleportResult = async (payload, key) => {
    try {
      for (let attempt = 0; attempt < teleportResultPollAttempts; attempt += 1) {
        await new Promise((resolve) => window.setTimeout(resolve, teleportResultPollMs));
        const result = await api('/api/shop/teleport', { method: 'POST', headers: { 'Idempotency-Key': key }, body: JSON.stringify(payload) });
        if (['processing', 'success_pending_persistence'].includes(result.status)) {
          if (result.status === 'success_pending_persistence' && attempt === 0) showTeleportResult(result);
          continue;
        }
        showTeleportResult(result);
        return;
      }
      toast('传送仍在游戏内处理中，可稍后刷新查看结果');
    } catch (error) {
      toast(error.message, 'error');
    } finally {
      teleportExecutionPending = false;
      await Promise.allSettled([loadTeleportActionData({ force: true }), loadTeleportMapData({ force: true })]);
      renderTeleportActions();
    }
  };

  modeButtons.forEach((button) => button.addEventListener('click', () => {
    teleportMode = button.dataset.teleportMode === 'vehicle' ? 'vehicle' : 'character';
    modeButtons.forEach((item) => {
      const active = item === button;
      item.classList.toggle('active', active);
      item.setAttribute('aria-pressed', String(active));
    });
    clearTeleportTarget();
    renderTeleportActions();
    renderTeleportMarkers();
  }));
  actionClear.addEventListener('click', () => {
    clearTeleportTarget();
    renderTeleportActions();
    renderTeleportMarkers();
  });
  destinationClear.addEventListener('click', () => {
    clearTeleportDestination();
    renderTeleportActions();
    renderTeleportMarkers();
  });
  actionRefresh.addEventListener('click', () => withBusy(actionRefresh, async () => {
    try { await Promise.all([loadTeleportActionData({ force: true }), loadTeleportMapData({ force: true })]); } catch (error) { if (error.status !== 401) toast(error.message, 'error'); }
  }));
  actionForm.addEventListener('submit', (event) => {
    event.preventDefault();
    if (!actionTarget.value || teleportExecutionPending) return;
    withBusy(actionExecute, async () => {
      try {
        const payload = { targetType: actionType.value, targetId: actionTarget.value };
        if (actionType.value.startsWith('vehicle_to_')) payload.destinationId = destinationId.value;
        const quote = await api('/api/shop/teleport/quote', { method: 'POST', body: JSON.stringify(payload) });
        teleportQuoteDraft = { payload, quote };
        renderTeleportReceipt(quote, 'quote');
      } catch (error) { toast(error.message, 'error'); }
    }).finally(() => renderTeleportActions());
  });
  receiptConfirm.addEventListener('click', () => {
    if (!teleportQuoteDraft || teleportExecutionPending) return;
    withBusy(receiptConfirm, async () => {
      const key = teleportRequestKey();
      const payload = { ...teleportQuoteDraft.payload, quoteToken: teleportQuoteDraft.quote.quoteToken };
      try {
        const result = await api('/api/shop/teleport', { method: 'POST', headers: { 'Idempotency-Key': key }, body: JSON.stringify(payload) });
        if (['processing', 'success_pending_persistence'].includes(result.status)) {
          teleportExecutionPending = true;
          renderTeleportActions();
          if (result.status === 'success_pending_persistence') showTeleportResult(result);
          else renderTeleportReceipt(teleportQuoteDraft.quote, 'pending');
          void pollTeleportResult(payload, key);
          return;
        }
        showTeleportResult(result);
        await Promise.allSettled([loadTeleportActionData({ force: true }), loadTeleportMapData({ force: true })]);
      } catch (error) {
        closeModal(receiptModal);
        teleportQuoteDraft = null;
        toast(error.message, 'error');
      }
    }).finally(() => renderTeleportActions());
  });
  zoomOut.addEventListener('click', () => setScale(scale - 0.25));
  zoomIn.addEventListener('click', () => setScale(scale + 0.25));
  zoomReset.addEventListener('click', resetScale);
  range.addEventListener('input', () => setScale(Number(range.value) / 100));
  refresh.addEventListener('click', () => withBusy(refresh, async () => {
    try { await loadTeleportMapData({ force: true }); } catch (error) { if (error.status !== 401) toast(error.message, 'error'); }
  }));
  vehicleLayer.addEventListener('change', renderTeleportMarkers);
  playerLayer.addEventListener('change', renderTeleportMarkers);
  teammateLayer.addEventListener('change', renderTeleportMarkers);
  flagLayer.addEventListener('change', renderTeleportMarkers);
  fixedLayer.addEventListener('change', renderTeleportMarkers);
  gridLayer.addEventListener('change', () => { grid.hidden = !gridLayer.checked; });
  frame.addEventListener('wheel', (event) => {
    event.preventDefault();
    setScale(scale + (event.deltaY < 0 ? 0.25 : -0.25), { x: event.clientX, y: event.clientY });
  }, { passive: false });
  frame.addEventListener('pointerdown', (event) => {
    if (scale <= 1 || event.button > 0 || event.target.closest('.teleport-marker')) return;
    dragState = { x: event.clientX, y: event.clientY, panX, panY };
    frame.setPointerCapture(event.pointerId);
    canvas.classList.add('dragging');
    frame.classList.add('dragging');
  });
  frame.addEventListener('pointermove', (event) => {
    if (!dragState) return;
    panX = dragState.panX + event.clientX - dragState.x;
    panY = dragState.panY + event.clientY - dragState.y;
    applyTransform();
  });
  frame.addEventListener('pointerup', stopDragging);
  frame.addEventListener('pointercancel', stopDragging);
  frame.addEventListener('dblclick', resetScale);

  image.addEventListener('error', () => renderTeleportMapStatus('地图加载失败，请刷新页面重试'), { once: true });
  if (window.ResizeObserver) {
    teleportMapResizeObserver?.disconnect();
    teleportMapResizeObserver = new ResizeObserver(() => renderTeleportMarkers());
    teleportMapResizeObserver.observe(frame);
  }
  resetScale();
  renderTeleportMapStatus();
  renderTeleportActions();
  if (state.user) loadTeleportActionData().catch(() => {});
  if (!teleportMapRefreshTimer) configureTeleportMapRefresh();
  root.dataset.teleportReady = 'true';
}

loadTeleportPage();
