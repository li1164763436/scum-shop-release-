import { ServiceError } from './commerce-service.js';

const LOCATION_LINE = /^([^:\r\n]{1,100}):\s*X=([-+]?(?:\d+(?:\.\d+)?|\.\d+))\s+Y=([-+]?(?:\d+(?:\.\d+)?|\.\d+))\s+Z=([-+]?(?:\d+(?:\.\d+)?|\.\d+))$/;
const LOCATION_FIELDS = Object.freeze(['steam_id', 'name', 'x', 'y', 'z', 'world', 'source']);
const LOCATION_NUMBER = /^[-+]?(?:\d+(?:\.\d+)?|\.\d+)$/;

function responseText(value) {
  if (typeof value === 'string') return value;
  if (!value || typeof value !== 'object') return String(value ?? '');
  for (const key of ['response', 'output', 'result', 'message', 'data']) {
    if (typeof value[key] === 'string') return value[key];
  }
  return '';
}

export function parseTeleportLocationResponse(input) {
  const lines = responseText(input).replace(/^\uFEFF/, '').split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const match = lines.length === 1 ? lines[0].match(LOCATION_LINE) : null;
  if (match) {
    const worldX = Number(match[2]);
    const worldY = Number(match[3]);
    const worldZ = Number(match[4]);
    if (![worldX, worldY, worldZ].every(Number.isFinite)) throw new ServiceError('Location返回坐标无效', 502, 'TELEPORT_LOCATION_COORDINATE_INVALID');
    return { name: match[1].trim(), worldX, worldY, worldZ };
  }

  const fields = new Map();
  for (const line of lines) {
    const separator = line.indexOf('=');
    const key = separator > 0 ? line.slice(0, separator).trim().toLowerCase() : '';
    const value = separator > 0 ? line.slice(separator + 1).trim() : '';
    if (!LOCATION_FIELDS.includes(key) || fields.has(key) || !value) throw new ServiceError('Location返回格式与已验证样本不一致', 502, 'TELEPORT_LOCATION_FORMAT_INVALID');
    fields.set(key, value);
  }
  if (fields.size !== LOCATION_FIELDS.length || !/^\d{17}$/.test(fields.get('steam_id') || '') || (fields.get('name') || '').length > 100 || fields.get('world') !== 'SCUM') {
    throw new ServiceError('Location返回格式与已验证样本不一致', 502, 'TELEPORT_LOCATION_FORMAT_INVALID');
  }
  const coordinates = ['x', 'y', 'z'].map((key) => fields.get(key));
  if (!coordinates.every((value) => LOCATION_NUMBER.test(value))) throw new ServiceError('Location返回坐标无效', 502, 'TELEPORT_LOCATION_COORDINATE_INVALID');
  const [worldX, worldY, worldZ] = coordinates.map(Number);
  if (![worldX, worldY, worldZ].every(Number.isFinite)) throw new ServiceError('Location返回坐标无效', 502, 'TELEPORT_LOCATION_COORDINATE_INVALID');
  return { steamId: fields.get('steam_id'), name: fields.get('name'), worldX, worldY, worldZ };
}

export class TeleportPlayerLocationProvider {
  constructor({ clients, reader = null, logger, clock = () => Date.now() }) {
    this.clients = clients;
    this.reader = reader;
    this.logger = logger;
    this.clock = clock;
    this.previousKnown = new Set();
  }

  async collect() {
    const { ggcon, config } = await this.clients();
    const observedAt = new Date(this.clock()).toISOString();
    let ids = [];
    let listError = null;
    try {
      const online = await ggcon.players({ priority: 'normal' });
      ids = [...new Set((Array.isArray(online) ? online : []).map((player) => String(player?.steamId || '').trim()).filter((value) => /^\d{17}$/.test(value)))];
    } catch (error) {
      listError = error;
      this.logger?.warn?.('在线玩家列表采集失败，使用SCUM.db人物坐标', { component: 'teleport-player-location', errorCode: error?.code || error?.name || 'TELEPORT_PLAYER_LIST_FAILED' });
    }


    let savedSnapshot = null;
    if (this.reader) {
      try {
        savedSnapshot = await this.reader.read(config?.ggcon?.serverDirectory);
      } catch (error) {
        this.logger?.warn?.('SCUM数据库人物位置读取失败，本轮无法更新存档位置', { component: 'teleport-player-location', errorCode: error?.code || error?.name || 'SCUM_TELEPORT_PLAYER_READ_FAILED' });
      }
    }

    if (listError && !savedSnapshot) throw listError;
    const playersBySteamId = new Map((savedSnapshot?.players || []).map((player) => [String(player.steamId), player]));
    const authoritativeOnline = listError ? this.previousKnown : new Set(ids);
    const offlineSteamIds = listError ? [] : [...new Set([...this.previousKnown, ...playersBySteamId.keys()])].filter((steamId) => !authoritativeOnline.has(steamId));
    if (!listError) this.previousKnown = authoritativeOnline;
    const players = listError
      ? [...playersBySteamId.values()]
      : ids.map((steamId) => playersBySteamId.get(steamId)).filter(Boolean);
    const live = players.filter((player) => player.source === 'rcon_location').length;
    const saved = players.length - live;
    const failed = Math.max(0, ids.length - players.length);
    return {
      observedAt,
      players,
      offlineSteamIds,
      attempted: listError ? this.previousKnown.size : ids.length,
      failed,
      live,
      saved,
      squads: savedSnapshot?.squads || null,
      squadSnapshotComplete: savedSnapshot?.complete === true && Array.isArray(savedSnapshot?.squads),
      available: listError ? false : failed === 0
    };
  }
}

export const teleportPlayerLocationInternals = { responseText, LOCATION_LINE };
