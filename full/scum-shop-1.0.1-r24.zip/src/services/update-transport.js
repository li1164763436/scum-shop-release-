import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash, verify as verifySignature } from 'node:crypto';
import { createReadStream, createWriteStream } from 'node:fs';
import { Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';

const RETRYABLE_STATUS = new Set([408, 425, 429, 500, 502, 503, 504]);
const DEFAULT_RETRIES = 3;
const DEFAULT_RETRY_DELAY_MS = 750;
const DEFAULT_REQUEST_TIMEOUT_MS = 120000;
const BUILTIN_PUBLIC_KEYS = Object.freeze({
  'release-2026-01': '-----BEGIN PUBLIC KEY-----\nMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEsVkygPZ1tqqsXfz3GwGX0/5fGOLL\nObxbNwkauO3y/bcdRyCYwxqcmLH8sXmsK6WniDFcjgty/VEtZH/P8MTgNg==\n-----END PUBLIC KEY-----\n'
});

function positiveInteger(value, fallback, { min = 1, max = Number.MAX_SAFE_INTEGER } = {}) {
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed >= min && parsed <= max ? parsed : fallback;
}

export function splitUrlList(value) {
  const values = Array.isArray(value) ? value : String(value || '').split(/[\r\n,]+/);
  return [...new Set(values.map(item => String(item || '').trim()).filter(Boolean))];
}

export function requireUpdateUrl(value, { name = '更新地址', allowHttp = false, allowedHosts = [] } = {}) {
  let url;
  try { url = new URL(String(value || '').trim()); } catch { throw new Error(`${name}无效`); }
  if (url.username || url.password || url.hash) throw new Error(`${name}不得包含凭据或片段`);
  const hostname = url.hostname.toLowerCase().replace(/\.$/, '');
  const hosts = splitUrlList(allowedHosts).map(host => host.toLowerCase().replace(/\.$/, ''));
  if (url.protocol === 'http:') {
    if (!allowHttp) throw new Error(`${name}必须使用 HTTPS`);
    if (hostname !== '127.0.0.1' || !hosts.includes('127.0.0.1')) throw new Error(`${name}仅允许白名单中的本机 127.0.0.1 使用 HTTP`);
  } else if (url.protocol !== 'https:') throw new Error(`${name}必须使用 HTTPS`);
  if (hosts.length && !hosts.includes(hostname)) throw new Error(`${name}不在允许的更新域名中`);
  return url;
}

export function updateTransportOptions(env = process.env) {
  return {
    retries: positiveInteger(env.VERSION_UPDATE_RETRIES, DEFAULT_RETRIES, { max: 10 }),
    retryDelayMs: positiveInteger(env.VERSION_UPDATE_RETRY_DELAY_MS, DEFAULT_RETRY_DELAY_MS, { max: 30000 }),
    requestTimeoutMs: positiveInteger(env.VERSION_UPDATE_REQUEST_TIMEOUT_MS, DEFAULT_REQUEST_TIMEOUT_MS, { min: 5000, max: 3600000 }),
    concurrency: positiveInteger(env.VERSION_UPDATE_CONCURRENCY, 4, { max: 16 }),
    allowHttp: env.VERSION_UPDATE_ALLOW_HTTP === '1',
    allowedHosts: splitUrlList(env.VERSION_UPDATE_ALLOWED_HOSTS),
    requireSignature: env.VERSION_UPDATE_REQUIRE_SIGNATURE === '1',
    publicKeys: new Map([...Object.entries(BUILTIN_PUBLIC_KEYS), ...parsePublicKeys(env.VERSION_UPDATE_PUBLIC_KEYS)])
  };
}

export function parsePublicKeys(value) {
  if (!value) return new Map();
  let parsed;
  try { parsed = typeof value === 'string' ? JSON.parse(value) : value; } catch { throw new Error('版本更新公钥配置不是有效的 JSON'); }
  if (!parsed || Array.isArray(parsed) || typeof parsed !== 'object') throw new Error('版本更新公钥配置无效');
  return new Map(Object.entries(parsed).map(([keyId, publicKey]) => [String(keyId), String(publicKey)]));
}

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function retryable(error) {
  return error?.name === 'AbortError' || error?.name === 'TimeoutError' || error?.code === 'ECONNRESET' || error?.code === 'ETIMEDOUT' || error?.retryable === true;
}

function responseError(response, label) {
  const error = new Error(`${label}失败（HTTP ${response.status}）`);
  error.status = response.status;
  error.retryable = RETRYABLE_STATUS.has(response.status);
  return error;
}

const REDIRECT_STATUS = new Set([301, 302, 303, 307, 308]);

async function fetchWithValidatedRedirects(rawUrl, { fetchImpl, request, signal, validateUrl, maxRedirects = 5 }) {
  let current = validateUrl ? validateUrl(rawUrl).href : rawUrl;
  for (let redirects = 0; redirects <= maxRedirects; redirects += 1) {
    const response = await fetchImpl(current, { cache: 'no-store', ...request, redirect: 'manual', signal });
    if (!REDIRECT_STATUS.has(response.status)) return { response, url: current };
    if (redirects === maxRedirects) throw new Error('更新地址重定向次数过多');
    const location = response.headers.get('location');
    if (!location) throw new Error('更新地址重定向缺少目标');
    const next = new URL(location, current).href;
    current = validateUrl ? validateUrl(next).href : next;
  }
  throw new Error('更新地址重定向次数过多');
}

export async function fetchFromMirrors(urls, {
  label = '更新请求',
  retries = DEFAULT_RETRIES,
  retryDelayMs = DEFAULT_RETRY_DELAY_MS,
  timeoutMs = DEFAULT_REQUEST_TIMEOUT_MS,
  fetchImpl = globalThis.fetch,
  request = {},
  validateUrl
} = {}) {
  const mirrors = splitUrlList(urls);
  if (!mirrors.length) throw new Error(`${label}没有可用地址`);
  const failures = [];
  for (const rawUrl of mirrors) {
    const url = validateUrl ? validateUrl(rawUrl).href : rawUrl;
    for (let attempt = 1; attempt <= retries; attempt += 1) {
      try {
        const result = await fetchWithValidatedRedirects(url, {
          fetchImpl,
          request,
          signal: AbortSignal.timeout(timeoutMs),
          validateUrl
        });
        if (!result.response.ok) throw responseError(result.response, label);
        return result;
      } catch (error) {
        failures.push({ url, error });
        if (attempt >= retries || !retryable(error)) break;
        await wait(retryDelayMs * (2 ** (attempt - 1)));
      }
    }
  }
  const last = failures.at(-1)?.error;
  const error = new Error(`${label}失败，所有更新地址均不可用`);
  error.cause = last;
  error.failures = failures;
  throw error;
}

export async function fetchJsonFromMirrors(urls, options = {}) {
  const retries = positiveInteger(options.retries, DEFAULT_RETRIES, { max: 10 });
  const retryDelayMs = positiveInteger(options.retryDelayMs, DEFAULT_RETRY_DELAY_MS, { max: 30000 });
  const failures = [];
  for (const rawUrl of splitUrlList(urls)) {
    for (let attempt = 1; attempt <= retries; attempt += 1) {
      try {
        const { response, url } = await fetchFromMirrors([rawUrl], { ...options, retries: 1 });
        return { value: await response.json(), url };
      } catch (cause) {
        failures.push({ url: rawUrl, error: cause });
        const transportFailure = cause.failures?.at(-1)?.error;
        if (transportFailure && !retryable(transportFailure)) break;
        if (attempt < retries) await wait(retryDelayMs * (2 ** (attempt - 1)));
      }
    }
  }
  const error = new Error(`${options.label || '更新清单'}内容无效或所有更新地址均不可用`);
  error.cause = failures.at(-1)?.error;
  error.failures = failures;
  throw error;
}

async function digestPrefix(file, length) {
  const hash = createHash('sha256');
  if (length <= 0) return hash;
  let read = 0;
  for await (const chunk of createReadStream(file, { start: 0, end: length - 1 })) {
    read += chunk.length;
    hash.update(chunk);
  }
  if (read !== length) throw new Error('续传临时文件大小已变化');
  return hash;
}

async function fileDigest(file) {
  const stat = await fs.stat(file);
  if (!stat.isFile()) return null;
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(file)) hash.update(chunk);
  return { size: stat.size, sha256: hash.digest('hex') };
}

const downloadLocks = new Map();

async function downloadVerifiedFileUnlocked({
  urls,
  destination,
  expectedSize,
  expectedSha256,
  label = '更新文件',
  retries = DEFAULT_RETRIES,
  retryDelayMs = DEFAULT_RETRY_DELAY_MS,
  timeoutMs = DEFAULT_REQUEST_TIMEOUT_MS,
  fetchImpl = globalThis.fetch,
  validateUrl
}) {
  const mirrors = splitUrlList(urls);
  if (!mirrors.length) throw new Error(`${label}没有可用地址`);
  await fs.mkdir(path.dirname(destination), { recursive: true });
  const partial = `${destination}.part`;
  const failures = [];
  for (const rawUrl of mirrors) {
    const url = validateUrl ? validateUrl(rawUrl).href : rawUrl;
    for (let attempt = 1; attempt <= retries; attempt += 1) {
      let offset = 0;
      try {
        const stat = await fs.stat(partial).catch(() => null);
        offset = stat?.isFile() && stat.size < expectedSize ? stat.size : 0;
        if (stat && offset === 0) await fs.rm(partial, { force: true });
        const headers = new Headers({ 'Accept-Encoding': 'identity' });
        if (offset > 0) headers.set('Range', `bytes=${offset}-`);
        const result = await fetchWithValidatedRedirects(url, {
          fetchImpl,
          request: { headers },
          signal: AbortSignal.timeout(timeoutMs),
          validateUrl
        });
        const { response } = result;
        if (!response.ok) throw responseError(response, label);
        if (offset > 0 && response.status !== 206) {
          await fs.rm(partial, { force: true });
          offset = 0;
        }
        if (offset > 0) {
          const range = /^bytes (\d+)-(\d+)\/(\d+)$/.exec(response.headers.get('content-range') || '');
          if (!range || Number(range[1]) !== offset || Number(range[2]) < offset || Number(range[3]) !== expectedSize) {
            const error = new Error(`${label}续传响应范围无效`);
            error.retryable = false;
            throw error;
          }
        }
        if (!response.body) throw new Error(`${label}下载响应为空`);
        const hash = await digestPrefix(partial, offset);
        let size = offset;
        const meter = new Transform({ transform(chunk, encoding, callback) {
          size += chunk.length;
          if (size > expectedSize) return callback(new Error(`${label}大小超出清单限制`));
          hash.update(chunk);
          callback(null, chunk);
        } });
        await pipeline(response.body, meter, createWriteStream(partial, { flags: offset > 0 ? 'a' : 'w' }));
        if (size < expectedSize) {
          const error = new Error(`${label}下载提前结束`);
          error.retryable = true;
          throw error;
        }
        if (size !== expectedSize || hash.digest('hex') !== expectedSha256) {
          await fs.rm(partial, { force: true });
          const error = new Error(`${label}校验失败`);
          error.retryable = false;
          throw error;
        }
        await fs.rename(partial, destination).catch(async error => {
          await fs.rm(destination, { force: true });
          await fs.rename(partial, destination).catch(() => { throw error; });
        });
        return { url: result.url, bytes: expectedSize - offset, resumedBytes: offset };
      } catch (error) {
        failures.push({ url, error });
        if (attempt >= retries || !retryable(error)) break;
        await wait(retryDelayMs * (2 ** (attempt - 1)));
      }
    }
  }
  const error = new Error(`${label}下载失败，所有更新地址均不可用`);
  error.cause = failures.at(-1)?.error;
  error.failures = failures;
  throw error;
}

export async function downloadVerifiedFile(options) {
  const key = path.resolve(options.destination);
  const previous = downloadLocks.get(key) || Promise.resolve();
  let release;
  const current = new Promise(resolve => { release = resolve; });
  const chain = previous.then(() => current);
  downloadLocks.set(key, chain);
  await previous;
  try {
    const existing = await fileDigest(key).catch(() => null);
    if (existing?.size === options.expectedSize && existing.sha256 === options.expectedSha256) {
      return { url: null, bytes: 0, resumedBytes: options.expectedSize, cached: true };
    }
    return await downloadVerifiedFileUnlocked(options);
  } finally {
    release();
    if (downloadLocks.get(key) === chain) downloadLocks.delete(key);
  }
}

export function releaseManifestSignaturePayload(manifest) {
  const lines = ['scum-release-manifest-signature-v1', `schemaVersion=${Number(manifest?.schemaVersion)}`, `version=${String(manifest?.version || '')}`, `releaseRevision=${Number(manifest?.releaseRevision || 0)}`];
  for (const file of manifest?.files || []) lines.push(`${String(file.path)}\0${Number(file.size)}\0${String(file.sha256)}`);
  return Buffer.from(`${lines.join('\n')}\n`, 'utf8');
}

export function verifyReleaseManifestSignature(manifest, { publicKeys = new Map(), requireSignature = false } = {}) {
  const signature = manifest?.signature;
  if (!signature) {
    if (requireSignature) throw new Error('更新完整性清单缺少数字签名');
    return { verified: false, legacy: true };
  }
  if (signature.algorithm !== 'ecdsa-p256-sha256' || !signature.keyId || !signature.value) throw new Error('更新完整性清单数字签名格式无效');
  const publicKey = publicKeys.get(String(signature.keyId));
  if (!publicKey) throw new Error(`更新完整性清单使用了未知签名密钥：${signature.keyId}`);
  const valid = verifySignature('sha256', releaseManifestSignaturePayload(manifest), { key: publicKey, dsaEncoding: 'ieee-p1363' }, Buffer.from(String(signature.value), 'base64'));
  if (!valid) throw new Error('更新完整性清单数字签名验证失败');
  return { verified: true, keyId: String(signature.keyId) };
}
