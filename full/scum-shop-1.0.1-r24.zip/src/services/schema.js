import { SCUM_LOG_TABLES, SCUM_LOG_TABLE_STATEMENTS } from './scum-log-table-schema.js';
import { accountTableStatement, migrateAccountSchema } from './account-schema-migration.js';

const SCHEMA_LOCK_NAME = 'scum_shop_schema_upgrade_v1';

const statements = [
  accountTableStatement,
  `CREATE TABLE IF NOT EXISTS gift_types (type_code VARCHAR(16) PRIMARY KEY, display_name VARCHAR(20) NOT NULL UNIQUE, sort_order INT UNSIGNED NOT NULL DEFAULT 0, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS cloud_pass_plans (pass_type VARCHAR(16) PRIMARY KEY, enabled TINYINT(1) NOT NULL DEFAULT 0, price BIGINT UNSIGNED NOT NULL DEFAULT 0, duration_days INT UNSIGNED NOT NULL DEFAULT 30, daily_quota INT UNSIGNED NOT NULL DEFAULT 0, updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS cloud_recycle_restrictions (item_code VARCHAR(80) PRIMARY KEY, item_name VARCHAR(100) NOT NULL DEFAULT '', reason VARCHAR(500) NOT NULL DEFAULT '', enabled TINYINT(1) NOT NULL DEFAULT 1, created_by_user_id BIGINT UNSIGNED NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS \`系统配置\` (setting_key VARCHAR(64) PRIMARY KEY, background_image VARCHAR(2000) NOT NULL DEFAULT '', attribute_point_price BIGINT UNSIGNED NOT NULL DEFAULT 0, skill_level_price BIGINT UNSIGNED NOT NULL DEFAULT 0, cloud_market_enabled TINYINT(1) NOT NULL DEFAULT 1, cloud_fee_bps INT UNSIGNED NOT NULL DEFAULT 300, cloud_withdraw_fee BIGINT UNSIGNED NOT NULL DEFAULT 0, cloud_daily_base_quota INT UNSIGNED NOT NULL DEFAULT 10, cloud_destroy_refund_percent INT UNSIGNED NOT NULL DEFAULT 20, cloud_destroy_fallback_refund BIGINT UNSIGNED NOT NULL DEFAULT 2, cloud_updated_by_user_id BIGINT UNSIGNED NULL, updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), CONSTRAINT chk_system_settings_cloud_fee CHECK (cloud_fee_bps <= 10000)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS \`数据表目录\` (physical_name VARCHAR(64) PRIMARY KEY, chinese_name VARCHAR(100) NOT NULL, category_name VARCHAR(100) NOT NULL, purpose VARCHAR(500) NOT NULL, object_type VARCHAR(16) NOT NULL DEFAULT 'table', updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_database_catalog_category (category_name,chinese_name)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS character_growth_purchases (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, steam_id VARCHAR(17) NOT NULL, request_key VARCHAR(100) NOT NULL UNIQUE, request_fingerprint CHAR(64) NOT NULL, purchase_type VARCHAR(16) NOT NULL, target_json JSON NOT NULL, quantity INT UNSIGNED NOT NULL, unit_price BIGINT UNSIGNED NOT NULL, total_price BIGINT UNSIGNED NOT NULL, balance_after BIGINT NOT NULL, status VARCHAR(16) NOT NULL DEFAULT 'processing', error_message VARCHAR(500) NULL, completed_at DATETIME(3) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_character_growth_player (steam_id,created_at), CONSTRAINT fk_character_growth_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT chk_character_growth_type CHECK (purchase_type IN ('attribute','skill')), CONSTRAINT chk_character_growth_quantity CHECK (quantity >= 1), CONSTRAINT chk_character_growth_status CHECK (status IN ('processing','completed','failed'))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS \`授权账号绑定\` (\`绑定编号\` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, \`授权账号\` VARCHAR(80) NOT NULL, \`授权账号规范值\` VARCHAR(80) NOT NULL UNIQUE, \`许可证ID\` VARCHAR(100) NOT NULL UNIQUE, \`商城用户编号\` BIGINT UNSIGNED NOT NULL UNIQUE, \`SteamID\` VARCHAR(17) NOT NULL UNIQUE, \`绑定状态\` VARCHAR(16) NOT NULL DEFAULT 'active', \`绑定时间\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), \`最后验证时间\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), \`撤销时间\` DATETIME(3) NULL, \`撤销原因\` VARCHAR(500) NULL, CONSTRAINT fk_license_binding_user FOREIGN KEY (\`商城用户编号\`) REFERENCES \`商城用户\`(\`商城用户编号\`), CONSTRAINT fk_license_binding_account FOREIGN KEY (\`SteamID\`) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT chk_license_binding_status CHECK (\`绑定状态\` IN ('active','revoked'))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS membership_change_logs (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, steam_id VARCHAR(17) NOT NULL, old_level INT NOT NULL, new_level INT NOT NULL, old_expires_at DATETIME(3) NULL, new_expires_at DATETIME(3) NULL, reason VARCHAR(500) NOT NULL, operator VARCHAR(100) NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_membership_logs_steam_created (steam_id,created_at), INDEX idx_membership_logs_created (created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS membership_strategies (level INT PRIMARY KEY, title VARCHAR(100) NOT NULL, opening_amount BIGINT UNSIGNED NOT NULL DEFAULT 0, period_days INT UNSIGNED NOT NULL DEFAULT 30, gift_tokens BIGINT UNSIGNED NOT NULL DEFAULT 0, upgrade_spend BIGINT UNSIGNED NOT NULL DEFAULT 0, teleport_discount DECIMAL(5,2) NOT NULL DEFAULT 100.00, online_bonus DECIMAL(5,2) NOT NULL DEFAULT 100.00, shopping_discount DECIMAL(5,2) NOT NULL DEFAULT 100.00, gift_discount DECIMAL(5,2) NOT NULL DEFAULT 100.00, recharge_bonus DECIMAL(5,2) NOT NULL DEFAULT 100.00, daily_teleports INT UNSIGNED NOT NULL DEFAULT 0, checkin_bonus BIGINT UNSIGNED NOT NULL DEFAULT 0, extra_hint VARCHAR(500) NULL, enabled TINYINT(1) NOT NULL DEFAULT 1, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), CONSTRAINT chk_membership_strategy_level CHECK (level BETWEEN 0 AND 100), CONSTRAINT chk_membership_strategy_discount CHECK (teleport_discount BETWEEN 0 AND 100 AND shopping_discount BETWEEN 0 AND 100 AND gift_discount BETWEEN 0 AND 100), CONSTRAINT chk_membership_strategy_bonus CHECK (online_bonus BETWEEN 0 AND 1000 AND recharge_bonus BETWEEN 0 AND 1000)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS \`传送管理设置\` (\`配置编号\` TINYINT UNSIGNED PRIMARY KEY, \`传送总开关\` TINYINT(1) NOT NULL DEFAULT 1, \`基础价格\` BIGINT UNSIGNED NOT NULL DEFAULT 0, \`基础每日次数\` INT UNSIGNED NOT NULL DEFAULT 0, \`冷却秒数\` INT UNSIGNED NOT NULL DEFAULT 300, \`角色计费方式\` VARCHAR(16) NOT NULL DEFAULT 'fixed', \`角色固定价格\` BIGINT UNSIGNED NOT NULL DEFAULT 0, \`角色每公里价格\` BIGINT UNSIGNED NOT NULL DEFAULT 0, \`角色每日次数\` INT UNSIGNED NOT NULL DEFAULT 0, \`角色传送间隔秒数\` INT UNSIGNED NOT NULL DEFAULT 300, \`载具计费方式\` VARCHAR(16) NOT NULL DEFAULT 'fixed', \`载具固定价格\` BIGINT UNSIGNED NOT NULL DEFAULT 0, \`载具每公里价格\` BIGINT UNSIGNED NOT NULL DEFAULT 0, \`载具每日次数\` INT UNSIGNED NOT NULL DEFAULT 0, \`载具传送间隔秒数\` INT UNSIGNED NOT NULL DEFAULT 300, \`小队玩家互传\` TINYINT(1) NOT NULL DEFAULT 0, \`玩家到小队载具\` TINYINT(1) NOT NULL DEFAULT 1, \`玩家到授权领地旗\` TINYINT(1) NOT NULL DEFAULT 1, \`固定位置传送\` TINYINT(1) NOT NULL DEFAULT 1, \`领地内载具到玩家\` TINYINT(1) NOT NULL DEFAULT 1, \`远距离载具到玩家\` TINYINT(1) NOT NULL DEFAULT 1, \`载具到固定位置\` TINYINT(1) NOT NULL DEFAULT 1, \`同意请求有效秒数\` INT UNSIGNED NOT NULL DEFAULT 300, \`最后修改管理员编号\` BIGINT UNSIGNED NULL, \`更新时间\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), CONSTRAINT chk_teleport_settings_singleton CHECK (\`配置编号\`=1)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS \`传送固定位置\` (\`位置编号\` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, \`位置名称\` VARCHAR(100) NOT NULL, \`世界X坐标\` DECIMAL(20,6) NOT NULL, \`世界Y坐标\` DECIMAL(20,6) NOT NULL, \`世界Z坐标\` DECIMAL(20,6) NOT NULL, \`是否启用\` TINYINT(1) NOT NULL DEFAULT 1, \`排序值\` INT UNSIGNED NOT NULL DEFAULT 0, \`来源类型\` VARCHAR(16) NOT NULL DEFAULT 'admin', \`可见范围\` VARCHAR(16) NOT NULL DEFAULT 'public', \`归属SteamID\` VARCHAR(17) NULL, \`创建管理员编号\` BIGINT UNSIGNED NULL, \`最后修改管理员编号\` BIGINT UNSIGNED NULL, \`创建时间\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), \`更新时间\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_teleport_fixed_enabled_sort (\`是否启用\`,\`排序值\`,\`位置编号\`), INDEX idx_teleport_fixed_owner (\`归属SteamID\`,\`是否启用\`), CONSTRAINT chk_teleport_fixed_source CHECK (\`来源类型\` IN ('admin','player')), CONSTRAINT chk_teleport_fixed_visibility CHECK (\`可见范围\` IN ('public','private')), CONSTRAINT chk_teleport_fixed_owner CHECK ((\`可见范围\`='public' AND \`归属SteamID\` IS NULL) OR (\`可见范围\`='private' AND \`归属SteamID\` IS NOT NULL)), CONSTRAINT fk_teleport_fixed_owner FOREIGN KEY (\`归属SteamID\`) REFERENCES \`商城用户\`(\`SteamID\`) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS \`玩家传送同意请求\` (\`请求编号\` CHAR(36) PRIMARY KEY, \`发起玩家SteamID\` VARCHAR(17) NOT NULL, \`目标玩家SteamID\` VARCHAR(17) NOT NULL, \`请求状态\` VARCHAR(16) NOT NULL DEFAULT 'pending', \`过期时间\` DATETIME(3) NOT NULL, \`同意时间\` DATETIME(3) NULL, \`拒绝时间\` DATETIME(3) NULL, \`使用时间\` DATETIME(3) NULL, \`创建时间\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), \`更新时间\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_teleport_consent_requester (\`发起玩家SteamID\`,\`创建时间\`), INDEX idx_teleport_consent_target (\`目标玩家SteamID\`,\`请求状态\`,\`过期时间\`), CONSTRAINT fk_teleport_consent_requester FOREIGN KEY (\`发起玩家SteamID\`) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT fk_teleport_consent_target FOREIGN KEY (\`目标玩家SteamID\`) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT chk_teleport_consent_players CHECK (\`发起玩家SteamID\`<>\`目标玩家SteamID\`), CONSTRAINT chk_teleport_consent_status CHECK (\`请求状态\` IN ('pending','accepted','rejected','consumed'))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS \`传送执行记录\` (\`记录编号\` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, \`发起玩家SteamID\` VARCHAR(17) NOT NULL, \`请求幂等键\` VARCHAR(100) NOT NULL UNIQUE, \`请求指纹\` CHAR(64) NOT NULL, \`目标类型\` VARCHAR(32) NOT NULL, \`目标引用\` VARCHAR(100) NOT NULL, \`目标名称快照\` VARCHAR(255) NOT NULL, \`游戏目标编号\` BIGINT UNSIGNED NULL, \`计费方式\` VARCHAR(16) NOT NULL DEFAULT 'fixed', \`传送距离公里\` DECIMAL(12,3) NULL, \`基础价格\` BIGINT UNSIGNED NOT NULL DEFAULT 0, \`折扣百分比\` DECIMAL(5,2) NOT NULL DEFAULT 100.00, \`实扣商城币\` BIGINT UNSIGNED NOT NULL DEFAULT 0, \`扣款后余额\` BIGINT NOT NULL, \`执行状态\` VARCHAR(32) NOT NULL DEFAULT 'prepared', \`错误代码\` VARCHAR(64) NULL, \`错误信息\` VARCHAR(500) NULL, \`完成时间\` DATETIME(3) NULL, \`创建时间\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), \`更新时间\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_teleport_player_day (\`发起玩家SteamID\`,\`创建时间\`,\`执行状态\`), CONSTRAINT fk_teleport_account FOREIGN KEY (\`发起玩家SteamID\`) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT chk_teleport_target_type CHECK (\`目标类型\` IN ('player','owned_vehicle','territory_flag','fixed_location','vehicle_to_territory_flag','vehicle_to_player','vehicle_to_fixed_location')), CONSTRAINT chk_teleport_status CHECK (\`执行状态\` IN ('prepared','completed','failed','manual_review')), CONSTRAINT chk_teleport_discount CHECK (\`折扣百分比\` BETWEEN 0 AND 100)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS \`传送位置快照\` (\`实体类型\` ENUM('flag') NOT NULL, \`实体标识\` VARCHAR(100) NOT NULL, \`归属SteamID\` VARCHAR(17) NOT NULL, \`显示名称\` VARCHAR(100) NOT NULL, \`世界X坐标\` DECIMAL(20,6) NOT NULL, \`世界Y坐标\` DECIMAL(20,6) NOT NULL, \`世界Z坐标\` DECIMAL(20,6) NULL, \`数据来源\` VARCHAR(100) NOT NULL, \`观测时间\` DATETIME(3) NOT NULL, \`是否当前有效\` TINYINT(1) NOT NULL DEFAULT 1, \`更新时间\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), PRIMARY KEY (\`实体类型\`,\`实体标识\`), INDEX \`传送位置快照_归属索引\` (\`归属SteamID\`,\`实体类型\`,\`是否当前有效\`), INDEX \`传送位置快照_观测时间索引\` (\`观测时间\`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS membership_policy (id TINYINT PRIMARY KEY, open_enabled TINYINT(1) NOT NULL DEFAULT 1, consumption_upgrade_enabled TINYINT(1) NOT NULL DEFAULT 0, renewal_enabled TINYINT(1) NOT NULL DEFAULT 1, renewal_price_strategy VARCHAR(16) NOT NULL DEFAULT 'original', renewal_gift_enabled TINYINT(1) NOT NULL DEFAULT 1, renewal_discount DECIMAL(5,2) NOT NULL DEFAULT 100.00, renewal_fixed_price BIGINT UNSIGNED NOT NULL DEFAULT 0, upgrade_strategy VARCHAR(16) NOT NULL DEFAULT 'allow', upgrade_expiry_strategy VARCHAR(16) NOT NULL DEFAULT 'extend', upgrade_gift_enabled TINYINT(1) NOT NULL DEFAULT 0, upgrade_gift_amount BIGINT UNSIGNED NOT NULL DEFAULT 0, lower_level_purchase VARCHAR(16) NOT NULL DEFAULT 'forbid', updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS membership_purchases (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, request_key VARCHAR(100) NOT NULL UNIQUE, steam_id VARCHAR(17) NOT NULL, old_level INT NOT NULL, new_level INT NOT NULL, purchase_type VARCHAR(16) NOT NULL, price BIGINT UNSIGNED NOT NULL, gift_tokens BIGINT UNSIGNED NOT NULL DEFAULT 0, expires_at DATETIME(3) NULL, balance_after BIGINT NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_membership_purchase_player (steam_id,created_at), CONSTRAINT fk_membership_purchase_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS bootstrap_states (state_key VARCHAR(64) PRIMARY KEY, created_user_id BIGINT UNSIGNED NULL, completed_at DATETIME(3) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), CONSTRAINT fk_bootstrap_state_user FOREIGN KEY (created_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS shop_sessions (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL, token_hash CHAR(64) NOT NULL UNIQUE, expires_at DATETIME(3) NOT NULL, revoked_at DATETIME(3) NULL, ip_address VARCHAR(64) NULL, user_agent VARCHAR(255) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_shop_sessions_user (user_id), INDEX idx_shop_sessions_expiry (expires_at), CONSTRAINT fk_shop_session_user FOREIGN KEY (user_id) REFERENCES \`商城用户\`(\`商城用户编号\`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS admin_role_audits (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, actor_user_id BIGINT UNSIGNED NULL, actor_type VARCHAR(16) NOT NULL DEFAULT 'shop_user', actor_label VARCHAR(100) NOT NULL, actor_username_snapshot VARCHAR(100) NOT NULL, target_user_id BIGINT UNSIGNED NOT NULL, target_username_snapshot VARCHAR(32) NOT NULL, target_steam_id VARCHAR(17) NULL, old_role VARCHAR(16) NOT NULL, new_role VARCHAR(16) NOT NULL, reason VARCHAR(500) NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_admin_role_audit_target_created (target_user_id,created_at), INDEX idx_admin_role_audit_actor_created (actor_user_id,created_at), CONSTRAINT fk_admin_role_audit_actor FOREIGN KEY (actor_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`) ON DELETE SET NULL, CONSTRAINT fk_admin_role_audit_target FOREIGN KEY (target_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`), CONSTRAINT chk_admin_role_audit_actor CHECK (actor_type IN ('shop_user','cli','license')), CONSTRAINT chk_admin_role_audit_change CHECK (old_role IN ('user','admin','super_admin') AND new_role IN ('user','admin','super_admin') AND old_role<>new_role)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS steam_bind_challenges (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, steam_id VARCHAR(17) NOT NULL, code_hash CHAR(64) NOT NULL, attempts INT UNSIGNED NOT NULL DEFAULT 0, max_attempts INT UNSIGNED NOT NULL DEFAULT 5, expires_at DATETIME(3) NOT NULL, consumed_at DATETIME(3) NULL, invalidated_at DATETIME(3) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_bind_challenge_steam (steam_id,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS coin_ledger (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, steam_id VARCHAR(17) NOT NULL, amount BIGINT NOT NULL, balance_after BIGINT NOT NULL, type VARCHAR(32) NOT NULL, reference_type VARCHAR(32) NULL, reference_id VARCHAR(100) NULL, note VARCHAR(255) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_ledger_steam_created (steam_id,created_at), INDEX idx_ledger_reference (reference_type,reference_id,type), CONSTRAINT fk_ledger_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS account_exchanges (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, steam_id VARCHAR(17) NOT NULL, request_key VARCHAR(100) NOT NULL UNIQUE, direction VARCHAR(16) NOT NULL, input_amount BIGINT UNSIGNED NOT NULL, output_amount BIGINT UNSIGNED NOT NULL, rate_snapshot DECIMAL(20,8) NOT NULL, coin_delta BIGINT NOT NULL, gold_delta BIGINT NOT NULL, status VARCHAR(16) NOT NULL DEFAULT 'pending', rcon_command VARCHAR(255) NOT NULL, rcon_response VARCHAR(500) NULL, error_message VARCHAR(500) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), completed_at DATETIME(3) NULL, INDEX idx_exchange_account_created (steam_id,created_at), INDEX idx_exchange_status (status,created_at), CONSTRAINT fk_exchange_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT chk_exchange_direction CHECK (direction IN ('coin_to_gold','gold_to_coin')), CONSTRAINT chk_exchange_status CHECK (status IN ('pending','executing','succeeded','failed','uncertain')), CONSTRAINT chk_exchange_amount CHECK (input_amount >= 1 AND output_amount >= 1)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS products (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, sku VARCHAR(64) NOT NULL UNIQUE, name VARCHAR(100) NOT NULL, price BIGINT NOT NULL, item_id VARCHAR(80) NOT NULL, grant_amount INT UNSIGNED NOT NULL, parent_category VARCHAR(100) NULL, category_name VARCHAR(100) NULL, currency_type VARCHAR(32) NOT NULL DEFAULT 'coin', min_member_level INT NOT NULL DEFAULT 0, image_path VARCHAR(500) NULL, fulfillment_codes TEXT NULL, enabled TINYINT(1) NOT NULL DEFAULT 1, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS product_categories (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, parent_name VARCHAR(100) NOT NULL, name VARCHAR(100) NOT NULL, sort_order INT UNSIGNED NOT NULL DEFAULT 0, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), UNIQUE KEY uk_product_category (parent_name,name), INDEX idx_product_category_parent (parent_name,sort_order,id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS product_parent_categories (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE, sort_order INT UNSIGNED NOT NULL DEFAULT 0, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_product_parent_sort (sort_order,id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS gift_packages (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE, gift_type VARCHAR(16) NOT NULL DEFAULT 'normal', description TEXT NULL, image_path VARCHAR(500) NULL, expires_at DATETIME(3) NULL, next_reset_at DATETIME(3) NULL, reset_cycle VARCHAR(16) NOT NULL DEFAULT 'none', enabled TINYINT(1) NOT NULL DEFAULT 1, target_steam_id VARCHAR(17) NULL, required_title VARCHAR(100) NULL, member_level INT NOT NULL DEFAULT 0, member_mode VARCHAR(16) NOT NULL DEFAULT 'minimum', total_limit INT UNSIGNED NOT NULL DEFAULT 1, daily_limit INT UNSIGNED NOT NULL DEFAULT 1, period_limit INT UNSIGNED NOT NULL DEFAULT 1, price BIGINT UNSIGNED NOT NULL DEFAULT 0, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_gifts_enabled_id (enabled,id), CONSTRAINT chk_gift_total CHECK (total_limit BETWEEN 1 AND 99999), CONSTRAINT chk_gift_daily CHECK (daily_limit BETWEEN 1 AND 99999), CONSTRAINT chk_gift_period CHECK (period_limit BETWEEN 1 AND 99999), CONSTRAINT chk_gift_price CHECK (price >= 0)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS gift_actions (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, gift_id BIGINT UNSIGNED NOT NULL, action_index INT UNSIGNED NOT NULL, action_type VARCHAR(16) NOT NULL, product_id BIGINT UNSIGNED NULL, item_id VARCHAR(80) NULL, quantity INT UNSIGNED NULL, options_json JSON NULL, coin_amount BIGINT UNSIGNED NULL, raw_text VARCHAR(500) NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), UNIQUE KEY uk_gift_action_index (gift_id,action_index), CONSTRAINT fk_gift_action_gift FOREIGN KEY (gift_id) REFERENCES gift_packages(id) ON DELETE CASCADE, CONSTRAINT fk_gift_action_product FOREIGN KEY (product_id) REFERENCES products(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS redeem_codes (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE, code_hash CHAR(64) NOT NULL UNIQUE, code_hint VARCHAR(4) NULL, code_type VARCHAR(16) NOT NULL DEFAULT 'normal', description TEXT NULL, enabled TINYINT(1) NOT NULL DEFAULT 1, target_steam_id VARCHAR(17) NULL, member_level INT NOT NULL DEFAULT 0, member_mode VARCHAR(16) NOT NULL DEFAULT 'minimum', total_limit INT UNSIGNED NULL, per_user_limit INT UNSIGNED NULL, starts_at DATETIME(3) NULL, expires_at DATETIME(3) NULL, created_by VARCHAR(100) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), used_count INT UNSIGNED NOT NULL DEFAULT 0, INDEX idx_redeem_codes_enabled_type (enabled,code_type), INDEX idx_redeem_codes_validity (enabled,starts_at,expires_at), INDEX idx_redeem_codes_target (target_steam_id,enabled), CONSTRAINT chk_redeem_code_hint CHECK (code_hint IS NULL OR CHAR_LENGTH(code_hint) BETWEEN 1 AND 4), CONSTRAINT chk_redeem_code_type CHECK (code_type IN ('normal','single','limited','timed','member','private')), CONSTRAINT chk_redeem_enabled CHECK (enabled IN (0,1)), CONSTRAINT chk_redeem_member_mode CHECK (member_mode IN ('minimum','exact')), CONSTRAINT chk_redeem_member_level CHECK (member_level >= 0), CONSTRAINT chk_redeem_total_limit CHECK (total_limit IS NULL OR total_limit >= 1), CONSTRAINT chk_redeem_per_user_limit CHECK (per_user_limit IS NULL OR per_user_limit >= 1), CONSTRAINT chk_redeem_limits CHECK (total_limit IS NULL OR per_user_limit IS NULL OR per_user_limit <= total_limit), CONSTRAINT chk_redeem_used_count CHECK (total_limit IS NULL OR used_count <= total_limit), CONSTRAINT chk_redeem_validity CHECK (starts_at IS NULL OR expires_at IS NULL OR starts_at < expires_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS redeem_code_actions (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, redeem_code_id BIGINT UNSIGNED NOT NULL, action_index INT UNSIGNED NOT NULL, action_type VARCHAR(16) NOT NULL, item_id VARCHAR(80) NULL, quantity INT UNSIGNED NULL, options_json JSON NULL, coin_amount BIGINT UNSIGNED NULL, raw_text VARCHAR(500) NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), UNIQUE KEY uk_redeem_action_index (redeem_code_id,action_index), CONSTRAINT fk_redeem_action_code FOREIGN KEY (redeem_code_id) REFERENCES redeem_codes(id) ON DELETE CASCADE, CONSTRAINT chk_redeem_action_type CHECK (action_type IN ('spawn_item','shop_coin')), CONSTRAINT chk_redeem_action_payload CHECK ((action_type='spawn_item' AND item_id IS NOT NULL AND quantity IS NOT NULL AND quantity >= 1 AND coin_amount IS NULL) OR (action_type='shop_coin' AND item_id IS NULL AND quantity IS NULL AND coin_amount IS NOT NULL AND coin_amount >= 1))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS player_titles (steam_id VARCHAR(17) NOT NULL, title_name VARCHAR(100) NOT NULL, expires_at DATETIME(3) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), PRIMARY KEY (steam_id,title_name), INDEX idx_title_eligibility (steam_id,title_name,expires_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS orders (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, order_no VARCHAR(64) NOT NULL UNIQUE, source VARCHAR(32) NOT NULL, external_order_id VARCHAR(100) NULL, request_hash CHAR(64) NULL, steam_id VARCHAR(17) NOT NULL, gift_id BIGINT UNSIGNED NULL, gift_claim_id BIGINT UNSIGNED NULL UNIQUE, redeem_code_id BIGINT UNSIGNED NULL, redeem_claim_id BIGINT UNSIGNED NULL UNIQUE, total_amount BIGINT NOT NULL, status VARCHAR(32) NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), UNIQUE KEY uk_order_source_external (source,external_order_id), INDEX idx_orders_steam_created (steam_id,created_at), INDEX idx_orders_redeem_code (redeem_code_id), CONSTRAINT fk_order_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT fk_order_gift FOREIGN KEY (gift_id) REFERENCES gift_packages(id), CONSTRAINT fk_order_redeem_code FOREIGN KEY (redeem_code_id) REFERENCES redeem_codes(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS gift_claims (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, gift_id BIGINT UNSIGNED NOT NULL, steam_id VARCHAR(17) NOT NULL, order_id BIGINT UNSIGNED NULL UNIQUE, request_key VARCHAR(100) NOT NULL UNIQUE, claim_period_key VARCHAR(32) NULL, claim_day DATE NOT NULL, price_paid BIGINT UNSIGNED NOT NULL DEFAULT 0, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_claim_total (gift_id,steam_id,created_at), INDEX idx_claim_day (gift_id,steam_id,claim_day), INDEX idx_claim_period (gift_id,steam_id,claim_period_key), CONSTRAINT fk_claim_gift FOREIGN KEY (gift_id) REFERENCES gift_packages(id), CONSTRAINT fk_claim_order FOREIGN KEY (order_id) REFERENCES orders(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS redeem_code_claims (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, redeem_code_id BIGINT UNSIGNED NOT NULL, steam_id VARCHAR(17) NOT NULL, order_id BIGINT UNSIGNED NULL UNIQUE, request_key VARCHAR(100) NOT NULL UNIQUE, claim_day DATE NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_redeem_claim_code_created (redeem_code_id,created_at), INDEX idx_redeem_claim_player_created (steam_id,created_at), INDEX idx_redeem_claim_code_player_day (redeem_code_id,steam_id,claim_day), CONSTRAINT fk_redeem_claim_code FOREIGN KEY (redeem_code_id) REFERENCES redeem_codes(id), CONSTRAINT fk_redeem_claim_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT fk_redeem_claim_order FOREIGN KEY (order_id) REFERENCES orders(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS order_items (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, order_id BIGINT UNSIGNED NOT NULL, product_id BIGINT UNSIGNED NULL, sku VARCHAR(64) NOT NULL, name VARCHAR(100) NOT NULL, unit_price BIGINT NOT NULL, quantity INT UNSIGNED NOT NULL, item_id VARCHAR(80) NULL, grant_amount INT UNSIGNED NULL, parent_category VARCHAR(100) NULL, category_name VARCHAR(100) NULL, currency_type VARCHAR(32) NOT NULL DEFAULT 'coin', min_member_level INT NOT NULL DEFAULT 0, image_path VARCHAR(500) NULL, fulfillment_codes_snapshot TEXT NULL, INDEX idx_order_items_order (order_id), CONSTRAINT fk_order_item_order FOREIGN KEY (order_id) REFERENCES orders(id), CONSTRAINT fk_order_item_product FOREIGN KEY (product_id) REFERENCES products(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS fulfillment_tasks (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, order_id BIGINT UNSIGNED NOT NULL, order_item_id BIGINT UNSIGNED NULL, code_index INT UNSIGNED NOT NULL DEFAULT 0, generation INT UNSIGNED NOT NULL DEFAULT 0, replacement_of_task_id BIGINT UNSIGNED NULL, created_by_user_id BIGINT UNSIGNED NULL, replacement_reason VARCHAR(500) NULL, request_key VARCHAR(100) NULL, steam_id VARCHAR(17) NOT NULL, task_type VARCHAR(32) NOT NULL DEFAULT 'spawn_item', payload_json JSON NULL, coin_amount BIGINT UNSIGNED NULL, item_id VARCHAR(80) NULL, amount INT UNSIGNED NULL, status VARCHAR(32) NOT NULL DEFAULT 'pending', attempts INT UNSIGNED NOT NULL DEFAULT 0, next_attempt_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), last_error VARCHAR(500) NULL, locked_at DATETIME(3) NULL, delivery_token CHAR(36) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), UNIQUE KEY uk_task_item_generation (order_item_id,code_index,generation), UNIQUE KEY uk_task_request_key (request_key), INDEX idx_tasks_poll (status,next_attempt_at), CONSTRAINT fk_task_order FOREIGN KEY (order_id) REFERENCES orders(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS fulfillment_attempts (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, task_id BIGINT UNSIGNED NOT NULL, attempt_no INT UNSIGNED NOT NULL, status VARCHAR(32) NOT NULL, message VARCHAR(500) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_attempt_task_created (task_id,created_at), CONSTRAINT fk_attempt_task FOREIGN KEY (task_id) REFERENCES fulfillment_tasks(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS scheduled_announcement_runs (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, announcement_id VARCHAR(64) NOT NULL, scheduled_for DATETIME(3) NOT NULL, status VARCHAR(32) NOT NULL DEFAULT 'sending', sent_count INT UNSIGNED NOT NULL DEFAULT 0, failed_count INT UNSIGNED NOT NULL DEFAULT 0, last_error VARCHAR(500) NULL, started_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), completed_at DATETIME(3) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), UNIQUE KEY uk_announcement_slot (announcement_id,scheduled_for)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS server_monitor_samples (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, sampled_at DATETIME(3) NOT NULL, status VARCHAR(16) NOT NULL, rcon_ok TINYINT(1) NULL, player_query_ok TINYINT(1) NOT NULL, online_count INT UNSIGNED NULL, rcon_latency_ms INT UNSIGNED NULL, process_uptime_sec BIGINT UNSIGNED NOT NULL, process_rss_bytes BIGINT UNSIGNED NOT NULL, process_heap_used_bytes BIGINT UNSIGNED NOT NULL, process_cpu_percent DECIMAL(6,2) NOT NULL DEFAULT 0, worker_running TINYINT(1) NOT NULL, error_code VARCHAR(64) NULL, error_message VARCHAR(500) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_monitor_samples_sampled (sampled_at), INDEX idx_monitor_samples_status_sampled (status,sampled_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS online_player_snapshots (sample_id BIGINT UNSIGNED NOT NULL, steam_id VARCHAR(17) NOT NULL, character_name VARCHAR(255) NULL, steam_name VARCHAR(255) NULL, is_admin TINYINT(1) NOT NULL DEFAULT 0, money DECIMAL(20,2) NULL, gold DECIMAL(20,2) NULL, observed_at DATETIME(3) NOT NULL, PRIMARY KEY (sample_id,steam_id), INDEX idx_player_snapshot_steam_observed (steam_id,observed_at), CONSTRAINT fk_player_snapshot_sample FOREIGN KEY (sample_id) REFERENCES server_monitor_samples(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS player_presence_events (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, steam_id VARCHAR(17) NOT NULL, event_type VARCHAR(16) NOT NULL, character_name VARCHAR(255) NULL, steam_name VARCHAR(255) NULL, is_admin TINYINT(1) NOT NULL DEFAULT 0, observed_at DATETIME(3) NOT NULL, sample_id BIGINT UNSIGNED NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_presence_events_observed (observed_at), INDEX idx_presence_events_steam_observed (steam_id,observed_at), CONSTRAINT fk_presence_event_sample FOREIGN KEY (sample_id) REFERENCES server_monitor_samples(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS maintenance_windows (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, instance_id VARCHAR(128) NULL, title VARCHAR(100) NOT NULL, reason VARCHAR(500) NULL, scheduled_at DATETIME(3) NOT NULL, state VARCHAR(40) NOT NULL, fulfillment_paused TINYINT NOT NULL DEFAULT 0, pause_started_at DATETIME(3) NULL, maintenance_started_at DATETIME(3) NULL, awaiting_recovery_at DATETIME(3) NULL, recovery_ready_at DATETIME(3) NULL, completed_at DATETIME(3) NULL, cancelled_at DATETIME(3) NULL, created_by VARCHAR(100) NULL, confirmed_by VARCHAR(100) NULL, cancelled_by VARCHAR(100) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_maintenance_state_scheduled (state,scheduled_at), INDEX idx_maintenance_paused_state (fulfillment_paused,state)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS maintenance_announcement_runs (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, maintenance_id BIGINT UNSIGNED NOT NULL, minute_mark INT NOT NULL, scheduled_for DATETIME(3) NOT NULL, status VARCHAR(16) NOT NULL, sent_count INT UNSIGNED NOT NULL DEFAULT 0, failed_count INT UNSIGNED NOT NULL DEFAULT 0, last_error VARCHAR(500) NULL, started_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), completed_at DATETIME(3) NULL, UNIQUE KEY uk_maintenance_minute (maintenance_id,minute_mark), CONSTRAINT fk_maintenance_run_window FOREIGN KEY (maintenance_id) REFERENCES maintenance_windows(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS maintenance_audit_logs (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, maintenance_id BIGINT UNSIGNED NOT NULL, action VARCHAR(50) NOT NULL, actor VARCHAR(100) NULL, details_json JSON NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_maintenance_audit_window_created (maintenance_id,created_at), CONSTRAINT fk_maintenance_audit_window FOREIGN KEY (maintenance_id) REFERENCES maintenance_windows(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS reward_rules (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, rule_type VARCHAR(32) NOT NULL, threshold_value BIGINT UNSIGNED NOT NULL, reward_type VARCHAR(16) NOT NULL DEFAULT 'shop_coin', gift_id BIGINT UNSIGNED NULL, product_id BIGINT UNSIGNED NULL, coin_amount BIGINT UNSIGNED NULL, enabled TINYINT(1) NOT NULL DEFAULT 1, created_by_user_id BIGINT UNSIGNED NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), UNIQUE KEY uk_reward_rule_type_threshold (rule_type,threshold_value), INDEX idx_reward_rules_enabled_type (enabled,rule_type,threshold_value), CONSTRAINT fk_reward_rule_gift FOREIGN KEY (gift_id) REFERENCES gift_packages(id), CONSTRAINT fk_reward_rule_product FOREIGN KEY (product_id) REFERENCES products(id), CONSTRAINT fk_reward_rule_creator FOREIGN KEY (created_by_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`) ON DELETE SET NULL, CONSTRAINT chk_reward_rule_type CHECK (rule_type IN ('daily_checkin','checkin_streak','checkin_total','online_total')), CONSTRAINT chk_reward_rule_reward_type CHECK (reward_type IN ('gift','product','shop_coin')), CONSTRAINT chk_reward_rule_threshold CHECK (threshold_value >= 1), CONSTRAINT chk_reward_rule_enabled CHECK (enabled IN (0,1))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS player_checkins (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, steam_id VARCHAR(17) NOT NULL, checkin_day DATE NOT NULL, streak_days INT UNSIGNED NOT NULL, total_days INT UNSIGNED NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), UNIQUE KEY uk_player_checkin_day (steam_id,checkin_day), UNIQUE KEY uk_player_checkin_id_steam (id,steam_id), INDEX idx_player_checkins_steam_created (steam_id,created_at), CONSTRAINT fk_player_checkin_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT chk_player_checkin_streak CHECK (streak_days >= 1), CONSTRAINT chk_player_checkin_total CHECK (total_days >= streak_days)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS player_online_totals (steam_id VARCHAR(17) PRIMARY KEY, total_seconds BIGINT UNSIGNED NOT NULL DEFAULT 0, updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_player_online_totals_seconds (total_seconds), CONSTRAINT fk_player_online_total_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT chk_player_online_total CHECK (total_seconds >= 0)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS player_online_accruals (sample_id BIGINT UNSIGNED NOT NULL, steam_id VARCHAR(17) NOT NULL, previous_sample_id BIGINT UNSIGNED NOT NULL, credited_seconds BIGINT UNSIGNED NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), PRIMARY KEY (sample_id,steam_id), INDEX idx_online_accruals_steam_sample (steam_id,sample_id), INDEX idx_online_accruals_previous_player (previous_sample_id,steam_id), CONSTRAINT fk_online_accrual_sample FOREIGN KEY (sample_id) REFERENCES server_monitor_samples(id), CONSTRAINT fk_online_accrual_previous_sample FOREIGN KEY (previous_sample_id) REFERENCES server_monitor_samples(id), CONSTRAINT fk_online_accrual_current_snapshot FOREIGN KEY (sample_id,steam_id) REFERENCES online_player_snapshots(sample_id,steam_id), CONSTRAINT fk_online_accrual_previous_snapshot FOREIGN KEY (previous_sample_id,steam_id) REFERENCES online_player_snapshots(sample_id,steam_id), CONSTRAINT chk_online_accrual_distinct_samples CHECK (previous_sample_id <> sample_id), CONSTRAINT chk_online_accrual_seconds CHECK (credited_seconds >= 1)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS reward_requests (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, request_key VARCHAR(100) NOT NULL, steam_id VARCHAR(17) NOT NULL, checkin_id BIGINT UNSIGNED NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), UNIQUE KEY uk_reward_request_key (request_key), UNIQUE KEY uk_reward_request_id_steam (id,steam_id), INDEX idx_reward_requests_player_created (steam_id,created_at), INDEX idx_reward_requests_checkin_player (checkin_id,steam_id), CONSTRAINT fk_reward_request_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT fk_reward_request_checkin_player FOREIGN KEY (checkin_id,steam_id) REFERENCES player_checkins(id,steam_id), CONSTRAINT chk_reward_request_key CHECK (CHAR_LENGTH(request_key) >= 1)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS reward_claims (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, request_id BIGINT UNSIGNED NOT NULL, claim_key VARCHAR(160) NOT NULL, steam_id VARCHAR(17) NOT NULL, rule_id BIGINT UNSIGNED NOT NULL, checkin_id BIGINT UNSIGNED NULL, sample_id BIGINT UNSIGNED NULL, gift_id BIGINT UNSIGNED NULL, product_id BIGINT UNSIGNED NULL, coin_amount BIGINT UNSIGNED NULL, order_id BIGINT UNSIGNED NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), UNIQUE KEY uk_reward_claim_key (claim_key), UNIQUE KEY uk_reward_claim_order (order_id), INDEX idx_reward_claims_request (request_id), INDEX idx_reward_claims_player_created (steam_id,created_at), INDEX idx_reward_claims_rule_player (rule_id,steam_id), INDEX idx_reward_claims_checkin_player (checkin_id,steam_id), INDEX idx_reward_claims_sample (sample_id), CONSTRAINT fk_reward_claim_request_player FOREIGN KEY (request_id,steam_id) REFERENCES reward_requests(id,steam_id), CONSTRAINT fk_reward_claim_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT fk_reward_claim_rule FOREIGN KEY (rule_id) REFERENCES reward_rules(id), CONSTRAINT fk_reward_claim_checkin_player FOREIGN KEY (checkin_id,steam_id) REFERENCES player_checkins(id,steam_id), CONSTRAINT fk_reward_claim_sample FOREIGN KEY (sample_id) REFERENCES server_monitor_samples(id) ON DELETE SET NULL, CONSTRAINT fk_reward_claim_gift FOREIGN KEY (gift_id) REFERENCES gift_packages(id), CONSTRAINT fk_reward_claim_product FOREIGN KEY (product_id) REFERENCES products(id), CONSTRAINT fk_reward_claim_order FOREIGN KEY (order_id) REFERENCES orders(id), CONSTRAINT chk_reward_claim_key CHECK (CHAR_LENGTH(claim_key) >= 1)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS activities (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE, description TEXT NULL, starts_at DATETIME(3) NOT NULL, ends_at DATETIME(3) NOT NULL, enabled TINYINT(1) NOT NULL DEFAULT 1, created_by_user_id BIGINT UNSIGNED NOT NULL, lottery_pool_id BIGINT UNSIGNED NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), UNIQUE KEY uk_activities_lottery_pool (lottery_pool_id), INDEX idx_activities_visible (enabled,starts_at,ends_at), CONSTRAINT fk_activity_creator FOREIGN KEY (created_by_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`), CONSTRAINT chk_activity_window CHECK (starts_at < ends_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS lottery_pools (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE, description TEXT NULL, image_path VARCHAR(500) NULL, currency_type VARCHAR(32) NOT NULL DEFAULT 'coin', single_price BIGINT UNSIGNED NOT NULL DEFAULT 0, starts_at DATETIME(3) NOT NULL, ends_at DATETIME(3) NOT NULL, enabled TINYINT(1) NOT NULL DEFAULT 1, deleted_at DATETIME(3) NULL, current_version_id BIGINT UNSIGNED NULL, created_by_user_id BIGINT UNSIGNED NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_lottery_pools_visible (enabled,starts_at,ends_at), CONSTRAINT fk_lottery_pool_creator FOREIGN KEY (created_by_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`) ON DELETE SET NULL, CONSTRAINT chk_lottery_pool_window CHECK (starts_at < ends_at), CONSTRAINT chk_lottery_pool_currency CHECK (currency_type='coin'), CONSTRAINT chk_lottery_pool_price CHECK (single_price >= 0)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS lottery_pool_versions (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, pool_id BIGINT UNSIGNED NOT NULL, version_no INT UNSIGNED NOT NULL, single_price BIGINT UNSIGNED NOT NULL, ten_price BIGINT UNSIGNED NOT NULL, daily_free_count INT UNSIGNED NOT NULL DEFAULT 0, pity_threshold INT UNSIGNED NOT NULL, config_snapshot_json JSON NOT NULL, created_by_user_id BIGINT UNSIGNED NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), UNIQUE KEY uk_lottery_pool_version (pool_id,version_no), INDEX idx_lottery_versions_pool_created (pool_id,created_at), CONSTRAINT fk_lottery_version_pool FOREIGN KEY (pool_id) REFERENCES lottery_pools(id), CONSTRAINT fk_lottery_version_creator FOREIGN KEY (created_by_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`), CONSTRAINT chk_lottery_prices CHECK (single_price >= 0 AND ten_price >= 0), CONSTRAINT chk_lottery_pity CHECK (pity_threshold >= 1)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS lottery_prizes (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, version_id BIGINT UNSIGNED NOT NULL, prize_index INT UNSIGNED NOT NULL, reward_type VARCHAR(16) NOT NULL DEFAULT 'gift', gift_id BIGINT UNSIGNED NULL, product_id BIGINT UNSIGNED NULL, reward_name_snapshot VARCHAR(100) NOT NULL, weight BIGINT UNSIGNED NOT NULL, rarity VARCHAR(50) NOT NULL, label VARCHAR(100) NULL, is_pity TINYINT(1) NOT NULL DEFAULT 0, gift_name_snapshot VARCHAR(100) NULL, action_snapshot_json JSON NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), UNIQUE KEY uk_lottery_prize_index (version_id,prize_index), INDEX idx_lottery_prizes_version_pity (version_id,is_pity), CONSTRAINT fk_lottery_prize_version FOREIGN KEY (version_id) REFERENCES lottery_pool_versions(id), CONSTRAINT fk_lottery_prize_gift FOREIGN KEY (gift_id) REFERENCES gift_packages(id), CONSTRAINT fk_lottery_prize_product FOREIGN KEY (product_id) REFERENCES products(id), CONSTRAINT chk_lottery_weight CHECK (weight >= 1), CONSTRAINT chk_lottery_prize_reward_type CHECK (reward_type IN ('gift','product','shop_coin','custom')), CONSTRAINT chk_lottery_prize_reference CHECK ((reward_type='gift' AND gift_id IS NOT NULL AND product_id IS NULL) OR (reward_type='product' AND gift_id IS NULL AND product_id IS NOT NULL) OR (reward_type IN ('shop_coin','custom') AND gift_id IS NULL AND product_id IS NULL))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS activity_gifts (activity_id BIGINT UNSIGNED NOT NULL, gift_id BIGINT UNSIGNED NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), PRIMARY KEY (activity_id,gift_id), CONSTRAINT fk_activity_gift_activity FOREIGN KEY (activity_id) REFERENCES activities(id) ON DELETE CASCADE, CONSTRAINT fk_activity_gift_gift FOREIGN KEY (gift_id) REFERENCES gift_packages(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS activity_lottery_pools (activity_id BIGINT UNSIGNED NOT NULL, pool_id BIGINT UNSIGNED NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), PRIMARY KEY (activity_id,pool_id), CONSTRAINT fk_activity_pool_activity FOREIGN KEY (activity_id) REFERENCES activities(id) ON DELETE CASCADE, CONSTRAINT fk_activity_pool_pool FOREIGN KEY (pool_id) REFERENCES lottery_pools(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS activity_gift_claims (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, activity_id BIGINT UNSIGNED NOT NULL, gift_id BIGINT UNSIGNED NOT NULL, gift_claim_id BIGINT UNSIGNED NOT NULL, steam_id VARCHAR(17) NOT NULL, activity_snapshot_json JSON NOT NULL, gift_snapshot_json JSON NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), UNIQUE KEY uk_activity_gift_claim (gift_claim_id), INDEX idx_activity_gift_claim_player (steam_id,created_at), CONSTRAINT fk_activity_gift_claim_activity FOREIGN KEY (activity_id) REFERENCES activities(id), CONSTRAINT fk_activity_gift_claim_gift FOREIGN KEY (gift_id) REFERENCES gift_packages(id), CONSTRAINT fk_activity_gift_claim_claim FOREIGN KEY (gift_claim_id) REFERENCES gift_claims(id), CONSTRAINT fk_activity_gift_claim_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS lottery_player_states (pool_id BIGINT UNSIGNED NOT NULL, steam_id VARCHAR(17) NOT NULL, pity_count INT UNSIGNED NOT NULL DEFAULT 0, free_day DATE NULL, free_used INT UNSIGNED NOT NULL DEFAULT 0, updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), PRIMARY KEY (pool_id,steam_id), CONSTRAINT fk_lottery_state_pool FOREIGN KEY (pool_id) REFERENCES lottery_pools(id), CONSTRAINT fk_lottery_state_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS lottery_batches (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, request_key VARCHAR(100) NOT NULL UNIQUE, steam_id VARCHAR(17) NOT NULL, pool_id BIGINT UNSIGNED NOT NULL, version_id BIGINT UNSIGNED NOT NULL, draw_count INT UNSIGNED NOT NULL, free_count INT UNSIGNED NOT NULL, paid_count INT UNSIGNED NOT NULL, price_paid BIGINT UNSIGNED NOT NULL, balance_before BIGINT UNSIGNED NOT NULL, balance_after BIGINT UNSIGNED NOT NULL, pity_before INT UNSIGNED NOT NULL, pity_after INT UNSIGNED NOT NULL, pool_snapshot_json JSON NOT NULL, order_id BIGINT UNSIGNED NULL UNIQUE, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_lottery_batches_player_created (steam_id,created_at), INDEX idx_lottery_batches_pool_created (pool_id,created_at), CONSTRAINT fk_lottery_batch_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT fk_lottery_batch_pool FOREIGN KEY (pool_id) REFERENCES lottery_pools(id), CONSTRAINT fk_lottery_batch_version FOREIGN KEY (version_id) REFERENCES lottery_pool_versions(id), CONSTRAINT fk_lottery_batch_order FOREIGN KEY (order_id) REFERENCES orders(id), CONSTRAINT chk_lottery_draw_count CHECK (draw_count IN (1,10))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS lottery_draws (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, batch_id BIGINT UNSIGNED NOT NULL, draw_index INT UNSIGNED NOT NULL, prize_id BIGINT UNSIGNED NOT NULL, reward_type VARCHAR(16) NOT NULL DEFAULT 'gift', gift_id BIGINT UNSIGNED NULL, reward_name_snapshot VARCHAR(100) NOT NULL, weight_snapshot BIGINT UNSIGNED NOT NULL, total_weight_snapshot BIGINT UNSIGNED NOT NULL, rarity_snapshot VARCHAR(50) NOT NULL, label_snapshot VARCHAR(100) NULL, is_pity_snapshot TINYINT(1) NOT NULL, forced_pity TINYINT(1) NOT NULL, pity_before INT UNSIGNED NOT NULL, pity_after INT UNSIGNED NOT NULL, prize_snapshot_json JSON NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), UNIQUE KEY uk_lottery_draw_index (batch_id,draw_index), CONSTRAINT fk_lottery_draw_batch FOREIGN KEY (batch_id) REFERENCES lottery_batches(id), CONSTRAINT fk_lottery_draw_prize FOREIGN KEY (prize_id) REFERENCES lottery_prizes(id), CONSTRAINT fk_lottery_draw_gift FOREIGN KEY (gift_id) REFERENCES gift_packages(id), CONSTRAINT chk_lottery_draw_reward_type CHECK (reward_type IN ('gift','product','shop_coin','custom'))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS lottery_fulfillment_logs (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, lottery_batch_id BIGINT UNSIGNED NOT NULL, lottery_draw_id BIGINT UNSIGNED NOT NULL, order_id BIGINT UNSIGNED NOT NULL, fulfillment_task_id BIGINT UNSIGNED NOT NULL, steam_id VARCHAR(17) NOT NULL, pool_id BIGINT UNSIGNED NOT NULL, pool_name_snapshot VARCHAR(100) NOT NULL, reward_type VARCHAR(16) NOT NULL, reward_name_snapshot VARCHAR(100) NOT NULL, task_type VARCHAR(32) NOT NULL, status VARCHAR(32) NOT NULL DEFAULT 'pending', error_summary VARCHAR(500) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), UNIQUE KEY uk_lottery_fulfillment_task (fulfillment_task_id), INDEX idx_lottery_fulfillment_batch (lottery_batch_id,id), INDEX idx_lottery_fulfillment_draw (lottery_draw_id,id), INDEX idx_lottery_fulfillment_player (steam_id,id), INDEX idx_lottery_fulfillment_status (status,id), CONSTRAINT fk_lottery_fulfillment_batch FOREIGN KEY (lottery_batch_id) REFERENCES lottery_batches(id), CONSTRAINT fk_lottery_fulfillment_draw FOREIGN KEY (lottery_draw_id) REFERENCES lottery_draws(id), CONSTRAINT fk_lottery_fulfillment_order FOREIGN KEY (order_id) REFERENCES orders(id), CONSTRAINT fk_lottery_fulfillment_task FOREIGN KEY (fulfillment_task_id) REFERENCES fulfillment_tasks(id), CONSTRAINT fk_lottery_fulfillment_pool FOREIGN KEY (pool_id) REFERENCES lottery_pools(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS stocks (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, code VARCHAR(16) NOT NULL UNIQUE, name VARCHAR(100) NOT NULL, description TEXT NULL, current_price BIGINT UNSIGNED NOT NULL, base_price BIGINT UNSIGNED NOT NULL, enabled TINYINT(1) NOT NULL DEFAULT 1, paused TINYINT(1) NOT NULL DEFAULT 0, deleted_at DATETIME(3) NULL, pricing_mode VARCHAR(16) NOT NULL DEFAULT 'hybrid', volume_metric VARCHAR(16) NOT NULL DEFAULT 'quantity', baseline_value BIGINT UNSIGNED NOT NULL DEFAULT 1, auto_volume_max BIGINT UNSIGNED NOT NULL DEFAULT 0, volume_sensitivity_bps INT UNSIGNED NOT NULL DEFAULT 100, volatility_bps INT UNSIGNED NOT NULL, max_change_bps INT UNSIGNED NOT NULL, min_price BIGINT UNSIGNED NOT NULL, max_price BIGINT UNSIGNED NULL, fee_bps INT UNSIGNED NOT NULL, period_seconds INT UNSIGNED NOT NULL, price_version BIGINT UNSIGNED NOT NULL DEFAULT 1, last_period_key BIGINT NULL, created_by_user_id BIGINT UNSIGNED NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_stocks_tradeable (enabled,paused), CONSTRAINT fk_stock_creator FOREIGN KEY (created_by_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`) ON DELETE SET NULL, CONSTRAINT chk_stock_prices CHECK (current_price >= 1 AND base_price >= 1 AND min_price >= 1 AND baseline_value >= 1), CONSTRAINT chk_stock_bps CHECK (volatility_bps <= 10000 AND max_change_bps <= 10000 AND fee_bps <= 10000 AND volume_sensitivity_bps <= 10000), CONSTRAINT chk_stock_period CHECK (period_seconds >= 1), CONSTRAINT chk_stock_pricing_mode CHECK (pricing_mode IN ('volume','hybrid','manual')), CONSTRAINT chk_stock_volume_metric CHECK (volume_metric IN ('quantity','amount'))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS stock_volume_bindings (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, stock_id BIGINT UNSIGNED NOT NULL, binding_type VARCHAR(16) NOT NULL, product_id BIGINT UNSIGNED NULL, product_sku VARCHAR(64) NULL, parent_category VARCHAR(100) NULL, category_name VARCHAR(100) NULL, weight_bps INT UNSIGNED NOT NULL DEFAULT 10000, enabled TINYINT(1) NOT NULL DEFAULT 1, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_stock_bindings_stock (stock_id,enabled,binding_type), INDEX idx_stock_bindings_product (product_id,product_sku,enabled), INDEX idx_stock_bindings_category (parent_category,category_name,enabled), CONSTRAINT fk_stock_binding_stock FOREIGN KEY (stock_id) REFERENCES stocks(id) ON DELETE CASCADE, CONSTRAINT fk_stock_binding_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL, CONSTRAINT chk_stock_binding_type CHECK (binding_type IN ('product','category')), CONSTRAINT chk_stock_binding_weight CHECK (weight_bps BETWEEN 1 AND 10000)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS stock_price_history (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, stock_id BIGINT UNSIGNED NOT NULL, source VARCHAR(16) NOT NULL DEFAULT 'automatic', period_key BIGINT NULL, price_before BIGINT UNSIGNED NOT NULL, price_after BIGINT UNSIGNED NOT NULL, change_bps INT NOT NULL, price_version BIGINT UNSIGNED NOT NULL, volume_quantity BIGINT UNSIGNED NULL, volume_amount BIGINT UNSIGNED NULL, simulated_volume_quantity BIGINT UNSIGNED NOT NULL DEFAULT 0, simulated_volume_amount BIGINT UNSIGNED NOT NULL DEFAULT 0, baseline_value BIGINT UNSIGNED NULL, volume_change_bps INT NULL, simulated_volume_change_bps INT NULL, random_change_bps INT NULL, actor_user_id BIGINT UNSIGNED NULL, actor_username_snapshot VARCHAR(100) NULL, reason VARCHAR(500) NULL, request_key VARCHAR(100) NULL, priced_at DATETIME(3) NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), UNIQUE KEY uk_stock_period (stock_id,period_key), UNIQUE KEY uk_stock_price_request (request_key), INDEX idx_stock_prices_stock_time (stock_id,priced_at), CONSTRAINT fk_stock_price_stock FOREIGN KEY (stock_id) REFERENCES stocks(id), CONSTRAINT fk_stock_price_actor FOREIGN KEY (actor_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`) ON DELETE SET NULL, CONSTRAINT chk_stock_price_source CHECK (source IN ('automatic','manual'))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS stock_holdings (stock_id BIGINT UNSIGNED NOT NULL, steam_id VARCHAR(17) NOT NULL, quantity BIGINT UNSIGNED NOT NULL DEFAULT 0, average_cost BIGINT UNSIGNED NOT NULL DEFAULT 0, updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), PRIMARY KEY (stock_id,steam_id), INDEX idx_holdings_player (steam_id), CONSTRAINT fk_holding_stock FOREIGN KEY (stock_id) REFERENCES stocks(id), CONSTRAINT fk_holding_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT chk_holding_average CHECK ((quantity=0 AND average_cost=0) OR (quantity>0 AND average_cost>0))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS stock_trades (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, request_key VARCHAR(100) NOT NULL UNIQUE, steam_id VARCHAR(17) NOT NULL, stock_id BIGINT UNSIGNED NOT NULL, direction VARCHAR(4) NOT NULL, quantity BIGINT UNSIGNED NOT NULL, price BIGINT UNSIGNED NOT NULL, fee BIGINT UNSIGNED NOT NULL, gross_amount BIGINT UNSIGNED NOT NULL, net_amount BIGINT UNSIGNED NOT NULL, balance_before BIGINT UNSIGNED NOT NULL, balance_after BIGINT UNSIGNED NOT NULL, holding_before BIGINT UNSIGNED NOT NULL, holding_after BIGINT UNSIGNED NOT NULL, average_cost_before BIGINT UNSIGNED NOT NULL, average_cost_after BIGINT UNSIGNED NOT NULL, price_version BIGINT UNSIGNED NOT NULL, price_time_snapshot DATETIME(3) NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_stock_trades_player_created (steam_id,created_at), INDEX idx_stock_trades_stock_created (stock_id,created_at), CONSTRAINT fk_stock_trade_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT fk_stock_trade_stock FOREIGN KEY (stock_id) REFERENCES stocks(id), CONSTRAINT chk_stock_trade_direction CHECK (direction IN ('buy','sell')), CONSTRAINT chk_stock_trade_quantity CHECK (quantity >= 1)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS stock_watchlists (steam_id VARCHAR(17) NOT NULL, stock_id BIGINT UNSIGNED NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), PRIMARY KEY (steam_id,stock_id), INDEX idx_stock_watchlist_stock (stock_id), CONSTRAINT fk_stock_watchlist_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`) ON DELETE CASCADE, CONSTRAINT fk_stock_watchlist_stock FOREIGN KEY (stock_id) REFERENCES stocks(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS stock_market_announcements (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, title VARCHAR(150) NOT NULL, content TEXT NOT NULL, enabled TINYINT(1) NOT NULL DEFAULT 1, starts_at DATETIME(3) NULL, ends_at DATETIME(3) NULL, created_by_user_id BIGINT UNSIGNED NOT NULL, updated_by_user_id BIGINT UNSIGNED NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_stock_announcements_visible (enabled,starts_at,ends_at), CONSTRAINT fk_stock_announcement_creator FOREIGN KEY (created_by_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`), CONSTRAINT fk_stock_announcement_updater FOREIGN KEY (updated_by_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`), CONSTRAINT chk_stock_announcement_window CHECK (starts_at IS NULL OR ends_at IS NULL OR starts_at < ends_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS vehicles (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, vehicle_code VARCHAR(64) NOT NULL UNIQUE, owner_steam_id VARCHAR(17) NULL, owner_name VARCHAR(100) NULL, vehicle_type VARCHAR(80) NOT NULL, model_name VARCHAR(120) NOT NULL, display_name VARCHAR(120) NULL, plate_number VARCHAR(64) NULL UNIQUE, status VARCHAR(16) NOT NULL DEFAULT 'active', condition_percent DECIMAL(5,2) NULL, fuel_percent DECIMAL(5,2) NULL, grid_code VARCHAR(16) NULL, world_x DECIMAL(14,4) NULL, world_y DECIMAL(14,4) NULL, world_z DECIMAL(14,4) NULL, map_x_percent DECIMAL(7,4) NULL, map_y_percent DECIMAL(7,4) NULL, location_note VARCHAR(500) NULL, last_seen_at DATETIME(3) NULL, notes TEXT NULL, source_type VARCHAR(32) NULL, source_vehicle_id BIGINT UNSIGNED NULL, source_asset_id VARCHAR(255) NULL, source_vehicle_alias VARCHAR(120) NULL, source_entity_class VARCHAR(120) NULL, source_lock_slots INT UNSIGNED NULL, location_source VARCHAR(32) NULL, source_synchronized_at DATETIME(3) NULL, source_sync_state VARCHAR(16) NOT NULL DEFAULT 'manual', source_missing_since DATETIME(3) NULL, status_before_source_lost VARCHAR(16) NULL, created_by_user_id BIGINT UNSIGNED NULL, updated_by_user_id BIGINT UNSIGNED NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_vehicles_owner (owner_steam_id,owner_name), INDEX idx_vehicles_status (status,updated_at), INDEX idx_vehicles_type (vehicle_type,model_name), CONSTRAINT fk_vehicle_creator FOREIGN KEY (created_by_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`) ON DELETE SET NULL, CONSTRAINT fk_vehicle_updater FOREIGN KEY (updated_by_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`) ON DELETE SET NULL, CONSTRAINT chk_vehicle_status CHECK (status IN ('active','stored','maintenance','lost','destroyed','retired')), CONSTRAINT chk_vehicle_condition CHECK (condition_percent IS NULL OR condition_percent BETWEEN 0 AND 100), CONSTRAINT chk_vehicle_fuel CHECK (fuel_percent IS NULL OR fuel_percent BETWEEN 0 AND 100), CONSTRAINT chk_vehicle_map_x CHECK (map_x_percent IS NULL OR map_x_percent BETWEEN 0 AND 100), CONSTRAINT chk_vehicle_map_y CHECK (map_y_percent IS NULL OR map_y_percent BETWEEN 0 AND 100)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS vehicle_insurance_strategies (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE, total_claim_limit INT UNSIGNED NOT NULL, daily_claim_limit INT UNSIGNED NOT NULL, duration_days INT UNSIGNED NOT NULL, purchase_condition VARCHAR(200) NOT NULL DEFAULT '无需绑定载具', product_id BIGINT UNSIGNED NULL, vehicle_type VARCHAR(80) NOT NULL, vehicle_code VARCHAR(80) NOT NULL, price BIGINT UNSIGNED NOT NULL, enabled TINYINT(1) NOT NULL DEFAULT 1, deleted_at DATETIME(3) NULL, created_by_user_id BIGINT UNSIGNED NULL, updated_by_user_id BIGINT UNSIGNED NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_vehicle_insurance_strategy_sale (enabled,vehicle_type,price), INDEX idx_vehicle_insurance_strategy_product (product_id), CONSTRAINT fk_vehicle_insurance_strategy_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL, CONSTRAINT fk_vehicle_insurance_strategy_creator FOREIGN KEY (created_by_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`) ON DELETE SET NULL, CONSTRAINT fk_vehicle_insurance_strategy_updater FOREIGN KEY (updated_by_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`) ON DELETE SET NULL, CONSTRAINT chk_vehicle_insurance_strategy_claims CHECK (total_claim_limit >= 1 AND daily_claim_limit >= 1 AND daily_claim_limit <= total_claim_limit), CONSTRAINT chk_vehicle_insurance_strategy_duration CHECK (duration_days >= 1)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS vehicle_insurance (vehicle_id BIGINT UNSIGNED PRIMARY KEY, strategy_id BIGINT UNSIGNED NULL, policy_number VARCHAR(100) NULL UNIQUE, status VARCHAR(16) NOT NULL DEFAULT 'none', insured_value BIGINT UNSIGNED NULL, premium_amount BIGINT UNSIGNED NULL, total_claim_limit INT UNSIGNED NULL, daily_claim_limit INT UNSIGNED NULL, total_claims_used INT UNSIGNED NOT NULL DEFAULT 0, daily_claims_used INT UNSIGNED NOT NULL DEFAULT 0, daily_claim_date DATE NULL, starts_at DATETIME(3) NULL, expires_at DATETIME(3) NULL, coverage_note VARCHAR(1000) NULL, notes VARCHAR(1000) NULL, updated_by_user_id BIGINT UNSIGNED NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_vehicle_insurance_status (status,expires_at), INDEX idx_vehicle_insurance_strategy (strategy_id), CONSTRAINT fk_vehicle_insurance_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE, CONSTRAINT fk_vehicle_insurance_strategy FOREIGN KEY (strategy_id) REFERENCES vehicle_insurance_strategies(id) ON DELETE SET NULL, CONSTRAINT fk_vehicle_insurance_updater FOREIGN KEY (updated_by_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`) ON DELETE SET NULL, CONSTRAINT chk_vehicle_insurance_status CHECK (status IN ('none','active','expired','suspended')), CONSTRAINT chk_vehicle_insurance_period CHECK (starts_at IS NULL OR expires_at IS NULL OR starts_at < expires_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS vehicle_insurance_purchases (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, request_key VARCHAR(100) NOT NULL UNIQUE, steam_id VARCHAR(17) NOT NULL, vehicle_id BIGINT UNSIGNED NULL, strategy_id BIGINT UNSIGNED NOT NULL, strategy_name_snapshot VARCHAR(100) NOT NULL, product_id_snapshot BIGINT UNSIGNED NULL, vehicle_type_snapshot VARCHAR(80) NOT NULL, vehicle_code_snapshot VARCHAR(80) NOT NULL, total_claim_limit_snapshot INT UNSIGNED NOT NULL, daily_claim_limit_snapshot INT UNSIGNED NOT NULL, purchase_condition_snapshot VARCHAR(500) NOT NULL, duration_days_snapshot INT UNSIGNED NOT NULL, policy_number VARCHAR(100) NOT NULL, price BIGINT UNSIGNED NOT NULL, balance_after BIGINT NOT NULL, starts_at DATETIME(3) NOT NULL, expires_at DATETIME(3) NOT NULL, cancelled_at DATETIME(3) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_vehicle_insurance_purchase_player (steam_id,created_at), CONSTRAINT fk_vehicle_insurance_purchase_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT fk_vehicle_insurance_purchase_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id), CONSTRAINT fk_vehicle_insurance_purchase_strategy FOREIGN KEY (strategy_id) REFERENCES vehicle_insurance_strategies(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS vehicle_insurance_claims (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, request_key VARCHAR(100) NOT NULL UNIQUE, claim_number VARCHAR(100) NOT NULL UNIQUE, steam_id VARCHAR(17) NOT NULL, purchase_id BIGINT UNSIGNED NOT NULL, vehicle_id BIGINT UNSIGNED NOT NULL, old_source_vehicle_id BIGINT UNSIGNED NOT NULL, strategy_id BIGINT UNSIGNED NOT NULL, vehicle_code VARCHAR(80) NOT NULL, total_claim_limit INT UNSIGNED NOT NULL, daily_claim_limit INT UNSIGNED NOT NULL, order_id BIGINT UNSIGNED NOT NULL, fulfillment_task_id BIGINT UNSIGNED NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_vehicle_insurance_claim_player (steam_id,created_at), INDEX idx_vehicle_insurance_claim_purchase (purchase_id,created_at), INDEX idx_vehicle_insurance_claim_vehicle (vehicle_id,created_at), CONSTRAINT fk_vehicle_insurance_claim_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT fk_vehicle_insurance_claim_purchase FOREIGN KEY (purchase_id) REFERENCES vehicle_insurance_purchases(id), CONSTRAINT fk_vehicle_insurance_claim_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id), CONSTRAINT fk_vehicle_insurance_claim_strategy FOREIGN KEY (strategy_id) REFERENCES vehicle_insurance_strategies(id), CONSTRAINT fk_vehicle_insurance_claim_order FOREIGN KEY (order_id) REFERENCES orders(id), CONSTRAINT fk_vehicle_insurance_claim_task FOREIGN KEY (fulfillment_task_id) REFERENCES fulfillment_tasks(id), CONSTRAINT chk_vehicle_insurance_claim_limits CHECK (total_claim_limit >= 1 AND daily_claim_limit >= 1 AND daily_claim_limit <= total_claim_limit)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS vehicle_audit_logs (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, vehicle_id BIGINT UNSIGNED NULL, vehicle_code_snapshot VARCHAR(64) NOT NULL, action VARCHAR(32) NOT NULL, changes_json JSON NOT NULL, actor_user_id BIGINT UNSIGNED NULL, actor_name VARCHAR(100) NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_vehicle_audit_vehicle (vehicle_id,id), INDEX idx_vehicle_audit_actor (actor_user_id,created_at), CONSTRAINT fk_vehicle_audit_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE SET NULL, CONSTRAINT fk_vehicle_audit_actor FOREIGN KEY (actor_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS cloud_inventory_batches (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, steam_id VARCHAR(17) NOT NULL, source_item_id VARCHAR(80) NULL UNIQUE, item_code VARCHAR(80) NOT NULL, item_name VARCHAR(100) NOT NULL, quantity INT UNSIGNED NOT NULL, reserved_quantity INT UNSIGNED NOT NULL DEFAULT 0, item_health DECIMAL(10,4) NULL, item_max_health DECIMAL(10,4) NULL, item_dirtiness DECIMAL(10,4) NULL, item_uses INT UNSIGNED NULL, item_max_uses INT UNSIGNED NULL, item_max_quantity INT UNSIGNED NULL, item_stackable TINYINT(1) NOT NULL DEFAULT 0, item_radiation_amount DECIMAL(20,8) NULL, item_weight DECIMAL(20,8) NULL, item_water_weight DECIMAL(20,8) NULL, item_external_weight DECIMAL(20,8) NULL, item_total_weight DECIMAL(20,8) NULL, item_xml_base64 LONGTEXT NULL, item_body_damage_base64 LONGTEXT NULL, item_snapshot_json JSON NULL, status VARCHAR(16) NOT NULL DEFAULT 'active', created_by_user_id BIGINT UNSIGNED NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_cloud_inventory_owner (steam_id,status,updated_at), INDEX idx_cloud_inventory_item (item_code,status), CONSTRAINT fk_cloud_inventory_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT fk_cloud_inventory_creator FOREIGN KEY (created_by_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`) ON DELETE SET NULL, CONSTRAINT chk_cloud_inventory_quantity CHECK (reserved_quantity <= quantity), CONSTRAINT chk_cloud_inventory_status CHECK (status IN ('active','empty','locked'))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS cloud_market_listings (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, inventory_id BIGINT UNSIGNED NOT NULL, seller_steam_id VARCHAR(17) NOT NULL, item_code VARCHAR(80) NOT NULL, item_name VARCHAR(100) NOT NULL, quantity INT UNSIGNED NOT NULL, remaining_quantity INT UNSIGNED NOT NULL, unit_price BIGINT UNSIGNED NOT NULL, fee_bps INT UNSIGNED NOT NULL, status VARCHAR(16) NOT NULL DEFAULT 'active', created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_cloud_listing_market (status,item_code,unit_price,id), INDEX idx_cloud_listing_seller (seller_steam_id,status,id), CONSTRAINT fk_cloud_listing_inventory FOREIGN KEY (inventory_id) REFERENCES cloud_inventory_batches(id), CONSTRAINT fk_cloud_listing_seller FOREIGN KEY (seller_steam_id) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT chk_cloud_listing_quantity CHECK (quantity >= 1 AND remaining_quantity <= quantity), CONSTRAINT chk_cloud_listing_price CHECK (unit_price >= 1 AND fee_bps <= 10000), CONSTRAINT chk_cloud_listing_status CHECK (status IN ('active','sold','cancelled'))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS cloud_market_trades (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, request_key VARCHAR(100) NOT NULL UNIQUE, listing_id BIGINT UNSIGNED NOT NULL, seller_steam_id VARCHAR(17) NOT NULL, buyer_steam_id VARCHAR(17) NOT NULL, item_code VARCHAR(80) NOT NULL, item_name VARCHAR(100) NOT NULL, quantity INT UNSIGNED NOT NULL, unit_price BIGINT UNSIGNED NOT NULL, gross_amount BIGINT UNSIGNED NOT NULL, fee BIGINT UNSIGNED NOT NULL, seller_net BIGINT UNSIGNED NOT NULL, buyer_balance_after BIGINT NOT NULL, seller_balance_after BIGINT NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_cloud_trade_buyer (buyer_steam_id,created_at), INDEX idx_cloud_trade_seller (seller_steam_id,created_at), INDEX idx_cloud_trade_listing (listing_id,id), CONSTRAINT fk_cloud_trade_listing FOREIGN KEY (listing_id) REFERENCES cloud_market_listings(id), CONSTRAINT fk_cloud_trade_seller FOREIGN KEY (seller_steam_id) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT fk_cloud_trade_buyer FOREIGN KEY (buyer_steam_id) REFERENCES \`商城用户\`(\`SteamID\`), CONSTRAINT chk_cloud_trade_values CHECK (quantity >= 1 AND unit_price >= 1 AND gross_amount >= seller_net AND gross_amount >= fee)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS player_admin_capability_probes (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, mode VARCHAR(32) NOT NULL, endpoint_identifier VARCHAR(500) NOT NULL, probed_at DATETIME(3) NOT NULL, response_summary VARCHAR(500) NULL, response_hash CHAR(64) NULL, kick_supported TINYINT(1) NOT NULL DEFAULT 0, ban_supported TINYINT(1) NOT NULL DEFAULT 0, unban_supported TINYINT(1) NOT NULL DEFAULT 0, error_code VARCHAR(64) NULL, error_message VARCHAR(500) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_player_admin_probe_time (probed_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS player_admin_actions (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, action_type VARCHAR(16) NOT NULL, target_steam_id VARCHAR(17) NOT NULL, target_name_snapshot VARCHAR(255) NULL, admin_user_id BIGINT UNSIGNED NULL, admin_username_snapshot VARCHAR(100) NOT NULL, reason VARCHAR(500) NOT NULL, duration_minutes INT UNSIGNED NULL, confirmation VARCHAR(100) NOT NULL, request_key VARCHAR(100) NOT NULL UNIQUE, request_fingerprint CHAR(64) NOT NULL, status VARCHAR(32) NOT NULL DEFAULT 'pending', command_profile VARCHAR(64) NOT NULL DEFAULT 'scum-player-admin', command_version VARCHAR(16) NOT NULL DEFAULT 'v1', renderer_version VARCHAR(16) NOT NULL, delivery_token CHAR(36) NULL, capability_probe_id BIGINT UNSIGNED NOT NULL, parent_action_id BIGINT UNSIGNED NULL, unban_action_id BIGINT UNSIGNED NULL UNIQUE, temporary_ban_expires_at DATETIME(3) NULL, dispatched_at DATETIME(3) NULL, completed_at DATETIME(3) NULL, result_code VARCHAR(64) NULL, error_code VARCHAR(64) NULL, response_summary VARCHAR(500) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_player_admin_actions_target (target_steam_id,created_at), INDEX idx_player_admin_actions_status_expiry (status,temporary_ban_expires_at), UNIQUE KEY uk_player_admin_parent_action (parent_action_id,action_type), CONSTRAINT fk_player_admin_actor FOREIGN KEY (admin_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`) ON DELETE SET NULL, CONSTRAINT fk_player_admin_probe FOREIGN KEY (capability_probe_id) REFERENCES player_admin_capability_probes(id), CONSTRAINT fk_player_admin_parent FOREIGN KEY (parent_action_id) REFERENCES player_admin_actions(id), CONSTRAINT fk_player_admin_unban FOREIGN KEY (unban_action_id) REFERENCES player_admin_actions(id), CONSTRAINT chk_player_admin_action_type CHECK (action_type IN ('kick','ban','temp_ban','unban'))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS player_admin_action_attempts (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, action_id BIGINT UNSIGNED NOT NULL, attempt_no INT UNSIGNED NOT NULL, event_type VARCHAR(32) NOT NULL, status VARCHAR(32) NOT NULL, uncertain_delivery TINYINT(1) NOT NULL DEFAULT 0, response_summary VARCHAR(500) NULL, error_summary VARCHAR(500) NULL, actor_user_id BIGINT UNSIGNED NULL, actor_username_snapshot VARCHAR(100) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), UNIQUE KEY uk_player_admin_attempt (action_id,attempt_no), INDEX idx_player_admin_attempt_action (action_id,created_at), CONSTRAINT fk_player_admin_attempt_action FOREIGN KEY (action_id) REFERENCES player_admin_actions(id) ON DELETE CASCADE, CONSTRAINT fk_player_admin_attempt_actor FOREIGN KEY (actor_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS player_admin_verifications (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, action_id BIGINT UNSIGNED NOT NULL, admin_user_id BIGINT UNSIGNED NOT NULL, admin_username_snapshot VARCHAR(100) NOT NULL, result VARCHAR(16) NOT NULL, note VARCHAR(500) NOT NULL, request_key VARCHAR(100) NOT NULL UNIQUE, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_player_admin_verify_action (action_id,created_at), CONSTRAINT fk_player_admin_verify_action FOREIGN KEY (action_id) REFERENCES player_admin_actions(id) ON DELETE CASCADE, CONSTRAINT fk_player_admin_verify_actor FOREIGN KEY (admin_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`), CONSTRAINT chk_player_admin_verify_result CHECK (result IN ('succeeded','failed'))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS scum_log_files (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, source_type VARCHAR(16) NOT NULL DEFAULT 'kill', path_hash CHAR(64) NOT NULL, basename VARCHAR(255) NOT NULL, identity CHAR(64) NOT NULL UNIQUE, birthtime_ms BIGINT NOT NULL, ctime_ms BIGINT NOT NULL, offset_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0, pending_fragment MEDIUMTEXT NOT NULL, pending_position BIGINT UNSIGNED NOT NULL DEFAULT 0, cursor_probe_hash CHAR(64) NULL, cursor_probe_length INT UNSIGNED NOT NULL DEFAULT 0, size_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0, mtime_ms BIGINT NOT NULL DEFAULT 0, encoding VARCHAR(16) NULL, rotation_count INT UNSIGNED NOT NULL DEFAULT 0, truncation_count INT UNSIGNED NOT NULL DEFAULT 0, last_status VARCHAR(32) NOT NULL DEFAULT 'new', last_error VARCHAR(500) NULL, last_processed_at DATETIME(3) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), INDEX idx_scum_log_path (path_hash,id), INDEX idx_scum_log_status (last_status,updated_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS scum_kill_events (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, event_time DATETIME(3) NOT NULL, killer_steam_id VARCHAR(17) NOT NULL, killer_name VARCHAR(255) NULL, victim_steam_id VARCHAR(17) NOT NULL, victim_name VARCHAR(255) NULL, weapon VARCHAR(255) NULL, distance_meters DECIMAL(10,2) NULL, event_type VARCHAR(16) NOT NULL, source_file_id BIGINT UNSIGNED NOT NULL, source_position VARCHAR(64) NOT NULL, event_hash CHAR(64) NOT NULL, parser_version VARCHAR(16) NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), UNIQUE KEY uk_scum_event_source (source_file_id,source_position), UNIQUE KEY uk_scum_event_hash (event_hash), INDEX idx_scum_event_time (event_time,id), INDEX idx_scum_killer_time (killer_steam_id,event_time), INDEX idx_scum_victim_time (victim_steam_id,event_time), CONSTRAINT fk_scum_event_file FOREIGN KEY (source_file_id) REFERENCES scum_log_files(id), CONSTRAINT chk_scum_event_type CHECK (event_type IN ('kill','suicide'))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS scum_log_parse_failures (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, source_file_id BIGINT UNSIGNED NOT NULL, source_position VARCHAR(64) NOT NULL, line_hash CHAR(64) NOT NULL, reason VARCHAR(64) NOT NULL, preview VARCHAR(240) NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), UNIQUE KEY uk_scum_failure_source (source_file_id,source_position), INDEX idx_scum_failure_created (created_at), CONSTRAINT fk_scum_failure_file FOREIGN KEY (source_file_id) REFERENCES scum_log_files(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS scum_chat_events (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, event_time DATETIME(3) NOT NULL, steam_id VARCHAR(17) NOT NULL, player_name VARCHAR(255) NOT NULL, character_number INT UNSIGNED NOT NULL, channel VARCHAR(16) NOT NULL, message_text TEXT NOT NULL, parse_status VARCHAR(32) NOT NULL, command_type VARCHAR(16) NULL, command_target VARCHAR(100) NULL, source_file_id BIGINT UNSIGNED NOT NULL, source_position VARCHAR(64) NOT NULL, line_hash CHAR(64) NOT NULL, event_hash CHAR(64) NOT NULL, parser_version VARCHAR(16) NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), UNIQUE KEY uk_scum_chat_source (source_file_id,source_position), UNIQUE KEY uk_scum_chat_event_hash (event_hash), INDEX idx_scum_chat_time (event_time,id), INDEX idx_scum_chat_player_time (steam_id,event_time), INDEX idx_scum_chat_command (parse_status,channel,id), CONSTRAINT fk_scum_chat_file FOREIGN KEY (source_file_id) REFERENCES scum_log_files(id), CONSTRAINT chk_scum_chat_channel CHECK (channel IN ('Global','Local','Squad','Admin'))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS scum_chat_claim_audits (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, event_id BIGINT UNSIGNED NOT NULL, command_type VARCHAR(16) NOT NULL, command_target VARCHAR(100) NOT NULL, result VARCHAR(16) NOT NULL, gift_id BIGINT UNSIGNED NULL, gift_claim_id BIGINT UNSIGNED NULL, order_id BIGINT UNSIGNED NULL, error_code VARCHAR(64) NULL, error_message VARCHAR(500) NULL, processed_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), UNIQUE KEY uk_scum_chat_claim_event (event_id), INDEX idx_scum_chat_claim_result (result,processed_at), CONSTRAINT fk_scum_chat_claim_event FOREIGN KEY (event_id) REFERENCES scum_chat_events(id) ON DELETE CASCADE, CONSTRAINT fk_scum_chat_claim_gift FOREIGN KEY (gift_id) REFERENCES gift_packages(id), CONSTRAINT fk_scum_chat_claim_gift_claim FOREIGN KEY (gift_claim_id) REFERENCES gift_claims(id), CONSTRAINT fk_scum_chat_claim_order FOREIGN KEY (order_id) REFERENCES orders(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
];
statements.push(...SCUM_LOG_TABLE_STATEMENTS);
statements.push(`CREATE TABLE IF NOT EXISTS chat_auto_reply_rules (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,trigger_text VARCHAR(50) NOT NULL UNIQUE,response_text VARCHAR(500) NOT NULL,total_limit INT UNSIGNED NOT NULL DEFAULT 0,daily_limit INT UNSIGNED NOT NULL DEFAULT 0,min_member_level INT UNSIGNED NOT NULL DEFAULT 0,price BIGINT UNSIGNED NOT NULL DEFAULT 0,enabled TINYINT(1) NOT NULL DEFAULT 1,created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
statements.push(`CREATE TABLE IF NOT EXISTS chat_auto_reply_audits (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,event_id BIGINT UNSIGNED NOT NULL UNIQUE,rule_id BIGINT UNSIGNED NOT NULL,result VARCHAR(16) NOT NULL,response_text VARCHAR(500) NOT NULL,error_message VARCHAR(500) NULL,processed_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),CONSTRAINT fk_chat_reply_event FOREIGN KEY(event_id) REFERENCES scum_chat_events(id) ON DELETE CASCADE,CONSTRAINT fk_chat_reply_rule FOREIGN KEY(rule_id) REFERENCES chat_auto_reply_rules(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
statements.push(`CREATE TABLE IF NOT EXISTS game_admin_commands (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,verb VARCHAR(100) NOT NULL,command_text VARCHAR(255) NOT NULL,subcategory VARCHAR(64) NOT NULL,description_zh TEXT NULL,description_en TEXT NULL,usage_text TEXT NOT NULL,usage_zh TEXT NULL,executor_level VARCHAR(64) NULL,execution_side VARCHAR(32) NULL,scope_json JSON NOT NULL,arguments_json JSON NOT NULL,examples_json JSON NOT NULL,notes_zh_json JSON NOT NULL,audit_json JSON NOT NULL,raw_json JSON NOT NULL,source_url VARCHAR(500) NOT NULL,source_build VARCHAR(255) NULL,source_audited_at VARCHAR(64) NULL,imported_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),UNIQUE KEY uk_game_admin_command_verb (verb),INDEX idx_game_admin_command_category (subcategory,verb),INDEX idx_game_admin_command_level (executor_level,verb)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

statements.push(`CREATE TABLE IF NOT EXISTS cloud_pass_purchases (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, request_key VARCHAR(100) NOT NULL UNIQUE, steam_id VARCHAR(17) NOT NULL, pass_type VARCHAR(16) NOT NULL, price BIGINT UNSIGNED NOT NULL, daily_quota INT UNSIGNED NOT NULL, starts_at DATETIME(3) NOT NULL, expires_at DATETIME(3) NOT NULL, balance_after BIGINT NOT NULL, created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), INDEX idx_cloud_pass_owner (steam_id,pass_type,expires_at), CONSTRAINT fk_cloud_pass_account FOREIGN KEY (steam_id) REFERENCES \`商城用户\`(\`SteamID\`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

const tableCommentNames = `
gift_types=礼包类型字典
cloud_pass_plans=云储证套餐设置
cloud_pass_purchases=云储证购买记录
cloud_recycle_restrictions=云储回收限制
系统配置=系统配置
数据表目录=数据库功能分类目录
character_growth_purchases=角色属性技能购买记录
account_exchanges=账户资产兑换记录
商城用户=商城与游戏统一用户账户
授权账号绑定=授权账号固定绑定
membership_change_logs=会员变更记录
membership_strategies=会员策略
membership_policy=会员购买策略
membership_purchases=会员购买记录
bootstrap_states=系统初始化状态
shop_sessions=商城登录会话
admin_role_audits=管理员角色审计
steam_bind_challenges=Steam绑定挑战
coin_ledger=商城币流水
product_categories=商品分类
product_parent_categories=商品父分类
products=商品
 gift_packages=礼包
 gift_actions=礼包动作
 redeem_codes=兑换码
 redeem_code_actions=兑换码动作
 player_titles=玩家称号
 orders=订单
 gift_claims=礼包领取记录
 redeem_code_claims=兑换码领取记录
 order_items=订单明细
 fulfillment_tasks=发货任务
 fulfillment_attempts=发货尝试记录
 scheduled_announcement_runs=定时公告执行记录
 server_monitor_samples=服务器监控采样
 online_player_snapshots=在线玩家快照
 player_presence_events=玩家在线状态事件
 maintenance_windows=维护窗口
 maintenance_announcement_runs=维护公告执行记录
 maintenance_audit_logs=维护审计记录
 reward_rules=奖励规则
 player_checkins=玩家签到记录
 player_online_totals=玩家累计在线时长
 player_online_accruals=在线时长累计明细
 reward_requests=奖励请求
 reward_claims=奖励领取记录
 activities=活动
 lottery_pools=抽奖池
 lottery_pool_versions=抽奖池版本
 lottery_prizes=抽奖奖项
 activity_gifts=活动礼包关联
 activity_lottery_pools=活动奖池关联
 activity_gift_claims=活动礼包领取记录
 lottery_player_states=玩家抽奖状态
 lottery_batches=抽奖批次
 lottery_draws=抽奖结果
 lottery_fulfillment_logs=抽奖发货记录
 stocks=股票标的
 stock_volume_bindings=股票成交量绑定
 stock_price_history=股票价格历史
 stock_holdings=玩家股票持仓
 stock_trades=股票交易记录
 stock_watchlists=玩家股票自选
stock_market_announcements=股市公告
vehicles=载具档案
vehicle_insurance_strategies=载具保险销售策略
vehicle_insurance=载具保险
vehicle_insurance_purchases=载具保险购买记录
vehicle_insurance_claims=载具保险索赔记录
vehicle_audit_logs=载具操作审计
载具档案=载具档案
载具保险销售策略=载具保险销售策略
载具保险=载具保险
载具保险购买记录=载具保险购买记录
载具保险索赔记录=载具保险索赔记录
载具操作审计=载具操作审计
cloud_inventory_batches=云储库存批次
cloud_market_listings=云储市场挂单
cloud_market_trades=云储市场成交记录
player_admin_capability_probes=玩家管理能力探测
 player_admin_actions=玩家管理操作
 player_admin_action_attempts=玩家管理投递尝试
 player_admin_verifications=玩家管理人工核查
 scum_log_files=SCUM日志文件状态
 scum_kill_events=SCUM击杀事件
 scum_log_parse_failures=SCUM日志解析失败
 scum_chat_events=SCUM聊天事件
 scum_chat_claim_audits=SCUM聊天领取审计
chat_auto_reply_rules=聊天自动回复规则
chat_auto_reply_audits=聊天自动回复审计
传送管理设置=商城传送设置
传送固定位置=商城角色传送固定位置
传送执行记录=商城传送操作记录
玩家传送同意请求=玩家传送同意请求
传送位置快照=商城前台传送位置快照
game_admin_commands=游戏管理命令目录
`.trim().split('\n').map((line) => line.trim().split('='));

const tableComments = Object.fromEntries(tableCommentNames);
for (const { table, label } of SCUM_LOG_TABLES) tableComments[table] = `SCUM${label}日志中文物理表`;

const columnCommentNames = `
pass_type=云储证类型
duration_days=有效天数
daily_quota=每日增加额度
starts_at=生效时间
expires_at=到期时间
id=编号
steam_id=SteamID
balance=商城币余额
input_amount=兑换输入数量
output_amount=兑换输出数量
rate_snapshot=兑换比例快照
coin_delta=商城币变动
gold_delta=金条变动
rcon_command=RCON命令
rcon_response=RCON响应
error_message=错误信息
created_at=创建时间
updated_at=更新时间
实体类型=传送实体类型
实体标识=传送实体唯一标识
归属SteamID=实体归属SteamID
显示名称=前台显示名称
世界X坐标=游戏世界X坐标
世界Y坐标=游戏世界Y坐标
世界Z坐标=游戏世界Z坐标
数据来源=位置数据来源
观测时间=位置观测时间
是否当前有效=是否为当前有效快照
更新时间=更新时间
配置编号=传送设置配置编号
传送总开关=传送功能总开关
基础价格=传送基础价格
基础每日次数=每日基础传送次数
冷却秒数=传送冷却秒数
小队玩家互传=是否允许小队玩家互传
玩家到小队载具=是否允许玩家传送到小队载具
玩家到授权领地旗=是否允许玩家传送到授权领地旗
固定位置传送=是否允许玩家传送到固定位置
位置编号=固定位置编号
位置名称=固定位置名称
是否启用=是否启用固定位置
排序值=固定位置显示顺序
来源类型=固定位置来源类型
可见范围=固定位置对全部玩家或私人玩家可见
归属SteamID=私人固定位置归属玩家SteamID
创建管理员编号=创建位置的管理员编号
创建时间=创建时间
领地内载具到玩家=是否允许领地内载具传送到玩家
远距离载具到玩家=是否允许远距离载具传送到玩家
载具到固定位置=是否允许载具传送到服务端固定位置
同意请求有效秒数=历史同意请求有效秒数
最后修改管理员编号=最后修改设置的管理员编号
请求编号=传送同意请求编号
发起玩家SteamID=发起传送的玩家SteamID
目标玩家SteamID=目标玩家SteamID
请求状态=传送同意请求状态
过期时间=请求过期时间
同意时间=请求同意时间
拒绝时间=请求拒绝时间
使用时间=请求使用时间
记录编号=传送执行记录编号
请求幂等键=防止传送重复执行的请求键
请求指纹=传送请求内容指纹
目标类型=传送目标类型
目标引用=传送目标安全引用
目标名称快照=执行时目标显示名称
游戏目标编号=游戏内目标编号
折扣百分比=传送折扣百分比
实扣商城币=实际扣除商城币
扣款后余额=扣款后的商城币余额
执行状态=传送执行状态
错误代码=传送错误代码
错误信息=错误信息
完成时间=传送完成时间
创建时间=创建时间
username=用户名
normalized=标准化用户名
password_hash=密码哈希
password_salt=密码盐
role=用户角色
status=状态
member_level=会员等级
member_expires_at=会员到期时间
last_login=最后登录时间
old_level=原会员等级
new_level=新会员等级
old_expires_at=原到期时间
new_expires_at=新到期时间
reason=原因
operator=操作人
level=等级
title=标题
opening_amount=开通金额
period_days=有效天数
gift_tokens=赠送代币数
upgrade_spend=升级消费门槛
teleport_discount=传送折扣
online_bonus=在线奖励倍率
shopping_discount=购物折扣
gift_discount=礼包折扣
recharge_bonus=充值奖励倍率
daily_teleports=每日传送次数
checkin_bonus=签到奖励
extra_hint=附加提示
enabled=是否启用
state_key=状态键
created_user_id=创建用户编号
completed_at=完成时间
user_id=用户编号
token_hash=令牌哈希
expires_at=到期时间
revoked_at=撤销时间
ip_address=IP地址
user_agent=用户代理
actor_user_id=操作用户编号
actor_type=操作来源类型
actor_label=操作方标识
actor_username_snapshot=操作用户名快照
target_user_id=目标用户编号
target_username_snapshot=目标用户名快照
target_steam_id=目标SteamID
old_role=原角色
new_role=新角色
code_hash=验证码哈希
attempts=尝试次数
max_attempts=最大尝试次数
consumed_at=使用时间
invalidated_at=失效时间
amount=数量或金额
balance_after=变动后余额
type=类型
reference_type=关联类型
reference_id=关联编号
note=备注
input_amount=兑换输入数量
output_amount=兑换输出数量
rate_snapshot=兑换比例快照
coin_delta=商城币变动
 gold_delta=金条变动
rcon_command=RCON命令
rcon_response=RCON响应
completed_at=完成时间
sku=商品SKU
name=名称
price=价格
item_id=游戏物品编号
grant_amount=发放数量
parent_category=父分类
category_name=分类名称
currency_type=货币类型
min_member_level=最低会员等级
image_path=图片路径
fulfillment_codes=发货代码
gift_type=礼包类型
description=说明
required_title=所需称号
member_mode=会员匹配模式
total_limit=总次数限制
daily_limit=每日次数限制
period_limit=周期次数限制
gift_id=礼包编号
action_index=动作序号
action_type=动作类型
product_id=商品编号
product_quantity=商品数量
quantity=数量
options_json=选项JSON
coin_amount=商城币数量
raw_text=原始动作文本
code_hint=兑换码掩码提示
code_type=兑换码类型
per_user_limit=单用户次数限制
starts_at=开始时间
created_by=创建人
used_count=已使用次数
redeem_code_id=兑换码编号
title_name=称号名称
squad_id=小队编号
squad_name=小队名称
order_no=订单号
source=来源
external_order_id=外部订单编号
request_hash=请求哈希
gift_claim_id=礼包领取编号
redeem_claim_id=兑换码领取编号
total_amount=订单总金额
order_id=订单编号
request_key=幂等请求键
claim_period_key=领取周期键
claim_day=领取日期
price_paid=实付金额
unit_price=单价
fulfillment_codes_snapshot=发货代码快照
order_item_id=订单明细编号
code_index=代码序号
generation=任务代次
replacement_of_task_id=被替换任务编号
created_by_user_id=创建用户编号
replacement_reason=替换原因
task_type=任务类型
payload_json=任务载荷JSON
next_attempt_at=下次尝试时间
last_error=最后错误
locked_at=锁定时间
delivery_token=投递令牌
task_id=任务编号
attempt_no=尝试序号
message=消息
announcement_id=公告编号
scheduled_for=计划执行时间
sent_count=发送成功数
failed_count=发送失败数
started_at=开始时间
sampled_at=采样时间
rcon_ok=RCON是否正常
player_query_ok=玩家查询是否正常
online_count=在线人数
rcon_latency_ms=RCON延迟毫秒
process_uptime_sec=进程运行秒数
process_rss_bytes=进程常驻内存字节
process_heap_used_bytes=进程堆内存字节
process_cpu_percent=进程CPU占用百分比
worker_running=发货任务进程是否运行
error_code=错误代码
error_message=错误信息
sample_id=采样编号
character_name=角色名称
steam_name=Steam名称
is_admin=是否管理员
observed_at=观测时间
event_type=事件类型
instance_id=实例编号
title=标题
scheduled_at=计划时间
state=状态
fulfillment_paused=是否暂停发货
pause_started_at=暂停开始时间
maintenance_started_at=维护开始时间
awaiting_recovery_at=等待恢复时间
recovery_ready_at=恢复就绪时间
cancelled_at=取消时间
confirmed_by=确认人
cancelled_by=取消人
maintenance_id=维护编号
minute_mark=分钟节点
action=操作动作
actor=操作人
details_json=详情JSON
rule_type=规则类型
threshold_value=阈值
gift_id=礼包编号
checkin_day=签到日期
streak_days=连续签到天数
total_days=累计签到天数
total_seconds=累计在线秒数
previous_sample_id=前次采样编号
credited_seconds=计入秒数
checkin_id=签到编号
request_id=请求编号
claim_key=领取幂等键
rule_id=规则编号
lottery_pool_id=抽奖池编号
pool_id=奖池编号
version_no=版本号
single_price=单抽价格
ten_price=十连抽价格
daily_free_count=每日免费次数
pity_threshold=保底阈值
config_snapshot_json=配置快照JSON
version_id=版本编号
prize_index=奖项序号
reward_type=奖励类型
reward_name_snapshot=奖励名称快照
weight=权重
luck_required=幸运度要求
rarity=稀有度
label=标签
is_pity=是否保底奖项
gift_name_snapshot=礼包名称快照
action_snapshot_json=动作快照JSON
activity_id=活动编号
activity_snapshot_json=活动快照JSON
gift_snapshot_json=礼包快照JSON
pity_count=保底计数
free_day=免费抽奖日期
free_used=已用免费次数
draw_count=抽奖次数
free_count=免费次数
paid_count=付费次数
balance_before=操作前余额
pity_before=操作前保底计数
pity_after=操作后保底计数
pool_snapshot_json=奖池快照JSON
batch_id=批次编号
draw_index=抽奖序号
prize_id=奖项编号
weight_snapshot=权重快照
total_weight_snapshot=总权重快照
rarity_snapshot=稀有度快照
label_snapshot=标签快照
is_pity_snapshot=保底标记快照
forced_pity=是否触发保底
prize_snapshot_json=奖项快照JSON
lottery_batch_id=抽奖批次编号
lottery_draw_id=抽奖结果编号
fulfillment_task_id=发货任务编号
pool_name_snapshot=奖池名称快照
error_summary=错误摘要
code=股票代码
current_price=当前价格
base_price=基准价格
paused=是否暂停
deleted_at=删除时间
pricing_mode=定价模式
volume_metric=成交量指标
baseline_value=基线值
volume_sensitivity_bps=成交量敏感度基点
volatility_bps=波动基点
max_change_bps=最大涨跌基点
min_price=最低价格
fee_bps=手续费基点
period_seconds=周期秒数
price_version=价格版本
last_period_key=最后周期键
stock_id=股票编号
binding_type=绑定类型
product_sku=商品SKU快照
weight_bps=权重基点
period_key=周期键
price_before=变动前价格
price_after=变动后价格
change_bps=涨跌基点
volume_quantity=成交件数
volume_amount=成交金额
volume_change_bps=成交量信号基点
random_change_bps=随机信号基点
priced_at=定价时间
average_cost=平均成本
direction=交易方向
fee=手续费
gross_amount=成交总额
net_amount=结算金额
holding_before=交易前持仓
holding_after=交易后持仓
average_cost_before=交易前平均成本
average_cost_after=交易后平均成本
price_time_snapshot=报价时间
content=内容
updated_by_user_id=更新用户编号
mode=模式
endpoint_identifier=端点标识
probed_at=探测时间
response_summary=响应摘要
response_hash=响应哈希
kick_supported=是否支持踢出
ban_supported=是否支持封禁
unban_supported=是否支持解封
target_name_snapshot=目标名称快照
admin_user_id=管理员用户编号
admin_username_snapshot=管理员用户名快照
duration_minutes=时长分钟
confirmation=确认文本
request_fingerprint=请求指纹
command_profile=命令配置
command_version=命令版本
renderer_version=渲染器版本
capability_probe_id=能力探测编号
parent_action_id=父操作编号
unban_action_id=解封操作编号
temporary_ban_expires_at=临时封禁到期时间
dispatched_at=发送时间
result_code=结果代码
action_id=操作编号
uncertain_delivery=投递是否不确定
actor_username_snapshot=操作用户名快照
result=结果
source_type=日志来源类型
path_hash=路径哈希
basename=文件名
identity=文件身份标识
birthtime_ms=文件创建时间毫秒
ctime_ms=文件变更时间毫秒
offset_bytes=读取偏移字节
pending_fragment=待处理文本片段
pending_position=待处理位置
cursor_probe_hash=游标探针哈希
cursor_probe_length=游标探针长度
size_bytes=文件大小字节
mtime_ms=文件修改时间毫秒
encoding=文件编码
rotation_count=轮转次数
truncation_count=截断次数
last_status=最后状态
last_processed_at=最后处理时间
event_time=事件时间
killer_steam_id=击杀者SteamID
killer_name=击杀者名称
victim_steam_id=受害者SteamID
victim_name=受害者名称
weapon=武器
distance_meters=距离米
source_file_id=来源文件编号
source_position=来源位置
event_hash=事件哈希
parser_version=解析器版本
line_hash=原始行哈希
preview=脱敏预览
player_name=玩家名称
character_number=角色编号
channel=聊天频道
message_text=聊天内容
parse_status=解析状态
command_type=命令类型
command_target=命令目标
event_id=事件编号
processed_at=处理时间
`.trim().split('\n').map((line) => line.split('='));

const columnComments = Object.fromEntries(columnCommentNames);

function splitDefinitions(body) {
  const definitions = [];
  let start = 0;
  let depth = 0;
  let quote = null;
  for (let index = 0; index <= body.length; index += 1) {
    const character = body[index];
    if (quote) {
      if (character === quote && body[index - 1] !== '\\') quote = null;
    } else if (character === "'" || character === '`' || character === '"') quote = character;
    else if (character === '(') depth += 1;
    else if (character === ')') depth -= 1;
    else if ((character === ',' && depth === 0) || index === body.length) {
      definitions.push(body.slice(start, index).trim());
      start = index + 1;
    }
  }
  return definitions;
}

function describeColumns(table, columns) {
  return columns.map((column) => columnComments[column] || `${tableComments[table]}业务字段 ${column}`).join('、');
}

function parseSchemaObjects() {
  const comments = [];
  for (const statement of statements) {
    const tableMatch = statement.match(/^CREATE TABLE IF NOT EXISTS (?:`([^`]+)`|([a-z0-9_]+))/);
    const table = tableMatch?.[1] || tableMatch?.[2];
    const body = statement.slice(statement.indexOf('(') + 1, statement.lastIndexOf(') ENGINE='));
    const definitions = splitDefinitions(body);
    comments.push({ objectType: 'table', table, objectName: '', comment: tableComments[table] });
    for (const definition of definitions) {
      const columnMatch = definition.match(/^(?:`([^`]+)`|([a-z][a-z0-9_]*))\s/);
      const column = columnMatch?.[1] || columnMatch?.[2];
      if (column) {
        comments.push({ objectType: 'column', table, objectName: column, comment: columnComments[column] || `${tableComments[table]}业务字段 ${column}` });
        if (/\bPRIMARY KEY\b/.test(definition)) comments.push({ objectType: 'index', table, objectName: 'PRIMARY', comment: `${describeColumns(table, [column])}主键索引` });
        if (/\bUNIQUE\b/.test(definition)) comments.push({ objectType: 'index', table, objectName: column, comment: `${describeColumns(table, [column])}唯一索引` });
        continue;
      }
      const index = definition.match(/^(PRIMARY KEY|UNIQUE KEY|INDEX)\s*(?:([a-z0-9_]+)\s*)?\(([^)]+)\)/);
      if (index) {
        const columns = index[3].split(',').map((value) => value.trim().replaceAll('`', '').split(/\s|\(/)[0]);
        const name = index[1] === 'PRIMARY KEY' ? 'PRIMARY' : index[2];
        comments.push({ objectType: 'index', table, objectName: name, comment: `${describeColumns(table, columns)}${index[1] === 'UNIQUE KEY' || name === 'PRIMARY' ? '唯一' : '查询'}索引` });
      }
      const foreignKey = definition.match(/^CONSTRAINT\s+(?:`([^`]+)`|([a-z0-9_]+))\s+FOREIGN KEY\s*\(([^)]+)\)\s+REFERENCES\s+(?:`([^`]+)`|([a-z0-9_]+))\s*\(([^)]+)\)/);
      if (foreignKey) {
        const constraint = foreignKey[1] || foreignKey[2];
        const columns = foreignKey[3].split(',').map((value) => value.trim().replaceAll('`', ''));
        const targetTable = foreignKey[4] || foreignKey[5];
        comments.push({ objectType: 'foreign_key', table, objectName: constraint, comment: `${describeColumns(table, columns)}关联${tableComments[targetTable]}` });
      }
    }
  }
  return comments;
}

const additionalSchemaComments = [
  ['index','scum_chat_events','uk_scum_chat_event_hash','聊天事件哈希唯一索引'],
  ['index','scum_log_files','idx_scum_log_source_path','日志来源与路径查询索引'],
  ['index','orders','uk_orders_gift_claim','礼包领取编号唯一索引'],
  ['index','orders','uk_orders_redeem_claim','兑换码领取编号唯一索引'],
  ['index','gift_claims','uk_gift_claim_request','礼包领取请求键唯一索引'],
  ['index','gift_claims','uk_gift_claim_order','礼包领取订单唯一索引'],
  ['index','coin_ledger','uk_ledger_reference','商城币流水关联对象唯一索引'],
  ['index','fulfillment_tasks','uk_task_request_key','发货请求键唯一索引'],
  ['index','coin_ledger','idx_ledger_order_purchase_time','订单消费流水时间查询索引'],
  ['index','orders','idx_orders_source_id','订单来源查询索引'],
  ['index','order_items','idx_order_items_product_category','订单商品分类查询索引'],
  ['foreign_key','lottery_pools','fk_lottery_pool_current_version','当前版本关联抽奖池版本'],
  ['foreign_key','activities','fk_activity_lottery_pool','自动活动关联抽奖池']
].map(([objectType, table, objectName, comment]) => ({ objectType, table, objectName, comment }));

const schemaComments = [
  ...parseSchemaObjects(),
  ...additionalSchemaComments,
  { objectType: 'column', table: 'maintenance_windows', objectName: 'countdown_marks_json', comment: '倒计时节点JSON' },
  { objectType: 'column', table: 'maintenance_windows', objectName: 'announcement_template', comment: '公告模板' },
  { objectType: 'column', table: 'maintenance_windows', objectName: 'recovery_success_threshold', comment: '恢复成功阈值' },
  { objectType: 'table', table: 'schema_comments', objectName: '', comment: '数据库结构中文备注字典' },
  { objectType: 'column', table: 'schema_comments', objectName: 'object_type', comment: '结构对象类型' },
  { objectType: 'column', table: 'schema_comments', objectName: 'table_name', comment: '英文物理表名' },
  { objectType: 'column', table: 'schema_comments', objectName: 'object_name', comment: '英文物理对象名' },
  { objectType: 'column', table: 'schema_comments', objectName: 'comment_text', comment: '中文备注说明' },
  { objectType: 'column', table: 'schema_comments', objectName: 'updated_at', comment: '更新时间' },
  { objectType: 'index', table: 'schema_comments', objectName: 'PRIMARY', comment: '对象类型、表名和对象名联合主键索引' }
].filter((entry, index, all) =>
  entry.table && entry.comment && all.findIndex((candidate) => candidate.objectType === entry.objectType && candidate.table === entry.table && candidate.objectName === entry.objectName) === index
);

const columnMigrations = [
  ['lottery_pools','ten_price','ALTER TABLE lottery_pools ADD COLUMN ten_price BIGINT UNSIGNED NULL AFTER single_price'],
  ['系统配置','cloud_withdraw_fee','ALTER TABLE `系统配置` ADD COLUMN cloud_withdraw_fee BIGINT UNSIGNED NOT NULL DEFAULT 0'],
  ['系统配置','cloud_minimum_fee','ALTER TABLE `系统配置` ADD COLUMN cloud_minimum_fee BIGINT UNSIGNED NOT NULL DEFAULT 1 AFTER cloud_fee_bps'],
  ['系统配置','cloud_recycle_control_enabled','ALTER TABLE `系统配置` ADD COLUMN cloud_recycle_control_enabled TINYINT(1) NOT NULL DEFAULT 1 AFTER cloud_daily_base_quota'],
  ['系统配置','cloud_destroy_refund_percent','ALTER TABLE `系统配置` ADD COLUMN cloud_destroy_refund_percent INT UNSIGNED NOT NULL DEFAULT 20 AFTER cloud_recycle_control_enabled'],
  ['系统配置','cloud_destroy_fallback_refund','ALTER TABLE `系统配置` ADD COLUMN cloud_destroy_fallback_refund BIGINT UNSIGNED NOT NULL DEFAULT 2 AFTER cloud_destroy_refund_percent'],
  ['cloud_recycle_restrictions','reason',"ALTER TABLE cloud_recycle_restrictions ADD COLUMN reason VARCHAR(500) NOT NULL DEFAULT '' AFTER item_code"],
  ['cloud_recycle_restrictions','item_name',"ALTER TABLE cloud_recycle_restrictions ADD COLUMN item_name VARCHAR(100) NOT NULL DEFAULT '' AFTER item_code"],
  ['cloud_recycle_restrictions','enabled','ALTER TABLE cloud_recycle_restrictions ADD COLUMN enabled TINYINT(1) NOT NULL DEFAULT 1 AFTER reason'],
  ['cloud_market_listings','minimum_fee','ALTER TABLE cloud_market_listings ADD COLUMN minimum_fee BIGINT UNSIGNED NOT NULL DEFAULT 1 AFTER fee_bps'],
  ['cloud_inventory_batches','item_health','ALTER TABLE cloud_inventory_batches ADD COLUMN item_health DECIMAL(10,4) NULL AFTER reserved_quantity'],
  ['cloud_inventory_batches','item_max_health','ALTER TABLE cloud_inventory_batches ADD COLUMN item_max_health DECIMAL(10,4) NULL AFTER item_health'],
  ['cloud_inventory_batches','item_dirtiness','ALTER TABLE cloud_inventory_batches ADD COLUMN item_dirtiness DECIMAL(10,4) NULL AFTER item_max_health'],
  ['cloud_inventory_batches','item_uses','ALTER TABLE cloud_inventory_batches ADD COLUMN item_uses INT UNSIGNED NULL AFTER item_dirtiness'],
  ['cloud_inventory_batches','item_max_uses','ALTER TABLE cloud_inventory_batches ADD COLUMN item_max_uses INT UNSIGNED NULL AFTER item_uses'],
  ['cloud_inventory_batches','item_max_quantity','ALTER TABLE cloud_inventory_batches ADD COLUMN item_max_quantity INT UNSIGNED NULL AFTER item_max_uses'],
  ['cloud_inventory_batches','item_stackable','ALTER TABLE cloud_inventory_batches ADD COLUMN item_stackable TINYINT(1) NOT NULL DEFAULT 0 AFTER item_max_quantity'],
  ['cloud_inventory_batches','item_radiation_amount','ALTER TABLE cloud_inventory_batches ADD COLUMN item_radiation_amount DECIMAL(20,8) NULL AFTER item_stackable'],
  ['cloud_inventory_batches','item_weight','ALTER TABLE cloud_inventory_batches ADD COLUMN item_weight DECIMAL(20,8) NULL AFTER item_radiation_amount'],
  ['cloud_inventory_batches','item_water_weight','ALTER TABLE cloud_inventory_batches ADD COLUMN item_water_weight DECIMAL(20,8) NULL AFTER item_weight'],
  ['cloud_inventory_batches','item_external_weight','ALTER TABLE cloud_inventory_batches ADD COLUMN item_external_weight DECIMAL(20,8) NULL AFTER item_water_weight'],
  ['cloud_inventory_batches','item_total_weight','ALTER TABLE cloud_inventory_batches ADD COLUMN item_total_weight DECIMAL(20,8) NULL AFTER item_external_weight'],
  ['cloud_inventory_batches','item_xml_base64','ALTER TABLE cloud_inventory_batches ADD COLUMN item_xml_base64 LONGTEXT NULL AFTER item_total_weight'],
  ['cloud_inventory_batches','item_body_damage_base64','ALTER TABLE cloud_inventory_batches ADD COLUMN item_body_damage_base64 LONGTEXT NULL AFTER item_xml_base64'],
  ['cloud_inventory_batches','item_snapshot_json','ALTER TABLE cloud_inventory_batches ADD COLUMN item_snapshot_json JSON NULL AFTER item_body_damage_base64'],
  ['reward_rules','coin_amount','ALTER TABLE reward_rules ADD COLUMN coin_amount BIGINT UNSIGNED NULL AFTER gift_id'],
  ['reward_rules','reward_type',"ALTER TABLE reward_rules ADD COLUMN reward_type VARCHAR(16) NOT NULL DEFAULT 'shop_coin' AFTER threshold_value"],
  ['reward_rules','product_id','ALTER TABLE reward_rules ADD COLUMN product_id BIGINT UNSIGNED NULL AFTER gift_id'],
  ['reward_rules','product_quantity','ALTER TABLE reward_rules ADD COLUMN product_quantity INT UNSIGNED NOT NULL DEFAULT 1 AFTER product_id'],
  ['reward_rules','product_items_json','ALTER TABLE reward_rules ADD COLUMN product_items_json JSON NULL AFTER product_quantity'],
  ['lottery_prizes','luck_required','ALTER TABLE lottery_prizes ADD COLUMN luck_required TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER weight'],
  ['lottery_prizes','stock_quantity','ALTER TABLE lottery_prizes ADD COLUMN stock_quantity INT UNSIGNED NOT NULL DEFAULT 4294967295 AFTER luck_required'],
  ['lottery_prizes','stock_remaining','ALTER TABLE lottery_prizes ADD COLUMN stock_remaining INT UNSIGNED NOT NULL DEFAULT 4294967295 AFTER stock_quantity'],
  ['lottery_pools','luck_growth','ALTER TABLE lottery_pools ADD COLUMN luck_growth TINYINT UNSIGNED NOT NULL DEFAULT 1 AFTER single_price'],
  ['reward_claims','coin_amount','ALTER TABLE reward_claims ADD COLUMN coin_amount BIGINT UNSIGNED NULL AFTER gift_id'],
  ['reward_claims','product_id','ALTER TABLE reward_claims ADD COLUMN product_id BIGINT UNSIGNED NULL AFTER gift_id'],
  ['membership_change_logs','operator',"ALTER TABLE membership_change_logs ADD COLUMN operator VARCHAR(100) NOT NULL DEFAULT 'admin' AFTER reason"],
  ['online_player_snapshots','money','ALTER TABLE online_player_snapshots ADD COLUMN money DECIMAL(20,2) NULL AFTER is_admin'],
  ['online_player_snapshots','gold','ALTER TABLE online_player_snapshots ADD COLUMN gold DECIMAL(20,2) NULL AFTER money'],
  ['admin_role_audits','actor_type',"ALTER TABLE admin_role_audits ADD COLUMN actor_type VARCHAR(16) NOT NULL DEFAULT 'shop_user' AFTER actor_user_id"],
  ['admin_role_audits','actor_label',"ALTER TABLE admin_role_audits ADD COLUMN actor_label VARCHAR(100) NOT NULL DEFAULT 'legacy-shop-user' AFTER actor_type"],
  ['gift_packages','gift_type',"ALTER TABLE gift_packages ADD COLUMN gift_type VARCHAR(16) NOT NULL DEFAULT 'normal' AFTER name"],
  ['gift_packages','description','ALTER TABLE gift_packages ADD COLUMN description TEXT NULL AFTER gift_type'],
  ['gift_packages','target_steam_id','ALTER TABLE gift_packages ADD COLUMN target_steam_id VARCHAR(17) NULL AFTER enabled'],
  ['gift_packages','required_title','ALTER TABLE gift_packages ADD COLUMN required_title VARCHAR(100) NULL AFTER target_steam_id'],
  ['gift_packages','member_level','ALTER TABLE gift_packages ADD COLUMN member_level INT NOT NULL DEFAULT 0 AFTER required_title'],
  ['gift_packages','member_mode',"ALTER TABLE gift_packages ADD COLUMN member_mode VARCHAR(16) NOT NULL DEFAULT 'minimum' AFTER member_level"],
  ['gift_packages','total_limit','ALTER TABLE gift_packages ADD COLUMN total_limit INT UNSIGNED NOT NULL DEFAULT 1 AFTER member_mode'],
  ['gift_packages','daily_limit','ALTER TABLE gift_packages ADD COLUMN daily_limit INT UNSIGNED NOT NULL DEFAULT 1 AFTER total_limit'],
  ['gift_packages','period_limit','ALTER TABLE gift_packages ADD COLUMN period_limit INT UNSIGNED NOT NULL DEFAULT 1 AFTER daily_limit'],
  ['gift_packages','price','ALTER TABLE gift_packages ADD COLUMN price BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER period_limit'],
  ['gift_packages','image_path','ALTER TABLE gift_packages ADD COLUMN image_path VARCHAR(500) NULL AFTER description'],
  ['gift_packages','expires_at','ALTER TABLE gift_packages ADD COLUMN expires_at DATETIME(3) NULL AFTER image_path'],
  ['gift_packages','next_reset_at','ALTER TABLE gift_packages ADD COLUMN next_reset_at DATETIME(3) NULL AFTER expires_at'],
  ['gift_packages','reset_cycle',"ALTER TABLE gift_packages ADD COLUMN reset_cycle VARCHAR(16) NOT NULL DEFAULT 'none' AFTER next_reset_at"],
  ['gift_claims','steam_id','ALTER TABLE gift_claims ADD COLUMN steam_id VARCHAR(17) NULL AFTER gift_id'],
  ['gift_claims','order_id','ALTER TABLE gift_claims ADD COLUMN order_id BIGINT UNSIGNED NULL AFTER steam_id'],
  ['gift_claims','request_key','ALTER TABLE gift_claims ADD COLUMN request_key VARCHAR(100) NULL AFTER order_id'],
  ['gift_claims','claim_period_key','ALTER TABLE gift_claims ADD COLUMN claim_period_key VARCHAR(32) NULL AFTER request_key'],
  ['gift_claims','claim_day','ALTER TABLE gift_claims ADD COLUMN claim_day DATE NULL AFTER claim_period_key'],
  ['gift_claims','price_paid','ALTER TABLE gift_claims ADD COLUMN price_paid BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER claim_day'],
  ['player_titles','expires_at','ALTER TABLE player_titles ADD COLUMN expires_at DATETIME(3) NULL AFTER title_name'],
  ['player_titles','created_at','ALTER TABLE player_titles ADD COLUMN created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)'],
  ['player_titles','updated_at','ALTER TABLE player_titles ADD COLUMN updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)'],
  ['products','parent_category','ALTER TABLE products ADD COLUMN parent_category VARCHAR(100) NULL'],
  ['products','category_name','ALTER TABLE products ADD COLUMN category_name VARCHAR(100) NULL'],
  ['products','currency_type',"ALTER TABLE products ADD COLUMN currency_type VARCHAR(32) NOT NULL DEFAULT 'coin'"],
  ['products','min_member_level','ALTER TABLE products ADD COLUMN min_member_level INT NOT NULL DEFAULT 0'],
  ['products','max_uses','ALTER TABLE products ADD COLUMN max_uses INT UNSIGNED NULL AFTER min_member_level'],
  ['products','image_path','ALTER TABLE products ADD COLUMN image_path VARCHAR(500) NULL'],
  ['products','fulfillment_codes','ALTER TABLE products ADD COLUMN fulfillment_codes TEXT NULL'],
  ['vehicles','source_type','ALTER TABLE vehicles ADD COLUMN source_type VARCHAR(32) NULL AFTER notes'],
  ['vehicles','source_vehicle_id','ALTER TABLE vehicles ADD COLUMN source_vehicle_id BIGINT UNSIGNED NULL AFTER source_type'],
  ['vehicles','source_asset_id','ALTER TABLE vehicles ADD COLUMN source_asset_id VARCHAR(255) NULL AFTER source_vehicle_id'],
  ['vehicles','source_vehicle_alias','ALTER TABLE vehicles ADD COLUMN source_vehicle_alias VARCHAR(120) NULL AFTER source_asset_id'],
  ['vehicles','source_entity_class','ALTER TABLE vehicles ADD COLUMN source_entity_class VARCHAR(120) NULL AFTER source_vehicle_alias'],
  ['vehicles','source_lock_slots','ALTER TABLE vehicles ADD COLUMN source_lock_slots INT UNSIGNED NULL AFTER source_entity_class'],
  ['vehicles','location_source','ALTER TABLE vehicles ADD COLUMN location_source VARCHAR(32) NULL AFTER source_lock_slots'],
  ['vehicles','source_synchronized_at','ALTER TABLE vehicles ADD COLUMN source_synchronized_at DATETIME(3) NULL AFTER location_source'],
  ['vehicles','source_sync_state',"ALTER TABLE vehicles ADD COLUMN source_sync_state VARCHAR(16) NOT NULL DEFAULT 'manual' AFTER source_synchronized_at"],
  ['vehicles','source_missing_since','ALTER TABLE vehicles ADD COLUMN source_missing_since DATETIME(3) NULL AFTER source_sync_state'],
  ['vehicles','status_before_source_lost','ALTER TABLE vehicles ADD COLUMN status_before_source_lost VARCHAR(16) NULL AFTER source_missing_since'],
  ['vehicle_insurance_strategies','product_id','ALTER TABLE vehicle_insurance_strategies ADD COLUMN product_id BIGINT UNSIGNED NULL AFTER duration_days'],
  ['vehicle_insurance_strategies','vehicle_code','ALTER TABLE vehicle_insurance_strategies ADD COLUMN vehicle_code VARCHAR(80) NULL AFTER vehicle_type'],
  ['vehicle_insurance_strategies','purchase_condition',"ALTER TABLE vehicle_insurance_strategies ADD COLUMN purchase_condition VARCHAR(200) NOT NULL DEFAULT '无需绑定载具' AFTER duration_days"],
  ['vehicle_insurance','strategy_id','ALTER TABLE vehicle_insurance ADD COLUMN strategy_id BIGINT UNSIGNED NULL AFTER vehicle_id'],
  ['vehicle_insurance','total_claim_limit','ALTER TABLE vehicle_insurance ADD COLUMN total_claim_limit INT UNSIGNED NULL AFTER premium_amount'],
  ['vehicle_insurance','daily_claim_limit','ALTER TABLE vehicle_insurance ADD COLUMN daily_claim_limit INT UNSIGNED NULL AFTER total_claim_limit'],
  ['vehicle_insurance','total_claims_used','ALTER TABLE vehicle_insurance ADD COLUMN total_claims_used INT UNSIGNED NOT NULL DEFAULT 0 AFTER daily_claim_limit'],
  ['vehicle_insurance','daily_claims_used','ALTER TABLE vehicle_insurance ADD COLUMN daily_claims_used INT UNSIGNED NOT NULL DEFAULT 0 AFTER total_claims_used'],
  ['vehicle_insurance','daily_claim_date','ALTER TABLE vehicle_insurance ADD COLUMN daily_claim_date DATE NULL AFTER daily_claims_used'],
  ['orders','gift_id','ALTER TABLE orders ADD COLUMN gift_id BIGINT UNSIGNED NULL AFTER steam_id'],
  ['orders','gift_claim_id','ALTER TABLE orders ADD COLUMN gift_claim_id BIGINT UNSIGNED NULL AFTER gift_id'],
  ['orders','redeem_code_id','ALTER TABLE orders ADD COLUMN redeem_code_id BIGINT UNSIGNED NULL AFTER gift_claim_id'],
  ['orders','redeem_claim_id','ALTER TABLE orders ADD COLUMN redeem_claim_id BIGINT UNSIGNED NULL AFTER redeem_code_id'],
  ['activities','lottery_pool_id','ALTER TABLE activities ADD COLUMN lottery_pool_id BIGINT UNSIGNED NULL AFTER created_by_user_id'],
  ['lottery_pools','image_path','ALTER TABLE lottery_pools ADD COLUMN image_path VARCHAR(500) NULL AFTER description'],
  ['lottery_pools','currency_type',"ALTER TABLE lottery_pools ADD COLUMN currency_type VARCHAR(32) NOT NULL DEFAULT 'coin' AFTER image_path"],
  ['lottery_pools','single_price','ALTER TABLE lottery_pools ADD COLUMN single_price BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER currency_type'],
  ['lottery_pools','deleted_at','ALTER TABLE lottery_pools ADD COLUMN deleted_at DATETIME(3) NULL AFTER enabled'],
  ['lottery_prizes','reward_type',"ALTER TABLE lottery_prizes ADD COLUMN reward_type VARCHAR(16) NOT NULL DEFAULT 'gift' AFTER prize_index"],
  ['lottery_prizes','product_id','ALTER TABLE lottery_prizes ADD COLUMN product_id BIGINT UNSIGNED NULL AFTER gift_id'],
  ['lottery_prizes','reward_name_snapshot','ALTER TABLE lottery_prizes ADD COLUMN reward_name_snapshot VARCHAR(100) NULL AFTER product_id'],
  ['lottery_prizes','action_snapshot_json','ALTER TABLE lottery_prizes ADD COLUMN action_snapshot_json JSON NULL AFTER gift_name_snapshot'],
  ['lottery_draws','reward_type',"ALTER TABLE lottery_draws ADD COLUMN reward_type VARCHAR(16) NOT NULL DEFAULT 'gift' AFTER prize_id"],
  ['lottery_draws','reward_name_snapshot','ALTER TABLE lottery_draws ADD COLUMN reward_name_snapshot VARCHAR(100) NULL AFTER gift_id'],
  ['lottery_fulfillment_logs','status',"ALTER TABLE lottery_fulfillment_logs ADD COLUMN status VARCHAR(32) NOT NULL DEFAULT 'pending' AFTER task_type"],
  ['fulfillment_tasks','task_type',"ALTER TABLE fulfillment_tasks ADD COLUMN task_type VARCHAR(32) NOT NULL DEFAULT 'spawn_item' AFTER steam_id"],
  ['fulfillment_tasks','payload_json','ALTER TABLE fulfillment_tasks ADD COLUMN payload_json JSON NULL AFTER task_type'],
  ['fulfillment_tasks','coin_amount','ALTER TABLE fulfillment_tasks ADD COLUMN coin_amount BIGINT UNSIGNED NULL AFTER payload_json'],
  ['fulfillment_tasks','generation','ALTER TABLE fulfillment_tasks ADD COLUMN generation INT UNSIGNED NOT NULL DEFAULT 0 AFTER code_index'],
  ['fulfillment_tasks','replacement_of_task_id','ALTER TABLE fulfillment_tasks ADD COLUMN replacement_of_task_id BIGINT UNSIGNED NULL'],
  ['fulfillment_tasks','created_by_user_id','ALTER TABLE fulfillment_tasks ADD COLUMN created_by_user_id BIGINT UNSIGNED NULL'],
  ['fulfillment_tasks','replacement_reason','ALTER TABLE fulfillment_tasks ADD COLUMN replacement_reason VARCHAR(500) NULL'],
  ['fulfillment_tasks','request_key','ALTER TABLE fulfillment_tasks ADD COLUMN request_key VARCHAR(100) NULL'],
  ['server_monitor_samples','rcon_ok','ALTER TABLE server_monitor_samples ADD COLUMN rcon_ok TINYINT(1) NULL AFTER status'],
  ['server_monitor_samples','process_cpu_percent','ALTER TABLE server_monitor_samples ADD COLUMN process_cpu_percent DECIMAL(6,2) NOT NULL DEFAULT 0 AFTER process_heap_used_bytes'],
  ['server_monitor_samples','worker_running','ALTER TABLE server_monitor_samples ADD COLUMN worker_running TINYINT(1) NOT NULL DEFAULT 0 AFTER process_heap_used_bytes'],
  ['player_presence_events','created_at','ALTER TABLE player_presence_events ADD COLUMN created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) AFTER sample_id'],
  ['maintenance_windows','countdown_marks_json','ALTER TABLE maintenance_windows ADD COLUMN countdown_marks_json JSON NULL AFTER fulfillment_paused'],
  ['maintenance_windows','announcement_template','ALTER TABLE maintenance_windows ADD COLUMN announcement_template VARCHAR(500) NULL AFTER countdown_marks_json'],
  ['maintenance_windows','recovery_success_threshold','ALTER TABLE maintenance_windows ADD COLUMN recovery_success_threshold INT NULL AFTER announcement_template'],
  ['maintenance_windows','awaiting_recovery_at','ALTER TABLE maintenance_windows ADD COLUMN awaiting_recovery_at DATETIME(3) NULL AFTER maintenance_started_at'],
  ['maintenance_windows','created_by','ALTER TABLE maintenance_windows ADD COLUMN created_by VARCHAR(100) NULL AFTER cancelled_at'],
  ['maintenance_windows','confirmed_by','ALTER TABLE maintenance_windows ADD COLUMN confirmed_by VARCHAR(100) NULL AFTER created_by'],
  ['maintenance_windows','cancelled_by','ALTER TABLE maintenance_windows ADD COLUMN cancelled_by VARCHAR(100) NULL AFTER confirmed_by'],
  ['maintenance_announcement_runs','id','ALTER TABLE maintenance_announcement_runs ADD COLUMN id BIGINT UNSIGNED AUTO_INCREMENT UNIQUE FIRST'],
  ['maintenance_announcement_runs','started_at','ALTER TABLE maintenance_announcement_runs ADD COLUMN started_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) AFTER last_error'],
  ['maintenance_audit_logs','actor','ALTER TABLE maintenance_audit_logs ADD COLUMN actor VARCHAR(100) NULL AFTER action'],
  ['player_admin_capability_probes','endpoint_identifier',"ALTER TABLE player_admin_capability_probes ADD COLUMN endpoint_identifier VARCHAR(500) NOT NULL DEFAULT 'legacy://unknown' AFTER mode"],
  ['player_admin_actions','confirmation',"ALTER TABLE player_admin_actions ADD COLUMN confirmation VARCHAR(100) NOT NULL DEFAULT 'legacy-confirmation' AFTER duration_minutes"],
  ['player_admin_actions','renderer_version',"ALTER TABLE player_admin_actions ADD COLUMN renderer_version VARCHAR(16) NOT NULL DEFAULT 'v1' AFTER status"],
  ['player_admin_actions','temporary_ban_expires_at','ALTER TABLE player_admin_actions ADD COLUMN temporary_ban_expires_at DATETIME(3) NULL AFTER unban_action_id'],
  ['player_admin_action_attempts','attempt_no','ALTER TABLE player_admin_action_attempts ADD COLUMN attempt_no INT UNSIGNED NOT NULL DEFAULT 1 AFTER action_id'],
  ['player_admin_action_attempts','uncertain_delivery','ALTER TABLE player_admin_action_attempts ADD COLUMN uncertain_delivery TINYINT(1) NOT NULL DEFAULT 0 AFTER status'],
  ['player_admin_action_attempts','response_summary','ALTER TABLE player_admin_action_attempts ADD COLUMN response_summary VARCHAR(500) NULL AFTER uncertain_delivery'],
  ['player_admin_action_attempts','error_summary','ALTER TABLE player_admin_action_attempts ADD COLUMN error_summary VARCHAR(500) NULL AFTER response_summary'],
  ['scum_log_files','source_type',"ALTER TABLE scum_log_files ADD COLUMN source_type VARCHAR(16) NOT NULL DEFAULT 'kill' AFTER id"],
  ['scum_log_files','cursor_probe_hash','ALTER TABLE scum_log_files ADD COLUMN cursor_probe_hash CHAR(64) NULL AFTER pending_position'],
  ['scum_log_files','cursor_probe_length','ALTER TABLE scum_log_files ADD COLUMN cursor_probe_length INT UNSIGNED NOT NULL DEFAULT 0 AFTER cursor_probe_hash'],
  ['scum_chat_events','event_hash','ALTER TABLE scum_chat_events ADD COLUMN event_hash CHAR(64) NULL AFTER line_hash'],
  ['stocks','deleted_at','ALTER TABLE stocks ADD COLUMN deleted_at DATETIME(3) NULL AFTER paused'],
  ['stocks','pricing_mode',"ALTER TABLE stocks ADD COLUMN pricing_mode VARCHAR(16) NOT NULL DEFAULT 'hybrid' AFTER deleted_at"],
  ['stocks','volume_metric',"ALTER TABLE stocks ADD COLUMN volume_metric VARCHAR(16) NOT NULL DEFAULT 'quantity' AFTER pricing_mode"],
  ['stocks','baseline_value','ALTER TABLE stocks ADD COLUMN baseline_value BIGINT UNSIGNED NOT NULL DEFAULT 1 AFTER volume_metric'],
  ['stocks','auto_volume_max','ALTER TABLE stocks ADD COLUMN auto_volume_max BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER baseline_value'],
  ['stocks','max_price','ALTER TABLE stocks ADD COLUMN max_price BIGINT UNSIGNED NULL AFTER min_price'],
  ['stocks','volume_sensitivity_bps','ALTER TABLE stocks ADD COLUMN volume_sensitivity_bps INT UNSIGNED NOT NULL DEFAULT 100 AFTER baseline_value'],
  ['stock_price_history','source',"ALTER TABLE stock_price_history ADD COLUMN source VARCHAR(16) NOT NULL DEFAULT 'automatic' AFTER stock_id"],
  ['stock_price_history','volume_quantity','ALTER TABLE stock_price_history ADD COLUMN volume_quantity BIGINT UNSIGNED NULL AFTER price_version'],
  ['stock_price_history','volume_amount','ALTER TABLE stock_price_history ADD COLUMN volume_amount BIGINT UNSIGNED NULL AFTER volume_quantity'],
  ['stock_price_history','simulated_volume_quantity','ALTER TABLE stock_price_history ADD COLUMN simulated_volume_quantity BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER volume_amount'],
  ['stock_price_history','simulated_volume_amount','ALTER TABLE stock_price_history ADD COLUMN simulated_volume_amount BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER simulated_volume_quantity'],
  ['stock_price_history','baseline_value','ALTER TABLE stock_price_history ADD COLUMN baseline_value BIGINT UNSIGNED NULL AFTER volume_amount'],
  ['stock_price_history','volume_change_bps','ALTER TABLE stock_price_history ADD COLUMN volume_change_bps INT NULL AFTER baseline_value'],
  ['stock_price_history','simulated_volume_change_bps','ALTER TABLE stock_price_history ADD COLUMN simulated_volume_change_bps INT NULL AFTER volume_change_bps'],
  ['stock_price_history','random_change_bps','ALTER TABLE stock_price_history ADD COLUMN random_change_bps INT NULL AFTER volume_change_bps'],
  ['stock_price_history','actor_user_id','ALTER TABLE stock_price_history ADD COLUMN actor_user_id BIGINT UNSIGNED NULL AFTER random_change_bps'],
  ['stock_price_history','actor_username_snapshot','ALTER TABLE stock_price_history ADD COLUMN actor_username_snapshot VARCHAR(100) NULL AFTER actor_user_id'],
  ['stock_price_history','reason','ALTER TABLE stock_price_history ADD COLUMN reason VARCHAR(500) NULL AFTER actor_username_snapshot'],
  ['stock_price_history','request_key','ALTER TABLE stock_price_history ADD COLUMN request_key VARCHAR(100) NULL AFTER reason']
];

const tableCategoryRules = [
  ['系统与配置', ['系统配置','数据表目录','schema_comments','bootstrap_states']],
  ['玩家与会员', ['商城用户','shop_sessions','steam_bind_challenges','membership_change_logs','membership_strategies','player_titles','character_growth_purchases','account_exchanges']],
  ['保险管理', ['载具档案','载具保险销售策略','载具保险','载具保险购买记录','载具保险索赔记录','载具操作审计']],
  ['传送管理', ['传送管理设置','传送固定位置','传送执行记录','传送位置快照']],
  ['历史兼容数据', ['玩家传送同意请求']],
  ['商品与订单', ['products','orders','order_items','coin_ledger','fulfillment_tasks','fulfillment_attempts']],
  ['礼包与兑换', ['gift_packages','gift_actions','gift_claims','redeem_codes','redeem_code_actions','redeem_code_claims']],
  ['活动与抽奖', ['activities','activity_gifts','activity_lottery_pools','activity_gift_claims','lottery_pools','lottery_pool_versions','lottery_prizes','lottery_player_states','lottery_batches','lottery_draws','lottery_fulfillment_logs']],
  ['签到与奖励', ['reward_rules','reward_requests','reward_claims','player_checkins','player_online_totals','player_online_accruals']],
  ['股票与云储', ['stocks','stock_volume_bindings','stock_price_history','stock_holdings','stock_trades','stock_watchlists','stock_market_announcements','cloud_inventory_batches','cloud_market_listings','cloud_market_trades']],
  ['监控与运维', ['scheduled_announcement_runs','server_monitor_samples','online_player_snapshots','player_presence_events','maintenance_windows','maintenance_announcement_runs','maintenance_audit_logs','player_admin_capability_probes','player_admin_actions','player_admin_action_attempts','player_admin_verifications']],
  ['游戏日志', ['scum_log_files','scum_kill_events','scum_log_parse_failures','scum_chat_events','scum_chat_claim_audits', ...SCUM_LOG_TABLES.map(({ table }) => table)]],
  ['权限与审计', ['admin_role_audits']]
];

function tableCategory(table) {
  return tableCategoryRules.find(([, tables]) => tables.includes(table))?.[0] || '其他数据';
}

const views = [
  ['数据库功能目录', 'SELECT category_name AS `功能分类`, chinese_name AS `中文表名`, physical_name AS `物理表名`, purpose AS `功能说明`, object_type AS `对象类型` FROM `数据表目录`'],
  ['系统配置总览', 'SELECT setting_key AS `配置键`, background_image AS `网站背景图`, attribute_point_price AS `属性点单价`, skill_level_price AS `技能等级单价`, cloud_market_enabled AS `云储市场启用`, cloud_fee_bps AS `云储手续费基点`, cloud_daily_base_quota AS `云储每日基础额度`, updated_at AS `更新时间` FROM `系统配置`'],
  ['传送载具位置', 'SELECT `载具档案编号`, `车主SteamID` AS `归属SteamID`, COALESCE(NULLIF(`显示名称`,\'\'),NULLIF(`型号名称`,\'\'),`载具类型`) AS `显示名称`, `车牌号`, `世界X坐标`, `世界Y坐标`, `世界Z坐标`, `地图X百分比`, `地图Y百分比`, `位置来源`, `最后观测时间`, `档案状态`, `更新时间` FROM `载具档案` WHERE `车主SteamID` IS NOT NULL'], 
  ['玩家综合资料', 'SELECT `SteamID`, `登录账号` AS `用户名`, `游戏名称`, `账户状态`, `会员等级`, `会员到期时间`, `商城币余额`, `游戏币`, `游戏金条` AS `金条`, `最后游戏在线时间`, COALESCE(`最后游戏在线时间`,`最后登录时间`,`商城账户创建时间`) AS `更新时间` FROM `商城用户`'],
  ['订单履约总览', 'SELECT o.id AS `订单编号`, o.order_no AS `订单号`, o.source AS `订单来源`, o.steam_id AS `SteamID`, o.total_amount AS `订单金额`, o.status AS `订单状态`, (SELECT COUNT(*) FROM order_items i WHERE i.order_id=o.id) AS `明细数量`, (SELECT COALESCE(SUM(i.quantity),0) FROM order_items i WHERE i.order_id=o.id) AS `商品总数`, (SELECT COUNT(*) FROM fulfillment_tasks t WHERE t.order_id=o.id) AS `发货任务数`, (SELECT COUNT(*) FROM fulfillment_tasks t WHERE t.order_id=o.id AND t.status IN (\'completed\',\'succeeded\')) AS `发货成功数`, (SELECT COUNT(*) FROM fulfillment_tasks t WHERE t.order_id=o.id AND t.status IN (\'failed\',\'uncertain\')) AS `发货异常数`, o.created_at AS `创建时间`, o.updated_at AS `更新时间` FROM orders o'],
  ['抽奖履约总览', 'SELECT b.id AS `抽奖批次`, b.steam_id AS `SteamID`, b.pool_id AS `奖池编号`, p.name AS `奖池名称`, b.draw_count AS `抽取次数`, b.price_paid AS `实付金额`, (SELECT COUNT(*) FROM lottery_draws d WHERE d.batch_id=b.id) AS `中奖结果数`, (SELECT COUNT(*) FROM lottery_fulfillment_logs l WHERE l.lottery_batch_id=b.id) AS `发货记录数`, (SELECT COUNT(*) FROM lottery_fulfillment_logs l WHERE l.lottery_batch_id=b.id AND l.status IN (\'completed\',\'succeeded\')) AS `发货成功数`, (SELECT COUNT(*) FROM lottery_fulfillment_logs l WHERE l.lottery_batch_id=b.id AND l.status IN (\'failed\',\'uncertain\')) AS `发货异常数`, b.created_at AS `抽奖时间` FROM lottery_batches b JOIN lottery_pools p ON p.id=b.pool_id'],
  ['云储交易总览', 'SELECT l.id AS `挂单编号`, l.seller_steam_id AS `卖家SteamID`, l.item_code AS `物品代码`, l.item_name AS `物品名称`, l.quantity AS `挂单数量`, l.remaining_quantity AS `剩余数量`, l.unit_price AS `单价`, l.status AS `挂单状态`, COUNT(t.id) AS `成交笔数`, COALESCE(SUM(t.quantity),0) AS `成交数量`, COALESCE(SUM(t.gross_amount),0) AS `成交总额`, l.created_at AS `创建时间`, l.updated_at AS `更新时间` FROM cloud_market_listings l LEFT JOIN cloud_market_trades t ON t.listing_id=l.id GROUP BY l.id,l.seller_steam_id,l.item_code,l.item_name,l.quantity,l.remaining_quantity,l.unit_price,l.status,l.created_at,l.updated_at'],
  ['角色属性技能购买记录', 'SELECT id AS `记录编号`, steam_id AS `SteamID`, purchase_type AS `购买类型`, quantity AS `数量`, unit_price AS `单价`, total_price AS `总价`, balance_after AS `购买后余额`, status AS `状态`, error_message AS `错误信息`, completed_at AS `完成时间`, created_at AS `创建时间` FROM character_growth_purchases'],
  ['账户资产兑换记录', 'SELECT id AS `记录编号`, steam_id AS `SteamID`, direction AS `兑换方向`, input_amount AS `输入数量`, output_amount AS `输出数量`, rate_snapshot AS `兑换比例`, coin_delta AS `商城币变动`, gold_delta AS `金条变动`, status AS `状态`, error_message AS `错误信息`, created_at AS `创建时间`, completed_at AS `完成时间` FROM account_exchanges'],
  ['会员策略', 'SELECT level AS `会员等级`, title AS `会员称号`, opening_amount AS `开通金额`, period_days AS `有效天数`, gift_tokens AS `赠送代币`, upgrade_spend AS `升级消费门槛`, teleport_discount AS `传送折扣`, online_bonus AS `在线加成`, shopping_discount AS `购物折扣`, gift_discount AS `礼包折扣`, recharge_bonus AS `充值加成`, daily_teleports AS `每日传送次数`, checkin_bonus AS `签到奖励`, enabled AS `启用`, updated_at AS `更新时间` FROM membership_strategies'],
  ['玩家抽奖状态', 'SELECT pool_id AS `奖池编号`, steam_id AS `SteamID`, pity_count AS `保底计数`, free_day AS `免费抽取日期`, free_used AS `已用免费次数`, updated_at AS `更新时间` FROM lottery_player_states'],
  ['抽奖发货记录', 'SELECT id AS `记录编号`, lottery_batch_id AS `抽奖批次`, lottery_draw_id AS `抽奖结果`, order_id AS `订单编号`, fulfillment_task_id AS `发货任务`, steam_id AS `SteamID`, pool_id AS `奖池编号`, pool_name_snapshot AS `奖池名称`, reward_type AS `奖励类型`, reward_name_snapshot AS `奖励名称`, task_type AS `任务类型`, status AS `状态`, error_summary AS `错误摘要`, created_at AS `创建时间`, updated_at AS `更新时间` FROM lottery_fulfillment_logs'],
  ['云储库存批次', 'SELECT id AS `库存编号`, steam_id AS `SteamID`, item_code AS `物品代码`, item_name AS `物品名称`, quantity AS `数量`, reserved_quantity AS `预留数量`, status AS `状态`, created_at AS `创建时间`, updated_at AS `更新时间` FROM cloud_inventory_batches'],
  ['云储市场挂单', 'SELECT id AS `挂单编号`, inventory_id AS `库存编号`, seller_steam_id AS `卖家SteamID`, item_code AS `物品代码`, item_name AS `物品名称`, quantity AS `挂单数量`, remaining_quantity AS `剩余数量`, unit_price AS `单价`, fee_bps AS `手续费基点`, status AS `状态`, created_at AS `创建时间`, updated_at AS `更新时间` FROM cloud_market_listings'],
  ['云储市场成交记录', 'SELECT id AS `成交编号`, listing_id AS `挂单编号`, seller_steam_id AS `卖家SteamID`, buyer_steam_id AS `买家SteamID`, item_code AS `物品代码`, item_name AS `物品名称`, quantity AS `数量`, unit_price AS `单价`, gross_amount AS `成交总额`, fee AS `手续费`, seller_net AS `卖家实收`, buyer_balance_after AS `买家余额`, seller_balance_after AS `卖家余额`, created_at AS `成交时间` FROM cloud_market_trades'],
  ['玩家账户', 'SELECT `SteamID`, `商城币余额`, `商城账户创建时间` AS `创建时间`, `最后游戏在线时间` AS `更新时间` FROM `商城用户` WHERE `SteamID` IS NOT NULL'],

  ['会员变更记录', 'SELECT id AS `记录编号`, steam_id AS `SteamID`, old_level AS `变更前等级`, new_level AS `变更后等级`, old_expires_at AS `变更前到期时间`, new_expires_at AS `变更后到期时间`, reason AS `操作原因`, operator AS `操作者`, created_at AS `操作时间` FROM membership_change_logs'],
  ['管理员角色审计', 'SELECT id AS `审计编号`, actor_user_id AS `操作管理员编号`, actor_type AS `操作来源`, actor_label AS `操作标识`, actor_username_snapshot AS `操作管理员`, target_user_id AS `目标用户编号`, target_username_snapshot AS `目标用户名`, target_steam_id AS `目标SteamID`, old_role AS `原角色`, new_role AS `新角色`, reason AS `原因`, created_at AS `操作时间` FROM admin_role_audits'],
  ['商城币流水', 'SELECT id AS `流水编号`, steam_id AS `SteamID`, amount AS `变动金额`, balance_after AS `变动后余额`, type AS `类型`, reference_type AS `关联类型`, reference_id AS `关联编号`, note AS `备注`, created_at AS `创建时间` FROM coin_ledger'],
  ['商品', 'SELECT id AS `商品编号`, sku AS `SKU`, name AS `商品名称`, price AS `价格`, parent_category AS `父分类`, category_name AS `分类`, currency_type AS `货币类型`, min_member_level AS `会员等级要求`, image_path AS `图片路径`, enabled AS `启用`, created_at AS `创建时间`, updated_at AS `更新时间` FROM products'],
  ['礼包', 'SELECT id AS `礼包编号`, name AS `礼包名称`, gift_type AS `礼包类型`, description AS `说明`, enabled AS `启用`, target_steam_id AS `目标SteamID`, required_title AS `指定称号`, member_level AS `会员等级`, member_mode AS `会员模式`, total_limit AS `总次数`, daily_limit AS `每日次数`, period_limit AS `周期次数`, price AS `价格`, created_at AS `创建时间`, updated_at AS `更新时间` FROM gift_packages'],
  ['礼包动作', 'SELECT id AS `动作编号`, gift_id AS `礼包编号`, action_index AS `动作序号`, action_type AS `动作类型`, product_id AS `关联商品编号`, quantity AS `数量`, coin_amount AS `商城币数量`, created_at AS `创建时间` FROM gift_actions'],
  ['礼包领取记录', 'SELECT id AS `领取编号`, gift_id AS `礼包编号`, steam_id AS `SteamID`, order_id AS `订单编号`, claim_period_key AS `周期键`, claim_day AS `领取日期`, price_paid AS `实付价格`, created_at AS `创建时间` FROM gift_claims'],
  ['兑换码', "SELECT id AS `兑换码编号`, name AS `名称`, CASE WHEN code_hint IS NULL OR code_hint='' THEN NULL ELSE CONCAT('****',code_hint) END AS `掩码提示`, code_type AS `类型`, enabled AS `启用`, member_level AS `会员等级`, member_mode AS `会员模式`, total_limit AS `总次数限制`, per_user_limit AS `单用户次数限制`, used_count AS `已使用次数`, starts_at AS `开始时间`, expires_at AS `过期时间`, created_at AS `创建时间`, updated_at AS `更新时间` FROM redeem_codes"],
  ['兑换码动作', 'SELECT id AS `动作编号`, redeem_code_id AS `兑换码编号`, action_index AS `动作序号`, action_type AS `动作类型`, quantity AS `数量`, coin_amount AS `商城币数量`, created_at AS `创建时间` FROM redeem_code_actions'],
  ['兑换码领取记录', 'SELECT id AS `领取编号`, redeem_code_id AS `兑换码编号`, steam_id AS `SteamID`, order_id AS `订单编号`, claim_day AS `领取日期`, created_at AS `创建时间` FROM redeem_code_claims'],
  ['玩家称号', 'SELECT steam_id AS `SteamID`, title_name AS `称号`, expires_at AS `过期时间`, created_at AS `创建时间`, updated_at AS `更新时间` FROM player_titles'],
  ['玩家小队', 'SELECT `SteamID`,`小队编号`,`小队名称`,`小队更新时间` AS `更新时间` FROM `商城用户` WHERE `小队编号` IS NOT NULL'],
  ['订单', 'SELECT id AS `订单编号`, order_no AS `订单号`, source AS `来源`, steam_id AS `SteamID`, gift_id AS `礼包编号`, gift_claim_id AS `礼包领取编号`, redeem_code_id AS `兑换码编号`, redeem_claim_id AS `兑换领取编号`, total_amount AS `金额`, status AS `状态`, created_at AS `创建时间`, updated_at AS `更新时间` FROM orders'],
  ['订单明细', 'SELECT id AS `明细编号`, order_id AS `订单编号`, product_id AS `商品编号`, sku AS `SKU快照`, name AS `名称快照`, unit_price AS `单价`, quantity AS `数量`, parent_category AS `父分类`, category_name AS `分类`, currency_type AS `货币类型`, min_member_level AS `会员等级要求`, image_path AS `图片路径` FROM order_items'],
  ['发货任务', 'SELECT id AS `任务编号`, order_id AS `订单编号`, order_item_id AS `订单明细编号`, steam_id AS `SteamID`, task_type AS `任务类型`, amount AS `数量`, coin_amount AS `商城币数量`, status AS `状态`, attempts AS `尝试次数`, last_error AS `最后错误`, created_at AS `创建时间`, updated_at AS `更新时间` FROM fulfillment_tasks'],
  ['发货尝试记录', 'SELECT id AS `记录编号`, task_id AS `任务编号`, attempt_no AS `尝试序号`, status AS `状态`, message AS `结果`, created_at AS `创建时间` FROM fulfillment_attempts'],
  ['定时公告执行记录', 'SELECT id AS `记录编号`, announcement_id AS `公告编号`, scheduled_for AS `计划时间`, status AS `状态`, sent_count AS `成功数`, failed_count AS `失败数`, last_error AS `最后错误`, started_at AS `开始时间`, completed_at AS `完成时间` FROM scheduled_announcement_runs'],
  ['服务器监控采样', 'SELECT id AS `采样编号`, sampled_at AS `采样时间`, status AS `状态`, rcon_ok AS `RCON正常`, player_query_ok AS `玩家查询成功`, online_count AS `在线人数`, rcon_latency_ms AS `查询延迟毫秒`, process_uptime_sec AS `进程运行秒数`, process_rss_bytes AS `进程内存字节`, process_heap_used_bytes AS `堆内存字节`, process_cpu_percent AS `CPU占用百分比`, worker_running AS `发货Worker运行中`, error_code AS `错误代码`, error_message AS `错误信息`, created_at AS `创建时间` FROM server_monitor_samples'],
  ['在线玩家快照', 'SELECT sample_id AS `采样编号`, steam_id AS `SteamID`, character_name AS `角色名`, steam_name AS `Steam名称`, is_admin AS `管理员`, observed_at AS `观测时间` FROM online_player_snapshots'],
  ['玩家上下线记录', 'SELECT id AS `记录编号`, steam_id AS `SteamID`, event_type AS `事件类型`, character_name AS `角色名`, steam_name AS `Steam名称`, is_admin AS `管理员`, observed_at AS `观测时间`, sample_id AS `采样编号` FROM player_presence_events'],
  ['维护窗口', 'SELECT id AS `维护编号`, instance_id AS `实例快照`, title AS `标题`, reason AS `原因`, scheduled_at AS `计划时间`, state AS `状态`, fulfillment_paused AS `发货暂停`, pause_started_at AS `暂停开始`, maintenance_started_at AS `维护开始`, recovery_ready_at AS `恢复就绪`, completed_at AS `完成时间`, cancelled_at AS `取消时间`, created_by AS `创建者`, confirmed_by AS `确认者`, cancelled_by AS `取消者`, created_at AS `创建时间`, updated_at AS `更新时间` FROM maintenance_windows'],
  ['维护公告执行记录', 'SELECT id AS `记录编号`, maintenance_id AS `维护编号`, minute_mark AS `分钟节点`, scheduled_for AS `计划时间`, status AS `状态`, sent_count AS `成功数`, failed_count AS `失败数`, last_error AS `最后错误`, started_at AS `开始时间`, completed_at AS `完成时间` FROM maintenance_announcement_runs'],
  ['维护操作记录', 'SELECT id AS `记录编号`, maintenance_id AS `维护编号`, action AS `动作`, actor AS `操作人`, created_at AS `创建时间` FROM maintenance_audit_logs'],
  ['奖励规则', 'SELECT r.id AS `规则编号`, r.rule_type AS `规则类型`, r.threshold_value AS `奖励门槛`, r.reward_type AS `奖励类型`, r.gift_id AS `礼包编号`, g.name AS `礼包名称`, r.product_id AS `商品编号`, p.name AS `商品名称`, r.coin_amount AS `商城币数量`, r.enabled AS `启用`, r.created_by_user_id AS `创建管理员编号`, u.`登录账号` AS `创建管理员`, r.created_at AS `创建时间`, r.updated_at AS `更新时间` FROM reward_rules r LEFT JOIN gift_packages g ON g.id=r.gift_id LEFT JOIN products p ON p.id=r.product_id LEFT JOIN `商城用户` u ON u.`商城用户编号`=r.created_by_user_id'],
  ['玩家签到记录', 'SELECT id AS `签到编号`, steam_id AS `SteamID`, checkin_day AS `上海签到日期`, streak_days AS `连续签到天数`, total_days AS `累计签到天数`, created_at AS `签到时间` FROM player_checkins'],
  ['玩家在线时长', 'SELECT steam_id AS `SteamID`, total_seconds AS `累计在线秒数`, updated_at AS `更新时间` FROM player_online_totals'],
  ['在线时长累计明细', 'SELECT a.sample_id AS `采样编号`, a.steam_id AS `SteamID`, a.previous_sample_id AS `前次采样编号`, a.credited_seconds AS `计入秒数`, p.sampled_at AS `前次采样时间`, s.sampled_at AS `本次采样时间`, a.created_at AS `创建时间` FROM player_online_accruals a JOIN server_monitor_samples p ON p.id=a.previous_sample_id JOIN server_monitor_samples s ON s.id=a.sample_id'],
  ['奖励领取记录', 'SELECT c.id AS `领取编号`, c.steam_id AS `SteamID`, c.rule_id AS `规则编号`, r.rule_type AS `规则类型`, c.checkin_id AS `签到编号`, c.sample_id AS `采样编号`, c.gift_id AS `礼包编号`, g.name AS `礼包名称`, c.product_id AS `商品编号`, p.name AS `商品名称`, c.coin_amount AS `商城币数量`, c.order_id AS `订单编号`, c.created_at AS `创建时间` FROM reward_claims c JOIN reward_rules r ON r.id=c.rule_id LEFT JOIN gift_packages g ON g.id=c.gift_id LEFT JOIN products p ON p.id=c.product_id'],
  ['活动', 'SELECT a.id AS `活动编号`, a.name AS `名称`, a.description AS `说明`, a.starts_at AS `开始时间`, a.ends_at AS `结束时间`, a.enabled AS `启用`, u.`登录账号` AS `创建管理员`, a.created_at AS `创建时间`, a.updated_at AS `更新时间` FROM activities a JOIN `商城用户` u ON u.`商城用户编号`=a.created_by_user_id'],
  ['活动礼包关联', 'SELECT ag.activity_id AS `活动编号`, a.name AS `活动名称`, ag.gift_id AS `礼包编号`, g.name AS `礼包名称`, ag.created_at AS `关联时间` FROM activity_gifts ag JOIN activities a ON a.id=ag.activity_id JOIN gift_packages g ON g.id=ag.gift_id'],
  ['活动奖池关联', 'SELECT ap.activity_id AS `活动编号`, a.name AS `活动名称`, ap.pool_id AS `奖池编号`, p.name AS `奖池名称`, ap.created_at AS `关联时间` FROM activity_lottery_pools ap JOIN activities a ON a.id=ap.activity_id JOIN lottery_pools p ON p.id=ap.pool_id'],
  ['活动礼包领取记录', 'SELECT c.id AS `记录编号`, c.activity_id AS `活动编号`, c.gift_id AS `礼包编号`, c.gift_claim_id AS `礼包领取编号`, c.steam_id AS `SteamID`, c.created_at AS `领取时间` FROM activity_gift_claims c'],
  ['抽奖池', 'SELECT p.id AS `奖池编号`, p.name AS `名称`, p.description AS `说明`, p.image_path AS `图片路径`, p.currency_type AS `抽奖货币`, p.single_price AS `单抽金额`, p.starts_at AS `开始时间`, p.ends_at AS `结束时间`, p.enabled AS `启用`, p.current_version_id AS `当前版本编号`, p.created_at AS `创建时间`, p.updated_at AS `更新时间` FROM lottery_pools p'],
  ['抽奖池版本', 'SELECT v.id AS `版本编号`, v.pool_id AS `奖池编号`, v.version_no AS `版本号`, v.single_price AS `单抽价格`, v.daily_free_count AS `每日免费次数`, v.pity_threshold AS `保底阈值`, v.created_at AS `创建时间` FROM lottery_pool_versions v'],
  ['抽奖奖项', 'SELECT p.id AS `奖项编号`, p.version_id AS `版本编号`, p.prize_index AS `奖项序号`, p.reward_type AS `奖励类型`, p.gift_id AS `礼包编号`, p.product_id AS `商品编号`, p.reward_name_snapshot AS `奖励名称快照`, p.weight AS `权重`, p.rarity AS `稀有度`, p.label AS `标签`, p.is_pity AS `保底奖项`, p.created_at AS `创建时间` FROM lottery_prizes p'],
  ['抽奖批次', 'SELECT b.id AS `批次编号`, b.steam_id AS `SteamID`, b.pool_id AS `奖池编号`, b.version_id AS `版本编号`, b.draw_count AS `抽数`, b.free_count AS `免费抽数`, b.paid_count AS `付费抽数`, b.price_paid AS `实付商城币`, b.balance_before AS `抽奖前余额`, b.balance_after AS `抽奖后余额`, b.pity_before AS `抽奖前保底计数`, b.pity_after AS `抽奖后保底计数`, b.order_id AS `订单编号`, b.created_at AS `抽奖时间` FROM lottery_batches b'],
  ['抽奖结果', 'SELECT d.id AS `结果编号`, d.batch_id AS `批次编号`, d.draw_index AS `抽序号`, d.reward_type AS `奖励类型`, d.gift_id AS `礼包编号`, d.reward_name_snapshot AS `奖励名称快照`, d.weight_snapshot AS `权重快照`, d.total_weight_snapshot AS `总权重快照`, d.rarity_snapshot AS `稀有度快照`, d.label_snapshot AS `标签快照`, d.is_pity_snapshot AS `保底奖项`, d.forced_pity AS `触发保底`, d.pity_before AS `抽前计数`, d.pity_after AS `抽后计数`, d.created_at AS `创建时间` FROM lottery_draws d'],
  ['股票标的', 'SELECT s.id AS `股票编号`, s.code AS `代码`, s.name AS `名称`, s.description AS `说明`, s.current_price AS `当前价格`, s.base_price AS `基准价格`, s.enabled AS `启用`, s.paused AS `暂停`, s.pricing_mode AS `定价模式`, s.volume_metric AS `成交指标`, s.baseline_value AS `成交基线`, s.volume_sensitivity_bps AS `成交敏感度基点`, s.volatility_bps AS `随机扰动基点`, s.max_change_bps AS `周期最大涨跌基点`, s.min_price AS `最低价`, s.fee_bps AS `手续费基点`, s.period_seconds AS `周期秒数`, s.price_version AS `价格版本`, s.created_at AS `创建时间`, s.updated_at AS `更新时间` FROM stocks s'],
  ['股票成交绑定', 'SELECT b.id AS `绑定编号`, b.stock_id AS `股票编号`, b.binding_type AS `绑定类型`, b.product_id AS `商品编号`, b.product_sku AS `SKU快照`, b.parent_category AS `父分类`, b.category_name AS `分类`, b.weight_bps AS `权重基点`, b.enabled AS `启用`, b.updated_at AS `更新时间` FROM stock_volume_bindings b'],
  ['股票价格历史', 'SELECT h.id AS `记录编号`, h.stock_id AS `股票编号`, h.source AS `来源`, h.period_key AS `周期键`, h.price_before AS `变动前价格`, h.price_after AS `变动后价格`, h.change_bps AS `涨跌基点`, h.price_version AS `价格版本`, h.volume_quantity AS `成交件数`, h.volume_amount AS `成交金额`, h.baseline_value AS `成交基线`, h.volume_change_bps AS `成交信号基点`, h.random_change_bps AS `随机信号基点`, h.actor_username_snapshot AS `操作管理员`, h.reason AS `原因`, h.priced_at AS `定价时间` FROM stock_price_history h'],
  ['股票自选', 'SELECT w.steam_id AS `SteamID`, w.stock_id AS `股票编号`, w.created_at AS `加入时间` FROM stock_watchlists w'],
  ['股市公告', 'SELECT a.id AS `公告编号`, a.title AS `标题`, a.content AS `内容`, a.enabled AS `启用`, a.starts_at AS `开始时间`, a.ends_at AS `结束时间`, a.created_at AS `创建时间`, a.updated_at AS `更新时间` FROM stock_market_announcements a'],
  ['玩家持仓', 'SELECT h.stock_id AS `股票编号`, h.steam_id AS `SteamID`, h.quantity AS `持仓数量`, h.average_cost AS `平均成本`, h.updated_at AS `更新时间` FROM stock_holdings h'],
  ['股票交易记录', 'SELECT t.id AS `交易编号`, t.steam_id AS `SteamID`, t.stock_id AS `股票编号`, t.direction AS `方向`, t.quantity AS `数量`, t.price AS `成交价`, t.fee AS `手续费`, t.gross_amount AS `成交总额`, t.net_amount AS `结算金额`, t.balance_before AS `交易前余额`, t.balance_after AS `交易后余额`, t.holding_before AS `交易前持仓`, t.holding_after AS `交易后持仓`, t.average_cost_before AS `交易前平均成本`, t.average_cost_after AS `交易后平均成本`, t.price_version AS `价格版本`, t.price_time_snapshot AS `报价时间`, t.created_at AS `交易时间` FROM stock_trades t'],
  ['玩家管理能力探测', 'SELECT id AS `探测编号`, mode AS `RCON模式`, probed_at AS `探测时间`, response_summary AS `响应摘要`, kick_supported AS `踢出可用`, ban_supported AS `永久封禁可用`, unban_supported AS `解封可用`, error_code AS `错误代码`, error_message AS `错误信息` FROM player_admin_capability_probes'],
  ['玩家管理操作记录', 'SELECT a.id AS `操作编号`, a.action_type AS `动作`, a.target_steam_id AS `SteamID`, a.target_name_snapshot AS `目标名称`, a.admin_user_id AS `管理员编号`, a.admin_username_snapshot AS `管理员`, a.reason AS `原因`, a.duration_minutes AS `时长分钟`, a.status AS `状态`, a.parent_action_id AS `父操作编号`, a.unban_action_id AS `解封操作编号`, a.temporary_ban_expires_at AS `临时封禁到期时间`, a.dispatched_at AS `发送时间`, a.completed_at AS `完成时间`, a.result_code AS `结果代码`, a.error_code AS `错误代码`, a.response_summary AS `响应摘要`, a.created_at AS `创建时间`, a.updated_at AS `更新时间` FROM player_admin_actions a'],
  ['玩家管理投递记录', 'SELECT id AS `记录编号`, action_id AS `操作编号`, attempt_no AS `尝试序号`, event_type AS `事件类型`, status AS `状态`, uncertain_delivery AS `投递不确定`, response_summary AS `响应摘要`, error_summary AS `错误摘要`, actor_user_id AS `核查管理员编号`, actor_username_snapshot AS `核查管理员`, created_at AS `创建时间` FROM player_admin_action_attempts'],
  ['玩家管理人工核查', 'SELECT id AS `核查编号`, action_id AS `操作编号`, admin_user_id AS `管理员编号`, admin_username_snapshot AS `管理员`, result AS `核查结果`, note AS `核查说明`, created_at AS `核查时间` FROM player_admin_verifications'],
  ['SCUM日志文件状态', 'SELECT id AS `文件编号`, source_type AS `来源类型`, basename AS `文件名`, offset_bytes AS `读取偏移`, size_bytes AS `文件大小`, encoding AS `编码`, rotation_count AS `轮转次数`, truncation_count AS `截断次数`, last_status AS `最后状态`, last_error AS `最后错误`, last_processed_at AS `最后处理时间`, updated_at AS `更新时间` FROM scum_log_files'],
  ['SCUM击杀事件', 'SELECT id AS `事件编号`, event_time AS `事件时间`, killer_steam_id AS `击杀者SteamID`, killer_name AS `击杀者名称`, victim_steam_id AS `受害者SteamID`, victim_name AS `受害者名称`, weapon AS `武器`, distance_meters AS `距离米`, event_type AS `事件类型`, source_file_id AS `来源文件编号`, source_position AS `来源位置`, parser_version AS `解析器版本`, created_at AS `入库时间` FROM scum_kill_events'],
  ['SCUM日志解析失败', 'SELECT id AS `记录编号`, source_file_id AS `来源文件编号`, source_position AS `来源位置`, reason AS `原因`, preview AS `脱敏预览`, created_at AS `记录时间` FROM scum_log_parse_failures'],
  ['SCUM聊天事件', 'SELECT id AS `事件编号`, event_time AS `事件时间`, steam_id AS `SteamID`, player_name AS `玩家名`, character_number AS `角色编号`, channel AS `频道`, parse_status AS `解析状态`, command_type AS `命令类型`, command_target AS `命令目标`, source_file_id AS `来源文件编号`, source_position AS `来源位置`, parser_version AS `解析器版本`, created_at AS `入库时间` FROM scum_chat_events'],
  ['SCUM聊天领取审计', 'SELECT id AS `审计编号`, event_id AS `聊天事件编号`, command_type AS `命令类型`, command_target AS `命令目标`, result AS `处理结果`, gift_id AS `礼包编号`, gift_claim_id AS `礼包领取编号`, order_id AS `订单编号`, error_code AS `错误代码`, error_message AS `脱敏错误`, processed_at AS `处理时间` FROM scum_chat_claim_audits']
];

async function hasColumn(db, table, column) {
  const rows = await db.query('SELECT COUNT(*) AS count FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?', [table, column]);
  return Number(rows[0]?.count) > 0;
}
async function columnIsNullable(db, table, column) {
  const rows = await db.query('SELECT is_nullable AS isNullable FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ? LIMIT 1', [table, column]);
  return String(rows[0]?.isNullable || '').toUpperCase() === 'YES';
}
async function columnIsInvisible(db, table, column) {
  const rows = await db.query('SELECT extra FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ? LIMIT 1', [table, column]);
  return String(rows[0]?.extra || '').toUpperCase().split(/\s+/).includes('INVISIBLE');
}
async function columnCharacterLength(db, table, column) {
  const rows = await db.query('SELECT character_maximum_length AS characterLength FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ? LIMIT 1', [table, column]);
  const length = Number(rows[0]?.characterLength);
  return Number.isFinite(length) ? length : null;
}
async function hasTable(db, table) {
  const rows = await db.query('SELECT COUNT(*) AS count FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ? AND table_type = ?', [table, 'BASE TABLE']);
  return Array.isArray(rows) && Number(rows[0]?.count) > 0;
}
async function hasView(db, view) {
  const rows = await db.query('SELECT COUNT(*) AS count FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ? AND table_type = ?', [view, 'VIEW']);
  return Array.isArray(rows) && Number(rows[0]?.count) > 0;
}
async function hasIndex(db, table, name) {
  const rows = await db.query('SELECT COUNT(*) AS count FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = ? AND index_name = ?', [table, name]);
  return Number(rows[0]?.count) > 0;
}
async function hasForeignKey(db, table, name) {
  const rows = await db.query('SELECT COUNT(*) AS count FROM information_schema.referential_constraints WHERE constraint_schema = DATABASE() AND table_name = ? AND constraint_name = ?', [table, name]);
  return Number(rows[0]?.count) > 0;
}
async function hasConstraint(db, table, name) {
  const rows = await db.query('SELECT COUNT(*) AS count FROM information_schema.table_constraints WHERE constraint_schema = DATABASE() AND table_name = ? AND constraint_name = ?', [table, name]);
  return Number(rows[0]?.count) > 0;
}
async function checkConstraintClause(db, name) {
  const rows = await db.query('SELECT check_clause AS checkClause FROM information_schema.check_constraints WHERE constraint_schema = DATABASE() AND constraint_name = ?', [name]);
  return String(rows[0]?.checkClause || '');
}
async function migrateNullableUserReference(db, table, column, foreignKey) {
  await db.query(`ALTER TABLE \`${table}\` MODIFY COLUMN \`${column}\` BIGINT UNSIGNED NULL`);
  const current = await db.query('SELECT delete_rule AS deleteRule FROM information_schema.referential_constraints WHERE constraint_schema=DATABASE() AND table_name=? AND constraint_name=?', [table, foreignKey]);
  if (current[0] && current[0].deleteRule !== 'SET NULL') await db.query(`ALTER TABLE \`${table}\` DROP FOREIGN KEY \`${foreignKey}\``);
  if (!(await hasForeignKey(db, table, foreignKey))) await db.query(`ALTER TABLE \`${table}\` ADD CONSTRAINT \`${foreignKey}\` FOREIGN KEY (\`${column}\`) REFERENCES \`商城用户\`(\`商城用户编号\`) ON DELETE SET NULL`);
}

function quoteIdentifier(identifier) {
  if (!identifier || String(identifier).includes('`')) throw new Error(`Invalid schema identifier: ${identifier}`);
  return `\`${identifier}\``;
}

function quoteComment(comment) {
  return `'${String(comment).replaceAll("'", "''")}'`;
}

function columnDefinitionFromCreateTable(createSql, column) {
  const body = createSql.slice(createSql.indexOf('(') + 1, createSql.lastIndexOf(')'));
  const definition = splitDefinitions(body).find((item) => item.startsWith(`${quoteIdentifier(column)} `));
  if (!definition) throw new Error(`Missing column definition for ${column}`);
  return definition.slice(quoteIdentifier(column).length + 1).replace(/\s+COMMENT\s+'(?:''|[^'])*'\s*$/i, '');
}

async function migrateSchemaComments(db) {
  await db.query("CREATE TABLE IF NOT EXISTS schema_comments (object_type ENUM('table','column','index','foreign_key') NOT NULL COMMENT '结构对象类型', table_name VARCHAR(64) NOT NULL COMMENT '英文物理表名', object_name VARCHAR(64) NOT NULL DEFAULT '' COMMENT '英文物理对象名', comment_text VARCHAR(500) NOT NULL COMMENT '中文备注说明', updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3) COMMENT '更新时间', PRIMARY KEY (object_type,table_name,object_name)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='数据库结构中文备注字典'");
  const tableEntries = schemaComments.filter(({ objectType, table }) => objectType === 'table' && tableComments[table] !== undefined);
  for (const { table, comment } of tableEntries) {
    const rows = await db.query('SELECT table_comment AS tableComment FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?', [table]);
    if (rows[0] && rows[0].tableComment !== comment) await db.query(`ALTER TABLE ${quoteIdentifier(table)} COMMENT = ${quoteComment(comment)}`);
  }
  const columnEntries = schemaComments.filter(({ objectType, table }) => objectType === 'column' && tableComments[table] !== undefined);
  for (const table of Object.keys(tableComments)) {
    const entries = columnEntries.filter((entry) => entry.table === table);
    const current = await db.query('SELECT column_name AS columnName, column_comment AS columnComment FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=?', [table]);
    if (!Array.isArray(current)) continue;
    const pending = entries.filter(({ objectName, comment }) => current.some((column) => column.columnName === objectName && column.columnComment !== comment));
    if (!pending.length) continue;
    const createRows = await db.query(`SHOW CREATE TABLE ${quoteIdentifier(table)}`);
    const createSql = createRows[0]?.['Create Table'] || createRows[0]?.createTable;
    for (const { objectName, comment } of pending) {
      const definition = columnDefinitionFromCreateTable(createSql, objectName);
      await db.query(`ALTER TABLE ${quoteIdentifier(table)} MODIFY COLUMN ${quoteIdentifier(objectName)} ${definition} COMMENT ${quoteComment(comment)}`);
    }
  }
  for (const { objectType, table, objectName, comment } of schemaComments) {
    await db.query('INSERT INTO schema_comments (object_type,table_name,object_name,comment_text) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE comment_text=VALUES(comment_text)', [objectType, table, objectName, comment]);
  }
  await db.query("DELETE c FROM schema_comments c LEFT JOIN information_schema.tables t ON t.table_schema=DATABASE() AND t.table_name=c.table_name WHERE c.object_type='table' AND t.table_name IS NULL");
  await db.query("DELETE c FROM schema_comments c LEFT JOIN information_schema.columns i ON i.table_schema=DATABASE() AND i.table_name=c.table_name AND i.column_name=c.object_name WHERE c.object_type='column' AND i.column_name IS NULL");
  await db.query("DELETE c FROM schema_comments c LEFT JOIN information_schema.statistics i ON i.table_schema=DATABASE() AND i.table_name=c.table_name AND i.index_name=c.object_name WHERE c.object_type='index' AND i.index_name IS NULL");
  await db.query("DELETE c FROM schema_comments c LEFT JOIN information_schema.referential_constraints i ON i.constraint_schema=DATABASE() AND i.table_name=c.table_name AND i.constraint_name=c.object_name WHERE c.object_type='foreign_key' AND i.constraint_name IS NULL");
}

async function migrateTableCatalog(db) {
  const tableEntries = [...Object.entries(tableComments), ['schema_comments', '数据库结构中文备注字典']];
  for (const [table, comment] of tableEntries) {
    await db.query('INSERT INTO `数据表目录` (physical_name,chinese_name,category_name,purpose,object_type) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE chinese_name=VALUES(chinese_name),category_name=VALUES(category_name),purpose=VALUES(purpose),object_type=VALUES(object_type)', [table, comment, tableCategory(table), `${tableCategory(table)}：${comment}`, 'table']);
  }
  for (const [name] of views) {
    await db.query('INSERT INTO `数据表目录` (physical_name,chinese_name,category_name,purpose,object_type) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE chinese_name=VALUES(chinese_name),category_name=VALUES(category_name),purpose=VALUES(purpose),object_type=VALUES(object_type)', [`view:${name}`, name, '功能总览', `中文只读视图：${name}`, 'view']);
  }
  await db.query("DELETE d FROM `数据表目录` d LEFT JOIN information_schema.tables t ON t.table_schema=DATABASE() AND t.table_name=d.physical_name AND t.table_type='BASE TABLE' WHERE d.object_type='table' AND t.table_name IS NULL");
  await db.query("DELETE d FROM `数据表目录` d LEFT JOIN information_schema.views v ON v.table_schema=DATABASE() AND v.table_name=SUBSTRING(d.physical_name,6) WHERE d.object_type='view' AND d.physical_name LIKE 'view:%' AND v.table_name IS NULL");
}

async function migrateSystemSettings(db) {
  if (await hasTable(db, 'website_settings')) {
    await db.query('INSERT INTO `系统配置` (setting_key,background_image) SELECT setting_key,background_image FROM website_settings ON DUPLICATE KEY UPDATE background_image=VALUES(background_image)');
    await db.query('DROP TABLE website_settings');
  }
  if (await hasTable(db, 'character_growth_settings')) {
    await db.query('INSERT INTO `系统配置` (setting_key,attribute_point_price,skill_level_price) SELECT setting_key,attribute_point_price,skill_level_price FROM character_growth_settings ON DUPLICATE KEY UPDATE attribute_point_price=VALUES(attribute_point_price),skill_level_price=VALUES(skill_level_price)');
    await db.query('DROP TABLE character_growth_settings');
  }
  if (await hasTable(db, 'cloud_warehouse_settings')) {
    await db.query('INSERT INTO `系统配置` (setting_key,cloud_market_enabled,cloud_fee_bps,cloud_daily_base_quota,cloud_updated_by_user_id) SELECT setting_key,market_enabled,fee_bps,daily_base_quota,updated_by_user_id FROM cloud_warehouse_settings ON DUPLICATE KEY UPDATE cloud_market_enabled=VALUES(cloud_market_enabled),cloud_fee_bps=VALUES(cloud_fee_bps),cloud_daily_base_quota=VALUES(cloud_daily_base_quota),cloud_updated_by_user_id=VALUES(cloud_updated_by_user_id)');
    await db.query('DROP TABLE cloud_warehouse_settings');
  }
  await db.query("INSERT IGNORE INTO `系统配置` (setting_key) VALUES ('default')");
  if (!(await hasForeignKey(db, '系统配置', 'fk_system_settings_cloud_updater'))) await db.query('ALTER TABLE `系统配置` ADD CONSTRAINT fk_system_settings_cloud_updater FOREIGN KEY (cloud_updated_by_user_id) REFERENCES \`商城用户\`(\`商城用户编号\`) ON DELETE SET NULL');
  if (await hasTable(db, 'system_initialization_state')) {
    await db.query("INSERT INTO bootstrap_states (state_key,completed_at,created_at) SELECT 'initial_super_admin',completed_at,updated_at FROM system_initialization_state WHERE first_shop_registration_completed=1 ON DUPLICATE KEY UPDATE completed_at=COALESCE(bootstrap_states.completed_at,VALUES(completed_at))");
    await db.query('DROP TABLE system_initialization_state');
  }
}

async function migrateLegacyGiftSchema(db) {
  if (await hasColumn(db, 'player_titles', 'title')) {
    if (!(await hasColumn(db, 'player_titles', 'title_name'))) {
      await db.query('ALTER TABLE player_titles CHANGE COLUMN title title_name VARCHAR(100) NOT NULL');
    }
  }

  if (await hasColumn(db, 'gift_packages', 'min_member_level')) {
    await db.query('UPDATE gift_packages SET member_level=min_member_level WHERE member_level=0');
  }
  if (await hasColumn(db, 'gift_packages', 'private_steam_id')) {
    await db.query("UPDATE gift_packages SET target_steam_id=private_steam_id, gift_type='private' WHERE private_steam_id IS NOT NULL AND private_steam_id<>''");
  }
  if (await hasColumn(db, 'gift_packages', 'reset_period')) {
    await db.query("UPDATE gift_packages SET gift_type=reset_period WHERE reset_period IN ('weekly','monthly','quarterly')");
  }

  if (await hasColumn(db, 'gift_claims', 'shop_user_id')) {
    await db.query('UPDATE gift_claims c LEFT JOIN `商城用户` u ON u.`商城用户编号`=c.shop_user_id SET c.steam_id=COALESCE(c.steam_id,u.`SteamID`) WHERE c.steam_id IS NULL');
  }
  await db.query("UPDATE gift_claims SET steam_id='00000000000000000' WHERE steam_id IS NULL");
  await db.query("UPDATE gift_claims SET request_key=CONCAT('legacy-gift-claim-',id) WHERE request_key IS NULL OR request_key=''");
  await db.query('UPDATE gift_claims SET claim_day=DATE(DATE_ADD(created_at, INTERVAL 8 HOUR)) WHERE claim_day IS NULL');
}

const teleportTableMigrations = [
  ['teleport_settings', '传送管理设置', [
    ['id','配置编号'],['enabled','传送总开关'],['base_price','基础价格'],['base_daily_limit','基础每日次数'],['cooldown_seconds','冷却秒数'],['player_enabled','小队玩家互传'],['owned_vehicle_enabled','玩家到小队载具'],['territory_flag_enabled','玩家到授权领地旗'],['vehicle_to_player_territory_enabled','领地内载具到玩家'],['vehicle_to_player_long_distance_enabled','远距离载具到玩家'],['vehicle_to_fixed_location_enabled','载具到固定位置'],['consent_expiry_seconds','同意请求有效秒数'],['updated_by_user_id','最后修改管理员编号'],['updated_at','更新时间']
  ]],
  ['teleport_player_consents', '玩家传送同意请求', [
    ['request_id','请求编号'],['requester_steam_id','发起玩家SteamID'],['target_steam_id','目标玩家SteamID'],['status','请求状态'],['expires_at','过期时间'],['accepted_at','同意时间'],['rejected_at','拒绝时间'],['consumed_at','使用时间'],['created_at','创建时间'],['updated_at','更新时间']
  ]],
  ['teleport_operations', '传送执行记录', [
    ['id','记录编号'],['steam_id','发起玩家SteamID'],['request_key','请求幂等键'],['request_fingerprint','请求指纹'],['target_type','目标类型'],['target_ref','目标引用'],['target_snapshot','目标名称快照'],['native_target_id','游戏目标编号'],['pricing_mode','计费方式'],['distance_kilometers','传送距离公里'],['base_price','基础价格'],['discount_percent','折扣百分比'],['charged_amount','实扣商城币'],['balance_after','扣款后余额'],['status','执行状态'],['error_code','错误代码'],['error_message','错误信息'],['completed_at','完成时间'],['created_at','创建时间'],['updated_at','更新时间']
  ]]
];

export async function migrateTeleportTablesToChinese(db) {
  for (const [, chineseTable] of teleportTableMigrations) {
    if (await hasView(db, chineseTable)) await db.query(`DROP VIEW ${quoteIdentifier(chineseTable)}`);
  }
  const checksByTable = new Map([
    ['传送管理设置', ['chk_teleport_settings_singleton']],
    ['玩家传送同意请求', ['chk_teleport_consent_players','chk_teleport_consent_status']],
    ['传送执行记录', ['chk_teleport_target_type','chk_teleport_status','chk_teleport_discount']]
  ]);
  for (const [legacyTable, chineseTable, columns] of teleportTableMigrations) {
    if (await hasTable(db, legacyTable)) {
      if (await hasTable(db, chineseTable)) throw new Error(`传送表迁移冲突：${legacyTable} 与 ${chineseTable} 同时存在`);
      await db.query(`RENAME TABLE ${quoteIdentifier(legacyTable)} TO ${quoteIdentifier(chineseTable)}`);
    }
    if (!(await hasTable(db, chineseTable))) continue;
    const hasLegacyColumns = await hasColumn(db, chineseTable, columns[0][0]);
    if (hasLegacyColumns) {
      for (const constraint of checksByTable.get(chineseTable) || []) {
        if (await hasConstraint(db, chineseTable, constraint)) await db.query(`ALTER TABLE ${quoteIdentifier(chineseTable)} DROP CHECK ${quoteIdentifier(constraint)}`);
      }
    }
    for (const [legacyColumn, chineseColumn] of columns) {
      if (await hasColumn(db, chineseTable, legacyColumn)) await db.query(`ALTER TABLE ${quoteIdentifier(chineseTable)} RENAME COLUMN ${quoteIdentifier(legacyColumn)} TO ${quoteIdentifier(chineseColumn)}`);
    }
  }
}

const vehicleTableMigrations = [
  ['vehicles', '载具档案', [
    ['id','载具档案编号'],['vehicle_code','载具档案编码'],['owner_steam_id','车主SteamID'],['owner_name','车主名称'],['vehicle_type','载具类型'],['model_name','型号名称'],['display_name','显示名称'],['plate_number','车牌号'],['status','档案状态'],['condition_percent','车况百分比'],['fuel_percent','燃油百分比'],['grid_code','地图格编号'],['world_x','世界X坐标'],['world_y','世界Y坐标'],['world_z','世界Z坐标'],['map_x_percent','地图X百分比'],['map_y_percent','地图Y百分比'],['location_note','位置备注'],['last_seen_at','最后观测时间'],['notes','备注'],['source_type','来源类型'],['source_vehicle_id','来源载具编号'],['source_asset_id','来源资产标识'],['source_vehicle_alias','来源载具别名'],['source_entity_class','来源实体类名'],['source_lock_slots','来源锁槽数量'],['location_source','位置来源'],['source_synchronized_at','来源同步时间'],['source_sync_state','来源同步状态'],['source_missing_since','来源缺失时间'],['status_before_source_lost','来源失联前状态'],['created_by_user_id','创建管理员编号'],['updated_by_user_id','更新管理员编号'],['created_at','创建时间'],['updated_at','更新时间']
  ]],
  ['vehicle_insurance_strategies', '载具保险销售策略', [
    ['id','策略编号'],['name','策略名称'],['total_claim_limit','总赔付次数上限'],['daily_claim_limit','每日赔付次数上限'],['duration_days','有效天数'],['purchase_condition','购买条件'],['product_id','载具商品编号'],['vehicle_type','载具类型'],['vehicle_code','载具代码'],['price','售价'],['enabled','是否启用'],['deleted_at','删除时间'],['created_by_user_id','创建管理员编号'],['updated_by_user_id','更新管理员编号'],['created_at','创建时间'],['updated_at','更新时间']
  ]],
  ['vehicle_insurance', '载具保险', [
    ['vehicle_id','载具档案编号'],['strategy_id','策略编号'],['policy_number','保单号'],['status','保险状态'],['insured_value','保险价值'],['premium_amount','保费金额'],['total_claim_limit','总赔付次数上限'],['daily_claim_limit','每日赔付次数上限'],['total_claims_used','总已赔付次数'],['daily_claims_used','每日已赔付次数'],['daily_claim_date','每日赔付统计日期'],['starts_at','生效时间'],['expires_at','到期时间'],['coverage_note','保障说明'],['notes','备注'],['updated_by_user_id','更新管理员编号'],['created_at','创建时间'],['updated_at','更新时间']
  ]],
  ['vehicle_insurance_purchases', '载具保险购买记录', [
    ['id','购买记录编号'],['request_key','购买请求键'],['steam_id','玩家SteamID'],['vehicle_id','载具档案编号'],['strategy_id','策略编号'],['strategy_name_snapshot','策略名称快照'],['product_id_snapshot','载具商品编号快照'],['vehicle_type_snapshot','载具类型快照'],['vehicle_code_snapshot','载具代码快照'],['total_claim_limit_snapshot','总赔付次数上限快照'],['daily_claim_limit_snapshot','每日赔付次数上限快照'],['purchase_condition_snapshot','购买条件快照'],['duration_days_snapshot','有效天数快照'],['policy_number','保单号'],['price','实付价格'],['balance_after','购买后余额'],['starts_at','生效时间'],['expires_at','到期时间'],['cancelled_at','删除时间'],['created_at','购买时间']
  ]],
  ['vehicle_insurance_claims', '载具保险索赔记录', [
    ['id','索赔记录编号'],['request_key','索赔请求键'],['claim_number','索赔单号'],['steam_id','玩家SteamID'],['purchase_id','购买记录编号'],['vehicle_id','载具档案编号'],['old_source_vehicle_id','原来源载具编号'],['strategy_id','策略编号'],['vehicle_code','载具代码'],['total_claim_limit','总赔付次数上限快照'],['daily_claim_limit','每日赔付次数上限快照'],['order_id','订单编号'],['fulfillment_task_id','发货任务编号'],['created_at','索赔时间']
  ]],
  ['vehicle_audit_logs', '载具操作审计', [
    ['id','审计记录编号'],['vehicle_id','载具档案编号'],['vehicle_code_snapshot','载具档案编码快照'],['action','操作动作'],['changes_json','变更内容'],['actor_user_id','操作管理员编号'],['actor_name','操作管理员名称'],['created_at','操作时间']
  ]]
];

const vehicleChecks = new Map([
  ['载具档案', [
    ['chk_vehicle_status', "`档案状态` IN ('active','stored','maintenance','lost','destroyed','retired')"],
    ['chk_vehicle_condition', '`车况百分比` IS NULL OR `车况百分比` BETWEEN 0 AND 100'],
    ['chk_vehicle_fuel', '`燃油百分比` IS NULL OR `燃油百分比` BETWEEN 0 AND 100'],
    ['chk_vehicle_map_x', '`地图X百分比` IS NULL OR `地图X百分比` BETWEEN 0 AND 100'],
    ['chk_vehicle_map_y', '`地图Y百分比` IS NULL OR `地图Y百分比` BETWEEN 0 AND 100']
  ]],
  ['载具保险销售策略', [
    ['chk_vehicle_insurance_strategy_claims', '`总赔付次数上限` >= 1 AND `每日赔付次数上限` >= 1 AND `每日赔付次数上限` <= `总赔付次数上限`'],
    ['chk_vehicle_insurance_strategy_duration', '`有效天数` >= 1']
  ]],
  ['载具保险', [
    ['chk_vehicle_insurance_status', "`保险状态` IN ('none','active','expired','suspended')"],
    ['chk_vehicle_insurance_period', '`生效时间` IS NULL OR `到期时间` IS NULL OR `生效时间` < `到期时间`']
  ]],
  ['载具保险索赔记录', [
    ['chk_vehicle_insurance_claim_limits', '`总赔付次数上限快照` >= 1 AND `每日赔付次数上限快照` >= 1 AND `每日赔付次数上限快照` <= `总赔付次数上限快照`']
  ]]
]);

async function createVehicleCompatibilityViews(db) {
  for (const [legacyTable, chineseTable, columns] of vehicleTableMigrations) {
    if (await hasTable(db, legacyTable)) continue;
    if (await hasView(db, legacyTable)) await db.query(`DROP VIEW ${quoteIdentifier(legacyTable)}`);
    if (await hasTable(db, chineseTable)) {
      const projection = columns.map(([legacyColumn, chineseColumn]) => `${quoteIdentifier(chineseColumn)} AS ${quoteIdentifier(legacyColumn)}`).join(',');
      await db.query(`CREATE VIEW ${quoteIdentifier(legacyTable)} AS SELECT ${projection} FROM ${quoteIdentifier(chineseTable)}`);
    }
  }
}

export async function migrateVehicleTablesToChinese(db) {
  for (const [, chineseTable] of vehicleTableMigrations) if (await hasView(db, chineseTable)) await db.query(`DROP VIEW ${quoteIdentifier(chineseTable)}`);
  if (await hasView(db, '传送载具位置')) await db.query('DROP VIEW `传送载具位置`');
  for (const [legacyTable, chineseTable] of vehicleTableMigrations) {
    if (await hasTable(db, legacyTable) && await hasTable(db, chineseTable)) throw new Error(`载具表迁移冲突：${legacyTable} 与 ${chineseTable} 同时存在`);
  }
  for (const [legacyTable, chineseTable] of vehicleTableMigrations) {
    const physicalTable = await hasTable(db, legacyTable) ? legacyTable : chineseTable;
    if (!(await hasTable(db, physicalTable))) continue;
    for (const [constraint] of vehicleChecks.get(chineseTable) || []) {
      if (await hasConstraint(db, physicalTable, constraint)) await db.query(`ALTER TABLE ${quoteIdentifier(physicalTable)} DROP CHECK ${quoteIdentifier(constraint)}`);
    }
  }
  const renames = [];
  for (const [legacyTable, chineseTable] of vehicleTableMigrations) if (await hasTable(db, legacyTable)) renames.push(`${quoteIdentifier(legacyTable)} TO ${quoteIdentifier(chineseTable)}`);
  if (renames.length) await db.query(`RENAME TABLE ${renames.join(',')}`);
  for (const [, chineseTable, columns] of vehicleTableMigrations) {
    if (!(await hasTable(db, chineseTable))) continue;
    for (const [legacyColumn, chineseColumn] of columns) {
      if (await hasColumn(db, chineseTable, legacyColumn) && await hasColumn(db, chineseTable, chineseColumn)) throw new Error(`载具字段迁移冲突：${chineseTable}.${legacyColumn} 与 ${chineseColumn} 同时存在`);
      if (await hasColumn(db, chineseTable, legacyColumn)) await db.query(`ALTER TABLE ${quoteIdentifier(chineseTable)} RENAME COLUMN ${quoteIdentifier(legacyColumn)} TO ${quoteIdentifier(chineseColumn)}`);
    }
    for (const [constraint, clause] of vehicleChecks.get(chineseTable) || []) {
      if (!(await hasConstraint(db, chineseTable, constraint))) await db.query(`ALTER TABLE ${quoteIdentifier(chineseTable)} ADD CONSTRAINT ${quoteIdentifier(constraint)} CHECK (${clause})`);
    }
  }
  if (await hasTable(db, '载具保险销售策略') && !(await hasConstraint(db, '载具保险销售策略', 'fk_vehicle_insurance_strategy_product'))) await db.query('ALTER TABLE `载具保险销售策略` ADD CONSTRAINT `fk_vehicle_insurance_strategy_product` FOREIGN KEY (`载具商品编号`) REFERENCES products(id) ON DELETE SET NULL');
  if (await hasTable(db, '载具保险') && !(await hasConstraint(db, '载具保险', 'fk_vehicle_insurance_strategy'))) await db.query('ALTER TABLE `载具保险` ADD CONSTRAINT `fk_vehicle_insurance_strategy` FOREIGN KEY (`策略编号`) REFERENCES `载具保险销售策略`(`策略编号`) ON DELETE SET NULL');
  await createVehicleCompatibilityViews(db);
  if (await hasTable(db, '载具档案')) await db.query("CREATE OR REPLACE ALGORITHM=TEMPTABLE VIEW `传送载具位置` AS SELECT `载具档案编号`,`车主SteamID` AS `归属SteamID`,COALESCE(NULLIF(`显示名称`,''),NULLIF(`型号名称`,''),`载具类型`) AS `显示名称`,`车牌号`,`世界X坐标`,`世界Y坐标`,`世界Z坐标`,`地图X百分比`,`地图Y百分比`,`位置来源`,`最后观测时间`,`档案状态`,`更新时间` FROM `载具档案` WHERE `车主SteamID` IS NOT NULL");
}

const PLAYER_LOCATION_MIGRATION_LOCK = 'scum_shop_player_location_squad_migration_v1';

async function playerLocationRawQuery(db, sql) {
  if (typeof db.rawQuery === 'function') return db.rawQuery(sql);
  return db.query(sql);
}

async function withPlayerLocationTableLock(db, clause, work) {
  await playerLocationRawQuery(db, `LOCK TABLES ${clause}`);
  try {
    return await work();
  } finally {
    await playerLocationRawQuery(db, 'UNLOCK TABLES').catch(() => {});
  }
}

async function migratePlayerLocationAndSquadOnConnection(db) {
  const lockRows = await db.query('SELECT GET_LOCK(?, 60) AS acquired', [PLAYER_LOCATION_MIGRATION_LOCK]);
  if (Number(lockRows?.[0]?.acquired) !== 1) throw new Error('玩家位置与小队迁移锁获取超时');
  try {
  const columns = [
    ['位置世界X坐标', 'DECIMAL(20,6) NULL'],
    ['位置世界Y坐标', 'DECIMAL(20,6) NULL'],
    ['位置世界Z坐标', 'DECIMAL(20,6) NULL'],
    ['位置数据来源', 'VARCHAR(100) NULL'],
    ['位置观测时间', 'DATETIME(3) NULL'],
    ['位置是否当前有效', 'TINYINT(1) NULL'],
    ['小队编号', 'VARCHAR(100) NULL'],
    ['小队名称', 'VARCHAR(100) NULL'],
    ['小队更新时间', 'DATETIME(3) NULL']
  ];
  for (const [column, definition] of columns) {
    if (!(await hasColumn(db, '商城用户', column))) await db.query(`ALTER TABLE \`商城用户\` ADD COLUMN ${quoteIdentifier(column)} ${definition}`);
  }
  if (await hasIndex(db, '商城用户', '商城用户_小队编号索引')) await db.query('ALTER TABLE `商城用户` DROP INDEX `商城用户_小队编号索引`');
  if (!(await hasIndex(db, '商城用户', '商城用户_小队成员索引'))) await db.query('ALTER TABLE `商城用户` ADD INDEX `商城用户_小队成员索引` (`小队编号`,`SteamID`)');

  const migrationTables = new Set();
  if (await hasTable(db, '传送位置快照')) {
    migrationTables.add('传送位置快照');
    if (!(await hasColumn(db, '传送位置快照', '世界Z坐标'))) await db.query('ALTER TABLE `传送位置快照` ADD COLUMN `世界Z坐标` DECIMAL(20,6) NULL AFTER `世界Y坐标`');
    const unknownTypes = await db.query("SELECT COUNT(*) AS count FROM `传送位置快照` WHERE `实体类型` NOT IN ('player','flag')");
    if (Number(unknownTypes?.[0]?.count || 0) !== 0) throw new Error('传送位置快照包含未知实体类型，拒绝收窄为领地旗快照');
  }
  if (await hasTable(db, 'player_squads')) migrationTables.add('player_squads');

  if (migrationTables.has('传送位置快照')) {
    await withPlayerLocationTableLock(db, '`商城用户` WRITE, `商城用户` AS u WRITE, `传送位置快照` WRITE, `传送位置快照` AS p WRITE', async () => {
    await db.query("INSERT INTO `商城用户` (`SteamID`,`游戏名称`,`位置世界X坐标`,`位置世界Y坐标`,`位置世界Z坐标`,`位置数据来源`,`位置观测时间`,`位置是否当前有效`) SELECT `实体标识`,`显示名称`,`世界X坐标`,`世界Y坐标`,`世界Z坐标`,`数据来源`,`观测时间`,`是否当前有效` FROM `传送位置快照` WHERE `实体类型`='player' ON DUPLICATE KEY UPDATE `游戏名称`=IF(`最后游戏在线时间` IS NULL OR VALUES(`位置观测时间`)>=`最后游戏在线时间`,VALUES(`游戏名称`),`游戏名称`),`位置世界X坐标`=IF(`位置观测时间` IS NULL OR VALUES(`位置观测时间`)>=`位置观测时间`,VALUES(`位置世界X坐标`),`位置世界X坐标`),`位置世界Y坐标`=IF(`位置观测时间` IS NULL OR VALUES(`位置观测时间`)>=`位置观测时间`,VALUES(`位置世界Y坐标`),`位置世界Y坐标`),`位置世界Z坐标`=IF(`位置观测时间` IS NULL OR VALUES(`位置观测时间`)>=`位置观测时间`,VALUES(`位置世界Z坐标`),`位置世界Z坐标`),`位置数据来源`=IF(`位置观测时间` IS NULL OR VALUES(`位置观测时间`)>=`位置观测时间`,VALUES(`位置数据来源`),`位置数据来源`),`位置是否当前有效`=IF(`位置观测时间` IS NULL OR VALUES(`位置观测时间`)>=`位置观测时间`,VALUES(`位置是否当前有效`),`位置是否当前有效`),`位置观测时间`=GREATEST(COALESCE(`位置观测时间`,VALUES(`位置观测时间`)),VALUES(`位置观测时间`))");
    const missing = await db.query("SELECT COUNT(*) AS count FROM `传送位置快照` p LEFT JOIN `商城用户` u ON BINARY u.`SteamID`=BINARY p.`实体标识` WHERE p.`实体类型`='player' AND (u.`商城用户编号` IS NULL OR u.`位置观测时间` IS NULL OR u.`位置观测时间`<p.`观测时间` OR ((u.`最后游戏在线时间` IS NULL OR p.`观测时间`>=u.`最后游戏在线时间`) AND NOT (BINARY u.`游戏名称`<=>BINARY p.`显示名称`)) OR (u.`位置观测时间`=p.`观测时间` AND (NOT (u.`位置世界X坐标`<=>p.`世界X坐标`) OR NOT (u.`位置世界Y坐标`<=>p.`世界Y坐标`) OR NOT (u.`位置世界Z坐标`<=>p.`世界Z坐标`) OR NOT (BINARY u.`位置数据来源`<=>BINARY p.`数据来源`) OR NOT (u.`位置是否当前有效`<=>p.`是否当前有效`))))");
    if (Number(missing?.[0]?.count || 0) !== 0) throw new Error('玩家位置快照迁入商城用户校验失败');
    await db.query("DELETE FROM `传送位置快照` WHERE `实体类型`='player'");
    const entityType = await db.query("SELECT column_type AS columnType FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='传送位置快照' AND column_name='实体类型' LIMIT 1");
    if (String(entityType?.[0]?.columnType || '').toLowerCase() !== "enum('flag')") await db.query("ALTER TABLE `传送位置快照` MODIFY COLUMN `实体类型` ENUM('flag') NOT NULL");
    });
  }

  if (migrationTables.has('player_squads')) {
    await withPlayerLocationTableLock(db, '`商城用户` WRITE, `商城用户` AS u WRITE, `player_squads` WRITE, `player_squads` AS s WRITE', async () => {
    await db.query('INSERT INTO `商城用户` (`SteamID`,`小队编号`,`小队名称`,`小队更新时间`) SELECT steam_id,squad_id,squad_name,updated_at FROM player_squads ON DUPLICATE KEY UPDATE `小队编号`=IF(`小队更新时间` IS NULL OR VALUES(`小队更新时间`)>=`小队更新时间`,VALUES(`小队编号`),`小队编号`),`小队名称`=IF(`小队更新时间` IS NULL OR VALUES(`小队更新时间`)>=`小队更新时间`,VALUES(`小队名称`),`小队名称`),`小队更新时间`=GREATEST(COALESCE(`小队更新时间`,VALUES(`小队更新时间`)),VALUES(`小队更新时间`))');
    const missing = await db.query('SELECT COUNT(*) AS count FROM player_squads s LEFT JOIN `商城用户` u ON BINARY u.`SteamID`=BINARY s.steam_id WHERE u.`商城用户编号` IS NULL OR u.`小队更新时间` IS NULL OR u.`小队更新时间`<s.updated_at OR (u.`小队更新时间`=s.updated_at AND (NOT (BINARY u.`小队编号`<=>BINARY s.squad_id) OR NOT (BINARY u.`小队名称`<=>BINARY s.squad_name)))');
    if (Number(missing?.[0]?.count || 0) !== 0) throw new Error('玩家小队迁入商城用户校验失败');
    await db.query('DROP TABLE player_squads');
    });
  }
  } finally {
    await db.query('SELECT RELEASE_LOCK(?) AS released', [PLAYER_LOCATION_MIGRATION_LOCK]);
  }
}

export async function migratePlayerLocationAndSquadIntoAccounts(db) {
  if (typeof db.withConnection !== 'function') throw new Error('玩家位置与小队迁移要求独占数据库连接');
  return db.withConnection((session) => migratePlayerLocationAndSquadOnConnection(session));
}

async function alignDatabaseDefaultToAccountSteamId(db) {
  const storage = await db.query("SELECT c.character_set_name AS charset,c.collation_name AS collation,s.default_character_set_name AS databaseCharset,s.default_collation_name AS databaseCollation FROM information_schema.columns c JOIN information_schema.schemata s ON s.schema_name=c.table_schema WHERE c.table_schema=DATABASE() AND c.table_name='商城用户' AND c.column_name='SteamID' LIMIT 1");
  if (!Array.isArray(storage)) return;
  const definition = storage[0];
  if (!definition) throw new Error('商城用户.SteamID 字符集定义不存在');
  if (!/^[A-Za-z0-9_]+$/.test(definition.charset || '') || !/^[A-Za-z0-9_]+$/.test(definition.collation || '')) throw new Error('商城用户.SteamID 字符集定义无效');
  if (definition.databaseCharset !== definition.charset || definition.databaseCollation !== definition.collation) {
    const alter = `ALTER DATABASE CHARACTER SET ${definition.charset} COLLATE ${definition.collation}`;
    if (typeof db.rawQuery === 'function') await db.rawQuery(alter);
    else await db.query(alter);
  }
}

async function ensureSchemaOnConnection(db) {
  await migrateAccountSchema(db);
  await alignDatabaseDefaultToAccountSteamId(db);
  await db.query('DROP VIEW IF EXISTS `玩家综合资料`');
  await db.query('DROP VIEW IF EXISTS `玩家账户`');
  if (await hasColumn(db, '商城用户', '角色名称') && !(await hasColumn(db, '商城用户', '游戏名称'))) {
    await db.query('ALTER TABLE `商城用户` RENAME COLUMN `角色名称` TO `游戏名称`');
  }
  for (const column of ['Steam名称', '商城账户更新时间', '游戏账户创建时间', '游戏账户更新时间', '玩家名称', '是否游戏管理员']) {
    if (await hasColumn(db, '商城用户', column)) await db.query(`ALTER TABLE \`商城用户\` DROP COLUMN ${quoteIdentifier(column)}`);
  }
  const hiddenAccountColumns = [
    ['登录账号规范值', 'VARCHAR(64) NULL'],
    ['密码盐', 'CHAR(32) NULL'],
    ['用户角色', "VARCHAR(16) NOT NULL DEFAULT 'user'"],
    ['管理员权限', 'JSON NULL']
  ];
  for (const [column, definition] of hiddenAccountColumns) {
    if (await hasColumn(db, '商城用户', column) && !(await columnIsInvisible(db, '商城用户', column))) {
      await db.query(`ALTER TABLE \`商城用户\` MODIFY COLUMN ${quoteIdentifier(column)} ${definition} INVISIBLE`);
    }
  }
  await migrateTeleportTablesToChinese(db);
  const vehicleSchemaAlreadyChinese = await hasTable(db, '载具档案');
  if (await hasColumn(db, 'player_titles', 'title')) {
    if (!(await hasColumn(db, 'player_titles', 'title_name'))) await db.query('ALTER TABLE player_titles CHANGE COLUMN title title_name VARCHAR(100) NOT NULL');
  }
  for (const sql of statements) {
    if (vehicleSchemaAlreadyChinese && /^CREATE TABLE IF NOT EXISTS (vehicles|vehicle_insurance_strategies|vehicle_insurance|vehicle_insurance_purchases|vehicle_insurance_claims|vehicle_audit_logs)\b/.test(sql)) continue;
    await db.query(sql);
  }
  if (!(await hasColumn(db, '传送位置快照', '世界Z坐标'))) await db.query('ALTER TABLE `传送位置快照` ADD COLUMN `世界Z坐标` DECIMAL(20,6) NULL AFTER `世界Y坐标`');
  await migratePlayerLocationAndSquadOnConnection(db);
  if (!(await hasColumn(db, '传送管理设置', '玩家到小队载具'))) await db.query('ALTER TABLE `传送管理设置` ADD COLUMN `玩家到小队载具` TINYINT(1) NOT NULL DEFAULT 1 AFTER `小队玩家互传`');
  if (!(await hasColumn(db, '传送管理设置', '玩家到授权领地旗'))) await db.query('ALTER TABLE `传送管理设置` ADD COLUMN `玩家到授权领地旗` TINYINT(1) NOT NULL DEFAULT 1 AFTER `玩家到小队载具`');
  if (!(await hasColumn(db, '传送管理设置', '固定位置传送'))) await db.query('ALTER TABLE `传送管理设置` ADD COLUMN `固定位置传送` TINYINT(1) NOT NULL DEFAULT 1 AFTER `玩家到授权领地旗`');
  const addFixedLocationVisibility = !(await hasColumn(db, '传送固定位置', '可见范围'));
  if (addFixedLocationVisibility) {
    await db.query("ALTER TABLE `传送固定位置` ADD COLUMN `可见范围` VARCHAR(16) NOT NULL DEFAULT 'public' AFTER `来源类型`");
    await db.query("UPDATE `传送固定位置` SET `可见范围`='private' WHERE `归属SteamID` IS NOT NULL");
  }
  const fixedOwnerClause = await checkConstraintClause(db, 'chk_teleport_fixed_owner');
  if (fixedOwnerClause && !fixedOwnerClause.includes('可见范围')) await db.query('ALTER TABLE `传送固定位置` DROP CHECK chk_teleport_fixed_owner');
  if (!(await hasConstraint(db, '传送固定位置', 'chk_teleport_fixed_visibility'))) await db.query("ALTER TABLE `传送固定位置` ADD CONSTRAINT chk_teleport_fixed_visibility CHECK (`可见范围` IN ('public','private'))");
  if (!(await hasConstraint(db, '传送固定位置', 'chk_teleport_fixed_owner'))) await db.query("ALTER TABLE `传送固定位置` ADD CONSTRAINT chk_teleport_fixed_owner CHECK ((`可见范围`='public' AND `归属SteamID` IS NULL) OR (`可见范围`='private' AND `归属SteamID` IS NOT NULL))");
  if (!(await hasColumn(db, '传送管理设置', '领地内载具到玩家'))) await db.query('ALTER TABLE `传送管理设置` ADD COLUMN `领地内载具到玩家` TINYINT(1) NOT NULL DEFAULT 1 AFTER `玩家到授权领地旗`');
  if (!(await hasColumn(db, '传送管理设置', '远距离载具到玩家'))) await db.query('ALTER TABLE `传送管理设置` ADD COLUMN `远距离载具到玩家` TINYINT(1) NOT NULL DEFAULT 1 AFTER `领地内载具到玩家`');
  if (!(await hasColumn(db, '传送管理设置', '载具到固定位置'))) await db.query('ALTER TABLE `传送管理设置` ADD COLUMN `载具到固定位置` TINYINT(1) NOT NULL DEFAULT 1 AFTER `远距离载具到玩家`');
  const missingTeleportColumns = new Set();
  for (const name of ['角色计费方式','角色固定价格','角色每公里价格','角色每日次数','角色传送间隔秒数','载具计费方式','载具固定价格','载具每公里价格','载具每日次数','载具传送间隔秒数']) {
    if (!(await hasColumn(db, '传送管理设置', name))) missingTeleportColumns.add(name);
  }
  if (missingTeleportColumns.has('角色固定价格')) await db.query("ALTER TABLE `传送管理设置` ADD COLUMN `角色固定价格` BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER `冷却秒数`");
  if (missingTeleportColumns.has('角色每公里价格')) await db.query('ALTER TABLE `传送管理设置` ADD COLUMN `角色每公里价格` BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER `角色固定价格`');
  if (missingTeleportColumns.has('角色每日次数')) await db.query('ALTER TABLE `传送管理设置` ADD COLUMN `角色每日次数` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `角色每公里价格`');
  if (missingTeleportColumns.has('角色传送间隔秒数')) await db.query('ALTER TABLE `传送管理设置` ADD COLUMN `角色传送间隔秒数` INT UNSIGNED NOT NULL DEFAULT 300 AFTER `角色每日次数`');
  if (missingTeleportColumns.has('载具计费方式')) await db.query("ALTER TABLE `传送管理设置` ADD COLUMN `载具计费方式` VARCHAR(16) NOT NULL DEFAULT 'fixed' AFTER `角色传送间隔秒数`");
  if (missingTeleportColumns.has('载具固定价格')) await db.query('ALTER TABLE `传送管理设置` ADD COLUMN `载具固定价格` BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER `载具计费方式`');
  if (missingTeleportColumns.has('载具每公里价格')) await db.query('ALTER TABLE `传送管理设置` ADD COLUMN `载具每公里价格` BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER `载具固定价格`');
  if (missingTeleportColumns.has('载具每日次数')) await db.query('ALTER TABLE `传送管理设置` ADD COLUMN `载具每日次数` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `载具每公里价格`');
  if (missingTeleportColumns.has('载具传送间隔秒数')) await db.query('ALTER TABLE `传送管理设置` ADD COLUMN `载具传送间隔秒数` INT UNSIGNED NOT NULL DEFAULT 300 AFTER `载具每日次数`');
  if (missingTeleportColumns.has('角色计费方式')) await db.query("ALTER TABLE `传送管理设置` ADD COLUMN `角色计费方式` VARCHAR(16) NOT NULL DEFAULT 'fixed' AFTER `冷却秒数`");
  const legacyBackfills = [];
  if (missingTeleportColumns.has('角色固定价格')) legacyBackfills.push('`角色固定价格`=`基础价格`');
  if (missingTeleportColumns.has('角色每日次数')) legacyBackfills.push('`角色每日次数`=`基础每日次数`');
  if (missingTeleportColumns.has('角色传送间隔秒数')) legacyBackfills.push('`角色传送间隔秒数`=`冷却秒数`');
  if (missingTeleportColumns.has('载具固定价格')) legacyBackfills.push('`载具固定价格`=`基础价格`');
  if (missingTeleportColumns.has('载具每日次数')) legacyBackfills.push('`载具每日次数`=`基础每日次数`');
  if (missingTeleportColumns.has('载具传送间隔秒数')) legacyBackfills.push('`载具传送间隔秒数`=`冷却秒数`');
  if (legacyBackfills.length) await db.query(`UPDATE \`传送管理设置\` SET ${legacyBackfills.join(',')} WHERE \`配置编号\`=1`);
  if (!(await hasColumn(db, '传送管理设置', '同意请求有效秒数'))) await db.query('ALTER TABLE `传送管理设置` ADD COLUMN `同意请求有效秒数` INT UNSIGNED NOT NULL DEFAULT 300 AFTER `载具到固定位置`');
  if (!(await hasColumn(db, '传送管理设置', '最后修改管理员编号'))) await db.query('ALTER TABLE `传送管理设置` ADD COLUMN `最后修改管理员编号` BIGINT UNSIGNED NULL AFTER `同意请求有效秒数`');
  if (!(await hasColumn(db, '传送执行记录', '目标玩家SteamID'))) await db.query('ALTER TABLE `传送执行记录` ADD COLUMN `目标玩家SteamID` VARCHAR(17) NULL AFTER `游戏目标编号`');
  if (!(await hasColumn(db, '传送执行记录', '计费方式'))) await db.query("ALTER TABLE `传送执行记录` ADD COLUMN `计费方式` VARCHAR(16) NOT NULL DEFAULT 'fixed' AFTER `目标玩家SteamID`");
  if (!(await hasColumn(db, '传送执行记录', '传送距离公里'))) await db.query('ALTER TABLE `传送执行记录` ADD COLUMN `传送距离公里` DECIMAL(12,3) NULL AFTER `计费方式`');
  if (!(await hasColumn(db, '传送执行记录', '载具回执'))) await db.query('ALTER TABLE `传送执行记录` ADD COLUMN `载具回执` LONGTEXT NULL AFTER `错误信息`');
  if (!(await hasColumn(db, '传送执行记录', '载具目标X'))) await db.query('ALTER TABLE `传送执行记录` ADD COLUMN `载具目标X` DECIMAL(20,6) NULL AFTER `载具回执`');
  if (!(await hasColumn(db, '传送执行记录', '载具目标Y'))) await db.query('ALTER TABLE `传送执行记录` ADD COLUMN `载具目标Y` DECIMAL(20,6) NULL AFTER `载具目标X`');
  if (!(await hasColumn(db, '传送执行记录', '载具目标Z'))) await db.query('ALTER TABLE `传送执行记录` ADD COLUMN `载具目标Z` DECIMAL(20,6) NULL AFTER `载具目标Y`');
  if (!(await hasColumn(db, '传送执行记录', '载具命令完成时间'))) await db.query('ALTER TABLE `传送执行记录` ADD COLUMN `载具命令完成时间` DATETIME(3) NULL AFTER `载具目标Z`');
  if (!(await hasColumn(db, '传送执行记录', '载具复核次数'))) await db.query('ALTER TABLE `传送执行记录` ADD COLUMN `载具复核次数` TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER `载具命令完成时间`');
  if (!(await hasColumn(db, '传送执行记录', '载具下次复核时间'))) await db.query('ALTER TABLE `传送执行记录` ADD COLUMN `载具下次复核时间` DATETIME(3) NULL AFTER `载具复核次数`');
  if (!(await hasColumn(db, '传送执行记录', '载具复核响应'))) await db.query('ALTER TABLE `传送执行记录` ADD COLUMN `载具复核响应` LONGTEXT NULL AFTER `载具下次复核时间`');
  if (!(await hasColumn(db, '传送执行记录', '载具复核租约时间'))) await db.query('ALTER TABLE `传送执行记录` ADD COLUMN `载具复核租约时间` DATETIME(3) NULL AFTER `载具复核响应`');
  if (!(await hasColumn(db, '传送执行记录', '退款时间'))) await db.query('ALTER TABLE `传送执行记录` ADD COLUMN `退款时间` DATETIME(3) NULL AFTER `载具复核租约时间`');
  if (!(await hasColumn(db, '传送执行记录', '退款原因'))) await db.query('ALTER TABLE `传送执行记录` ADD COLUMN `退款原因` VARCHAR(255) NULL AFTER `退款时间`');
  if (!(await hasIndex(db, '传送执行记录', 'idx_teleport_vehicle_verify'))) await db.query('ALTER TABLE `传送执行记录` ADD INDEX idx_teleport_vehicle_verify (`执行状态`,`载具下次复核时间`,`载具复核租约时间`)');
  const teleportTargetClause = await checkConstraintClause(db, 'chk_teleport_target_type');
  if (teleportTargetClause && (!teleportTargetClause.includes("'vehicle_to_territory_flag'") || !teleportTargetClause.includes("'vehicle_to_player'") || !teleportTargetClause.includes("'vehicle_to_fixed_location'") || !teleportTargetClause.includes("'fixed_location'"))) await db.query('ALTER TABLE `传送执行记录` DROP CHECK chk_teleport_target_type');
  if (await columnCharacterLength(db, '传送执行记录', '目标类型') < 32) await db.query('ALTER TABLE `传送执行记录` MODIFY COLUMN `目标类型` VARCHAR(32) NOT NULL');
  await db.query("UPDATE `传送执行记录` SET `目标类型`='vehicle_to_territory_flag' WHERE `目标类型`='vehicle_to_player_territory'");
  await db.query("UPDATE `传送执行记录` SET `目标类型`='vehicle_to_player' WHERE `目标类型`='vehicle_to_player_long_distance'");
  if (!(await hasConstraint(db, '传送管理设置', 'chk_teleport_settings_singleton'))) await db.query('ALTER TABLE `传送管理设置` ADD CONSTRAINT chk_teleport_settings_singleton CHECK (`配置编号`=1)');
  if (!(await hasConstraint(db, '玩家传送同意请求', 'chk_teleport_consent_players'))) await db.query('ALTER TABLE `玩家传送同意请求` ADD CONSTRAINT chk_teleport_consent_players CHECK (`发起玩家SteamID`<>`目标玩家SteamID`)');
  if (!(await hasConstraint(db, '玩家传送同意请求', 'chk_teleport_consent_status'))) await db.query("ALTER TABLE `玩家传送同意请求` ADD CONSTRAINT chk_teleport_consent_status CHECK (`请求状态` IN ('pending','accepted','rejected','consumed'))");
  if (!(await hasConstraint(db, '传送执行记录', 'chk_teleport_target_type'))) await db.query("ALTER TABLE `传送执行记录` ADD CONSTRAINT chk_teleport_target_type CHECK (`目标类型` IN ('player','owned_vehicle','territory_flag','fixed_location','vehicle_to_territory_flag','vehicle_to_player','vehicle_to_fixed_location'))");
  const teleportStatusClause = await checkConstraintClause(db, 'chk_teleport_status');
  if (teleportStatusClause && !teleportStatusClause.includes("'success_pending_persistence'")) await db.query('ALTER TABLE `传送执行记录` DROP CHECK chk_teleport_status');
  if (await columnCharacterLength(db, '传送执行记录', '执行状态') < 32) await db.query("ALTER TABLE `传送执行记录` MODIFY COLUMN `执行状态` VARCHAR(32) NOT NULL DEFAULT 'prepared'");
  if (!(await hasConstraint(db, '传送执行记录', 'chk_teleport_status'))) await db.query("ALTER TABLE `传送执行记录` ADD CONSTRAINT chk_teleport_status CHECK (`执行状态` IN ('prepared','completed','failed','manual_review','command_failed','command_result_unknown','success_pending_persistence','verified','refunded'))");
  if (!(await hasConstraint(db, '传送执行记录', 'chk_teleport_discount'))) await db.query('ALTER TABLE `传送执行记录` ADD CONSTRAINT chk_teleport_discount CHECK (`折扣百分比` BETWEEN 0 AND 100)');
  if (!(await hasColumn(db, 'chat_auto_reply_rules', 'total_limit'))) await db.query('ALTER TABLE chat_auto_reply_rules ADD COLUMN total_limit INT UNSIGNED NOT NULL DEFAULT 0 AFTER response_text');
  if (!(await hasColumn(db, 'chat_auto_reply_rules', 'daily_limit'))) await db.query('ALTER TABLE chat_auto_reply_rules ADD COLUMN daily_limit INT UNSIGNED NOT NULL DEFAULT 0 AFTER total_limit');
  if (!(await hasColumn(db, 'chat_auto_reply_rules', 'min_member_level'))) await db.query('ALTER TABLE chat_auto_reply_rules ADD COLUMN min_member_level INT UNSIGNED NOT NULL DEFAULT 0 AFTER daily_limit');
  if (!(await hasColumn(db, 'chat_auto_reply_rules', 'price'))) await db.query('ALTER TABLE chat_auto_reply_rules ADD COLUMN price BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER min_member_level');
  if (!(await hasColumn(db, 'redeem_codes', 'code_plain'))) await db.query('ALTER TABLE redeem_codes ADD COLUMN code_plain VARCHAR(64) NULL AFTER code_hash');
  if (!(await hasColumn(db, 'gift_types', 'sort_order'))) await db.query('ALTER TABLE gift_types ADD COLUMN sort_order INT UNSIGNED NOT NULL DEFAULT 0 AFTER display_name');
  const defaultGiftTypes = [['normal','普通',1],['private','私人',2],['title','称号',3],['squad','小队',4],['monthly','月度',5],['weekly','周度',6],['quarterly','季度',7]];
  for (const item of defaultGiftTypes) await db.query('INSERT INTO gift_types (type_code,display_name,sort_order) VALUES (?,?,?) ON DUPLICATE KEY UPDATE sort_order=IF(sort_order=0,VALUES(sort_order),sort_order)', item);
  await db.query('SET @gift_type_order := 7');
  await db.query('UPDATE gift_types SET sort_order=(@gift_type_order := @gift_type_order + 1) WHERE sort_order=0 ORDER BY created_at,type_code');
  const addProductCategorySort = !(await hasColumn(db, 'product_categories', 'sort_order'));
  if (addProductCategorySort) await db.query('ALTER TABLE product_categories ADD COLUMN sort_order INT UNSIGNED NOT NULL DEFAULT 0 AFTER name');
  await db.query("INSERT IGNORE INTO product_categories (parent_name,name) SELECT DISTINCT parent_category,category_name FROM products WHERE parent_category IS NOT NULL AND parent_category<>'' AND category_name IS NOT NULL AND category_name<>''");
  if (addProductCategorySort) await db.query('UPDATE product_categories SET sort_order=id');
  await db.query("INSERT IGNORE INTO product_parent_categories (name,sort_order) SELECT parent_name,MIN(id) FROM product_categories GROUP BY parent_name");
  await migrateSystemSettings(db);
  const membershipStrategyCheck = await db.query("SELECT check_clause AS checkClause FROM information_schema.check_constraints WHERE constraint_schema=DATABASE() AND constraint_name='chk_membership_strategy_level'");
  if (membershipStrategyCheck[0] && !String(membershipStrategyCheck[0].checkClause || '').includes('0')) {
    await db.query('ALTER TABLE membership_strategies DROP CHECK chk_membership_strategy_level');
    await db.query('ALTER TABLE membership_strategies ADD CONSTRAINT chk_membership_strategy_level CHECK (level BETWEEN 0 AND 100)');
  }
  await db.query("INSERT IGNORE INTO membership_strategies (level,title,opening_amount,period_days,gift_tokens,upgrade_spend,teleport_discount,online_bonus,shopping_discount,gift_discount,recharge_bonus,daily_teleports,checkin_bonus,extra_hint,enabled) VALUES (0,'默认玩家',0,30,0,0,100,100,100,100,100,0,0,'',1)");
  await db.query("INSERT IGNORE INTO `传送管理设置` (`配置编号`,`传送总开关`,`基础价格`,`基础每日次数`,`冷却秒数`,`角色计费方式`,`角色固定价格`,`角色每公里价格`,`角色每日次数`,`角色传送间隔秒数`,`载具计费方式`,`载具固定价格`,`载具每公里价格`,`载具每日次数`,`载具传送间隔秒数`,`小队玩家互传`,`玩家到小队载具`,`玩家到授权领地旗`,`固定位置传送`,`领地内载具到玩家`,`远距离载具到玩家`,`载具到固定位置`,`同意请求有效秒数`) VALUES (1,1,0,0,300,'fixed',0,0,0,300,'fixed',0,0,0,300,0,1,1,1,1,1,1,300)");
  await db.query("INSERT IGNORE INTO membership_policy (id) VALUES (1)");
  await db.query("INSERT IGNORE INTO chat_auto_reply_rules (trigger_text,response_text,enabled) VALUES ('@帮助','玩家可发送@领取新手礼包',1)");
  const auditActorChecks = await db.query("SELECT check_clause AS checkClause FROM information_schema.check_constraints WHERE constraint_schema=DATABASE() AND constraint_name='chk_admin_role_audit_actor'");
  if (auditActorChecks[0] && !String(auditActorChecks[0].checkClause || '').includes('license')) {
    await db.query('ALTER TABLE admin_role_audits DROP CHECK chk_admin_role_audit_actor');
    await db.query("ALTER TABLE admin_role_audits ADD CONSTRAINT chk_admin_role_audit_actor CHECK (actor_type IN ('shop_user','cli','license'))");
  }
  const auditRoleChecks = await db.query("SELECT check_clause AS checkClause FROM information_schema.check_constraints WHERE constraint_schema=DATABASE() AND constraint_name='chk_admin_role_audit_change'");
  if (auditRoleChecks[0] && !String(auditRoleChecks[0].checkClause || '').includes('super_admin')) {
    await db.query('ALTER TABLE admin_role_audits DROP CHECK chk_admin_role_audit_change');
    await db.query("ALTER TABLE admin_role_audits ADD CONSTRAINT chk_admin_role_audit_change CHECK (old_role IN ('user','admin','super_admin') AND new_role IN ('user','admin','super_admin') AND old_role<>new_role)");
  }
  const legacyVehicleTables = new Set(vehicleTableMigrations.map(([legacyTable]) => legacyTable));
  for (const [table, column, sql] of columnMigrations) {
    if (vehicleSchemaAlreadyChinese && legacyVehicleTables.has(table)) continue;
    if (!(await hasColumn(db, table, column))) await db.query(sql);
  }
  if (!(await columnIsNullable(db, 'admin_role_audits', 'target_steam_id'))) await db.query('ALTER TABLE admin_role_audits MODIFY COLUMN target_steam_id VARCHAR(17) NULL');
  if (!vehicleSchemaAlreadyChinese && !(await hasColumn(db, 'vehicle_insurance_strategies', 'deleted_at'))) await db.query('ALTER TABLE vehicle_insurance_strategies ADD COLUMN deleted_at DATETIME(3) NULL AFTER enabled');
  if (vehicleSchemaAlreadyChinese && !(await hasColumn(db, '载具保险销售策略', '删除时间'))) await db.query('ALTER TABLE `载具保险销售策略` ADD COLUMN `删除时间` DATETIME(3) NULL AFTER `是否启用`');
  if (!vehicleSchemaAlreadyChinese && !(await hasColumn(db, 'vehicle_insurance_purchases', 'strategy_name_snapshot'))) await db.query('ALTER TABLE vehicle_insurance_purchases ADD COLUMN strategy_name_snapshot VARCHAR(100) NULL AFTER strategy_id, ADD COLUMN product_id_snapshot BIGINT UNSIGNED NULL AFTER strategy_name_snapshot, ADD COLUMN vehicle_type_snapshot VARCHAR(80) NULL AFTER product_id_snapshot, ADD COLUMN vehicle_code_snapshot VARCHAR(80) NULL AFTER vehicle_type_snapshot, ADD COLUMN total_claim_limit_snapshot INT UNSIGNED NULL AFTER vehicle_code_snapshot, ADD COLUMN daily_claim_limit_snapshot INT UNSIGNED NULL AFTER total_claim_limit_snapshot, ADD COLUMN purchase_condition_snapshot VARCHAR(500) NULL AFTER daily_claim_limit_snapshot, ADD COLUMN duration_days_snapshot INT UNSIGNED NULL AFTER purchase_condition_snapshot');
  if (!vehicleSchemaAlreadyChinese) {
    await db.query('UPDATE vehicle_insurance_purchases p JOIN vehicle_insurance_strategies s ON s.id=p.strategy_id SET p.strategy_name_snapshot=COALESCE(p.strategy_name_snapshot,s.name),p.product_id_snapshot=COALESCE(p.product_id_snapshot,s.product_id),p.vehicle_type_snapshot=COALESCE(p.vehicle_type_snapshot,s.vehicle_type),p.vehicle_code_snapshot=COALESCE(p.vehicle_code_snapshot,s.vehicle_code),p.total_claim_limit_snapshot=COALESCE(p.total_claim_limit_snapshot,s.total_claim_limit),p.daily_claim_limit_snapshot=COALESCE(p.daily_claim_limit_snapshot,s.daily_claim_limit),p.purchase_condition_snapshot=COALESCE(p.purchase_condition_snapshot,s.purchase_condition),p.duration_days_snapshot=COALESCE(p.duration_days_snapshot,s.duration_days) WHERE p.strategy_name_snapshot IS NULL OR p.vehicle_type_snapshot IS NULL OR p.vehicle_code_snapshot IS NULL');
    await db.query("UPDATE vehicle_insurance_purchases SET strategy_name_snapshot=COALESCE(strategy_name_snapshot,'历史保险'),vehicle_type_snapshot=COALESCE(vehicle_type_snapshot,''),vehicle_code_snapshot=COALESCE(vehicle_code_snapshot,''),total_claim_limit_snapshot=COALESCE(total_claim_limit_snapshot,1),daily_claim_limit_snapshot=COALESCE(daily_claim_limit_snapshot,1),purchase_condition_snapshot=COALESCE(purchase_condition_snapshot,''),duration_days_snapshot=COALESCE(duration_days_snapshot,GREATEST(1,DATEDIFF(expires_at,starts_at))) WHERE strategy_name_snapshot IS NULL OR vehicle_type_snapshot IS NULL OR vehicle_code_snapshot IS NULL OR total_claim_limit_snapshot IS NULL OR daily_claim_limit_snapshot IS NULL OR purchase_condition_snapshot IS NULL OR duration_days_snapshot IS NULL");
  }
  if (!vehicleSchemaAlreadyChinese && !(await hasColumn(db, 'vehicle_insurance_purchases', 'cancelled_at'))) await db.query('ALTER TABLE vehicle_insurance_purchases ADD COLUMN cancelled_at DATETIME(3) NULL AFTER expires_at');
  if (vehicleSchemaAlreadyChinese && !(await hasColumn(db, '载具保险购买记录', '策略名称快照'))) await db.query('ALTER TABLE `载具保险购买记录` ADD COLUMN `策略名称快照` VARCHAR(100) NULL AFTER `策略编号`, ADD COLUMN `载具商品编号快照` BIGINT UNSIGNED NULL AFTER `策略名称快照`, ADD COLUMN `载具类型快照` VARCHAR(80) NULL AFTER `载具商品编号快照`, ADD COLUMN `载具代码快照` VARCHAR(80) NULL AFTER `载具类型快照`, ADD COLUMN `总赔付次数上限快照` INT UNSIGNED NULL AFTER `载具代码快照`, ADD COLUMN `每日赔付次数上限快照` INT UNSIGNED NULL AFTER `总赔付次数上限快照`, ADD COLUMN `购买条件快照` VARCHAR(500) NULL AFTER `每日赔付次数上限快照`, ADD COLUMN `有效天数快照` INT UNSIGNED NULL AFTER `购买条件快照`');
  if (vehicleSchemaAlreadyChinese) {
    await db.query('UPDATE `载具保险购买记录` p JOIN `载具保险销售策略` s ON s.`策略编号`=p.`策略编号` SET p.`策略名称快照`=COALESCE(p.`策略名称快照`,s.`策略名称`),p.`载具商品编号快照`=COALESCE(p.`载具商品编号快照`,s.`载具商品编号`),p.`载具类型快照`=COALESCE(p.`载具类型快照`,s.`载具类型`),p.`载具代码快照`=COALESCE(p.`载具代码快照`,s.`载具代码`),p.`总赔付次数上限快照`=COALESCE(p.`总赔付次数上限快照`,s.`总赔付次数上限`),p.`每日赔付次数上限快照`=COALESCE(p.`每日赔付次数上限快照`,s.`每日赔付次数上限`),p.`购买条件快照`=COALESCE(p.`购买条件快照`,s.`购买条件`),p.`有效天数快照`=COALESCE(p.`有效天数快照`,s.`有效天数`) WHERE p.`策略名称快照` IS NULL OR p.`载具类型快照` IS NULL OR p.`载具代码快照` IS NULL');
    await db.query("UPDATE `载具保险购买记录` SET `策略名称快照`=COALESCE(`策略名称快照`,'历史保险'),`载具类型快照`=COALESCE(`载具类型快照`,''),`载具代码快照`=COALESCE(`载具代码快照`,''),`总赔付次数上限快照`=COALESCE(`总赔付次数上限快照`,1),`每日赔付次数上限快照`=COALESCE(`每日赔付次数上限快照`,1),`购买条件快照`=COALESCE(`购买条件快照`,''),`有效天数快照`=COALESCE(`有效天数快照`,GREATEST(1,DATEDIFF(`到期时间`,`生效时间`))) WHERE `策略名称快照` IS NULL OR `载具类型快照` IS NULL OR `载具代码快照` IS NULL OR `总赔付次数上限快照` IS NULL OR `每日赔付次数上限快照` IS NULL OR `购买条件快照` IS NULL OR `有效天数快照` IS NULL");
  }
  if (vehicleSchemaAlreadyChinese && !(await hasColumn(db, '载具保险购买记录', '删除时间'))) await db.query('ALTER TABLE `载具保险购买记录` ADD COLUMN `删除时间` DATETIME(3) NULL AFTER `到期时间`');
  if (!vehicleSchemaAlreadyChinese && !(await columnIsNullable(db, 'vehicle_insurance_purchases', 'vehicle_id'))) await db.query('ALTER TABLE vehicle_insurance_purchases MODIFY COLUMN vehicle_id BIGINT UNSIGNED NULL');
  if (vehicleSchemaAlreadyChinese && !(await columnIsNullable(db, '载具保险购买记录', '载具档案编号'))) await db.query('ALTER TABLE `载具保险购买记录` MODIFY COLUMN `载具档案编号` BIGINT UNSIGNED NULL');
  await db.query('UPDATE lottery_pool_versions SET daily_free_count=0 WHERE daily_free_count<>0');
  await db.query('ALTER TABLE lottery_prizes MODIFY COLUMN luck_required BIGINT UNSIGNED NOT NULL DEFAULT 0');
  await db.query('ALTER TABLE lottery_player_states MODIFY COLUMN pity_count BIGINT UNSIGNED NOT NULL DEFAULT 0');
  await db.query("UPDATE reward_rules SET reward_type=CASE WHEN product_id IS NOT NULL THEN 'product' WHEN gift_id IS NOT NULL THEN 'gift' ELSE 'shop_coin' END");
  const rewardTypeChecks = await db.query("SELECT check_clause AS checkClause FROM information_schema.check_constraints WHERE constraint_schema=DATABASE() AND constraint_name='chk_reward_rule_reward_type'");
  if (rewardTypeChecks[0] && !String(rewardTypeChecks[0].checkClause || '').includes('combined')) await db.query('ALTER TABLE reward_rules DROP CHECK chk_reward_rule_reward_type');
  if (!(await hasConstraint(db, 'reward_rules', 'chk_reward_rule_reward_type'))) await db.query("ALTER TABLE reward_rules ADD CONSTRAINT chk_reward_rule_reward_type CHECK (reward_type IN ('gift','product','shop_coin','combined'))");
  if (!(await hasConstraint(db, 'reward_rules', 'fk_reward_rule_product'))) await db.query('ALTER TABLE reward_rules ADD CONSTRAINT fk_reward_rule_product FOREIGN KEY (product_id) REFERENCES products(id)');
  if (!(await hasConstraint(db, 'reward_claims', 'fk_reward_claim_product'))) await db.query('ALTER TABLE reward_claims ADD CONSTRAINT fk_reward_claim_product FOREIGN KEY (product_id) REFERENCES products(id)');
  try {
    await migrateSchemaComments(db);
    await migrateTableCatalog(db);
  } catch {
    // Metadata is auxiliary; a metadata failure must not prevent business startup.
  }
  await db.query("UPDATE admin_role_audits SET actor_label=actor_username_snapshot WHERE actor_type='shop_user' AND (actor_label='legacy-shop-user' OR actor_label='')");
  if (!(await hasConstraint(db, 'admin_role_audits', 'chk_admin_role_audit_actor'))) await db.query("ALTER TABLE admin_role_audits ADD CONSTRAINT chk_admin_role_audit_actor CHECK (actor_type IN ('shop_user','cli','license'))");
  for (const reference of [
    ['reward_rules', 'created_by_user_id', 'fk_reward_rule_creator'],
    ['activities', 'created_by_user_id', 'fk_activity_creator'],
    ['lottery_pools', 'created_by_user_id', 'fk_lottery_pool_creator'],
    ['lottery_pool_versions', 'created_by_user_id', 'fk_lottery_version_creator'],
    ['stocks', 'created_by_user_id', 'fk_stock_creator'],
    ['stock_market_announcements', 'created_by_user_id', 'fk_stock_announcement_creator'],
    ['stock_market_announcements', 'updated_by_user_id', 'fk_stock_announcement_updater']
  ]) await migrateNullableUserReference(db, ...reference);
  await db.query("UPDATE scum_log_files SET source_type='kill' WHERE source_type IS NULL OR source_type=''");
  const chatChannelCheck = await db.query("SELECT check_clause AS checkClause FROM information_schema.check_constraints WHERE constraint_schema=DATABASE() AND constraint_name='chk_scum_chat_channel'");
  if (!String(chatChannelCheck[0]?.checkClause || '').includes('Admin')) {
    if (chatChannelCheck[0]) await db.query('ALTER TABLE scum_chat_events DROP CHECK chk_scum_chat_channel');
    await db.query("ALTER TABLE scum_chat_events ADD CONSTRAINT chk_scum_chat_channel CHECK (channel IN ('Global','Local','Squad','Admin'))");
  }
  if (await hasColumn(db, 'scum_chat_events', 'event_hash')) {
    const canonicalChatHash = "SHA2(CONCAT(DATE_FORMAT(event_time,'%Y-%m-%dT%H:%i:%s.'),LEFT(DATE_FORMAT(event_time,'%f'),3),'Z|',steam_id,'|',channel,'|',character_number,'|',COALESCE(command_type,'message'),'|',COALESCE(command_target,message_text)),256)";
    await db.query(`UPDATE scum_chat_events SET event_hash=SHA2(CONCAT(${canonicalChatHash},'|legacy|',id),256) WHERE event_hash IS NULL OR event_hash=''`);
    await db.query(`UPDATE scum_chat_events e JOIN (SELECT COALESCE(MIN(CASE WHEN a.event_id IS NOT NULL THEN c.id END),MIN(c.id)) AS keeper_id FROM scum_chat_events c LEFT JOIN scum_chat_claim_audits a ON a.event_id=c.id GROUP BY ${canonicalChatHash.replaceAll('event_time', 'c.event_time').replaceAll('steam_id', 'c.steam_id').replaceAll('channel', 'c.channel').replaceAll('character_number', 'c.character_number').replaceAll('command_type', 'c.command_type').replaceAll('command_target', 'c.command_target').replaceAll('message_text', 'c.message_text')}) keepers ON keepers.keeper_id=e.id SET e.event_hash=${canonicalChatHash}`);
    await db.query('ALTER TABLE scum_chat_events MODIFY COLUMN event_hash CHAR(64) NOT NULL');
    if (!(await hasIndex(db, 'scum_chat_events', 'uk_scum_chat_event_hash'))) await db.query('ALTER TABLE scum_chat_events ADD UNIQUE KEY uk_scum_chat_event_hash (event_hash)');
  }
  if (!(await hasIndex(db, 'scum_log_files', 'idx_scum_log_source_path'))) await db.query('ALTER TABLE scum_log_files ADD INDEX idx_scum_log_source_path (source_type,path_hash,id)');
  await db.query('ALTER TABLE server_monitor_samples MODIFY COLUMN rcon_ok TINYINT(1) NULL');
  if (await hasColumn(db, 'server_monitor_samples', 'fulfillment_worker_running')) {
    await db.query('UPDATE server_monitor_samples SET worker_running=fulfillment_worker_running WHERE worker_running=0 AND fulfillment_worker_running<>0');
    await db.query('ALTER TABLE server_monitor_samples DROP COLUMN fulfillment_worker_running');
  }
  if (await hasColumn(db, 'server_monitor_samples', 'gsm3_ok')) await db.query('ALTER TABLE server_monitor_samples DROP COLUMN gsm3_ok');
  await migrateLegacyGiftSchema(db);
  await db.query('ALTER TABLE gift_claims MODIFY COLUMN steam_id VARCHAR(17) NOT NULL');
  await db.query('ALTER TABLE gift_claims MODIFY COLUMN request_key VARCHAR(100) NOT NULL');
  await db.query('ALTER TABLE gift_claims MODIFY COLUMN claim_day DATE NOT NULL');
  await db.query('ALTER TABLE order_items MODIFY COLUMN product_id BIGINT UNSIGNED NULL');
  await db.query('ALTER TABLE order_items MODIFY COLUMN item_id VARCHAR(80) NULL');
  await db.query('ALTER TABLE order_items MODIFY COLUMN grant_amount INT UNSIGNED NULL');
  await db.query('ALTER TABLE fulfillment_tasks MODIFY COLUMN order_item_id BIGINT UNSIGNED NULL');
  await db.query('ALTER TABLE fulfillment_tasks MODIFY COLUMN item_id VARCHAR(80) NULL');
  await db.query('ALTER TABLE fulfillment_tasks MODIFY COLUMN amount INT UNSIGNED NULL');
  if (!(await hasIndex(db, 'orders', 'uk_orders_gift_claim'))) await db.query('ALTER TABLE orders ADD UNIQUE KEY uk_orders_gift_claim (gift_claim_id)');
  if (!(await hasIndex(db, 'orders', 'uk_orders_redeem_claim'))) await db.query('ALTER TABLE orders ADD UNIQUE KEY uk_orders_redeem_claim (redeem_claim_id)');
  if (!(await hasIndex(db, 'orders', 'idx_orders_redeem_code'))) await db.query('ALTER TABLE orders ADD INDEX idx_orders_redeem_code (redeem_code_id)');
  if (!(await hasForeignKey(db, 'orders', 'fk_order_redeem_code'))) await db.query('ALTER TABLE orders ADD CONSTRAINT fk_order_redeem_code FOREIGN KEY (redeem_code_id) REFERENCES redeem_codes(id)');
  if (!(await hasIndex(db, 'gift_claims', 'uk_gift_claim_request'))) await db.query('ALTER TABLE gift_claims ADD UNIQUE KEY uk_gift_claim_request (request_key)');
  if (!(await hasIndex(db, 'gift_claims', 'uk_gift_claim_order'))) await db.query('ALTER TABLE gift_claims ADD UNIQUE KEY uk_gift_claim_order (order_id)');
  if (!(await hasIndex(db, 'coin_ledger', 'uk_ledger_reference'))) await db.query('ALTER TABLE coin_ledger ADD UNIQUE KEY uk_ledger_reference (reference_type,reference_id)');
  if (!(await hasIndex(db, 'fulfillment_tasks', 'uk_task_request_key'))) await db.query('ALTER TABLE fulfillment_tasks ADD UNIQUE KEY uk_task_request_key (request_key)');
  await db.query('ALTER TABLE maintenance_windows MODIFY COLUMN instance_id VARCHAR(128) NULL');
  await db.query('ALTER TABLE maintenance_windows MODIFY COLUMN reason VARCHAR(500) NULL');
  if (await hasIndex(db, 'maintenance_windows', 'uk_maintenance_active_slot')) await db.query('ALTER TABLE maintenance_windows DROP INDEX uk_maintenance_active_slot');
  if (await hasColumn(db, 'maintenance_windows', 'active_slot')) await db.query('ALTER TABLE maintenance_windows DROP COLUMN active_slot');
  if (!(await hasIndex(db, 'maintenance_windows', 'idx_maintenance_paused_state'))) await db.query('ALTER TABLE maintenance_windows ADD INDEX idx_maintenance_paused_state (fulfillment_paused,state)');
  await db.query('ALTER TABLE maintenance_audit_logs MODIFY COLUMN action VARCHAR(50) NOT NULL');
  if (!(await hasIndex(db, 'reward_claims', 'idx_reward_claims_request'))) await db.query('ALTER TABLE reward_claims ADD INDEX idx_reward_claims_request (request_id)');
  if (await hasIndex(db, 'reward_claims', 'uk_reward_claim_request')) await db.query('ALTER TABLE reward_claims DROP INDEX uk_reward_claim_request');
  await db.query('ALTER TABLE reward_rules MODIFY COLUMN gift_id BIGINT UNSIGNED NULL');
  await db.query('ALTER TABLE reward_claims MODIFY COLUMN gift_id BIGINT UNSIGNED NULL');
  const rewardEvidence = await db.query("SELECT COUNT(*) AS count FROM information_schema.table_constraints WHERE constraint_schema=DATABASE() AND table_name='reward_claims' AND constraint_name='chk_reward_claim_evidence' AND constraint_type='CHECK'");
  if (Number(rewardEvidence[0]?.count) > 0) await db.query('ALTER TABLE reward_claims DROP CHECK chk_reward_claim_evidence');
  const rewardSampleFk = await db.query("SELECT delete_rule AS deleteRule FROM information_schema.referential_constraints WHERE constraint_schema=DATABASE() AND table_name='reward_claims' AND constraint_name='fk_reward_claim_sample'");
  if (rewardSampleFk[0] && rewardSampleFk[0].deleteRule !== 'SET NULL') await db.query('ALTER TABLE reward_claims DROP FOREIGN KEY fk_reward_claim_sample');
  if (!(await hasForeignKey(db, 'reward_claims', 'fk_reward_claim_sample'))) await db.query('ALTER TABLE reward_claims ADD CONSTRAINT fk_reward_claim_sample FOREIGN KEY (sample_id) REFERENCES server_monitor_samples(id) ON DELETE SET NULL');
  if (!(await hasForeignKey(db, 'lottery_pools', 'fk_lottery_pool_current_version'))) await db.query('ALTER TABLE lottery_pools ADD CONSTRAINT fk_lottery_pool_current_version FOREIGN KEY (current_version_id) REFERENCES lottery_pool_versions(id)');
  if (!(await hasIndex(db, 'activities', 'uk_activities_lottery_pool'))) await db.query('ALTER TABLE activities ADD UNIQUE KEY uk_activities_lottery_pool (lottery_pool_id)');
  if (!(await hasForeignKey(db, 'activities', 'fk_activity_lottery_pool'))) await db.query('ALTER TABLE activities ADD CONSTRAINT fk_activity_lottery_pool FOREIGN KEY (lottery_pool_id) REFERENCES lottery_pools(id) ON DELETE SET NULL');
  const lotteryDrawCountClause = (await checkConstraintClause(db, 'chk_lottery_draw_count')).toLowerCase().replace(/[^a-z0-9,]/g, '');
  if (!lotteryDrawCountClause.includes('drawcountin1,10')) {
    if (await hasConstraint(db, 'lottery_batches', 'chk_lottery_draw_count')) await db.query('ALTER TABLE lottery_batches DROP CHECK chk_lottery_draw_count');
    await db.query('ALTER TABLE lottery_batches ADD CONSTRAINT chk_lottery_draw_count CHECK (draw_count IN (1,10))');
  }
  if (await hasColumn(db, 'lottery_prizes', 'reward_name_snapshot')) {
    await db.query("UPDATE lottery_prizes SET reward_type='gift' WHERE reward_type IS NULL OR reward_type=''");
    await db.query("UPDATE lottery_prizes SET reward_name_snapshot=COALESCE(NULLIF(reward_name_snapshot,''),NULLIF(gift_name_snapshot,''),CONCAT('礼包 #',gift_id),'历史礼包') WHERE reward_name_snapshot IS NULL OR reward_name_snapshot=''");
    await db.query('ALTER TABLE lottery_prizes MODIFY COLUMN gift_id BIGINT UNSIGNED NULL');
    await db.query('ALTER TABLE lottery_prizes MODIFY COLUMN reward_name_snapshot VARCHAR(100) NOT NULL');
    await db.query('ALTER TABLE lottery_prizes MODIFY COLUMN gift_name_snapshot VARCHAR(100) NULL');
    await db.query('ALTER TABLE lottery_prizes MODIFY COLUMN action_snapshot_json JSON NOT NULL');
    if (!(await hasForeignKey(db, 'lottery_prizes', 'fk_lottery_prize_product'))) await db.query('ALTER TABLE lottery_prizes ADD CONSTRAINT fk_lottery_prize_product FOREIGN KEY (product_id) REFERENCES products(id)');
    if (!(await hasConstraint(db, 'lottery_prizes', 'chk_lottery_prize_reward_type'))) await db.query("ALTER TABLE lottery_prizes ADD CONSTRAINT chk_lottery_prize_reward_type CHECK (reward_type IN ('gift','product','shop_coin','custom'))");
    if (!(await hasConstraint(db, 'lottery_prizes', 'chk_lottery_prize_reference'))) await db.query("ALTER TABLE lottery_prizes ADD CONSTRAINT chk_lottery_prize_reference CHECK ((reward_type='gift' AND gift_id IS NOT NULL AND product_id IS NULL) OR (reward_type='product' AND gift_id IS NULL AND product_id IS NOT NULL) OR (reward_type IN ('shop_coin','custom') AND gift_id IS NULL AND product_id IS NULL))");
  }
  if (await hasColumn(db, 'lottery_draws', 'reward_name_snapshot')) {
    await db.query("UPDATE lottery_draws SET reward_type='gift' WHERE reward_type IS NULL OR reward_type=''");
    await db.query("UPDATE lottery_draws d JOIN lottery_prizes p ON p.id=d.prize_id SET d.reward_name_snapshot=COALESCE(NULLIF(d.reward_name_snapshot,''),NULLIF(p.reward_name_snapshot,''),NULLIF(p.gift_name_snapshot,''),CONCAT('礼包 #',d.gift_id),'历史礼包') WHERE d.reward_name_snapshot IS NULL OR d.reward_name_snapshot=''");
    await db.query('ALTER TABLE lottery_draws MODIFY COLUMN gift_id BIGINT UNSIGNED NULL');
    await db.query('ALTER TABLE lottery_draws MODIFY COLUMN reward_name_snapshot VARCHAR(100) NOT NULL');
  }
  await db.query("UPDATE stock_price_history SET source='automatic' WHERE source IS NULL OR source=''");
  await db.query('UPDATE stocks SET last_period_key=NULL WHERE last_period_key IS NOT NULL AND last_period_key>FLOOR(UNIX_TIMESTAMP()/period_seconds)');
  await db.query('ALTER TABLE stock_price_history MODIFY COLUMN period_key BIGINT NULL');
  const vehicleIndexTable = vehicleSchemaAlreadyChinese ? '载具档案' : 'vehicles';
  if (!(await hasIndex(db, vehicleIndexTable, 'uk_vehicles_source_vehicle'))) await db.query(vehicleSchemaAlreadyChinese ? 'ALTER TABLE `载具档案` ADD UNIQUE KEY uk_vehicles_source_vehicle (`来源类型`,`来源载具编号`)' : 'ALTER TABLE vehicles ADD UNIQUE KEY uk_vehicles_source_vehicle (source_type,source_vehicle_id)');
  if (!(await hasIndex(db, vehicleIndexTable, 'idx_vehicles_source_sync'))) await db.query(vehicleSchemaAlreadyChinese ? 'ALTER TABLE `载具档案` ADD INDEX idx_vehicles_source_sync (`来源类型`,`来源同步状态`,`来源同步时间`)' : 'ALTER TABLE vehicles ADD INDEX idx_vehicles_source_sync (source_type,source_sync_state,source_synchronized_at)');
  if (!(await hasIndex(db, 'stock_price_history', 'uk_stock_price_request'))) await db.query('ALTER TABLE stock_price_history ADD UNIQUE KEY uk_stock_price_request (request_key)');
  if (!(await hasIndex(db, 'coin_ledger', 'idx_ledger_order_purchase_time'))) await db.query('ALTER TABLE coin_ledger ADD INDEX idx_ledger_order_purchase_time (type,reference_type,created_at,reference_id)');
  if (!(await hasIndex(db, 'orders', 'idx_orders_source_id'))) await db.query('ALTER TABLE orders ADD INDEX idx_orders_source_id (source,id)');
  if (!(await hasIndex(db, 'order_items', 'idx_order_items_product_category'))) await db.query('ALTER TABLE order_items ADD INDEX idx_order_items_product_category (product_id,sku,parent_category,category_name,order_id)');
  if (await hasColumn(db, 'player_admin_actions', 'expires_at')) await db.query('UPDATE player_admin_actions SET temporary_ban_expires_at=expires_at WHERE temporary_ban_expires_at IS NULL AND expires_at IS NOT NULL');
  await db.query('ALTER TABLE player_admin_actions MODIFY COLUMN admin_user_id BIGINT UNSIGNED NULL');
  await db.query('ALTER TABLE player_admin_actions MODIFY COLUMN delivery_token CHAR(36) NULL');
  if (!(await hasIndex(db, 'player_admin_actions', 'uk_player_admin_parent_action'))) await db.query('ALTER TABLE player_admin_actions ADD UNIQUE KEY uk_player_admin_parent_action (parent_action_id,action_type)');
  if (!(await hasIndex(db, 'player_admin_action_attempts', 'uk_player_admin_attempt'))) await db.query('ALTER TABLE player_admin_action_attempts ADD UNIQUE KEY uk_player_admin_attempt (action_id,attempt_no)');
  await migrateVehicleTablesToChinese(db);
  await ensureVehicleLimitSchema(db);
  await migrateTableCatalog(db);
  await db.query('DROP VIEW IF EXISTS `维护审计记录`');
  await db.query('DROP VIEW IF EXISTS `维护公告执行`');
  for (const [name, select] of views) await db.query(`CREATE OR REPLACE ALGORITHM=TEMPTABLE VIEW \`${name}\` AS ${select}`);
}

async function ensureVehicleLimitSchema(db) {
  await db.query(`CREATE TABLE IF NOT EXISTS \`载具数量治理配置\` (\`配置编号\` TINYINT UNSIGNED PRIMARY KEY,\`是否启用\` TINYINT(1) NOT NULL DEFAULT 0,\`每玩家允许数量\` INT UNSIGNED NOT NULL DEFAULT 3,\`宽限分钟数\` INT UNSIGNED NOT NULL DEFAULT 1440,\`提醒间隔分钟数\` INT UNSIGNED NOT NULL DEFAULT 60,\`更新管理员名称\` VARCHAR(100) NULL,\`更新时间\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),CONSTRAINT chk_vehicle_limit_singleton CHECK (\`配置编号\`=1),CONSTRAINT chk_vehicle_limit_enabled CHECK (\`是否启用\` IN (0,1)),CONSTRAINT chk_vehicle_limit_count CHECK (\`每玩家允许数量\` BETWEEN 1 AND 100),CONSTRAINT chk_vehicle_limit_grace CHECK (\`宽限分钟数\` BETWEEN 5 AND 43200),CONSTRAINT chk_vehicle_limit_warning CHECK (\`提醒间隔分钟数\` BETWEEN 5 AND 1440)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await db.query("INSERT IGNORE INTO `载具数量治理配置` (`配置编号`) VALUES (1)");
  await db.query(`CREATE TABLE IF NOT EXISTS \`载具数量治理状态\` (\`玩家SteamID\` VARCHAR(17) PRIMARY KEY,\`当前上锁数量\` INT UNSIGNED NOT NULL DEFAULT 0,\`允许数量快照\` INT UNSIGNED NOT NULL,\`治理状态\` VARCHAR(16) NOT NULL DEFAULT 'compliant',\`首次超限时间\` DATETIME(3) NULL,\`移除截止时间\` DATETIME(3) NULL,\`最近提醒时间\` DATETIME(3) NULL,\`更新时间\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),INDEX idx_vehicle_limit_state (\`治理状态\`,\`移除截止时间\`),CONSTRAINT chk_vehicle_limit_state CHECK (\`治理状态\` IN ('compliant','threshold','exceeded','review'))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await db.query(`CREATE TABLE IF NOT EXISTS \`载具数量治理任务\` (\`任务编号\` CHAR(36) PRIMARY KEY,\`玩家SteamID\` VARCHAR(17) NOT NULL,\`来源载具编号\` BIGINT UNSIGNED NOT NULL,\`载具身份指纹\` VARCHAR(500) NOT NULL,\`载具显示名称\` VARCHAR(120) NOT NULL,\`任务状态\` VARCHAR(16) NOT NULL DEFAULT 'pending',\`首次超限时间\` DATETIME(3) NOT NULL,\`移除截止时间\` DATETIME(3) NOT NULL,\`执行次数\` INT UNSIGNED NOT NULL DEFAULT 0,\`最近执行时间\` DATETIME(3) NULL,\`最后错误\` VARCHAR(500) NULL,\`完成时间\` DATETIME(3) NULL,\`创建时间\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),\`更新时间\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),UNIQUE KEY uk_vehicle_limit_entity (\`来源载具编号\`),INDEX idx_vehicle_limit_due (\`任务状态\`,\`移除截止时间\`),INDEX idx_vehicle_limit_owner (\`玩家SteamID\`,\`任务状态\`),CONSTRAINT chk_vehicle_limit_task_state CHECK (\`任务状态\` IN ('pending','removing','removed','cancelled','review'))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  const taskStateChecks = await db.query("SELECT cc.CHECK_CLAUSE AS clause FROM information_schema.table_constraints tc JOIN information_schema.check_constraints cc ON cc.constraint_schema=tc.constraint_schema AND cc.constraint_name=tc.constraint_name WHERE tc.table_schema=DATABASE() AND tc.table_name='载具数量治理任务' AND tc.constraint_name='chk_vehicle_limit_task_state'");
  if (taskStateChecks[0] && !String(taskStateChecks[0].clause || '').includes('removing')) await db.query('ALTER TABLE `载具数量治理任务` DROP CHECK chk_vehicle_limit_task_state');
  if (!await hasConstraint(db, '载具数量治理任务', 'chk_vehicle_limit_task_state')) await db.query("ALTER TABLE `载具数量治理任务` ADD CONSTRAINT chk_vehicle_limit_task_state CHECK (`任务状态` IN ('pending','removing','removed','cancelled','review'))");
  if (!await hasConstraint(db, '载具数量治理配置', 'chk_vehicle_limit_enabled')) {
    await db.query('UPDATE `载具数量治理配置` SET `是否启用`=IF(`是否启用`=0,0,1)');
    await db.query('ALTER TABLE `载具数量治理配置` ADD CONSTRAINT chk_vehicle_limit_enabled CHECK (`是否启用` IN (0,1))');
  }
}

async function ensureSchemaWithLock(db) {
  const lockRows = await db.query('SELECT GET_LOCK(?, 120) AS acquired', [SCHEMA_LOCK_NAME]);
  if (Number(lockRows?.[0]?.acquired) !== 1) throw new Error('数据库结构升级锁获取超时，请确认没有其他商城进程正在升级');
  try {
    await ensureSchemaOnConnection(db);
  } finally {
    await db.query('SELECT RELEASE_LOCK(?) AS released', [SCHEMA_LOCK_NAME]);
  }
}

export async function ensureSchema(db) {
  if (typeof db.withConnection === 'function') return db.withConnection(session => ensureSchemaWithLock(session));
  return ensureSchemaWithLock(db);
}

export { statements, views, schemaComments, tableComments, columnComments };


