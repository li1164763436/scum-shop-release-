import fs from 'node:fs';
import path from 'node:path';
import { setDefaultResultOrder } from 'node:dns';
import { fileURLToPath } from 'node:url';
import { ConfigStore } from './services/config-store.js';
import { createLogger } from './services/logger.js';
import { LicenseStore } from './services/license-store.js';
import { assertStartupAllowed } from './services/license-client.js';
import { createLicenseGuide } from './services/license-guide.js';
import { createDatabase } from './services/database.js';
import { ensureSchema } from './services/schema.js';
import { assertInitialSuperAdminBinding, createInitialSuperAdmin, hasInitialSuperAdmin } from './services/initial-super-admin-service.js';
import { createRuntimeHost } from './services/runtime-host.js';
import { DatabaseBackups } from './services/database-backups.js';
import { enforceManualServiceStartup } from './services/windows-service-startup.js';

setDefaultResultOrder('ipv4first');

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const host = process.env.HOST || '0.0.0.0';
const packageIdentity = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8').replace(/^\uFEFF/, ''));
const appVersion = packageIdentity.version;
const releaseRevision = Number.isSafeInteger(packageIdentity.releaseRevision) && packageIdentity.releaseRevision >= 0 ? packageIdentity.releaseRevision : 0;
const store = new ConfigStore(path.join(root, 'data', 'config.json'));
const port = (await store.read()).website.port;
const logger = createLogger(path.join(root, 'logs'));
enforceManualServiceStartup({ logger });
logger.info('SCUM RCON 控制台正在启动', { component: 'application', host, port });
const licenseStore = new LicenseStore(process.env.LICENSE_FILE || path.join(root, 'runtime', 'secrets', 'license.json'));

const runtime = createRuntimeHost({ host, port, root, appVersion, releaseRevision });
const backups = new DatabaseBackups({ root, store, logger });
await runtime.listen();
backups.start();

let business = null;
let starting = false;
let guide = null;
let closing = false;
let retryTimer = null;
let nextRetryAt = 0;
const TRANSIENT_STARTUP_CODES = new Set(['ECONNREFUSED', 'ECONNRESET', 'ETIMEDOUT', 'PROTOCOL_CONNECTION_LOST']);
async function withInitializedDatabase(handler) {
  const config = await store.read();
  const db = await createDatabase(config.mysql, null, { maxAttempts: 40, delayMs: 500 });
  try { await ensureSchema(db); return await handler(db); }
  finally { await db.close(); }
}
const initialAdmin = {
  required: async () => withInitializedDatabase(async db => !(await hasInitialSuperAdmin(db))),
  create: async ({ identity, steamId, password, metadata }) => withInitializedDatabase(db => createInitialSuperAdmin(db, { username: identity.username, steamId, password }, { actorType: 'license', actorLabel: identity.username, metadata, authorization: identity }))
};
async function showLicenseGuide(initialIdentity = null) {
  if (guide) return;
  const pendingGuide = createLicenseGuide({ port: 0, licenseStore, initialIdentity, initialAdmin, onAuthorized: async () => { guide = null; runtime.detachLicense(); await attemptStart(); } });
  guide = pendingGuide;
  try {
    await pendingGuide.listen();
    runtime.attachLicense(pendingGuide.server.address().port);
  } catch (error) {
    if (guide === pendingGuide) guide = null;
    await pendingGuide.close().catch(() => {});
    throw error;
  }
}
async function attemptStart() {
  if (starting || runtime.ready) return;
  starting = true;
  let initializedDb = null;
  try {
    const verified = await assertStartupAllowed({ store: licenseStore });
    const config = await store.read();
    initializedDb = await createDatabase(config.mysql, null, { maxAttempts: 40, delayMs: 500 });
    await ensureSchema(initializedDb);
    if (!(await hasInitialSuperAdmin(initializedDb))) {
      await initializedDb.close();
      initializedDb = null;
      await showLicenseGuide(verified);
      return;
    }
    await assertInitialSuperAdminBinding(initializedDb, verified, { allowLegacy: false });
    if (guide) {
      const completedGuide = guide;
      guide = null;
      runtime.detachLicense();
      await completedGuide.close().catch(() => {});
    }
    const { startApplication } = await import('./business-runtime.js');
    const database = initializedDb;
    business = await startApplication({ root, port, host, appVersion, releaseRevision, store, logger, licenseStore, runtime, onLicenseInvalid: showLicenseGuide, database });
    initializedDb = null;
  }
  catch (error) {
    await initializedDb?.close().catch(() => {});
    runtime.fail(error);
    nextRetryAt = Date.now() + (TRANSIENT_STARTUP_CODES.has(error?.code) ? 1000 : 30000);
    logger.error('商城业务未启动，运行主体保留', { code: error?.code || 'BUSINESS_START_FAILED', error });
    if (String(error?.code || '').startsWith('LICENSE_')) await showLicenseGuide();
  } finally { starting = false; }
}
runtime.retry = attemptStart;
runtime.shutdown = () => { setImmediate(() => { void closeSubject(); }); };
runtime.backups = backups;
await attemptStart();
retryTimer = setInterval(() => { if (!guide && !runtime.ready && !backups.restoring && Date.now() >= nextRetryAt) void attemptStart(); }, 1000);
retryTimer.unref();

async function closeSubject() {
  if (closing) return; closing = true; clearInterval(retryTimer); await backups.stopAndDrain();
  await business?.close(); if (guide) await guide.close(); await runtime.close();
}
process.once('SIGTERM', () => { void closeSubject(); });
process.once('SIGINT', () => { void closeSubject(); });
